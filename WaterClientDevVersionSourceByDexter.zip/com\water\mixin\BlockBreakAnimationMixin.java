package com.water.mixin;

import com.water.module.modules.render.BreakAnimations;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin({WorldRenderer.class})
public final class BlockBreakAnimationMixin {
   @ModifyVariable(
      method = {"setBlockBreakingInfo"},
      at = @At("HEAD"),
      argsOnly = true,
      ordinal = 0
   )
   private int water$animateBreakStage(int progress, int entityId, BlockPos pos) {
      return BreakAnimations.transform(pos, progress);
   }
}

