package com.water.module.modules.misc;

import com.water.module.Category;
import com.water.module.Module;
import com.water.setting.Setting;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import net.minecraft.client.option.SimpleOption;

public final class ChunkToggle extends Module {
   private final Setting<Float> lowChunks = new Setting<>("Low Chunks", 2.0F, 2.0F, 32.0F);
   private final Setting<Float> highChunks = new Setting<>("High Chunks", 8.0F, 2.0F, 32.0F);
   private final Setting<Float> lowTicks = new Setting<>("Low Ticks", 8.0F, 1.0F, 40.0F);
   private final Setting<Float> resetUpY = new Setting<>("Reset Up Y", 4.0F, 1.0F, 32.0F);
   private final Setting<Float> triggerDownY = new Setting<>("Trigger Down Y", 3.0F, 1.0F, 32.0F);
   private int savedDistance = -1;
   private int lowTimer = 0;
   private int lastApplied = -1;
   private double lastY = 0.0;
   private double highestYAfterPulse = 0.0;
   private boolean pulsing = false;
   private boolean waitingForUp = false;
   private boolean armedAfterUp = false;
   private static Field valueField;

   public ChunkToggle() {
      super("Render Method", Category.MISC);
      this.addSetting(this.lowChunks);
      this.addSetting(this.highChunks);
      this.addSetting(this.lowTicks);
      this.addSetting(this.resetUpY);
      this.addSetting(this.triggerDownY);
   }

   @Override
   public void onEnable() {
      if (mc.options != null && mc.player != null) {
         this.savedDistance = mc.options.getClampedViewDistance();
         this.lastApplied = -1;
         this.lastY = mc.player.getY();
         this.highestYAfterPulse = this.lastY;
         this.startPulse();
      }
   }

   @Override
   public void onDisable() {
      if (mc.options != null) {
         if (this.savedDistance >= 2) {
            this.setViewDistance(this.savedDistance);
         }

         this.savedDistance = -1;
         this.lowTimer = 0;
         this.lastApplied = -1;
         this.pulsing = false;
         this.waitingForUp = false;
         this.armedAfterUp = false;
      }
   }

   @Override
   public void onTick() {
      if (mc.options != null && mc.world != null && mc.player != null) {
         double y = mc.player.getY();
         if (this.pulsing) {
            this.lowTimer--;
            if (this.lowTimer <= 0) {
               this.applyHigh();
               this.pulsing = false;
               this.waitingForUp = true;
               this.armedAfterUp = false;
               this.highestYAfterPulse = y;
            } else {
               this.applyLow();
            }

            this.lastY = y;
         } else {
            if (this.waitingForUp) {
               if (y > this.highestYAfterPulse) {
                  this.highestYAfterPulse = y;
               }

               if (y >= this.lastY + this.resetUpY.getValue().floatValue()) {
                  this.armedAfterUp = true;
               }

               if (this.armedAfterUp && this.highestYAfterPulse - y >= this.triggerDownY.getValue().floatValue()) {
                  this.startPulse();
               }
            }

            this.lastY = y;
         }
      }
   }

   private void startPulse() {
      this.pulsing = true;
      this.waitingForUp = false;
      this.armedAfterUp = false;
      this.lowTimer = Math.max(1, this.lowTicks.getValue().intValue());
      this.applyLow();
   }

   private void applyLow() {
      int low = this.clamp(this.lowChunks.getValue().intValue(), 2, 32);
      this.applyDistance(low);
   }

   private void applyHigh() {
      int low = this.clamp(this.lowChunks.getValue().intValue(), 2, 32);
      int high = this.clamp(this.highChunks.getValue().intValue(), 2, 32);
      if (high < low) {
         high = low;
      }

      this.applyDistance(high);
   }

   private void applyDistance(int distance) {
      distance = this.clamp(distance, 2, 32);
      if (this.lastApplied != distance || mc.options.getClampedViewDistance() != distance) {
         this.lastApplied = distance;
         this.setViewDistance(distance);
      }
   }

   private void setViewDistance(int distance) {
      distance = this.clamp(distance, 2, 32);
      SimpleOption<Integer> opt = mc.options.getViewDistance();
      Field field = valueField;
      if (field == null) {
         field = this.resolveValueField(opt);
         valueField = field;
      }

      if (field != null) {
         try {
            field.set(opt, distance);
            if (Integer.valueOf(distance).equals(opt.getValue())) {
               this.scheduleReload();
               return;
            }

            valueField = null;
         } catch (Exception var6) {
         }
      }

      try {
         opt.setValue(distance);
      } catch (Exception var5) {
      }

      this.scheduleReload();
   }

   private void scheduleReload() {
      if (mc.worldRenderer != null) {
         mc.worldRenderer.scheduleTerrainUpdate();
      }
   }

   private Field resolveValueField(SimpleOption<?> option) {
      Object current;
      try {
         current = option.getValue();
      } catch (Exception var9) {
         current = null;
      }

      Field fallback = null;

      for (Field field : SimpleOption.class.getDeclaredFields()) {
         if (!Modifier.isStatic(field.getModifiers())) {
            if ("value".equals(field.getName())) {
               fallback = field;
            }

            field.setAccessible(true);

            try {
               Object value = field.get(option);
               if (current == null ? value == null : current.equals(value)) {
                  return field;
               }
            } catch (Exception var10) {
            }
         }
      }

      if (fallback != null) {
         fallback.setAccessible(true);
         return fallback;
      } else {
         return null;
      }
   }

   private int clamp(int value, int min, int max) {
      return Math.max(min, Math.min(max, value));
   }
}

