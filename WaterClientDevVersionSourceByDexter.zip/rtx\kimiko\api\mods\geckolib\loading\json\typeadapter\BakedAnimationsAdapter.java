package rtx.kimiko.api.mods.geckolib.loading.json.typeadapter;

import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import it.unimi.dsi.fastutil.doubles.DoubleObjectPair;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentMap;
import net.minecraft.util.JsonHelper;
import org.apache.commons.lang3.math.NumberUtils;
import rtx.kimiko.api.mods.geckolib.GeckoLibConstants;
import rtx.kimiko.api.mods.geckolib.animation.object.EasingType;
import rtx.kimiko.api.mods.geckolib.animation.object.LoopType;
import rtx.kimiko.api.mods.geckolib.cache.animation.Animation;
import rtx.kimiko.api.mods.geckolib.cache.animation.BoneAnimation;
import rtx.kimiko.api.mods.geckolib.cache.animation.Keyframe;
import rtx.kimiko.api.mods.geckolib.cache.animation.KeyframeStack;
import rtx.kimiko.api.mods.geckolib.loading.math.MathParser;
import rtx.kimiko.api.mods.geckolib.loading.math.MathValue;
import rtx.kimiko.api.mods.geckolib.loading.math.function.misc.ToRadFunction;
import rtx.kimiko.api.mods.geckolib.loading.math.value.Constant;
import rtx.kimiko.api.mods.geckolib.loading.math.value.Negative;
import rtx.kimiko.api.mods.geckolib.loading.object.BakedAnimations;
import rtx.kimiko.api.mods.geckolib.object.CompoundException;
import rtx.kimiko.api.mods.geckolib.util.JsonUtil;

public final class BakedAnimationsAdapter {
   public static ConcurrentMap<Double, Constant> COMPRESSION_CACHE = null;

   private static Animation bakeAnimation(String string, JsonObject jsonObject, JsonDeserializationContext jsonDeserializationContext) throws CompoundException {
      double d = jsonObject.has("animation_length") ? JsonHelper.getDouble(jsonObject, "animation_length") : -1.0;
      LoopType loopType = LoopType.fromJson(jsonObject.get("loop"));
      BoneAnimation[] boneAnimationArray = bakeBoneAnimations(JsonHelper.getObject(jsonObject, "bones", new JsonObject()));
      Animation.KeyframeMarkers keyframeMarkers = (Animation.KeyframeMarkers)jsonDeserializationContext.deserialize(jsonObject, Animation.KeyframeMarkers.class);
      if (d == -1.0) {
         d = calculateAnimationLength(boneAnimationArray);
      }

      return Animation.create(string, d, loopType, boneAnimationArray, keyframeMarkers);
   }

   private static List<DoubleObjectPair<JsonElement>> getKeyframes(JsonElement jsonElement) {
      if (jsonElement == null) {
         return List.of();
      } else {
         if (jsonElement instanceof JsonPrimitive jsonPrimitive) {
            JsonArray jsonArray = new JsonArray(3);
            jsonArray.add(jsonPrimitive);
            jsonArray.add(jsonPrimitive);
            jsonArray.add(jsonPrimitive);
            jsonElement = jsonArray;
         }

         if (jsonElement instanceof JsonArray jsonArray) {
            return ObjectArrayList.of(new DoubleObjectPair[]{DoubleObjectPair.of(0.0, jsonArray)});
         } else if (!(jsonElement instanceof JsonObject jsonObject)) {
            throw new JsonParseException("Invalid object type provided to getTripletObj, got: " + jsonElement);
         } else if (jsonObject.has("vector")) {
            return ObjectArrayList.of(new DoubleObjectPair[]{DoubleObjectPair.of(0.0, jsonObject)});
         } else {
            List<DoubleObjectPair<JsonElement>> resultList = new ObjectArrayList();

            for (Entry<String, JsonElement> entry : jsonObject.entrySet()) {
               double d = readTimestamp(entry.getKey());
               if (d == 0.0 && !resultList.isEmpty()) {
                  throw new JsonParseException("Invalid keyframe data - multiple starting keyframes?" + entry.getKey());
               }

               JsonElement v = entry.getValue();
               if (v instanceof JsonObject entryObj && !entryObj.has("vector")) {
                  addBedrockKeyframes(d, entryObj, resultList);
               } else {
                  resultList.add(DoubleObjectPair.of(d, entry.getValue()));
               }
            }

            return resultList;
         }
      }
   }

   private static double readTimestamp(String string) {
      return NumberUtils.isCreatable(string) ? Double.parseDouble(string) : 0.0;
   }

   private static void addBedrockKeyframes(double d, JsonObject jsonObject, List<DoubleObjectPair<JsonElement>> list) {
      boolean bl = false;
      if (jsonObject.has("pre")) {
         bl = true;
         list.add(DoubleObjectPair.of(d == 0.0 ? d : d - 0.001, extractBedrockKeyframe(jsonObject.get("pre"))));
      }

      if (jsonObject.has("post")) {
         JsonArray jsonArray = extractBedrockKeyframe(jsonObject.get("post"));
         if (jsonObject.has("lerp_mode")) {
            JsonObject jsonObject2 = new JsonObject();
            jsonObject2.add("vector", jsonArray);
            jsonObject2.add("easing", jsonObject.get("lerp_mode"));
            list.add(DoubleObjectPair.of(d, jsonObject2));
         } else {
            list.add(DoubleObjectPair.of(d, jsonArray));
         }
      } else if (!bl) {
         throw new JsonParseException("Invalid keyframe data - expected array, found " + jsonObject);
      }
   }

   private static BoneAnimation[] bakeBoneAnimations(JsonObject jsonObject) throws CompoundException {
      BoneAnimation[] boneAnimationArray = new BoneAnimation[jsonObject.size()];
      int n = 0;

      for (Entry entry : jsonObject.entrySet()) {
         JsonObject jsonObject2 = ((JsonElement)entry.getValue()).getAsJsonObject();
         KeyframeStack keyframeStack = buildKeyframeStack(getKeyframes(jsonObject2.get("scale")), false);
         KeyframeStack keyframeStack2 = buildKeyframeStack(getKeyframes(jsonObject2.get("position")), false);
         KeyframeStack keyframeStack3 = buildKeyframeStack(getKeyframes(jsonObject2.get("rotation")), true);
         boneAnimationArray[n] = new BoneAnimation((String)entry.getKey(), keyframeStack3, keyframeStack2, keyframeStack);
         n++;
      }

      return boneAnimationArray;
   }

   private static JsonArray extractBedrockKeyframe(JsonElement jsonElement) {
      if (jsonElement.isJsonArray()) {
         return jsonElement.getAsJsonArray();
      } else if (!jsonElement.isJsonObject()) {
         throw new JsonParseException("Invalid keyframe data - expected array or object, found " + jsonElement);
      } else {
         JsonObject jsonObject = jsonElement.getAsJsonObject();
         if (jsonObject.has("vector")) {
            return jsonObject.get("vector").getAsJsonArray();
         } else {
            return jsonObject.has("pre") ? jsonObject.get("pre").getAsJsonArray() : jsonObject.get("post").getAsJsonArray();
         }
      }
   }

   private static MathValue compressMathValue(MathValue mathValue) {
      return COMPRESSION_CACHE != null && !mathValue.isMutable() ? COMPRESSION_CACHE.computeIfAbsent(mathValue.get(null), Constant::new) : mathValue;
   }

   private static List<Keyframe> addSplineArgs(List<Keyframe> list) {
      Keyframe keyframe;
      if (list.size() == 1 && (keyframe = list.getFirst()).easingType() != EasingType.LINEAR) {
         list.set(0, new Keyframe(keyframe.startTime(), keyframe.length(), keyframe.startValue(), keyframe.endValue()));
         return list;
      } else {
         for (int i = 0; i < list.size(); i++) {
            Keyframe keyframe2 = list.get(i);
            if (keyframe2.easingType() == EasingType.CATMULLROM) {
               MathValue[] values = new MathValue[]{
                  i == 0 ? keyframe2.startValue() : list.get(i - 1).endValue(), i + 1 >= list.size() ? keyframe2.endValue() : list.get(i + 1).endValue()
               };
               list.set(
                  i, new Keyframe(keyframe2.startTime(), keyframe2.length(), keyframe2.startValue(), keyframe2.endValue(), keyframe2.easingType(), values)
               );
            }
         }

         return list;
      }
   }

   private static KeyframeStack buildKeyframeStack(List<DoubleObjectPair<JsonElement>> list, boolean bl) throws CompoundException {
      if (list.isEmpty()) {
         return KeyframeStack.EMPTY;
      } else {
         List<Keyframe> xList = new ObjectArrayList();
         List<Keyframe> yList = new ObjectArrayList();
         List<Keyframe> zList = new ObjectArrayList();
         MathValue prevX = null;
         MathValue prevY = null;
         MathValue prevZ = null;
         DoubleObjectPair<JsonElement> prevPair = null;

         for (DoubleObjectPair<JsonElement> pair : list) {
            JsonElement jsonElement = (JsonElement)pair.right();
            double prevTime = prevPair != null ? prevPair.leftDouble() : 0.0;
            double curTime = pair.leftDouble();
            double duration = curTime - prevTime;
            JsonArray jsonArray = jsonElement instanceof JsonArray array ? array : JsonHelper.getArray(jsonElement.getAsJsonObject(), "vector");
            MathValue rawX = MathParser.parseJson(jsonArray.get(0));
            MathValue rawY = MathParser.parseJson(jsonArray.get(1));
            MathValue rawZ = MathParser.parseJson(jsonArray.get(2));
            MathValue curX = compressMathValue((MathValue)(bl ? new Negative(new ToRadFunction(rawX)) : rawX));
            MathValue curY = compressMathValue((MathValue)(bl ? new Negative(new ToRadFunction(rawY)) : rawY));
            MathValue curZ = compressMathValue((MathValue)(bl ? new ToRadFunction(rawZ) : rawZ));
            JsonObject jsonObject = jsonElement instanceof JsonObject obj ? obj : null;
            EasingType easing = jsonObject != null && jsonObject.has("easing") ? EasingType.fromJson(jsonObject.get("easing")) : EasingType.LINEAR;
            List<MathValue> easingArgs = (List<MathValue>)(List)(jsonObject != null && jsonObject.has("easingArgs")
               ? JsonUtil.jsonArrayToList(JsonHelper.getArray(jsonObject, "easingArgs"), el -> new Constant(el.getAsDouble()))
               : new ObjectArrayList());
            xList.add(new Keyframe(curTime, duration, prevPair == null ? curX : prevX, curX, easing, easingArgs));
            yList.add(new Keyframe(curTime, duration, prevPair == null ? curY : prevY, curY, easing, easingArgs));
            zList.add(new Keyframe(curTime, duration, prevPair == null ? curZ : prevZ, curZ, easing, easingArgs));
            prevX = curX;
            prevY = curY;
            prevZ = curZ;
            prevPair = pair;
         }

         return new KeyframeStack(addSplineArgs(xList), addSplineArgs(yList), addSplineArgs(zList));
      }
   }

   private static double calculateAnimationLength(BoneAnimation[] boneAnimationArray) {
      double d = 0.0;

      for (BoneAnimation boneAnimation : boneAnimationArray) {
         d = Math.max(d, boneAnimation.rotationKeyFrames().getTotalKeyframeTime());
         d = Math.max(d, boneAnimation.positionKeyFrames().getTotalKeyframeTime());
         d = Math.max(d, boneAnimation.scaleKeyFrames().getTotalKeyframeTime());
      }

      return d == 0.0 ? Double.MAX_VALUE : d;
   }

   public static JsonDeserializer<BakedAnimations> deserializer() throws JsonParseException {
      return BakedAnimationsAdapter::fromJson;
   }

   public static BakedAnimations fromJson(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) {
      JsonObject jsonObject = jsonElement.getAsJsonObject();
      Object2ObjectOpenHashMap object2ObjectOpenHashMap = new Object2ObjectOpenHashMap(jsonObject.size());

      for (Entry entry : jsonObject.entrySet()) {
         try {
            object2ObjectOpenHashMap.put(
               (String)entry.getKey(), bakeAnimation((String)entry.getKey(), ((JsonElement)entry.getValue()).getAsJsonObject(), jsonDeserializationContext)
            );
         } catch (Exception var9) {
            if (var9 instanceof CompoundException compoundException) {
               compoundException.withMessage("Unable to parse animation: " + (String)entry.getKey());
            } else {
               GeckoLibConstants.LOGGER.error("Unable to parse animation: {}", entry.getKey());
            }

            var9.printStackTrace();
         }
      }

      return new BakedAnimations(object2ObjectOpenHashMap);
   }
}

