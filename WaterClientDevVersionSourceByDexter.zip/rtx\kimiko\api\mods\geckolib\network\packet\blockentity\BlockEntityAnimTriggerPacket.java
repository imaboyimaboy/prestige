package rtx.kimiko.api.mods.geckolib.network.packet.blockentity;

import java.util.Optional;
import java.util.function.Consumer;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.network.packet.CustomPayload.Id;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import rtx.kimiko.api.mods.geckolib.GeckoLibConstants;
import rtx.kimiko.api.mods.geckolib.animatable.GeoBlockEntity;
import rtx.kimiko.api.mods.geckolib.network.packet.MultiloaderPacket;
import rtx.kimiko.api.mods.geckolib.util.ClientUtil;

public final class BlockEntityAnimTriggerPacket implements MultiloaderPacket {
   private BlockPos pos;
   private Optional<String> controllerName;
   private String animName;
   public static final Id<BlockEntityAnimTriggerPacket> TYPE = new Id(GeckoLibConstants.id("blockentity_anim_trigger"));
   public static final PacketCodec<PacketByteBuf, BlockEntityAnimTriggerPacket> CODEC = PacketCodec.tuple(
      BlockPos.PACKET_CODEC,
      BlockEntityAnimTriggerPacket::pos,
      PacketCodecs.STRING.collect(PacketCodecs::optional),
      BlockEntityAnimTriggerPacket::controllerName,
      PacketCodecs.STRING,
      BlockEntityAnimTriggerPacket::animName,
      BlockEntityAnimTriggerPacket::new
   );

   public BlockEntityAnimTriggerPacket(BlockPos pos, Optional<String> controllerName, String animName) {
      this.pos = pos;
      this.controllerName = controllerName;
      this.animName = animName;
   }

   public Id<? extends CustomPayload> getId() {
      return TYPE;
   }

   @Override
   public void receiveMessage(PlayerEntity playerEntity, Consumer<Runnable> consumer) {
      consumer.accept(() -> {
         World world = ClientUtil.getLevel();
         BlockEntity blockEntity;
         if (world != null && (blockEntity = world.getBlockEntity(this.pos)) instanceof GeoBlockEntity) {
            GeoBlockEntity geoBlockEntity = (GeoBlockEntity)blockEntity;
            geoBlockEntity.triggerAnim(this.controllerName.orElse(null), this.animName);
         }
      });
   }

   public BlockPos pos() {
      return this.pos;
   }

   public Optional<String> controllerName() {
      return this.controllerName;
   }

   public String animName() {
      return this.animName;
   }
}

