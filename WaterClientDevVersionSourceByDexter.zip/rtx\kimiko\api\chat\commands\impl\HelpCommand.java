package rtx.kimiko.api.chat.commands.impl;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.text.ClickEvent.RunCommand;
import net.minecraft.text.HoverEvent.ShowText;
import net.minecraft.util.Formatting;
import rtx.kimiko.api.chat.commands.Command;
import rtx.kimiko.api.chat.commands.CommandManager;
import rtx.kimiko.api.chat.commands.helpers.CommandDividers;
import rtx.kimiko.api.chat.commands.helpers.Paginator;
import rtx.kimiko.api.chat.commands.helpers.TabCompleteHelper;

public final class HelpCommand extends Command {
   public HelpCommand() {
      super("help", "Shows available commands");
   }

   @Override
   public void execute(String string, String[] stringArray) {
      CommandManager commandManager = CommandManager.getInstance();
      if (stringArray.length != 0 && !this.isInteger(stringArray[0])) {
         Command command2 = commandManager.getCommand(stringArray[0]);
         if (command2 == null) {
            this.logDirect("Command '" + stringArray[0] + "' not found.", Formatting.RED);
         } else {
            String string3 = command2.getName().toUpperCase();
            List<String> list = command2.getLongDesc();
            int n = CommandDividers.calcLineCountForContent(string3, list);
            this.logDirectRaw(CommandDividers.header(string3, n));
            String string4 = commandManager.getPrefix();

            for (int i = 0; i < list.size(); i++) {
               String string5 = list.get(i);
               if (!string5.isEmpty()) {
                  if (i == 0) {
                     this.logDirectRaw(Text.literal("Desc: null").formatted(Formatting.GRAY));
                  } else if (string5.startsWith("> ")) {
                     this.logDirectRaw(Text.literal(string4 + string5.substring(2)).formatted(Formatting.WHITE));
                  } else {
                     this.logDirectRaw(Text.literal(string5).formatted(Formatting.WHITE));
                  }
               }
            }

            this.logDirectRaw(CommandDividers.footer(string3, n));
         }
      } else {
         int n = stringArray.length > 0 && this.isInteger(stringArray[0]) ? Integer.parseInt(stringArray[0]) : 1;
         List<Command> list = commandManager.getCommands().stream().filter(command -> !command.hiddenFromHelp()).collect(Collectors.toList());
         List<String> list2 = list.stream()
            .map(command -> commandManager.getPrefix() + command.getName() + " - " + command.getShortDesc())
            .collect(Collectors.toList());
         String string2 = "COMMANDS";
         int n2 = CommandDividers.calcLineCountForContent("COMMANDS", list2);
         Paginator<Command> paginator = new Paginator<>(list);
         paginator.setPage(n);
         paginator.display(
            () -> this.logDirectRaw(CommandDividers.header("COMMANDS", n2)),
            cmd -> {
               String cmdName = commandManager.getPrefix() + cmd.getName();
               MutableText mutableText = Text.literal(cmdName)
                  .formatted(Formatting.WHITE)
                  .append(Text.literal("\n" + cmd.getShortDesc()).formatted(Formatting.GRAY));
               return Text.literal(cmdName)
                  .formatted(Formatting.WHITE)
                  .append(Text.literal(" - " + cmd.getShortDesc()).formatted(Formatting.GRAY))
                  .styled(
                     style -> style.withHoverEvent(new ShowText(mutableText))
                        .withClickEvent(new RunCommand(commandManager.getPrefix() + string + " " + cmd.getName()))
                  );
            },
            commandManager.getPrefix() + string
         );
         this.logDirectRaw(CommandDividers.footer("COMMANDS", n2));
      }
   }

   private boolean isInteger(String string) {
      try {
         Integer.parseInt(string);
         return true;
      } catch (NumberFormatException var3) {
         return false;
      }
   }

   @Override
   public List<String> getLongDesc() {
      return Arrays.asList("Shows command help.", "Usage:", "> help", "> help <command>");
   }

   @Override
   public Stream<String> tabComplete(String string, String[] stringArray) {
      return stringArray.length == 1 ? new TabCompleteHelper().filterPrefix(stringArray[0]).addCommands(CommandManager.getInstance()).stream() : Stream.empty();
   }
}

