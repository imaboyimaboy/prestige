package com.water.mixin;

import com.water.gui.HudEditor;
import com.water.gui.hud.SpotifyQueueHud;
import com.water.module.modules.client.SpotifyHud;
import com.water.module.modules.render.Freecam;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.Mouse;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.input.MouseInput;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Mouse.class})
public class MouseMixin {
   private static double toScaledX(MinecraftClient mc, double rawX) {
      if (mc != null && mc.getWindow() != null) {
         double w = mc.getWindow().getWidth();
         return w <= 0.0 ? rawX : rawX * (mc.getWindow().getScaledWidth() / w);
      } else {
         return rawX;
      }
   }

   private static double toScaledY(MinecraftClient mc, double rawY) {
      if (mc != null && mc.getWindow() != null) {
         double h = mc.getWindow().getHeight();
         return h <= 0.0 ? rawY : rawY * (mc.getWindow().getScaledHeight() / h);
      } else {
         return rawY;
      }
   }

   @Inject(
      method = {"onMouseButton"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 0
   )
   private void water$hudEditorMouseButtonClick(long window, MouseInput input, int action, CallbackInfo ci) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc != null && mc.currentScreen instanceof ChatScreen) {
         if (action == 1) {
            double smx2 = toScaledX(mc, mc.mouse.getX());
            double smy2 = toScaledY(mc, mc.mouse.getY());
            int button = input.button();
            if (SpotifyHud.handleClick(smx2, smy2, button)) {
               ci.cancel();
               return;
            }

            if (SpotifyQueueHud.onMouseClick(smx2, smy2, button)) {
               ci.cancel();
               return;
            }

            if (HudEditor.INSTANCE.onMouseClick(smx2, smy2, button)) {
               ci.cancel();
            }
         } else if (action == 0) {
            SpotifyQueueHud.onMouseRelease();
            HudEditor.INSTANCE.onMouseRelease();
         }
      }
   }

   @Inject(
      method = {"onCursorPos"},
      at = {@At("HEAD")},
      require = 0
   )
   private void water$hudEditorCursorPos(long window, double x, double y, CallbackInfo ci) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc != null && mc.player != null) {
         if (mc.currentScreen instanceof ChatScreen) {
            boolean queueDrag = SpotifyQueueHud.isDragging();
            boolean hudDrag = HudEditor.INSTANCE.isDragging();
            if (queueDrag || hudDrag) {
               if (GLFW.glfwGetMouseButton(window, 0) != 1) {
                  SpotifyQueueHud.onMouseRelease();
                  HudEditor.INSTANCE.onMouseRelease();
               } else {
                  if (queueDrag) {
                     SpotifyQueueHud.onMouseDrag(toScaledX(mc, x), toScaledY(mc, y));
                  } else {
                     HudEditor.INSTANCE.onMouseDrag(toScaledX(mc, x), toScaledY(mc, y));
                  }
               }
            }
         }
      }
   }

   @Inject(
      method = {"onMouseScroll"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void water$useScrollForFreecamSpeed(long window, double horizontal, double vertical, CallbackInfo ci) {
      if (Freecam.instance != null && Freecam.instance.isEnabled()) {
         if (MinecraftClient.getInstance().currentScreen == null) {
            double scrollAmount = vertical != 0.0 ? vertical : horizontal;
            if (scrollAmount != 0.0) {
               Freecam.instance.adjustSpeed(scrollAmount);
               ci.cancel();
            }
         }
      }
   }

   @Inject(
      method = {"onMouseScroll"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void water$hudEditorMouseScroll(long window, double horizontal, double vertical, CallbackInfo ci) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc != null && mc.currentScreen instanceof ChatScreen) {
         double amount = vertical != 0.0 ? vertical : horizontal;
         if (amount != 0.0) {
            double sx = toScaledX(mc, mc.mouse.getX());
            double sy = toScaledY(mc, mc.mouse.getY());
            if (SpotifyQueueHud.onScroll(sx, sy, amount)) {
               ci.cancel();
            } else {
               if (HudEditor.INSTANCE.onMouseScroll(sx, sy, amount)) {
                  ci.cancel();
               }
            }
         }
      }
   }
}

