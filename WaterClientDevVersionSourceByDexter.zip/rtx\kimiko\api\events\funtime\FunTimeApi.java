package rtx.kimiko.api.events.funtime;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map.Entry;
import rtx.kimiko.utils.net.Endpoints;

public final class FunTimeApi {
   public static final FunTimeApi INSTANCE = new FunTimeApi();
   private final HttpClient httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5L)).build();
   private volatile String baseUrl = Endpoints.funtime();

   private FunTimeApi() {
   }

   private static JsonObject parse(String string) {
      try {
         JsonElement jsonElement = JsonParser.parseString(string == null ? "" : string);
         return jsonElement.isJsonObject() ? jsonElement.getAsJsonObject() : new JsonObject();
      } catch (RuntimeException var2) {
         return new JsonObject();
      }
   }

   private static String string(JsonObject jsonObject, String string, String string2) {
      if (jsonObject == null) {
         return string2;
      } else {
         JsonElement jsonElement = jsonObject.get(string);
         if (jsonElement != null && jsonElement.isJsonPrimitive()) {
            String string3 = jsonElement.getAsString().trim();
            return string3.isEmpty() ? string2 : string3;
         } else {
            return string2;
         }
      }
   }

   private static long number(JsonObject jsonObject, String string, long l) {
      if (jsonObject == null) {
         return l;
      } else {
         JsonElement jsonElement = jsonObject.get(string);
         return jsonElement != null && jsonElement.isJsonPrimitive() && jsonElement.getAsJsonPrimitive().isNumber() ? jsonElement.getAsLong() : l;
      }
   }

   private JsonObject request(String string) throws FunTimeApiException {
      String string2 = this.baseUrl + string;
      HttpRequest httpRequest = HttpRequest.newBuilder(URI.create(string2)).timeout(Duration.ofSeconds(10L)).header("Accept", "application/json").GET().build();

      HttpResponse<String> httpResponse;
      try {
         httpResponse = this.httpClient.send(httpRequest, BodyHandlers.ofString());
      } catch (InterruptedException var6) {
         Thread.currentThread().interrupt();
         throw new FunTimeApiException(-1, "interrupted", "Запрос прерван");
      } catch (IOException var7) {
         throw new FunTimeApiException(-1, "network", "Сеть недоступна: " + var7.getClass().getSimpleName());
      }

      JsonObject jsonObject = parse(httpResponse.body());
      if (httpResponse.statusCode() == 200) {
         return jsonObject;
      } else {
         throw new FunTimeApiException(httpResponse.statusCode(), "http", "HTTP " + httpResponse.statusCode());
      }
   }

   public List<FunTimeEvent> events() throws FunTimeApiException {
      JsonObject jsonObject = servers(this.request("events"));
      ArrayList<FunTimeEvent> arrayList = new ArrayList<>();

      for (Entry entry : jsonObject.entrySet()) {
         int n = anarchyOf((String)entry.getKey());
         if (((JsonElement)entry.getValue()).isJsonArray()) {
            for (JsonElement jsonElement : ((JsonElement)entry.getValue()).getAsJsonArray()) {
               if (jsonElement.isJsonObject()) {
                  JsonObject jsonObject2 = jsonElement.getAsJsonObject();
                  arrayList.add(
                     new FunTimeEvent(string(jsonObject2, "name", "Событие"), n, 0, string(jsonObject2, "id", ""), string(jsonObject2, "rarity", ""))
                  );
               }
            }
         }
      }

      return arrayList;
   }

   private static JsonObject servers(JsonObject jsonObject) {
      JsonObject jsonObject2 = jsonObject.getAsJsonObject("servers");
      return jsonObject2 == null ? new JsonObject() : jsonObject2;
   }

   public List<FunTimeMine> mines() throws FunTimeApiException {
      JsonObject jsonObject = servers(this.request("mines"));
      ArrayList<FunTimeMine> arrayList = new ArrayList<>();

      for (Entry entry : jsonObject.entrySet()) {
         String string = (String)entry.getKey();
         if (((JsonElement)entry.getValue()).isJsonArray()) {
            for (JsonElement jsonElement : ((JsonElement)entry.getValue()).getAsJsonArray()) {
               if (jsonElement.isJsonObject()) {
                  JsonObject jsonObject2 = jsonElement.getAsJsonObject();
                  arrayList.add(
                     new FunTimeMine(
                        string,
                        serverLabel(string),
                        string(jsonObject2, "name", ""),
                        string(jsonObject2, "rarity", ""),
                        "",
                        number(jsonObject2, "refillAt", 0L)
                     )
                  );
               }
            }
         }
      }

      return arrayList;
   }

   private static String serverLabel(String string) {
      if (string != null && !string.isBlank()) {
         int n = anarchyOf(string);
         if (n <= 0) {
            return string;
         } else {
            String string2 = string.toUpperCase(Locale.ROOT);
            String string3 = string2.contains("LITE") ? "Лайт-Анархия" : "Анархия";
            String string4 = string2.contains("NEW") ? " (1.21)" : "";
            return string3 + " " + n + string4;
         }
      } else {
         return "";
      }
   }

   public void setBaseUrl(String string) {
      if (string != null && !string.isBlank()) {
         this.baseUrl = string.endsWith("/") ? string.trim() : string.trim() + "/";
      }
   }

   private static int anarchyOf(String string) {
      if (string == null) {
         return 0;
      } else {
         StringBuilder stringBuilder = new StringBuilder();

         for (int i = 0; i < string.length(); i++) {
            char c = string.charAt(i);
            if (c >= '0' && c <= '9') {
               stringBuilder.append(c);
            }
         }

         try {
            return stringBuilder.isEmpty() ? 0 : Integer.parseInt(stringBuilder.toString());
         } catch (NumberFormatException var4) {
            return 0;
         }
      }
   }
}

