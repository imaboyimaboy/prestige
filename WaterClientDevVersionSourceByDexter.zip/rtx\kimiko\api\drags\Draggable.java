package rtx.kimiko.api.drags;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.DrawContext;
import rtx.kimiko.api.ui.settings.Setting;

public abstract class Draggable {
   private String string;
   private DragController drag;
   private float defaultX;
   private float defaultY;
   private boolean visible = true;
   private List<Setting> cachedHudSettings;

   protected Draggable(String string, float f, float f2) {
      this.string = string;
      this.defaultX = f;
      this.defaultY = f2;
      this.drag = new DragController(f, f2);
   }

   public String getId() {
      return this.string;
   }

   public String displayName() {
      return this.string;
   }

   public abstract float width();

   public Position getPosition() {
      return new Position(this.drag.getTargetX(), this.drag.getTargetY());
   }

   public abstract float height();

   public final List<Setting> hudSettings() {
      if (this.cachedHudSettings == null) {
         this.cachedHudSettings = this.buildHudSettings();
      }

      return this.cachedHudSettings;
   }

   public float overlayHeight() {
      return this.height();
   }

   final void renderNormal(DrawContext drawContext) {
      if (this.visible) {
         this.drag.beginRender();
         float f = this.drag.getTiltAngle();
         if (Math.abs(f) < 0.01F) {
            try {
               this.render(drawContext);
            } finally {
               this.drag.endRender();
            }
         } else {
            float f2 = this.drag.getRenderX() + this.width() * 0.5F;
            float f3 = this.drag.getRenderY() + this.height() * 0.5F;
            drawContext.getMatrices().pushMatrix();
            drawContext.getMatrices().translate(f2, f3);
            drawContext.getMatrices().rotate((float)Math.toRadians(f));
            drawContext.getMatrices().translate(-f2, -f3);

            try {
               this.render(drawContext);
            } finally {
               drawContext.getMatrices().popMatrix();
               this.drag.endRender();
            }
         }
      }
   }

   public boolean isInteractive() {
      return this.visible;
   }

   public float overlayWidth() {
      return this.width();
   }

   protected List<Setting> buildHudSettings() {
      return new ArrayList<>();
   }

   protected abstract void render(DrawContext var1);

   public boolean isVisible() {
      return this.visible;
   }

   public void resetToDefault() {
      this.drag.setTargetX(this.defaultX);
      this.drag.setTargetY(this.defaultY);
      this.drag.syncToTarget();
   }

   final boolean hitTest(float f, float f2) {
      return this.drag.isHovered(f, f2, this.width(), this.height());
   }

   public DragController getDrag() {
      return this.drag;
   }

   protected float getX() {
      return this.drag.getRenderX();
   }

   protected float getY() {
      return this.drag.getRenderY();
   }

   public void setVisible(boolean bl) {
      this.visible = bl;
   }
}

