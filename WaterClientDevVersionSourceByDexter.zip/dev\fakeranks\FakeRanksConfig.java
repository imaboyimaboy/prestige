package dev.fakeranks;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import net.fabricmc.loader.api.FabricLoader;

public class FakeRanksConfig {
   private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
   private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("fakeranks.json");
   public boolean enabled = true;
   public boolean guiEnabled = true;
   public boolean skinStealEnabled = true;
   public boolean chatPrefixEnabled = true;
   public boolean nametagEnabled = true;
   public boolean mediaEnabled = true;
   public boolean tierTagsEnabled = true;
   public boolean smoothGuiAnimations = false;
   public boolean blossomHidden = true;
   public String customName = "";
   public FakeRank rank = FakeRank.NONE;
   public FakeStaffBadge staffBadge = FakeStaffBadge.NONE;

   public static FakeRanksConfig load() {
      if (Files.notExists(PATH)) {
         FakeRanksConfig created = new FakeRanksConfig();
         created.save();
         return created;
      } else {
         try {
            FakeRanksConfig var2;
            try (BufferedReader reader = Files.newBufferedReader(PATH)) {
               FakeRanksConfig config = (FakeRanksConfig)GSON.fromJson(reader, FakeRanksConfig.class);
               var2 = config == null ? new FakeRanksConfig() : config;
            }

            return var2;
         } catch (RuntimeException | IOException var5) {
            return new FakeRanksConfig();
         }
      }
   }

   public void save() {
      try {
         Files.createDirectories(PATH.getParent());

         try (BufferedWriter writer = Files.newBufferedWriter(PATH)) {
            GSON.toJson(this, writer);
         }
      } catch (IOException var6) {
      }
   }
}

