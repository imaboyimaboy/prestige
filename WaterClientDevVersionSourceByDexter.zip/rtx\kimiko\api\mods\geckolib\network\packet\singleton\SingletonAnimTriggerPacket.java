package rtx.kimiko.api.mods.geckolib.network.packet.singleton;

import java.util.Optional;
import java.util.function.Consumer;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.network.packet.CustomPayload.Id;
import rtx.kimiko.api.mods.geckolib.GeckoLibConstants;
import rtx.kimiko.api.mods.geckolib.animatable.GeoAnimatable;
import rtx.kimiko.api.mods.geckolib.animatable.manager.AnimatableManager;
import rtx.kimiko.api.mods.geckolib.cache.SyncedSingletonAnimatableCache;
import rtx.kimiko.api.mods.geckolib.network.packet.MultiloaderPacket;

public final class SingletonAnimTriggerPacket implements MultiloaderPacket {
   private String syncableId;
   private long instanceId;
   private Optional<String> controllerName;
   private String animName;
   public static final Id<SingletonAnimTriggerPacket> TYPE = new Id(GeckoLibConstants.id("singleton_anim_trigger"));
   public static final PacketCodec<PacketByteBuf, SingletonAnimTriggerPacket> CODEC = PacketCodec.tuple(
      PacketCodecs.STRING,
      SingletonAnimTriggerPacket::syncableId,
      PacketCodecs.VAR_LONG,
      SingletonAnimTriggerPacket::instanceId,
      PacketCodecs.STRING.collect(PacketCodecs::optional),
      SingletonAnimTriggerPacket::controllerName,
      PacketCodecs.STRING,
      SingletonAnimTriggerPacket::animName,
      SingletonAnimTriggerPacket::new
   );

   public SingletonAnimTriggerPacket(String syncableId, long instanceId, Optional<String> controllerName, String animName) {
      this.syncableId = syncableId;
      this.instanceId = instanceId;
      this.controllerName = controllerName;
      this.animName = animName;
   }

   public Id<? extends CustomPayload> getId() {
      return TYPE;
   }

   @Override
   public void receiveMessage(PlayerEntity playerEntity, Consumer<Runnable> consumer) {
      consumer.accept(() -> {
         GeoAnimatable geoAnimatable = SyncedSingletonAnimatableCache.getSyncedAnimatable(this.syncableId);
         if (geoAnimatable != null) {
            AnimatableManager<?> animatableManager = geoAnimatable.getAnimatableInstanceCache().getManagerForId(this.instanceId);
            if (this.controllerName.isPresent()) {
               animatableManager.tryTriggerAnimation(this.controllerName.get(), this.animName);
            } else {
               animatableManager.tryTriggerAnimation(this.animName);
            }
         }
      });
   }

   public String syncableId() {
      return this.syncableId;
   }

   public long instanceId() {
      return this.instanceId;
   }

   public Optional<String> controllerName() {
      return this.controllerName;
   }

   public String animName() {
      return this.animName;
   }
}

