package rtx.kimiko.api.mods.geckolib.cache.animation;

import it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet;
import java.util.Set;
import rtx.kimiko.api.mods.geckolib.loading.math.value.Variable;

public final class BoneAnimation {
   private String boneName;
   private KeyframeStack rotationKeyFrames;
   private KeyframeStack positionKeyFrames;
   private KeyframeStack scaleKeyFrames;

   public BoneAnimation(String boneName, KeyframeStack rotationKeyFrames, KeyframeStack positionKeyFrames, KeyframeStack scaleKeyFrames) {
      this.boneName = boneName;
      this.rotationKeyFrames = rotationKeyFrames;
      this.positionKeyFrames = positionKeyFrames;
      this.scaleKeyFrames = scaleKeyFrames;
   }

   public Set<Variable> getUsedVariables() {
      ReferenceOpenHashSet referenceOpenHashSet = new ReferenceOpenHashSet();
      referenceOpenHashSet.addAll(this.rotationKeyFrames.getUsedVariables());
      referenceOpenHashSet.addAll(this.positionKeyFrames.getUsedVariables());
      referenceOpenHashSet.addAll(this.scaleKeyFrames.getUsedVariables());
      return referenceOpenHashSet;
   }

   public String boneName() {
      return this.boneName;
   }

   public KeyframeStack rotationKeyFrames() {
      return this.rotationKeyFrames;
   }

   public KeyframeStack positionKeyFrames() {
      return this.positionKeyFrames;
   }

   public KeyframeStack scaleKeyFrames() {
      return this.scaleKeyFrames;
   }
}

