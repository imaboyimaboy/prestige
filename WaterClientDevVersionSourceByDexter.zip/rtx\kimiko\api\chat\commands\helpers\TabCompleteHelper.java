package rtx.kimiko.api.chat.commands.helpers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;
import rtx.kimiko.api.chat.commands.Command;
import rtx.kimiko.api.chat.commands.CommandManager;

public class TabCompleteHelper {
   private final List<String> candidates = new ArrayList<>();

   public TabCompleteHelper append(String... items) {
      if (items != null) {
         this.candidates.addAll(Arrays.asList(items));
      }

      return this;
   }

   public TabCompleteHelper append(Collection<String> items) {
      if (items != null) {
         this.candidates.addAll(items);
      }

      return this;
   }

   public TabCompleteHelper addCommands(CommandManager cm) {
      if (cm != null) {
         for (Command c : cm.getCommands()) {
            this.candidates.add(c.getName());
         }
      }

      return this;
   }

   public TabCompleteHelper sortAlphabetically() {
      Collections.sort(this.candidates, String.CASE_INSENSITIVE_ORDER);
      return this;
   }

   public TabCompleteHelper filterPrefix(String prefix) {
      if (prefix != null && !prefix.isEmpty()) {
         String lower = prefix.toLowerCase(Locale.ROOT);
         this.candidates.removeIf(s -> !s.toLowerCase(Locale.ROOT).startsWith(lower));
         return this;
      } else {
         return this;
      }
   }

   public Stream<String> stream() {
      return this.candidates.stream();
   }
}

