package rtx.kimiko.api.mods.geckolib.cache.model;

public final class GeoVertex {
   private float posX;
   private float posY;
   private float posZ;
   private float texU;
   private float texV;

   public GeoVertex(double d, double d2, double d3) {
      this((float)d, (float)d2, (float)d3, 0.0F, 0.0F);
   }

   public GeoVertex(float posX, float posY, float posZ, float texU, float texV) {
      this.posX = posX;
      this.posY = posY;
      this.posZ = posZ;
      this.texU = texU;
      this.texV = texV;
   }

   public GeoVertex withUVs(float f, float f2) {
      return new GeoVertex(this.posX, this.posY, this.posZ, f, f2);
   }

   public float posX() {
      return this.posX;
   }

   public float posY() {
      return this.posY;
   }

   public float posZ() {
      return this.posZ;
   }

   public float texU() {
      return this.texU;
   }

   public float texV() {
      return this.texV;
   }
}

