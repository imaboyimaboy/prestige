package com.water.mixin;

import com.water.module.modules.donut.FakeRoles;
import com.water.module.modules.misc.Freelook;
import com.water.module.modules.misc.NameProtect;
import com.water.module.modules.render.Freecam;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({Entity.class})
public class EntityMixin {
   @Inject(
      method = {"changeLookDirection"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onChangeLookDirection(double cursorDeltaX, double cursorDeltaY, CallbackInfo ci) {
      Entity self = (Entity)(Object)this;
      if (self == MinecraftClient.getInstance().player) {
         if (Freecam.instance != null && Freecam.instance.isEnabled()) {
            Freecam.instance
               .updateRotation(cursorDeltaX * 0.15 * Freecam.instance.getLookSensitivity(), cursorDeltaY * 0.15 * Freecam.instance.getLookSensitivity());
            ci.cancel();
         } else {
            if (Freelook.instance != null && Freelook.instance.isCameraActive()) {
               Freelook.instance.consumeMouseDelta(cursorDeltaX, cursorDeltaY);
               ci.cancel();
            }
         }
      }
   }

   @Inject(
      method = {"isSneaking"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onIsSneaking(CallbackInfoReturnable<Boolean> cir) {
      if (Freecam.instance != null && Freecam.instance.isEnabled() && (Object)this == MinecraftClient.getInstance().player) {
         cir.setReturnValue(Freecam.instance.shouldRenderSneaking());
      }
   }

   @Inject(
      method = {"shouldRender(D)Z"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onShouldRender(double distance, CallbackInfoReturnable<Boolean> cir) {
      if (Freecam.instance != null && Freecam.instance.isEnabled() && distance < 25600.0) {
         cir.setReturnValue(true);
      }
   }

   @Inject(
      method = {"getDisplayName"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void onGetDisplayName(CallbackInfoReturnable<Text> cir) {
      if (FakeRoles.isActive()) {
         Text modified = FakeRoles.modifyChatText((Text)cir.getReturnValue());
         if (modified != cir.getReturnValue()) {
            cir.setReturnValue(modified);
            return;
         }
      }

      if (NameProtect.instance != null && NameProtect.instance.isEnabled() && MinecraftClient.getInstance().getSession() != null) {
         String name = MinecraftClient.getInstance().getSession().getUsername();
         if (name != null) {
            Text returned = (Text)cir.getReturnValue();
            if (returned != null) {
               String str = returned.getString();
               if (str.contains(name)) {
                  cir.setReturnValue(Text.literal(str.replace(name, NameProtect.instance.getFakeName())));
               }
            }
         }
      }
   }

   @Inject(
      method = {"getName"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void onGetName(CallbackInfoReturnable<Text> cir) {
      if (FakeRoles.isActive()) {
         Text modified = FakeRoles.modifyChatText((Text)cir.getReturnValue());
         if (modified != cir.getReturnValue()) {
            cir.setReturnValue(modified);
            return;
         }
      }

      if (NameProtect.instance != null && NameProtect.instance.isEnabled() && MinecraftClient.getInstance().getSession() != null) {
         String name = MinecraftClient.getInstance().getSession().getUsername();
         if (name != null) {
            Text returned = (Text)cir.getReturnValue();
            if (returned != null) {
               String str = returned.getString();
               if (str.contains(name)) {
                  cir.setReturnValue(Text.literal(str.replace(name, NameProtect.instance.getFakeName())));
               }
            }
         }
      }
   }
}

