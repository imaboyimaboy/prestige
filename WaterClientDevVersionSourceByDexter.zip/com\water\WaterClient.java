package com.water;

import com.water.gui.hud.SpotifyQueueHud;
import com.water.gui.notification.NotificationManager;
import com.water.module.ActivatableModule;
import com.water.module.Module;
import com.water.module.ModuleManager;
import com.water.module.modules.client.Hud;
import com.water.module.modules.client.SpotifyHud;
import com.water.module.modules.client.WaterPlus;
import com.water.module.modules.donut.OldDonutScoreboard;
import com.water.module.modules.misc.NameTags;
import com.water.module.modules.misc.PearlESP;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.EndTick;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.option.KeyBinding.Category;
import net.minecraft.client.util.InputUtil.Type;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rtx.kimiko.api.ui.UI;
import rtx.kimiko.utils.sounds.Sounds;

public class WaterClient {
   public static final Logger LOGGER = LoggerFactory.getLogger("Water");
   private static KeyBinding rightShiftKey;

   public static boolean isMenuKey(int keyCode, int scanCode) {
      return keyCode == WaterPlus.getGuiKey();
   }

   public static void toggleClickGui() {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client != null) {
         client.execute(() -> {
            if (client.currentScreen instanceof UI gui) {
               gui.close();
            } else {
               client.setScreen(UI.INSTANCE);
               Sounds.play("gui_open");
               if (client.mouse != null) {
                  client.mouse.unlockCursor();
               }
            }
         });
      }
   }

   public void onInitializeClient() {
      LOGGER.info("Initialisiere Water Client (Yarn Mappings)");
      ModuleManager.INSTANCE.init();
      rightShiftKey = KeyBindingHelper.registerKeyBinding(
         new KeyBinding("key.water.toggle_menu", Type.KEYSYM, 344, new Category(Identifier.of("water", "general")))
      );
      HudRenderCallback.EVENT.register((HudRenderCallback)(context, tickCounter) -> {
         try {
            NameTags.renderHud(context, tickCounter.getTickProgress(false));
            PearlESP.renderHud(context, tickCounter.getTickProgress(false));
            Hud.renderHud(context);
            SpotifyHud.renderHud(context);
            SpotifyQueueHud.visible = Hud.showSpotifyQueue();
            if (SpotifyQueueHud.visible) {
               MinecraftClient mc2 = MinecraftClient.getInstance();
               if (mc2 != null) {
                  double sf2 = mc2.getWindow().getScaleFactor();
                  double smx = mc2.mouse.getX() / sf2;
                  double smy = mc2.mouse.getY() / sf2;
                  SpotifyQueueHud.render(context, smx, smy);
               }
            }

            OldDonutScoreboard.renderHud(context);
            NotificationManager.INSTANCE.render(context);
         } catch (Throwable var9) {
         }
      });
      ClientTickEvents.END_CLIENT_TICK.register((EndTick)client -> {
         ModuleManager.INSTANCE.onTick();
         if (client.currentScreen == null && client.getWindow() != null) {
            for (Module m : ModuleManager.INSTANCE.getModules()) {
               int bind = m.getBind();
               ActivatableModule activatable = m instanceof ActivatableModule a ? a : null;
               int activationKey = activatable != null ? activatable.getActivationKey() : 0;
               if (bind != 0) {
                  try {
                     boolean pressed = GLFW.glfwGetKey(client.getWindow().getHandle(), bind) == 1;
                     if (pressed && !m.wasBindPressed && activationKey != bind) {
                        m.onBindPressed();
                     }

                     m.wasBindPressed = pressed;
                  } catch (Exception var8) {
                  }
               }

               if (activatable != null && activationKey != 0) {
                  try {
                     boolean pressed = GLFW.glfwGetKey(client.getWindow().getHandle(), activationKey) == 1;
                     if (pressed && !activatable.wasActivationKeyPressed) {
                        activatable.onActivationKeyPressed();
                     }

                     activatable.wasActivationKeyPressed = pressed;
                  } catch (Exception var7) {
                  }
               }
            }
         }
      });
   }
}

