package com.water.setting;

public final class SectionSetting extends Setting<String> {
   public SectionSetting(String name) {
      super(name, name);
   }
}

