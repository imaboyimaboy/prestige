package com.water.module;

import com.water.gui.notification.NotificationManager;
import com.water.module.modules.client.WaterPlus;
import com.water.setting.Setting;
import com.water.utils.WaterSounds;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;

public abstract class Module {
   private String name;
   private Category category;
   private boolean enabled;
   private int bind = 0;
   private boolean expanded = false;
   public boolean wasBindPressed = false;
   private final List<Setting<?>> settings = new ArrayList<>();
   protected static final MinecraftClient mc = MinecraftClient.getInstance();

   public Module(String name, Category category) {
      this.name = name;
      this.category = category;
      this.enabled = false;
   }

   public void addSetting(Setting<?> setting) {
      this.settings.add(setting);
   }

   public List<Setting<?>> getSettings() {
      return this.settings;
   }

   public String getName() {
      return this.name;
   }

   public Category getCategory() {
      return this.category;
   }

   public void setEnabled(boolean enabled) {
      this.enabled = enabled;
      if (enabled) {
         WaterSounds.moduleOn();
         this.onEnable();
      } else {
         this.onDisable();
      }

      ModuleManager.INSTANCE.saveConfig();

      try {
         if (WaterPlus.notificationsEnabled()) {
            NotificationManager.INSTANCE.pushToggle(this.name, enabled, this.getModuleIcon());
         }
      } catch (Exception var3) {
      }
   }

   public ItemStack getModuleIcon() {
      Item named = resolveItemByName(this.name);
      return named != null && named != Items.AIR ? new ItemStack(named) : new ItemStack(this.categoryDefaultItem());
   }

   private static Item resolveItemByName(String moduleName) {
      String var1 = moduleName.toLowerCase().replace(" ", "_");
      switch (var1.hashCode()) {
         case -2048606734:
            if (var1.equals("spotify_hud")) {
               return Items.JUKEBOX;
            }
            break;
         case -1965825027:
            if (var1.equals("tunnel_base_finder")) {
               return Items.DIAMOND_PICKAXE;
            }
            break;
         case -1815040898:
            if (var1.equals("coordsnapper")) {
               return Items.COMPASS;
            }
            break;
         case -1800963612:
            if (var1.equals("nameprotect")) {
               return Items.BOOK;
            }
            break;
         case -1538756804:
            if (var1.equals("mace_swap")) {
               return Items.MACE;
            }
            break;
         case -1537620213:
            if (var1.equals("freelook")) {
               return Items.SPYGLASS;
            }
            break;
         case -1356578512:
            if (var1.equals("tab_detector")) {
               return Items.PLAYER_HEAD;
            }
            break;
         case -1323126747:
            if (var1.equals("chat_macro")) {
               return Items.WRITABLE_BOOK;
            }
            break;
         case -1272164374:
            if (var1.equals("speraswap")) {
               return Items.MACE;
            }
            break;
         case -1217012392:
            if (var1.equals("hitbox")) {
               return Items.BARRIER;
            }
            break;
         case -1127683930:
            if (var1.equals("auto_crystal")) {
               return Items.END_CRYSTAL;
            }
            break;
         case -1031981916:
            if (var1.equals("activitydebug")) {
               return Items.DEBUG_STICK;
            }
            break;
         case -950671987:
            if (var1.equals("auto_double_hand")) {
               return Items.SHIELD;
            }
            break;
         case -948295837:
            if (var1.equals("auto_inv_totem")) {
               return Items.TOTEM_OF_UNDYING;
            }
            break;
         case -895679974:
            if (var1.equals("sprint")) {
               return Items.FEATHER;
            }
            break;
         case -836477084:
            if (var1.equals("fast_place")) {
               return Items.PISTON;
            }
            break;
         case -794661098:
            if (var1.equals("shield_breaker")) {
               return Items.SHIELD;
            }
            break;
         case -721818682:
            if (var1.equals("swing_speed")) {
               return Items.CLOCK;
            }
            break;
         case -646302923:
            if (var1.equals("autolog")) {
               return Items.PAPER;
            }
            break;
         case -646295210:
            if (var1.equals("autotpa")) {
               return Items.ENDER_PEARL;
            }
            break;
         case -633657918:
            if (var1.equals("anchor_macro")) {
               return Items.RESPAWN_ANCHOR;
            }
            break;
         case -604554815:
            if (var1.equals("killaura")) {
               return Items.DIAMOND_SWORD;
            }
            break;
         case -603799069:
            if (var1.equals("freecam")) {
               return Items.ENDER_EYE;
            }
            break;
         case -600094315:
            if (var1.equals("friends")) {
               return Items.PLAYER_HEAD;
            }
            break;
         case -525253186:
            if (var1.equals("storage_esp")) {
               return Items.CHEST;
            }
            break;
         case -485357535:
            if (var1.equals("skinscraper")) {
               return Items.LEATHER_CHESTPLATE;
            }
            break;
         case -483412593:
            if (var1.equals("antitrap")) {
               return Items.TRIPWIRE_HOOK;
            }
            break;
         case -406812957:
            if (var1.equals("double_anchor")) {
               return Items.RESPAWN_ANCHOR;
            }
            break;
         case -363042231:
            if (var1.equals("fullbright")) {
               return Items.GLOWSTONE;
            }
            break;
         case -252984109:
            if (var1.equals("extra_esp")) {
               return Items.GLASS;
            }
            break;
         case -247831194:
            if (var1.equals("sus_chunk_finder")) {
               return Items.SUSPICIOUS_SAND;
            }
            break;
         case -212063490:
            if (var1.equals("hover_totem")) {
               return Items.TOTEM_OF_UNDYING;
            }
            break;
         case -210027214:
            if (var1.equals("dev_spawner_visuals")) {
               return Items.SPAWNER;
            }
            break;
         case -39199439:
            if (var1.equals("auto_totem")) {
               return Items.TOTEM_OF_UNDYING;
            }
            break;
         case -38886664:
            if (var1.equals("spawner_protect")) {
               return Items.SPAWNER;
            }
            break;
         case 103671:
            if (var1.equals("hud")) {
               return Items.MAP;
            }
            break;
         case 29713809:
            if (var1.equals("weather_notifier")) {
               return Items.LIGHTNING_ROD;
            }
            break;
         case 258689162:
            if (var1.equals("bonedropper")) {
               return Items.BONE;
            }
            break;
         case 415315984:
            if (var1.equals("sky_shaders")) {
               return Items.END_CRYSTAL;
            }
            break;
         case 671061161:
            if (var1.equals("schematic_builder")) {
               return Items.SCAFFOLDING;
            }
            break;
         case 756305249:
            if (var1.equals("elytra_swap")) {
               return Items.ELYTRA;
            }
            break;
         case 872771280:
            if (var1.equals("block_esp")) {
               return Items.GLASS;
            }
            break;
         case 1033601164:
            if (var1.equals("fake_tier")) {
               return Items.NAME_TAG;
            }
            break;
         case 1051001992:
            if (var1.equals("fakeroles")) {
               return Items.PAPER;
            }
            break;
         case 1052064362:
            if (var1.equals("fakestats")) {
               return Items.PAPER;
            }
            break;
         case 1126033155:
            if (var1.equals("water_+")) {
               return Items.WATER_BUCKET;
            }
            break;
         case 1350967808:
            if (var1.equals("skin_changer")) {
               return Items.LEATHER_CHESTPLATE;
            }
            break;
         case 1363520783:
            if (var1.equals("triggerbot")) {
               return Items.BOW;
            }
            break;
         case 1369338525:
            if (var1.equals("spawner_notifier")) {
               return Items.SPAWNER;
            }
            break;
         case 1525232897:
            if (var1.equals("radiusdebug")) {
               return Items.STICK;
            }
            break;
         case 1661303336:
            if (var1.equals("auto_tool")) {
               return Items.DIAMOND_PICKAXE;
            }
            break;
         case 1799004702:
            if (var1.equals("homesetter")) {
               return Items.RED_BED;
            }
            break;
         case 1841525028:
            if (var1.equals("nametags")) {
               return Items.NAME_TAG;
            }
            break;
         case 1844733621:
            if (var1.equals("auto_chunk_loader")) {
               return Items.ENDER_CHEST;
            }
            break;
         case 1896054282:
            if (var1.equals("smooth_builder")) {
               return Items.SCAFFOLDING;
            }
      }

      return null;
   }

   private Item categoryDefaultItem() {
      return switch (this.category) {
         case COMBAT -> Items.DIAMOND_SWORD;
         case RENDER -> Items.ENDER_EYE;
         case MISC -> Items.COMPASS;
         case CLIENT -> Items.WATER_BUCKET;
         default -> Items.PAPER;
      };
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public void toggle() {
      this.setEnabled(!this.enabled);
   }

   public void onBindPressed() {
      this.toggle();
   }

   public int getBind() {
      return this.bind;
   }

   public void setBind(int bind) {
      this.bind = bind;
      ModuleManager.INSTANCE.saveConfig();
   }

   void applyBind(int bind) {
      this.bind = bind;
   }

   void applyEnabled(boolean enabled) {
      this.enabled = enabled;
   }

   public boolean isExpanded() {
      return this.expanded;
   }

   public void setExpanded(boolean expanded) {
      this.expanded = expanded;
   }

   public void onEnable() {
   }

   public void onDisable() {
   }

   public void onTick() {
   }

   public void onRender(MatrixStack matrices, float tickDelta) {
   }

   public void onPacketReceive(Packet<?> packet) {
   }

   public boolean onPacketSend(Packet<?> packet) {
      return false;
   }

   static String _c8cc94c8a16() {
      return "_";
   }
}

