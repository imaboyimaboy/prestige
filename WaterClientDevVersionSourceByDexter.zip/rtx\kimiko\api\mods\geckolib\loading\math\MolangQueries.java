package rtx.kimiko.api.mods.geckolib.loading.math;

import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.Reference2DoubleMap;
import it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap;
import java.util.Arrays;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.ToDoubleFunction;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentHolder;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.Leashable;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Tameable;
import net.minecraft.entity.ai.pathing.AmphibiousSwimNavigation;
import net.minecraft.entity.ai.pathing.BirdNavigation;
import net.minecraft.entity.ai.pathing.MobNavigation;
import net.minecraft.entity.ai.pathing.SpiderNavigation;
import net.minecraft.entity.ai.pathing.SwimNavigation;
import net.minecraft.entity.mob.Angerable;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.dimension.DimensionType;
import rtx.kimiko.api.mods.geckolib.animatable.GeoAnimatable;
import rtx.kimiko.api.mods.geckolib.animation.AnimationController;
import rtx.kimiko.api.mods.geckolib.animation.state.ControllerState;
import rtx.kimiko.api.mods.geckolib.constant.DataTickets;
import rtx.kimiko.api.mods.geckolib.loading.math.value.Variable;
import rtx.kimiko.api.mods.geckolib.renderer.base.GeoRenderState;
import rtx.kimiko.api.mods.geckolib.util.ClientUtil;

public final class MolangQueries {
   public static final String ACTOR_COUNT = "query.actor_count";
   public static final String ANIM_TIME = "query.anim_time";
   public static final String BLOCK_STATE = "query.block_state";
   public static final String BLOCKING = "query.blocking";
   public static final String BODY_X_ROTATION = "query.body_x_rotation";
   public static final String BODY_Y_ROTATION = "query.body_y_rotation";
   public static final String CAN_CLIMB = "query.can_climb";
   public static final String CAN_FLY = "query.can_fly";
   public static final String CAN_SWIM = "query.can_swim";
   public static final String CAN_WALK = "query.can_walk";
   public static final String CARDINAL_FACING = "query.cardinal_facing";
   public static final String CARDINAL_FACING_2D = "query.cardinal_facing_2d";
   public static final String CARDINAL_PLAYER_FACING = "query.cardinal_player_facing";
   public static final String CONTROLLER_SPEED = "query.controller_speed";
   public static final String DAY = "query.day";
   public static final String DEATH_TICKS = "query.death_ticks";
   public static final String DISTANCE_FROM_CAMERA = "query.distance_from_camera";
   public static final String EQUIPMENT_COUNT = "query.equipment_count";
   public static final String FRAME_ALPHA = "query.frame_alpha";
   public static final String GET_ACTOR_INFO_ID = "query.get_actor_info_id";
   public static final String GROUND_SPEED = "query.ground_speed";
   public static final String HAS_CAPE = "query.has_cape";
   public static final String HAS_COLLISION = "query.has_collision";
   public static final String HAS_GRAVITY = "query.has_gravity";
   public static final String HAS_HEAD_GEAR = "query.has_head_gear";
   public static final String HAS_OWNER = "query.has_owner";
   public static final String HAS_PLAYER_RIDER = "query.has_player_rider";
   public static final String HAS_RIDER = "query.has_rider";
   public static final String HEAD_X_ROTATION = "query.head_x_rotation";
   public static final String HEAD_Y_ROTATION = "query.head_y_rotation";
   public static final String HEALTH = "query.health";
   public static final String HURT_TIME = "query.hurt_time";
   public static final String INVULNERABLE_TICKS = "query.invulnerable_ticks";
   public static final String IS_ALIVE = "query.is_alive";
   public static final String IS_ANGRY = "query.is_angry";
   public static final String IS_BABY = "query.is_baby";
   public static final String IS_BREATHING = "query.is_breathing";
   public static final String IS_ENCHANTED = "query.is_enchanted";
   public static final String IS_FIRE_IMMUNE = "query.is_fire_immune";
   public static final String IS_FIRST_PERSON = "query.is_first_person";
   public static final String IS_IN_CONTACT_WITH_WATER = "query.is_in_contact_with_water";
   public static final String IS_IN_LAVA = "query.is_in_lava";
   public static final String IS_IN_WATER = "query.is_in_water";
   public static final String IS_IN_WATER_OR_RAIN = "query.is_in_water_or_rain";
   public static final String IS_INVISIBLE = "query.is_invisible";
   public static final String IS_LEASHED = "query.is_leashed";
   public static final String IS_MOVING = "query.is_moving";
   public static final String IS_ON_FIRE = "query.is_on_fire";
   public static final String IS_ON_GROUND = "query.is_on_ground";
   public static final String IS_RIDING = "query.is_riding";
   public static final String IS_SADDLED = "query.is_saddled";
   public static final String IS_SILENT = "query.is_silent";
   public static final String IS_SLEEPING = "query.is_sleeping";
   public static final String IS_SNEAKING = "query.is_sneaking";
   public static final String IS_SPRINTING = "query.is_sprinting";
   public static final String IS_STACKABLE = "query.is_stackable";
   public static final String IS_SWIMMING = "query.is_swimming";
   public static final String IS_USING_ITEM = "query.is_using_item";
   public static final String IS_WALL_CLIMBING = "query.is_wall_climbing";
   public static final String ITEM_MAX_USE_DURATION = "query.item_max_use_duration";
   public static final String LIFE_TIME = "query.life_time";
   public static final String LIMB_SWING = "query.limb_swing";
   public static final String LIMB_SWING_AMOUNT = "query.limb_swing_amount";
   public static final String MAIN_HAND_ITEM_MAX_DURATION = "query.main_hand_item_max_duration";
   public static final String MAIN_HAND_ITEM_USE_DURATION = "query.main_hand_item_use_duration";
   public static final String MAX_DURABILITY = "query.max_durability";
   public static final String MAX_HEALTH = "query.max_health";
   public static final String MOON_BRIGHTNESS = "query.moon_brightness";
   public static final String MOON_PHASE = "query.moon_phase";
   public static final String MOVEMENT_DIRECTION = "query.movement_direction";
   public static final String PLAYER_LEVEL = "query.player_level";
   public static final String REMAINING_DURABILITY = "query.remaining_durability";
   public static final String RIDER_BODY_X_ROTATION = "query.rider_body_x_rotation";
   public static final String RIDER_BODY_Y_ROTATION = "query.rider_body_y_rotation";
   public static final String RIDER_HEAD_X_ROTATION = "query.rider_head_x_rotation";
   public static final String RIDER_HEAD_Y_ROTATION = "query.rider_head_y_rotation";
   public static final String SCALE = "query.scale";
   public static final String SLEEP_ROTATION = "query.sleep_rotation";
   public static final String TIME_OF_DAY = "query.time_of_day";
   public static final String TIME_STAMP = "query.time_stamp";
   public static final String VERTICAL_SPEED = "query.vertical_speed";
   public static final String YAW_SPEED = "query.yaw_speed";
   private static final Map<String, Variable> VARIABLES = new Object2ObjectOpenHashMap();
   private static final Map<Variable, ToDoubleFunction<MolangQueries.Actor<? extends GeoAnimatable>>> ACTOR_VARIABLES = new Reference2ObjectOpenHashMap();

   public static boolean isExistingVariable(String string) {
      return VARIABLES.containsKey(string);
   }

   public static <T extends GeoAnimatable> void buildActorVariables(
      MolangQueries.Actor<T> actor, Set<Variable> set, Reference2DoubleMap<Variable> reference2DoubleMap
   ) {
      for (Variable variable : set) {
         ToDoubleFunction<MolangQueries.Actor<? extends GeoAnimatable>> toDoubleFunction = ACTOR_VARIABLES.get(variable);
         if (toDoubleFunction != null && !reference2DoubleMap.containsKey(variable)) {
            reference2DoubleMap.put(variable, toDoubleFunction.applyAsDouble(actor));
         }
      }
   }

   static Variable getVariableFor(String string2) {
      return VARIABLES.computeIfAbsent(applyPrefixAliases(string2, "query.", "q."), string -> new Variable(string, 0.0));
   }

   static void registerVariable(Variable variable) {
      VARIABLES.put(variable.name(), variable);
   }

   private static void setDefaultBlockEntityQueryValues() {
      setActorVariable(
         "query.block_state",
         actor -> ((BlockEntity)actor.animatable)
            .getCachedState()
            .getBlock()
            .getStateManager()
            .getStates()
            .indexOf(((BlockEntity)actor.animatable).getCachedState())
      );
   }

   private static void setDefaultEntityQueryValues() {
      setActorVariable(
         "query.body_x_rotation", actor -> actor.animatable instanceof LivingEntity ? 0.0 : ((Entity)actor.animatable).getPitch(actor.partialTick)
      );
      setActorVariable("query.body_y_rotation", actor -> {
         double d;
         if (actor.animatable instanceof LivingEntity livingEntity) {
            d = MathHelper.lerp(actor.partialTick, livingEntity.lastBodyYaw, livingEntity.bodyYaw);
         } else {
            d = ((Entity)actor.animatable).getYaw(actor.partialTick);
         }

         return d;
      });
      setActorVariable("query.cardinal_facing", actor -> ((Entity)actor.animatable).getHorizontalFacing().getIndex());
      setActorVariable("query.cardinal_facing_2d", actor -> {
         int n = ((Entity)actor.animatable).getHorizontalFacing().getIndex();
         return n < 2 ? 6.0 : n;
      });
      setActorVariable("query.distance_from_camera", actor -> actor.cameraPos.distanceTo(((Entity)actor.animatable).getEntityPos()));
      setActorVariable("query.get_actor_info_id", actor -> ((Entity)actor.animatable).getId());
      setActorVariable(
         "query.equipment_count",
         actor -> {
            long l;
            if (actor.animatable instanceof EquipmentHolder equipmentHolder) {
               l = Arrays.stream(EquipmentSlot.values())
                  .filter(EquipmentSlot::isArmorSlot)
                  .filter(equipmentSlot -> !equipmentHolder.getEquippedStack(equipmentSlot).isEmpty())
                  .count();
            } else {
               l = 0L;
            }

            return l;
         }
      );
      setActorVariable("query.has_collision", actor -> !((Entity)actor.animatable).noClip ? 1.0 : 0.0);
      setActorVariable("query.has_gravity", actor -> !((Entity)actor.animatable).hasNoGravity() ? 1.0 : 0.0);
      setActorVariable("query.has_owner", actor -> {
         Object t = actor.animatable;
         Tameable tameable;
         return t instanceof Tameable && (tameable = (Tameable)t).getOwnerReference() != null ? 1.0 : 0.0;
      });
      setActorVariable("query.has_player_rider", actor -> ((Entity)actor.animatable).hasPassenger(PlayerEntity.class::isInstance) ? 1.0 : 0.0);
      setActorVariable("query.has_rider", actor -> ((Entity)actor.animatable).hasPassengers() ? 1.0 : 0.0);
      setActorVariable("query.is_alive", actor -> ((Entity)actor.animatable).isAlive() ? 1.0 : 0.0);
      setActorVariable("query.is_angry", actor -> {
         Object t = actor.animatable;
         Angerable angerable;
         return t instanceof Angerable && (angerable = (Angerable)t).hasAngerTime() ? 1.0 : 0.0;
      });
      setActorVariable("query.is_breathing", actor -> ((Entity)actor.animatable).getAir() >= ((Entity)actor.animatable).getMaxAir() ? 1.0 : 0.0);
      setActorVariable("query.is_fire_immune", actor -> ((Entity)actor.animatable).getType().isFireImmune() ? 1.0 : 0.0);
      setActorVariable("query.is_invisible", actor -> ((Entity)actor.animatable).isInvisible() ? 1.0 : 0.0);
      setActorVariable("query.is_in_contact_with_water", actor -> ((Entity)actor.animatable).isTouchingWaterOrRain() ? 1.0 : 0.0);
      setActorVariable("query.is_in_lava", actor -> ((Entity)actor.animatable).isInLava() ? 1.0 : 0.0);
      setActorVariable("query.is_in_water", actor -> ((Entity)actor.animatable).isTouchingWater() ? 1.0 : 0.0);
      setActorVariable("query.is_in_water_or_rain", actor -> ((Entity)actor.animatable).isTouchingWaterOrRain() ? 1.0 : 0.0);
      setActorVariable("query.is_leashed", actor -> {
         Object t = actor.animatable;
         Leashable leashable;
         return t instanceof Leashable && (leashable = (Leashable)t).isLeashed() ? 1.0 : 0.0;
      });
      setActorVariable("query.is_moving", actor -> actor.renderState.getOrDefaultGeckolibData(DataTickets.IS_MOVING, false) ? 1.0 : 0.0);
      setActorVariable("query.is_on_fire", actor -> ((Entity)actor.animatable).isOnFire() ? 1.0 : 0.0);
      setActorVariable("query.is_on_ground", actor -> ((Entity)actor.animatable).isOnGround() ? 1.0 : 0.0);
      setActorVariable("query.is_riding", actor -> ((Entity)actor.animatable).hasVehicle() ? 1.0 : 0.0);
      setActorVariable("query.is_saddled", actor -> {
         Object t = actor.animatable;
         EquipmentHolder equipmentHolder;
         return t instanceof EquipmentHolder && !(equipmentHolder = (EquipmentHolder)t).getEquippedStack(EquipmentSlot.SADDLE).isEmpty() ? 1.0 : 0.0;
      });
      setActorVariable("query.is_silent", actor -> ((Entity)actor.animatable).isSilent() ? 1.0 : 0.0);
      setActorVariable("query.is_sneaking", actor -> ((Entity)actor.animatable).isInSneakingPose() ? 1.0 : 0.0);
      setActorVariable("query.is_sprinting", actor -> ((Entity)actor.animatable).isSprinting() ? 1.0 : 0.0);
      setActorVariable("query.is_swimming", actor -> ((Entity)actor.animatable).isSwimming() ? 1.0 : 0.0);
      setActorVariable(
         "query.movement_direction",
         actor -> actor.renderState.getOrDefaultGeckolibData(DataTickets.IS_MOVING, false)
            ? Direction.getFacing(((Entity)actor.animatable).getVelocity()).getIndex()
            : 6.0
      );
      setActorVariable(
         "query.rider_body_x_rotation",
         actor -> ((Entity)actor.animatable).hasPassengers()
            ? (
               ((Entity)actor.animatable).getFirstPassenger() instanceof LivingEntity
                  ? 0.0
                  : ((Entity)actor.animatable).getFirstPassenger().getPitch(actor.partialTick)
            )
            : 0.0
      );
      setActorVariable("query.rider_body_y_rotation", actor -> {
         double d;
         if (((Entity)actor.animatable).hasPassengers()) {
            if (((Entity)actor.animatable).getFirstPassenger() instanceof LivingEntity livingEntity) {
               d = MathHelper.lerp(actor.partialTick, livingEntity.lastBodyYaw, livingEntity.bodyYaw);
            } else {
               d = ((Entity)actor.animatable).getFirstPassenger().getYaw(actor.partialTick);
            }
         } else {
            d = 0.0;
         }

         return d;
      });
      setActorVariable("query.rider_head_x_rotation", actor -> {
         double d;
         if (((Entity)actor.animatable).getFirstPassenger() instanceof LivingEntity livingEntity) {
            d = livingEntity.getPitch(actor.partialTick);
         } else {
            d = 0.0;
         }

         return d;
      });
      setActorVariable("query.rider_head_y_rotation", actor -> {
         double d;
         if (((Entity)actor.animatable).getFirstPassenger() instanceof LivingEntity livingEntity) {
            d = livingEntity.getYaw(actor.partialTick);
         } else {
            d = 0.0;
         }

         return d;
      });
      setActorVariable("query.vertical_speed", actor -> ((Entity)actor.animatable).getVelocity().y);
      setActorVariable("query.yaw_speed", actor -> ((Entity)actor.animatable).getYaw() - ((Entity)actor.animatable).lastYaw);
   }

   private static void setDefaultLivingEntityQueryValues() {
      setActorVariable("query.blocking", actor -> ((LivingEntity)actor.animatable).isBlocking() ? 1.0 : 0.0);
      setActorVariable(
         "query.death_ticks", actor -> ((LivingEntity)actor.animatable).deathTime == 0 ? 0.0 : ((LivingEntity)actor.animatable).deathTime + actor.partialTick
      );
      setActorVariable("query.ground_speed", actor -> ((LivingEntity)actor.animatable).getVelocity().horizontalLength());
      setActorVariable("query.has_head_gear", actor -> !((LivingEntity)actor.animatable).getEquippedStack(EquipmentSlot.HEAD).isEmpty() ? 1.0 : 0.0);
      setActorVariable(
         "query.head_x_rotation",
         actor -> actor.renderState
            .getOrDefaultGeckolibData(DataTickets.ENTITY_PITCH, ((LivingEntity)actor.animatable).getPitch(actor.partialTick))
            .floatValue()
      );
      setActorVariable(
         "query.head_y_rotation",
         actor -> actor.renderState.getOrDefaultGeckolibData(DataTickets.ENTITY_YAW, ((LivingEntity)actor.animatable).getYaw(actor.partialTick)).floatValue()
      );
      setActorVariable("query.health", actor -> ((LivingEntity)actor.animatable).getHealth());
      setActorVariable(
         "query.hurt_time", actor -> ((LivingEntity)actor.animatable).hurtTime == 0 ? 0.0 : ((LivingEntity)actor.animatable).hurtTime - actor.partialTick
      );
      setActorVariable(
         "query.invulnerable_ticks",
         actor -> ((LivingEntity)actor.animatable).timeUntilRegen == 0 ? 0.0 : ((LivingEntity)actor.animatable).timeUntilRegen - actor.partialTick
      );
      setActorVariable("query.is_baby", actor -> ((LivingEntity)actor.animatable).isBaby() ? 1.0 : 0.0);
      setActorVariable("query.is_sleeping", actor -> ((LivingEntity)actor.animatable).isSleeping() ? 1.0 : 0.0);
      setActorVariable("query.is_using_item", actor -> ((LivingEntity)actor.animatable).isUsingItem() ? 1.0 : 0.0);
      setActorVariable("query.is_wall_climbing", actor -> ((LivingEntity)actor.animatable).isClimbing() ? 1.0 : 0.0);
      setActorVariable("query.limb_swing", actor -> ((LivingEntity)actor.animatable).limbAnimator.getAnimationProgress());
      setActorVariable("query.limb_swing_amount", actor -> ((LivingEntity)actor.animatable).limbAnimator.getAmplitude(actor.partialTick()));
      setActorVariable(
         "query.main_hand_item_max_duration", actor -> ((LivingEntity)actor.animatable).getMainHandStack().getMaxUseTime((LivingEntity)actor.animatable)
      );
      setActorVariable(
         "query.main_hand_item_use_duration",
         actor -> ((LivingEntity)actor.animatable).getActiveHand() == Hand.MAIN_HAND
            ? ((LivingEntity)actor.animatable).getItemUseTime() / 20.0 + actor.partialTick
            : 0.0
      );
      setActorVariable("query.max_health", actor -> ((LivingEntity)actor.animatable).getMaxHealth());
      setActorVariable("query.scale", actor -> ((LivingEntity)actor.animatable).getScale());
      setActorVariable(
         "query.sleep_rotation",
         actor -> Optional.ofNullable(((LivingEntity)actor.animatable).getSleepingDirection())
            .<Float>map(Direction::getPositiveHorizontalDegrees)
            .orElse(0.0F)
            .floatValue()
      );
   }

   public static <T extends GeoAnimatable> void setVariableFunction(String string, ToDoubleFunction<ControllerState> toDoubleFunction) {
      Variable variable = getVariableFor(string);
      if (ACTOR_VARIABLES.containsKey(variable)) {
         throw new IllegalArgumentException("Cannot replace actor variables");
      } else {
         variable.set(toDoubleFunction);
      }
   }

   private static void setDefaultQueryValues() {
      setVariableValue("PI", Math.PI);
      setVariableValue("E", Math.E);
      setActorVariable("query.actor_count", actor -> ClientUtil.getVisibleEntityCount());
      setActorVariable("query.anim_time", actor -> actor.controller.getCurrentAnimationTime());
      setActorVariable("query.controller_speed", actor -> actor.controller.getAnimationSpeed());
      setActorVariable("query.cardinal_player_facing", actor -> actor.clientPlayer.getHorizontalFacing().ordinal());
      setActorVariable("query.day", actor -> actor.level.getTime() / 24000.0);
      setActorVariable("query.frame_alpha", actor -> actor.partialTick);
      setActorVariable("query.has_cape", actor -> ClientUtil.clientPlayerHasCape() ? 1.0 : 0.0);
      setActorVariable("query.is_first_person", actor -> ClientUtil.isFirstPerson() ? 1.0 : 0.0);
      setActorVariable("query.life_time", actor -> actor.renderTime / 20.0);
      setActorVariable("query.moon_brightness", actor -> DimensionType.MOON_SIZES[ClientUtil.getClientMoonPhase().getIndex()]);
      setActorVariable("query.moon_phase", actor -> ClientUtil.getClientMoonPhase().getIndex());
      setActorVariable("query.player_level", actor -> actor.clientPlayer.experienceLevel);
      setActorVariable("query.time_of_day", actor -> actor.level.getTimeOfDay() / 24000.0);
      setActorVariable("query.time_stamp", actor -> actor.level.getTime());
      setDefaultBlockEntityQueryValues();
      setDefaultEntityQueryValues();
      setDefaultLivingEntityQueryValues();
      setDefaultMobQueryValues();
      setDefaultItemQueryValues();
   }

   private static String applyPrefixAliases(String string, String string2, String... stringArray) {
      for (String string3 : stringArray) {
         if (string.startsWith(string3)) {
            return string2 + string.substring(string3.length());
         }
      }

      return string;
   }

   private static void setDefaultMobQueryValues() {
      setActorVariable(
         "query.can_climb",
         actor -> !((MobEntity)actor.animatable).isAiDisabled() && ((MobEntity)actor.animatable).getNavigation() instanceof SpiderNavigation ? 1.0 : 0.0
      );
      setActorVariable(
         "query.can_fly",
         actor -> !((MobEntity)actor.animatable).isAiDisabled() && ((MobEntity)actor.animatable).getNavigation() instanceof BirdNavigation ? 1.0 : 0.0
      );
      setActorVariable(
         "query.can_swim",
         actor -> (((MobEntity)actor.animatable).isAiDisabled() || !(((MobEntity)actor.animatable).getNavigation() instanceof SwimNavigation))
               && !(((MobEntity)actor.animatable).getNavigation() instanceof AmphibiousSwimNavigation)
            ? 0.0
            : 1.0
      );
      setActorVariable(
         "query.can_walk",
         actor -> (((MobEntity)actor.animatable).isAiDisabled() || !(((MobEntity)actor.animatable).getNavigation() instanceof MobNavigation))
               && !(((MobEntity)actor.animatable).getNavigation() instanceof AmphibiousSwimNavigation)
            ? 0.0
            : 1.0
      );
   }

   public static void setVariableValue(String string, double d) {
      Variable variable = getVariableFor(string);
      if (ACTOR_VARIABLES.containsKey(variable)) {
         throw new IllegalArgumentException("Cannot replace actor variables");
      } else {
         variable.set(d);
      }
   }

   public static <T extends GeoAnimatable> void setActorVariable(String string, ToDoubleFunction<MolangQueries.Actor<T>> toDoubleFunction) {
      Variable variable = getVariableFor(string);
      ACTOR_VARIABLES.put(variable, (ToDoubleFunction<MolangQueries.Actor<? extends GeoAnimatable>>)(ToDoubleFunction<?>)toDoubleFunction);
      variable.set(controllerState -> controllerState.getQueryValue(variable));
   }

   private static void setDefaultItemQueryValues() {
      setActorVariable("query.is_enchanted", actor -> actor.renderState.getGeckolibData(DataTickets.IS_ENCHANTED) ? 1.0 : 0.0);
      setActorVariable("query.is_stackable", actor -> actor.renderState.getGeckolibData(DataTickets.IS_STACKABLE) ? 1.0 : 0.0);
      setActorVariable("query.item_max_use_duration", actor -> actor.renderState.getGeckolibData(DataTickets.MAX_USE_DURATION).intValue());
      setActorVariable("query.max_durability", actor -> actor.renderState.getGeckolibData(DataTickets.MAX_DURABILITY).intValue());
      setActorVariable("query.remaining_durability", actor -> actor.renderState.getGeckolibData(DataTickets.REMAINING_DURABILITY).intValue());
   }

   static {
      setDefaultQueryValues();
   }

   public static final class Actor<T extends GeoAnimatable> {
      private T animatable;
      private GeoRenderState renderState;
      private final AnimationController<?> controller;
      private double renderTime;
      private float partialTick;
      private World level;
      private PlayerEntity clientPlayer;
      private Vec3d cameraPos;

      public Actor(
         T animatable,
         GeoRenderState renderState,
         AnimationController<?> controller,
         double renderTime,
         float partialTick,
         World level,
         PlayerEntity clientPlayer,
         Vec3d cameraPos
      ) {
         this.animatable = animatable;
         this.renderState = renderState;
         this.controller = controller;
         this.renderTime = renderTime;
         this.partialTick = partialTick;
         this.level = level;
         this.clientPlayer = clientPlayer;
         this.cameraPos = cameraPos;
      }

      public T animatable() {
         return this.animatable;
      }

      public GeoRenderState renderState() {
         return this.renderState;
      }

      public AnimationController<?> controller() {
         return this.controller;
      }

      public double renderTime() {
         return this.renderTime;
      }

      public float partialTick() {
         return this.partialTick;
      }

      public World level() {
         return this.level;
      }

      public PlayerEntity clientPlayer() {
         return this.clientPlayer;
      }

      public Vec3d cameraPos() {
         return this.cameraPos;
      }
   }
}

