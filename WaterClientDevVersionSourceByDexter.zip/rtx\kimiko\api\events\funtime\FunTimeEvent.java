package rtx.kimiko.api.events.funtime;

public final class FunTimeEvent {
   private String name;
   private int anarchy;
   private int seconds;
   private String status;
   private String rarity;

   public FunTimeEvent(String name, int anarchy, int seconds, String status, String rarity) {
      this.name = name;
      this.anarchy = anarchy;
      this.seconds = seconds;
      this.status = status;
      this.rarity = rarity;
   }

   public String name() {
      return this.name;
   }

   public int anarchy() {
      return this.anarchy;
   }

   public int seconds() {
      return this.seconds;
   }

   public String status() {
      return this.status;
   }

   public String rarity() {
      return this.rarity;
   }
}

