package com.water.module.modules.misc;

final class AutoMineRotation {
   private float yawSpeed;
   private float pitchSpeed;

   void reset() {
      this.yawSpeed = this.pitchSpeed = 0.0F;
   }

   private static float clamp(float v, float limit) {
      return Math.max(-limit, Math.min(limit, v));
   }

   private static float wrap(float v) {
      v %= 360.0F;
      if (v >= 180.0F) {
         v -= 360.0F;
      }

      if (v < -180.0F) {
         v += 360.0F;
      }

      return v;
   }

   private static float speed(float error, float previous, float maximum, float acceleration) {
      float desired = clamp(error * 0.2F, maximum);
      float next = previous + clamp(desired - previous, acceleration);
      return next * error <= 0.0F ? 0.0F : Math.copySign(Math.min(Math.abs(next), Math.abs(error)), error);
   }

   float[] step(float yaw, float pitch, float targetYaw, float targetPitch) {
      float dy = wrap(targetYaw - yaw);
      float dp = Math.max(-90.0F, Math.min(90.0F, targetPitch)) - pitch;
      this.yawSpeed = speed(dy, this.yawSpeed, 6.0F, 1.2F);
      this.pitchSpeed = speed(dp, this.pitchSpeed, 4.0F, 0.8F);
      return new float[]{yaw + this.yawSpeed, Math.max(-90.0F, Math.min(90.0F, pitch + this.pitchSpeed))};
   }
}

