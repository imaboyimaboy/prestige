package dev.fakeranks.mixin;

import dev.fakeranks.FakeRanksClient;
import net.minecraft.scoreboard.ScoreboardEntry;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({ScoreboardEntry.class})
public abstract class ScoreboardEntryMixin {
   @Inject(
      method = {"name"},
      at = {@At("RETURN")},
      cancellable = true,
      require = 0
   )
   private void fakeranks$name(CallbackInfoReturnable<Text> info) {
      ScoreboardEntry entry = (ScoreboardEntry)(Object)this;
      String realName = FakeRanksClient.STATE.realPlayerName();
      if (FakeRanksClient.STATE.enabled()) {
         Text current = (Text)info.getReturnValue();
         if (entry.owner().equals(realName) || current.getString().equals(realName)) {
            info.setReturnValue(FakeRanksClient.STATE.plainNameText());
         }
      }
   }
}

