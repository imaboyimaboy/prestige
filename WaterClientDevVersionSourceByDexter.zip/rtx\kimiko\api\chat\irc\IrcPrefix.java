package rtx.kimiko.api.chat.irc;

import java.util.Locale;
import net.minecraft.text.Text;
import rtx.kimiko.utils.string.chat.helper.TextHelper;

public enum IrcPrefix {
   NONE("none", "", "", false),
   PRISM("prism", "Призма", "astolfo", false),
   VECTOR("vector", "Вектор", "red_blue", false),
   SUNSET("sunset", "Закат", "orange_magenta", false),
   MAGMA("magma", "Магма", "red_orange", false),
   GARNET("garnet", "Гранат", "purple_bright_pink", false),
   RIME("rime", "Иней", "turquoise_blue", false),
   PHOENIX("phoenix", "Феникс", "bright_red", false),
   MALACHITE("malachite", "Малахит", "dark_green_bright_green", false),
   NOCTURNE("nocturne", "Ноктюрн", "black_light_purple", false),
   GRIN("grin", "(｡◕‿‿◕｡)", "yellow_cyan", true),
   QUARTZ("quartz", "Кварц", "cyan_orange_fade", false),
   AMBER("amber", "Янтарь", "orange_white", false),
   ETHER("ether", "Эфир", "blue_green_fade", false),
   NEBULA("nebula", "Небула", "purple_red_fade", false),
   CHIMERA("chimera", "Химера", "green_purple", false),
   ECLIPSE("eclipse", "Затмение", "white_black", false),
   EMBER("ember", "Уголёк", "dark_red_bright_red", false),
   CARDINAL("cardinal", "Кардинал", "dark_red", false),
   SAKURA("sakura", "Сакура", "pink_dark_pink", false),
   BLAZE("blaze", "Пламя", "red_white", false);

   private String id;
   private String display;
   private String gradient;
   private boolean bold;

   private IrcPrefix(String id, String display, String gradient, boolean bold) {
      this.id = id;
      this.display = display;
      this.gradient = gradient;
      this.bold = bold;
   }

   public Text component() {
      return (Text)(this.isNone() ? Text.empty() : TextHelper.applyPredefinedGradient(this.display + " ", this.gradient, this.bold));
   }

   public String id() {
      return this.id;
   }

   public String display() {
      return this.display;
   }

   public boolean isNone() {
      return this == NONE;
   }

   public static IrcPrefix fromId(String string) {
      if (string != null && !string.isBlank()) {
         String string2 = string.trim().toLowerCase(Locale.ROOT);

         for (IrcPrefix ircPrefix : values()) {
            if (ircPrefix.id.equals(string2) || ircPrefix.display.toLowerCase(Locale.ROOT).equals(string2)) {
               return ircPrefix;
            }
         }

         return NONE;
      } else {
         return NONE;
      }
   }

   public static String[] ids() {
      IrcPrefix[] ircPrefixArray = values();
      String[] stringArray = new String[ircPrefixArray.length];

      for (int i = 0; i < ircPrefixArray.length; i++) {
         stringArray[i] = ircPrefixArray[i].id;
      }

      return stringArray;
   }

   private static IrcPrefix[] $values() {
      return new IrcPrefix[]{
         NONE,
         PRISM,
         VECTOR,
         SUNSET,
         MAGMA,
         GARNET,
         RIME,
         PHOENIX,
         MALACHITE,
         NOCTURNE,
         GRIN,
         QUARTZ,
         AMBER,
         ETHER,
         NEBULA,
         CHIMERA,
         ECLIPSE,
         EMBER,
         CARDINAL,
         SAKURA,
         BLAZE
      };
   }
}

