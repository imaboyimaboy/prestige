package com.water.mixin;

import com.water.module.modules.donut.FakeStats;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({PlayerListHud.class})
public class PlayerListHudMixin {
   @Shadow
   private Text footer;

   @Inject(
      method = {"render"},
      at = {@At("HEAD")}
   )
   private void water$fakeFooter(DrawContext context, int scaledWindowWidth, Scoreboard scoreboard, ScoreboardObjective objective, CallbackInfo ci) {
      FakeStats fs = FakeStats.getInstance();
      if (fs != null && fs.isEnabled() && this.footer != null) {
         Text faked = fs.fakeFooterText(this.footer);
         if (faked != null) {
            this.footer = faked;
         }
      }
   }
}

