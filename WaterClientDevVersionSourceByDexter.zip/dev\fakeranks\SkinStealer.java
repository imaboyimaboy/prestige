package dev.fakeranks;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.yggdrasil.ProfileResult;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.SkinTextures;

public class SkinStealer {
   private volatile SkinTextures skin;
   private volatile UUID profileUuid;
   private volatile String requestedName = "";

   public SkinTextures skin() {
      return this.skin;
   }

   public UUID profileUuid() {
      return this.profileUuid;
   }

   public void clear() {
      this.skin = null;
      this.profileUuid = null;
      this.requestedName = "";
   }

   public void request(String username) {
      String clean = username == null ? "" : username.trim();
      if (!clean.isEmpty()) {
         if (this.skin == null || !clean.equalsIgnoreCase(this.requestedName)) {
            this.skin = null;
            this.requestedName = clean;
            CompletableFuture.<Optional<GameProfile>>supplyAsync(() -> this.profileFor(clean))
               .thenAccept(profile -> profile.ifPresent(this::fetchSkinTextures))
               .exceptionally(ignored -> null);
         }
      }
   }

   private void fetchSkinTextures(GameProfile profile) {
      MinecraftClient client = MinecraftClient.getInstance();
      this.profileUuid = profile.id();
      client.getSkinProvider().fetchSkinTextures(profile).thenAccept(textures -> {
         if (profile.name().equalsIgnoreCase(this.requestedName)) {
            textures.ifPresent(found -> client.execute(() -> {
               this.profileUuid = profile.id();
               this.skin = found;
            }));
         }
      });
   }

   private Optional<GameProfile> profileFor(String username) {
      try {
         String encoded = URI.create("https://api.mojang.com/users/profiles/minecraft/null").toASCIIString();
         HttpURLConnection connection = (HttpURLConnection)URI.create(encoded).toURL().openConnection();
         connection.setConnectTimeout(5000);
         connection.setReadTimeout(5000);
         connection.setRequestProperty("User-Agent", "FakeRanks/1.0");
         if (connection.getResponseCode() != 200) {
            return Optional.empty();
         } else {
            Optional var10;
            try (InputStreamReader reader = new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8)) {
               JsonObject object = JsonParser.parseReader(reader).getAsJsonObject();
               UUID uuid = this.undashedUuid(object.get("id").getAsString());
               String name = object.has("name") ? object.get("name").getAsString() : username;
               GameProfile profile = new GameProfile(uuid, name);
               ProfileResult result = MinecraftClient.getInstance().getApiServices().sessionService().fetchProfile(uuid, true);
               var10 = Optional.of(result == null ? profile : result.profile());
            }

            return var10;
         }
      } catch (Throwable var13) {
         return Optional.empty();
      }
   }

   private UUID undashedUuid(String id) {
      String value = id.toLowerCase(Locale.ROOT);
      return UUID.fromString(
         value.substring(0, 8) + "-" + value.substring(8, 12) + "-" + value.substring(12, 16) + "-" + value.substring(16, 20) + "-" + value.substring(20)
      );
   }
}

