package rtx.kimiko.api.mods.acountswiher.ru.vidtu.ias.config;

import java.nio.file.Path;
import java.util.Collections;
import java.util.List;

public final class IASServerShortcutsConfig {
   private IASServerShortcutsConfig() {
   }

   public static List<IASServerShortcutsConfig.ShortcutEntry> load(Path path) {
      return Collections.emptyList();
   }

   public final class ShortcutEntry {
      private String name;
      private String address;
      private String icon;

      public ShortcutEntry(String name, String address, String icon) {
         this.name = name;
         this.address = address;
         this.icon = icon;
      }

      public String name() {
         return this.name;
      }

      public String address() {
         return this.address;
      }

      public String icon() {
         return this.icon;
      }
   }
}

