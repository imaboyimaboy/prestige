package com.water.utils.renderer;

import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL14;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

public final class ESPGlowRenderer {
   private static int fboGeometry = -1;
   private static int texGeometry = -1;
   private static int fboBlurH = -1;
   private static int texBlurH = -1;
   private static int fboBlurV = -1;
   private static int texBlurV = -1;
   private static int progBlurH = -1;
   private static int progBlurV = -1;
   private static int progComposite = -1;
   private static int lastW = -1;
   private static int lastH = -1;
   private static boolean active = false;
   private static int savedFbo = 0;
   private static boolean shadersOk = false;
   public static float glowStrength = 2.0F;

   private ESPGlowRenderer() {
   }

   public static void begin() {
      if (!active) {
         MinecraftClient mc = MinecraftClient.getInstance();
         int w = mc.getFramebuffer().textureWidth;
         int h = mc.getFramebuffer().textureHeight;

         try {
            ensureResources(w, h);
         } catch (Exception var4) {
            System.err.println("[ESPGlowRenderer] Shader init failed: " + var4.getMessage());
            shadersOk = false;
            return;
         }

         if (shadersOk) {
            savedFbo = GL11.glGetInteger(36006);
            GL30.glBindFramebuffer(36160, fboGeometry);
            GL11.glClearColor(0.0F, 0.0F, 0.0F, 0.0F);
            GL11.glClear(16384);
            active = true;
         }
      }
   }

   public static void end() {
      if (active && shadersOk) {
         active = false;
         int w = lastW;
         int h = lastH;
         boolean blendWasOn = GL11.glIsEnabled(3042);
         boolean depthWasOn = GL11.glIsEnabled(2929);
         boolean depthMask = GL11.glGetBoolean(2930);
         int prevSrcRGB = GL11.glGetInteger(32969);
         int prevDstRGB = GL11.glGetInteger(32968);
         GL11.glDisable(2929);
         GL11.glDepthMask(false);
         GL30.glBindFramebuffer(36160, fboBlurH);
         GL11.glClearColor(0.0F, 0.0F, 0.0F, 0.0F);
         GL11.glClear(16384);
         GL11.glDisable(3042);
         GL20.glUseProgram(progBlurH);
         GL13.glActiveTexture(33984);
         GL11.glBindTexture(3553, texGeometry);
         GL20.glUniform1i(GL20.glGetUniformLocation(progBlurH, "Sampler0"), 0);
         GL20.glUniform2f(GL20.glGetUniformLocation(progBlurH, "uResolution"), w, h);
         GL11.glDrawArrays(4, 0, 6);
         GL30.glBindFramebuffer(36160, fboBlurV);
         GL11.glClear(16384);
         GL20.glUseProgram(progBlurV);
         GL13.glActiveTexture(33984);
         GL11.glBindTexture(3553, texBlurH);
         GL20.glUniform1i(GL20.glGetUniformLocation(progBlurV, "Sampler0"), 0);
         GL20.glUniform2f(GL20.glGetUniformLocation(progBlurV, "uResolution"), w, h);
         GL11.glDrawArrays(4, 0, 6);
         GL30.glBindFramebuffer(36160, savedFbo);
         GL11.glEnable(3042);
         GL14.glBlendFuncSeparate(770, 771, 1, 771);
         GL20.glUseProgram(progComposite);
         GL13.glActiveTexture(33984);
         GL11.glBindTexture(3553, texGeometry);
         GL20.glUniform1i(GL20.glGetUniformLocation(progComposite, "Sampler0"), 0);
         GL13.glActiveTexture(33985);
         GL11.glBindTexture(3553, texBlurV);
         GL20.glUniform1i(GL20.glGetUniformLocation(progComposite, "Sampler1"), 1);
         GL20.glUniform1f(GL20.glGetUniformLocation(progComposite, "uGlowStrength"), glowStrength);
         GL11.glDrawArrays(4, 0, 6);
         GL20.glUseProgram(0);
         GL13.glActiveTexture(33985);
         GL11.glBindTexture(3553, 0);
         GL13.glActiveTexture(33984);
         GL11.glBindTexture(3553, 0);
         GL14.glBlendFuncSeparate(prevSrcRGB, prevDstRGB, prevSrcRGB, prevDstRGB);
         if (!blendWasOn) {
            GL11.glDisable(3042);
         }

         if (depthWasOn) {
            GL11.glEnable(2929);
         }

         GL11.glDepthMask(depthMask);
      }
   }

   public static boolean isActive() {
      return active;
   }

   private static void ensureResources(int w, int h) {
      if (w != lastW || h != lastH || fboGeometry == -1 || !shadersOk) {
         lastW = w;
         lastH = h;
         deleteResources();
         texGeometry = createTexture(w, h);
         texBlurH = createTexture(w, h);
         texBlurV = createTexture(w, h);
         fboGeometry = createFbo(texGeometry);
         fboBlurH = createFbo(texBlurH);
         fboBlurV = createFbo(texBlurV);
         String vert = loadShader("esp_glow_vertex.vsh");
         progBlurH = compileProgram(vert, loadShader("esp_blur_h_fragment.fsh"));
         progBlurV = compileProgram(vert, loadShader("esp_blur_v_fragment.fsh"));
         progComposite = compileProgram(vert, loadShader("esp_composite_fragment.fsh"));
         shadersOk = true;
      }
   }

   private static int createTexture(int w, int h) {
      int tex = GL11.glGenTextures();
      GL11.glBindTexture(3553, tex);
      GL11.glTexImage2D(3553, 0, 6408, w, h, 0, 6408, 5121, (ByteBuffer)null);
      GL11.glTexParameteri(3553, 10241, 9729);
      GL11.glTexParameteri(3553, 10240, 9729);
      GL11.glTexParameteri(3553, 10242, 33071);
      GL11.glTexParameteri(3553, 10243, 33071);
      return tex;
   }

   private static int createFbo(int tex) {
      int fbo = GL30.glGenFramebuffers();
      GL30.glBindFramebuffer(36160, fbo);
      GL30.glFramebufferTexture2D(36160, 36064, 3553, tex, 0);
      GL30.glBindFramebuffer(36160, 0);
      return fbo;
   }

   private static void deleteResources() {
      if (fboGeometry != -1) {
         GL30.glDeleteFramebuffers(fboGeometry);
         fboGeometry = -1;
      }

      if (fboBlurH != -1) {
         GL30.glDeleteFramebuffers(fboBlurH);
         fboBlurH = -1;
      }

      if (fboBlurV != -1) {
         GL30.glDeleteFramebuffers(fboBlurV);
         fboBlurV = -1;
      }

      if (texGeometry != -1) {
         GL11.glDeleteTextures(texGeometry);
         texGeometry = -1;
      }

      if (texBlurH != -1) {
         GL11.glDeleteTextures(texBlurH);
         texBlurH = -1;
      }

      if (texBlurV != -1) {
         GL11.glDeleteTextures(texBlurV);
         texBlurV = -1;
      }

      shadersOk = false;
   }

   private static String loadShader(String name) {
      try {
         String var2;
         try (InputStream is = ESPGlowRenderer.class.getResourceAsStream("/assets/water/shaders/null")) {
            if (is == null) {
               throw new RuntimeException("Not found: null");
            }

            var2 = new String(is.readAllBytes(), StandardCharsets.UTF_8);
         }

         return var2;
      } catch (Exception var6) {
         throw new RuntimeException("Load failed: null", var6);
      }
   }

   private static int compileProgram(String vertSrc, String fragSrc) {
      int vert = GL20.glCreateShader(35633);
      GL20.glShaderSource(vert, vertSrc);
      GL20.glCompileShader(vert);
      if (GL20.glGetShaderi(vert, 35713) == 0) {
         throw new RuntimeException("VSH: " + GL20.glGetShaderInfoLog(vert));
      } else {
         int frag = GL20.glCreateShader(35632);
         GL20.glShaderSource(frag, fragSrc);
         GL20.glCompileShader(frag);
         if (GL20.glGetShaderi(frag, 35713) == 0) {
            throw new RuntimeException("FSH: " + GL20.glGetShaderInfoLog(frag));
         } else {
            int prog = GL20.glCreateProgram();
            GL20.glAttachShader(prog, vert);
            GL20.glAttachShader(prog, frag);
            GL20.glLinkProgram(prog);
            GL20.glDeleteShader(vert);
            GL20.glDeleteShader(frag);
            return prog;
         }
      }
   }
}

