package com.water.module.modules.render;

import com.water.module.Category;
import com.water.module.Module;
import com.water.setting.ModeSetting;
import com.water.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

public final class HitAnimation extends Module {
   public static HitAnimation INSTANCE;
   private final ModeSetting mode = new ModeSetting(
      "Animation Mode",
      "Swipe",
      "Swipe",
      "Down",
      "Smooth",
      "Power",
      "Feast",
      "Stab",
      "Overhead",
      "Cross",
      "Slash",
      "Thrust",
      "Lunge",
      "Sigma",
      "Combo",
      "Flux",
      "Off"
   );
   private final Setting<Float> swingSpeed = new Setting<>("Swing Speed", 1.0F, 0.1F, 3.0F);
   private final Setting<Float> swingScale = new Setting<>("Swing Scale", 3.7F, 1.0F, 10.0F);
   private final Setting<Boolean> mainHandOnly = new Setting<>("Main Hand Only", true);
   private final Setting<Boolean> customHandView = new Setting<>("Custom Hand View", false);
   private final Setting<Boolean> syncHands = new Setting<>("Sync Both Hands", false).visibleWhen(this.customHandView::getValue);
   private final Setting<Float> x = new Setting<>("X", 0.0F, -2.0F, 2.0F).visibleWhen(() -> this.customHandView.getValue() && this.syncHands.getValue());
   private final Setting<Float> y = new Setting<>("Y", 0.0F, -2.0F, 2.0F).visibleWhen(() -> this.customHandView.getValue() && this.syncHands.getValue());
   private final Setting<Float> z = new Setting<>("Z", 0.0F, -2.0F, 2.0F).visibleWhen(() -> this.customHandView.getValue() && this.syncHands.getValue());
   private final Setting<Float> rightX = new Setting<>("Right X", 0.0F, -2.0F, 2.0F)
      .visibleWhen(() -> this.customHandView.getValue() && !this.syncHands.getValue());
   private final Setting<Float> rightY = new Setting<>("Right Y", 0.0F, -2.0F, 2.0F)
      .visibleWhen(() -> this.customHandView.getValue() && !this.syncHands.getValue());
   private final Setting<Float> rightZ = new Setting<>("Right Z", 0.0F, -2.0F, 2.0F)
      .visibleWhen(() -> this.customHandView.getValue() && !this.syncHands.getValue());
   private final Setting<Float> leftX = new Setting<>("Left X", 0.0F, -2.0F, 2.0F)
      .visibleWhen(() -> this.customHandView.getValue() && !this.syncHands.getValue());
   private final Setting<Float> leftY = new Setting<>("Left Y", 0.0F, -2.0F, 2.0F)
      .visibleWhen(() -> this.customHandView.getValue() && !this.syncHands.getValue());
   private final Setting<Float> leftZ = new Setting<>("Left Z", 0.0F, -2.0F, 2.0F)
      .visibleWhen(() -> this.customHandView.getValue() && !this.syncHands.getValue());
   private static int comboState = 0;
   private static float lastSwingProgress = 0.0F;

   public HitAnimation() {
      super("Hit Animation", Category.RENDER);
      this.addSetting(this.mode);
      this.addSetting(this.swingSpeed);
      this.addSetting(this.swingScale);
      this.addSetting(this.mainHandOnly);
      this.addSetting(this.customHandView);
      this.addSetting(this.syncHands);
      this.addSetting(this.x);
      this.addSetting(this.y);
      this.addSetting(this.z);
      this.addSetting(this.rightX);
      this.addSetting(this.rightY);
      this.addSetting(this.rightZ);
      this.addSetting(this.leftX);
      this.addSetting(this.leftY);
      this.addSetting(this.leftZ);
      INSTANCE = this;
   }

   public static boolean isActive() {
      return INSTANCE != null && INSTANCE.isEnabled() && !INSTANCE.mode.check("Off") && hasHeldItem();
   }

   public static float getSwingSpeed() {
      return INSTANCE != null && INSTANCE.isEnabled() ? INSTANCE.swingSpeed.getValue() : 1.0F;
   }

   public static void applyHandView(MatrixStack matrix, Hand hand, ItemStack stack) {
      if (INSTANCE != null && INSTANCE.isEnabled() && INSTANCE.customHandView.getValue()) {
         if (stack != null && !stack.isEmpty()) {
            if (INSTANCE.syncHands.getValue()) {
               float sx = hand == Hand.MAIN_HAND ? INSTANCE.x.getValue() : -INSTANCE.x.getValue();
               matrix.translate(sx, INSTANCE.y.getValue(), INSTANCE.z.getValue());
            } else if (hand == Hand.MAIN_HAND) {
               matrix.translate(INSTANCE.rightX.getValue(), INSTANCE.rightY.getValue(), INSTANCE.rightZ.getValue());
            } else {
               matrix.translate(INSTANCE.leftX.getValue(), INSTANCE.leftY.getValue(), INSTANCE.leftZ.getValue());
            }
         }
      }
   }

   public static boolean apply(MatrixStack matrix, Hand hand, float swingProgress, float equipProgress) {
      if (!isActive() || INSTANCE == null) {
         return false;
      } else if (INSTANCE.mainHandOnly.getValue() && hand != Hand.MAIN_HAND) {
         return false;
      } else {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc != null && mc.player != null) {
            float strength = INSTANCE.swingScale.getValue();
            int armSide = mc.player.getMainArm() == Arm.RIGHT ? 1 : -1;
            float sin1 = MathHelper.sin(swingProgress * swingProgress * (float) Math.PI);
            float sin2 = MathHelper.sin(MathHelper.sqrt(swingProgress) * (float) Math.PI);
            float sinSmooth = MathHelper.sin(swingProgress * (float) Math.PI) * 0.5F;
            matrix.translate(-0.56F * armSide, 0.52F + equipProgress * 0.6F, 0.72F);
            String var10 = INSTANCE.mode.getValue();
            switch (var10.hashCode()) {
               case -1814666802:
                  if (!var10.equals("Smooth")) {
                     return false;
                  }

                  matrix.translate(armSide * 0.56F, -0.42F, -0.72F);
                  matrix.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(armSide * sin1 * -20.0F * strength));
                  matrix.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(armSide * sin2 * -20.0F * strength));
                  matrix.multiply(RotationAxis.POSITIVE_X.rotationDegrees(sin2 * -80.0F * strength));
                  matrix.translate(0.0F, -0.1F * strength, 0.0F);
                  break;
               case -1790560136:
                  if (!var10.equals("Thrust")) {
                     return false;
                  }

                  matrix.translate(armSide * 0.56F, -0.52F, -0.72F);
                  matrix.translate(armSide * 0.1F, -0.2F, -0.3F);
                  matrix.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-30.0F * MathHelper.sin(swingProgress * (float) Math.PI) * strength - 36.0F));
                  matrix.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(25.0F * MathHelper.sin(swingProgress * (float) Math.PI) * armSide * strength));
                  matrix.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(12.0F * armSide));
                  break;
               case 2136258:
                  if (!var10.equals("Down")) {
                     return false;
                  }

                  matrix.translate(armSide * 0.56F, -0.32F, -0.72F);
                  matrix.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(76.0F * armSide));
                  matrix.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-100.0F));
                  matrix.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(sin2 * -5.0F * strength));
                  matrix.multiply(RotationAxis.POSITIVE_X.rotationDegrees(sin2 * -155.0F * strength));
                  break;
               case 2192905:
                  if (!var10.equals("Flux")) {
                     return false;
                  }

                  float sqrtFlux = MathHelper.sqrt(swingProgress);
                  float fluxSin = MathHelper.sin(sqrtFlux * (float) Math.PI);
                  double eased = swingProgress < 1.0F ? 1.0 + 2.70158 * Math.pow(swingProgress - 1.0, 3.0) + 1.70158 * Math.pow(swingProgress - 1.0, 2.0) : 1.0;
                  matrix.translate(armSide * 0.56F, -0.42F, -0.72F);
                  matrix.translate(0.0F, (float)(-0.15 * eased), (float)(-0.3 * eased));
                  matrix.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(15.0F * armSide));
                  matrix.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(35.0F * armSide * fluxSin * strength));
                  matrix.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-65.0F * fluxSin * strength));
                  matrix.translate(0.0F, 0.1F * fluxSin * strength, 0.2F * fluxSin * strength);
                  break;
               case 2587234:
                  if (!var10.equals("Stab")) {
                     return false;
                  }

                  matrix.translate(armSide * 0.56F, -0.52F, -0.72F);
                  matrix.multiply(RotationAxis.POSITIVE_X.rotationDegrees(sin2 * -60.0F * strength));
                  matrix.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(sin2 * -30.0F * armSide * strength));
                  break;
               case 65290606:
                  if (!var10.equals("Combo")) {
                     return false;
                  }

                  if (swingProgress > 0.0F && swingProgress < 0.15F && lastSwingProgress > 0.5F) {
                     comboState = (comboState + 1) % 3;
                  }

                  lastSwingProgress = swingProgress;
                  if (comboState == 0) {
                     matrix.translate(armSide * 0.56F, -0.32F, -0.72F);
                     matrix.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(60.0F * armSide));
                     matrix.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-45.0F * armSide));
                     matrix.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-50.0F));
                     matrix.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(sin2 * 80.0F * armSide * strength));
                     matrix.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(sin2 * -30.0F * strength));
                  } else if (comboState == 1) {
                     matrix.translate(armSide * 0.56F, -0.32F, -0.72F);
                     matrix.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(60.0F * armSide));
                     matrix.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-45.0F * armSide));
                     matrix.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-50.0F));
                     matrix.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(sin2 * -80.0F * armSide * strength));
                     matrix.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(sin2 * 30.0F * strength));
                  } else {
                     matrix.translate(armSide * 0.56F, -0.52F, -0.72F);
                     matrix.translate(armSide * 0.1F, -0.15F, -0.25F);
                     matrix.multiply(RotationAxis.POSITIVE_X.rotationDegrees(sin2 * -90.0F * strength - 30.0F));
                     matrix.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(sin2 * 20.0F * armSide * strength));
                     matrix.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(15.0F * armSide));
                  }
                  break;
               case 65382432:
                  if (!var10.equals("Cross")) {
                     return false;
                  }

                  zenith(matrix, armSide);
                  matrix.multiply(RotationAxis.POSITIVE_X.rotationDegrees(50.0F));
                  matrix.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-60.0F * armSide));
                  matrix.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((110.0F + 20.0F * sin2 * strength) * armSide));
                  break;
               case 67752259:
                  if (!var10.equals("Feast")) {
                     return false;
                  }

                  matrix.translate(armSide * 0.56F, -0.32F, -0.72F);
                  matrix.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(60.0F * armSide));
                  matrix.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-80.0F));
                  matrix.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(35.0F * armSide));
                  matrix.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(sin2 * 75.0F * armSide * strength));
                  matrix.multiply(RotationAxis.POSITIVE_X.rotationDegrees(sin2 * -45.0F * strength));
                  break;
               case 73782147:
                  if (!var10.equals("Lunge")) {
                     return false;
                  }

                  zenith(matrix, armSide);
                  matrix.translate(0.0F, -0.2F, -0.4F);
                  matrix.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-120.0F * sin2 * strength - 3.0F));
                  break;
               case 77306085:
                  if (!var10.equals("Power")) {
                     return false;
                  }

                  matrix.translate(armSide * 0.56F, -0.32F, -0.72F);
                  matrix.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(61.0F * armSide));
                  matrix.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-60.0F));
                  matrix.translate(-sinSmooth * sinSmooth * sin1 * armSide * strength, 0.0F, 0.0F);
                  matrix.multiply(RotationAxis.POSITIVE_X.rotationDegrees(sin2 * sin1 * -30.0F * strength));
                  matrix.multiply(RotationAxis.POSITIVE_X.rotationDegrees(sinSmooth * -60.0F * strength));
                  break;
               case 79882757:
                  if (!var10.equals("Sigma")) {
                     return false;
                  }

                  float sqrtSwing = MathHelper.sqrt(swingProgress);
                  float hOff = -0.3F * MathHelper.sin(sqrtSwing * (float) Math.PI);
                  float iOff = 0.4F * MathHelper.sin(sqrtSwing * (float) Math.PI * 2.0F);
                  float jOff = -0.4F * MathHelper.sin(swingProgress * (float) Math.PI);
                  matrix.translate(armSide * 0.56F, -0.52F, -0.72F);
                  matrix.translate(armSide * hOff, iOff, jOff);
                  matrix.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(armSide * 45.0F));
                  matrix.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(armSide * sin2 * 70.0F * strength));
                  matrix.multiply(RotationAxis.POSITIVE_X.rotationDegrees(armSide * sin1 * -20.0F * strength));
                  break;
               case 79966557:
                  if (!var10.equals("Slash")) {
                     return false;
                  }

                  zenith(matrix, armSide);
                  matrix.multiply(RotationAxis.POSITIVE_X.rotationDegrees(50.0F));
                  matrix.multiply(RotationAxis.POSITIVE_Y.rotationDegrees((-30.0F * (1.0F - sin2) - 30.0F) * armSide));
                  matrix.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(110.0F * armSide));
                  break;
               case 80301850:
                  if (!var10.equals("Swipe")) {
                     return false;
                  }

                  matrix.translate(0.56F * armSide, -0.32F, -0.72F);
                  matrix.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(60.0F * armSide));
                  matrix.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-60.0F * armSide));
                  matrix.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-60.0F));
                  matrix.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(sin2 * sin1 * -5.0F * strength));
                  matrix.multiply(RotationAxis.POSITIVE_X.rotationDegrees(sin2 * sin1 * -120.0F * strength));
                  break;
               case 594339028:
                  if (var10.equals("Overhead")) {
                     matrix.translate(armSide * 0.56F, equipProgress * -0.2F - 0.5F, -0.7F);
                     matrix.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(45.0F * armSide));
                     matrix.multiply(RotationAxis.POSITIVE_X.rotationDegrees(sin2 * -85.0F * strength));
                     matrix.translate(armSide * -0.1F, 0.28F, 0.2F);
                     matrix.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-85.0F));
                     break;
                  }

                  return false;
               default:
                  return false;
            }

            return true;
         } else {
            return false;
         }
      }
   }

   private static boolean hasHeldItem() {
      MinecraftClient mc = MinecraftClient.getInstance();
      return mc != null && mc.player != null && !mc.player.getMainHandStack().isEmpty();
   }

   private static void zenith(MatrixStack matrices, int armSide) {
      matrices.translate(armSide * 0.56F, -0.52F, -0.72F);
   }
}

