package com.water.module.modules.donut;

import com.water.module.Category;
import com.water.module.Module;
import com.water.setting.ModeSetting;
import com.water.setting.Setting;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;

public final class BoneDropperBot extends Module {
   private static final int MIN_DELAY_MS = 100;
   private static final int MAX_DELAY_MS = 2000;
   private static final int DEFAULT_DELAY_MS = 300;
   private static final int PLAYER_INVENTORY_SLOT_COUNT = 36;
   private static final int PRIMARY_CLICK_BUTTON = 0;
   private static final long SPAWNER_DROP_TIMEOUT_MS = 4000L;
   private final ModeSetting mode = new ModeSetting("Mode", "Spawner", "Spawner", "Orders");
   private final Setting<Integer> delayMs = new Setting<>("Delay", 300, 100, 2000);
   private BoneDropperBot.BotState state = BoneDropperBot.BotState.SPAWNER_OPEN_MENU;
   private String lastMode = this.mode.getValue();
   private long nextActionAtMs;
   private int spawnerBoneCountBeforeDrop;
   private long spawnerDropRequestedAtMs;
   private boolean spawnerGridWasFullBeforeDrop;

   public BoneDropperBot() {
      super("BoneDropper", Category.DONUT);
      this.addSetting(this.mode);
      this.addSetting(this.delayMs);
   }

   @Override
   public void onEnable() {
      this.resetState();
   }

   @Override
   public void onDisable() {
      this.state = BoneDropperBot.BotState.SPAWNER_OPEN_MENU;
      this.nextActionAtMs = 0L;
   }

   @Override
   public void onTick() {
      if (mc.player != null && mc.world != null && mc.interactionManager != null) {
         if (mc.currentScreen == null || mc.currentScreen instanceof HandledScreen) {
            if (!this.mode.getValue().equalsIgnoreCase(this.lastMode)) {
               this.resetState();
            }

            long now = System.currentTimeMillis();
            if (now >= this.nextActionAtMs) {
               if (this.mode.check("Spawner")) {
                  this.tickSpawnerMode();
               } else {
                  this.tickOrdersMode();
               }
            }
         }
      }
   }

   private void tickSpawnerMode() {
      switch (this.state) {
         case SPAWNER_OPEN_MENU:
            if (this.isHandledMenuOpen()) {
               this.state = BoneDropperBot.BotState.SPAWNER_WAIT_MENU;
               this.scheduleNextAction();
               return;
            }

            this.interactWithTargetBlock();
            this.state = BoneDropperBot.BotState.SPAWNER_WAIT_MENU;
            this.scheduleNextAction();
            break;
         case SPAWNER_WAIT_MENU:
            if (!this.isHandledMenuOpen()) {
               this.state = BoneDropperBot.BotState.SPAWNER_OPEN_MENU;
               this.scheduleNextAction();
               return;
            }

            this.state = BoneDropperBot.BotState.SPAWNER_SCAN_GRID;
            this.scheduleNextAction();
            break;
         case SPAWNER_SCAN_GRID:
            ScreenHandler handlerx = this.getMenuHandler();
            if (handlerx == null) {
               this.state = BoneDropperBot.BotState.SPAWNER_OPEN_MENU;
               this.scheduleNextAction();
               return;
            }

            if (!this.isSpawnerGridFull(handlerx)) {
               this.scheduleNextAction();
               return;
            }

            this.state = BoneDropperBot.BotState.SPAWNER_CLICK_DROPPER;
            this.scheduleNextAction();
            break;
         case SPAWNER_CLICK_DROPPER:
            ScreenHandler handler = this.getMenuHandler();
            if (handler == null) {
               this.state = BoneDropperBot.BotState.SPAWNER_OPEN_MENU;
               this.scheduleNextAction();
               return;
            }

            Slot dropperSlot = this.findSpawnerDropperSlot(handler);
            if (dropperSlot == null) {
               this.scheduleNextAction();
               return;
            }

            this.spawnerGridWasFullBeforeDrop = this.isSpawnerGridFull(handler);
            if (!this.spawnerGridWasFullBeforeDrop) {
               this.state = BoneDropperBot.BotState.SPAWNER_SCAN_GRID;
               this.scheduleNextAction();
               return;
            }

            this.spawnerBoneCountBeforeDrop = this.countInventoryItem(Items.BONE);
            this.spawnerDropRequestedAtMs = System.currentTimeMillis();
            this.clickSlot(dropperSlot);
            this.state = BoneDropperBot.BotState.SPAWNER_WAIT_DROP_CONFIRM;
            this.scheduleNextAction();
            break;
         case SPAWNER_WAIT_DROP_CONFIRM:
            long now = System.currentTimeMillis();
            ScreenHandler handlerxx = this.getMenuHandler();
            boolean gridCleared = this.spawnerGridWasFullBeforeDrop && handlerxx != null && !this.isSpawnerGridFull(handlerxx);
            boolean gainedBones = this.countInventoryItem(Items.BONE) > this.spawnerBoneCountBeforeDrop;
            if (gridCleared || gainedBones) {
               if (handlerxx != null) {
                  this.closeMenu();
               }

               this.state = BoneDropperBot.BotState.SPAWNER_DONE;
               this.nextActionAtMs = Long.MAX_VALUE;
               return;
            }

            if (this.spawnerDropRequestedAtMs > 0L && now - this.spawnerDropRequestedAtMs > 4000L) {
               this.state = handlerxx == null ? BoneDropperBot.BotState.SPAWNER_OPEN_MENU : BoneDropperBot.BotState.SPAWNER_SCAN_GRID;
               this.scheduleNextAction();
               return;
            }

            this.scheduleNextAction();
         case SPAWNER_DONE:
            break;
         default:
            this.state = BoneDropperBot.BotState.SPAWNER_OPEN_MENU;
            this.scheduleNextAction();
      }
   }

   private void tickOrdersMode() {
      switch (this.state) {
         case ORDERS_SEND_COMMAND:
            if (!this.isHandledMenuOpen()) {
               this.sendServerCommand("/order");
               this.state = BoneDropperBot.BotState.ORDERS_WAIT_MENU;
               this.scheduleNextAction();
               return;
            }

            this.state = BoneDropperBot.BotState.ORDERS_CLICK_CHEST_ONE;
            this.scheduleNextAction();
            break;
         case ORDERS_WAIT_MENU:
            if (!this.isHandledMenuOpen()) {
               this.sendServerCommand("/order");
               this.scheduleNextAction();
               return;
            }

            this.state = BoneDropperBot.BotState.ORDERS_CLICK_CHEST_ONE;
            this.scheduleNextAction();
            break;
         case ORDERS_CLICK_CHEST_ONE:
            this.handleOrdersClickStep(BoneDropperBot.MenuTarget.CHEST, BoneDropperBot.BotState.ORDERS_CLICK_BONE);
            break;
         case ORDERS_CLICK_BONE:
            this.handleOrdersClickStep(BoneDropperBot.MenuTarget.BONE, BoneDropperBot.BotState.ORDERS_CLICK_CHEST_TWO);
            break;
         case ORDERS_CLICK_CHEST_TWO:
            this.handleOrdersClickStep(BoneDropperBot.MenuTarget.CHEST, BoneDropperBot.BotState.ORDERS_CLICK_DROPPER_ONE);
            break;
         case ORDERS_CLICK_DROPPER_ONE:
            this.handleOrdersClickStep(BoneDropperBot.MenuTarget.DROPPER, BoneDropperBot.BotState.ORDERS_CLICK_ARROW);
            break;
         case ORDERS_CLICK_ARROW:
            this.handleOrdersClickStep(BoneDropperBot.MenuTarget.ARROW, BoneDropperBot.BotState.ORDERS_CLICK_DROPPER_TWO);
            break;
         case ORDERS_CLICK_DROPPER_TWO:
            this.handleOrdersClickStep(BoneDropperBot.MenuTarget.DROPPER, BoneDropperBot.BotState.ORDERS_CLICK_CHEST_ONE);
            break;
         default:
            this.state = BoneDropperBot.BotState.ORDERS_SEND_COMMAND;
            this.scheduleNextAction();
      }
   }

   private void handleOrdersClickStep(BoneDropperBot.MenuTarget target, BoneDropperBot.BotState nextState) {
      ScreenHandler handler = this.getMenuHandler();
      if (handler == null) {
         this.sendServerCommand("/order");
         this.scheduleNextAction();
      } else {
         Slot slot = this.findUpperMenuSlot(handler, target, target == BoneDropperBot.MenuTarget.DROPPER || target == BoneDropperBot.MenuTarget.ARROW);
         if (slot == null) {
            this.scheduleNextAction();
         } else {
            this.clickSlot(slot);
            this.state = nextState;
            this.scheduleNextAction();
         }
      }
   }

   private boolean isSpawnerGridFull(ScreenHandler handler) {
      List<Slot> gridSlots = this.getSpawnerGridSlots(handler);
      if (gridSlots.isEmpty()) {
         return false;
      } else {
         for (Slot slot : gridSlots) {
            if (slot.isEnabled()) {
               ItemStack stack = slot.getStack();
               if (stack.isEmpty() || !this.matchesTarget(stack, BoneDropperBot.MenuTarget.BONE)) {
                  return false;
               }
            }
         }

         return true;
      }
   }

   private List<Slot> getSpawnerGridSlots(ScreenHandler handler) {
      List<Slot> upperSlots = this.getUpperMenuSlots(handler);
      if (upperSlots.isEmpty()) {
         return List.of();
      } else {
         int maxY = upperSlots.stream().mapToInt(slotx -> slotx.y).max().orElse(Integer.MIN_VALUE);
         List<Slot> gridSlots = new ArrayList<>();

         for (Slot slot : upperSlots) {
            if (slot.y < maxY) {
               gridSlots.add(slot);
            }
         }

         return gridSlots.isEmpty() ? upperSlots : gridSlots;
      }
   }

   private Slot findSpawnerDropperSlot(ScreenHandler handler) {
      List<Slot> upperSlots = this.getUpperMenuSlots(handler);
      if (upperSlots.isEmpty()) {
         return null;
      } else {
         int maxY = upperSlots.stream().mapToInt(slotx -> slotx.y).max().orElse(Integer.MIN_VALUE);
         Slot controlDropper = this.chooseBestMatchingSlot(upperSlots, BoneDropperBot.MenuTarget.DROPPER, true, maxY);
         if (controlDropper != null) {
            return controlDropper;
         } else {
            Slot anyDropper = this.chooseBestMatchingSlot(upperSlots, BoneDropperBot.MenuTarget.DROPPER, true, Integer.MIN_VALUE);
            if (anyDropper != null) {
               return anyDropper;
            } else {
               for (int i = upperSlots.size() - 1; i >= 0; i--) {
                  Slot slot = upperSlots.get(i);
                  if (slot.isEnabled()) {
                     return slot;
                  }
               }

               return null;
            }
         }
      }
   }

   private Slot findUpperMenuSlot(ScreenHandler handler, BoneDropperBot.MenuTarget target, boolean preferBottomRight) {
      return this.chooseBestMatchingSlot(this.getUpperMenuSlots(handler), target, preferBottomRight, Integer.MIN_VALUE);
   }

   private Slot chooseBestMatchingSlot(List<Slot> slots, BoneDropperBot.MenuTarget target, boolean preferBottomRight, int yFilter) {
      Slot best = null;

      for (Slot slot : slots) {
         if (slot.isEnabled() && (yFilter == Integer.MIN_VALUE || slot.y == yFilter) && this.matchesTarget(slot.getStack(), target)) {
            if (best == null) {
               best = slot;
            } else if (preferBottomRight) {
               if (slot.y > best.y || slot.y == best.y && slot.x >= best.x) {
                  best = slot;
               }
            } else if (slot.y < best.y || slot.y == best.y && slot.x < best.x) {
               best = slot;
            }
         }
      }

      return best;
   }

   private boolean matchesTarget(ItemStack stack, BoneDropperBot.MenuTarget target) {
      if (stack != null && !stack.isEmpty()) {
         Item item = stack.getItem();
         String lowerName = stack.getName().getString().toLowerCase(Locale.ROOT);

         return switch (target) {
            case BONE -> item == Items.BONE || lowerName.contains("bone");
            case CHEST -> item == Items.CHEST
               || item == Items.TRAPPED_CHEST
               || item == Items.ENDER_CHEST
               || lowerName.contains("chest")
               || lowerName.contains("truhe");
            case DROPPER -> item == Items.DROPPER || lowerName.contains("dropper");
            case ARROW -> item == Items.ARROW || lowerName.contains("arrow") || lowerName.contains("pfeil");
         };
      } else {
         return false;
      }
   }

   private List<Slot> getUpperMenuSlots(ScreenHandler handler) {
      if (handler != null && handler.slots != null && !handler.slots.isEmpty()) {
         int upperSlotCount = Math.max(0, handler.slots.size() - 36);
         if (upperSlotCount == 0) {
            upperSlotCount = handler.slots.size();
         }

         List<Slot> upperSlots = new ArrayList<>(upperSlotCount);

         for (int i = 0; i < upperSlotCount; i++) {
            upperSlots.add((Slot)handler.slots.get(i));
         }

         return upperSlots;
      } else {
         return List.of();
      }
   }

   private int countInventoryItem(Item item) {
      if (mc.player == null) {
         return 0;
      } else {
         int count = 0;

         for (int i = 0; i < mc.player.getInventory().size(); i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (!stack.isEmpty() && stack.isOf(item)) {
               count += stack.getCount();
            }
         }

         return count;
      }
   }

   private void clickSlot(Slot slot) {
      if (slot != null && mc.player != null && mc.interactionManager != null) {
         mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, slot.id, 0, SlotActionType.PICKUP, mc.player);
      }
   }

   private void interactWithTargetBlock() {
      if (mc.crosshairTarget instanceof BlockHitResult hit && mc.crosshairTarget.getType() == Type.BLOCK) {
         mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
         mc.player.swingHand(Hand.MAIN_HAND);
      }
   }

   private void closeMenu() {
      if (mc.player != null) {
         if (mc.currentScreen instanceof HandledScreen) {
            mc.player.closeHandledScreen();
            mc.setScreen(null);
         }
      }
   }

   private ScreenHandler getMenuHandler() {
      return mc.currentScreen instanceof HandledScreen && mc.player != null ? mc.player.currentScreenHandler : null;
   }

   private boolean isHandledMenuOpen() {
      return this.getMenuHandler() != null;
   }

   private void sendServerCommand(String command) {
      ClientPlayNetworkHandler networkHandler = mc.player != null ? mc.player.networkHandler : mc.getNetworkHandler();
      if (networkHandler != null) {
         String commandWithoutSlash = command.startsWith("/") ? command.substring(1) : command;

         try {
            networkHandler.sendChatCommand(commandWithoutSlash);
         } catch (Throwable var5) {
            networkHandler.sendChatMessage(command);
         }
      }
   }

   private void resetState() {
      this.lastMode = this.mode.getValue();
      this.state = this.mode.check("Spawner") ? BoneDropperBot.BotState.SPAWNER_OPEN_MENU : BoneDropperBot.BotState.ORDERS_SEND_COMMAND;
      this.nextActionAtMs = 0L;
      this.spawnerBoneCountBeforeDrop = 0;
      this.spawnerDropRequestedAtMs = 0L;
      this.spawnerGridWasFullBeforeDrop = false;
   }

   private void scheduleNextAction() {
      this.nextActionAtMs = System.currentTimeMillis() + this.delayMs.getValue().intValue();
   }

   enum BotState {
      SPAWNER_OPEN_MENU,
      SPAWNER_WAIT_MENU,
      SPAWNER_SCAN_GRID,
      SPAWNER_CLICK_DROPPER,
      SPAWNER_WAIT_DROP_CONFIRM,
      SPAWNER_DONE,
      ORDERS_SEND_COMMAND,
      ORDERS_WAIT_MENU,
      ORDERS_CLICK_CHEST_ONE,
      ORDERS_CLICK_BONE,
      ORDERS_CLICK_CHEST_TWO,
      ORDERS_CLICK_DROPPER_ONE,
      ORDERS_CLICK_ARROW,
      ORDERS_CLICK_DROPPER_TWO;

      private static BoneDropperBot.BotState[] $values() {
         return new BoneDropperBot.BotState[]{
            SPAWNER_OPEN_MENU,
            SPAWNER_WAIT_MENU,
            SPAWNER_SCAN_GRID,
            SPAWNER_CLICK_DROPPER,
            SPAWNER_WAIT_DROP_CONFIRM,
            SPAWNER_DONE,
            ORDERS_SEND_COMMAND,
            ORDERS_WAIT_MENU,
            ORDERS_CLICK_CHEST_ONE,
            ORDERS_CLICK_BONE,
            ORDERS_CLICK_CHEST_TWO,
            ORDERS_CLICK_DROPPER_ONE,
            ORDERS_CLICK_ARROW,
            ORDERS_CLICK_DROPPER_TWO
         };
      }
   }

   enum MenuTarget {
      BONE,
      CHEST,
      DROPPER,
      ARROW;

      private static BoneDropperBot.MenuTarget[] $values() {
         return new BoneDropperBot.MenuTarget[]{BONE, CHEST, DROPPER, ARROW};
      }
   }
}

