package rtx.kimiko.api.drags;

import java.util.Collections;
import java.util.List;
import net.minecraft.client.gui.DrawContext;
import rtx.kimiko.api.ui.settings.Setting;
import rtx.kimiko.utils.animations.Easing;
import rtx.kimiko.utils.animations.Easings;
import rtx.kimiko.utils.animations.SmoothAnimation;

public final class SplitRectComp extends Draggable {
   private static final Easing OUT_QUART = Easings.QUART_OUT;
   private float floatVal;
   private float floatVal2;
   private float floatVal3;
   private Draggable draggable;
   private final SmoothAnimation reveal = new SmoothAnimation();
   private boolean revealStarted;

   public SplitRectComp(String string, float f, float f2, float f3, float f4, float f5, Draggable draggable) {
      super(string, f, f2);
      this.floatVal = f3;
      this.floatVal2 = f4;
      this.floatVal3 = f5;
      this.draggable = draggable;
   }

   public Draggable origin() {
      return this.draggable;
   }

   @Override
   public float width() {
      return this.floatVal;
   }

   @Override
   public float height() {
      return this.floatVal2;
   }

   @Override
   protected void render(DrawContext drawContext) {
   }

   @Override
   protected List<Setting> buildHudSettings() {
      return Collections.emptyList();
   }

   public float radius() {
      return this.floatVal3;
   }
}

