package com.water.mixin;

import com.water.module.Module;
import com.water.module.ModuleManager;
import io.netty.channel.ChannelFutureListener;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.listener.PacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ClientConnection.class})
public class ClientConnectionMixin {
   @Inject(
      method = {"handlePacket"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private static void onHandlePacket(Packet<?> packet, PacketListener listener, CallbackInfo ci) {
      try {
         Module rtpModule = ModuleManager.INSTANCE.getModuleByName("RTP Home Reset");
         if (rtpModule != null && rtpModule.isEnabled() && containsBlockedText(packet)) {
            ci.cancel();
            return;
         }

         ModuleManager.INSTANCE.onPacketReceive(packet);
      } catch (Exception var4) {
      }
   }

   private static boolean containsBlockedText(Object obj) {
      if (obj == null) {
         return false;
      } else {
         for (Method m : obj.getClass().getDeclaredMethods()) {
            if (m.getParameterCount() == 0) {
               try {
                  m.setAccessible(true);
                  Object val = m.invoke(obj);
                  if (val instanceof Text t) {
                     if (isBlocked(t.getString())) {
                        return true;
                     }

                     if (isBlocked(t.getString())) {
                        return true;
                     }
                  }

                  if (val instanceof String s && isBlocked(s)) {
                     return true;
                  }
               } catch (Throwable var9) {
               }
            }
         }

         for (Class<?> cls = obj.getClass(); cls != null; cls = cls.getSuperclass()) {
            for (Field f : cls.getDeclaredFields()) {
               try {
                  f.setAccessible(true);
                  Object valx = f.get(obj);
                  if (valx instanceof Text t && isBlocked(t.getString())) {
                     return true;
                  }

                  if (valx instanceof String s && isBlocked(s)) {
                     return true;
                  }
               } catch (Throwable var8) {
               }
            }
         }

         return false;
      }
   }

   private static boolean isBlocked(String text) {
      if (text == null) {
         return false;
      } else {
         String lower = text.toLowerCase();
         return lower.contains("home deleted")
            || lower.contains("home set")
            || lower.contains("teleported to a random location")
            || lower.contains("teleported to your home");
      }
   }

   @Inject(
      method = {"send(Lnet/minecraft/network/packet/Packet;Lio/netty/channel/ChannelFutureListener;Z)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onSend(Packet<?> packet, ChannelFutureListener callbacks, boolean flush, CallbackInfo ci) {
      try {
         if (ModuleManager.INSTANCE.onPacketSend(packet)) {
            ci.cancel();
         }
      } catch (Exception var6) {
      }
   }
}

