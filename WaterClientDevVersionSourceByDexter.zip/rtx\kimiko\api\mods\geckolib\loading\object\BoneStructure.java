package rtx.kimiko.api.mods.geckolib.loading.object;

import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import java.util.Map;
import rtx.kimiko.api.mods.geckolib.loading.json.raw.Bone;

public final class BoneStructure {
   private Bone self;
   private Map<String, BoneStructure> children;

   public BoneStructure(Bone bone) {
      this(bone, new Object2ObjectOpenHashMap());
   }

   public BoneStructure(Bone self, Map<String, BoneStructure> children) {
      this.self = self;
      this.children = children;
   }

   public Bone self() {
      return this.self;
   }

   public Map<String, BoneStructure> children() {
      return this.children;
   }
}

