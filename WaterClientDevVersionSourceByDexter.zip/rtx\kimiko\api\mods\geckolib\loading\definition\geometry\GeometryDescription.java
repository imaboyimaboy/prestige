package rtx.kimiko.api.mods.geckolib.loading.definition.geometry;

import com.google.gson.JsonDeserializer;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import net.minecraft.util.JsonHelper;
import net.minecraft.util.math.Vec3d;
import rtx.kimiko.api.mods.geckolib.GeckoLibConstants;
import rtx.kimiko.api.mods.geckolib.util.JsonUtil;

public final class GeometryDescription {
   private String identifier;
   private Float visibleBoundsWidth;
   private Float visibleBoundsHeight;
   private Vec3d visibleBoundsOffset;
   private int textureWidth;
   private int textureHeight;

   public GeometryDescription(
      String identifier, Float visibleBoundsWidth, Float visibleBoundsHeight, Vec3d visibleBoundsOffset, int textureWidth, int textureHeight
   ) {
      this.identifier = identifier;
      this.visibleBoundsWidth = visibleBoundsWidth;
      this.visibleBoundsHeight = visibleBoundsHeight;
      this.visibleBoundsOffset = visibleBoundsOffset;
      this.textureWidth = textureWidth;
      this.textureHeight = textureHeight;
   }

   public static JsonDeserializer<GeometryDescription> gsonDeserializer() throws JsonParseException {
      return (jsonElement, type, jsonDeserializationContext) -> {
         JsonObject jsonObject = jsonElement.getAsJsonObject();
         String string = JsonHelper.getString(jsonObject, "identifier", null);
         Float f = JsonUtil.getOptionalFloat(jsonObject, "visible_bounds_width");
         Float f2 = JsonUtil.getOptionalFloat(jsonObject, "visible_bounds_height");
         Vec3d vec3d = JsonUtil.jsonToVec3(JsonHelper.getArray(jsonObject, "visible_bounds_offset", null));
         int n = JsonHelper.getInt(jsonObject, "texture_width", 16);
         int n2 = JsonHelper.getInt(jsonObject, "texture_height", 16);
         if (!jsonObject.has("texture_width") || !jsonObject.has("texture_height")) {
            GeckoLibConstants.LOGGER.warn("GeckoLib model {} does not have texture dimensions specified, likely an invalid geometry json!", string);
         }

         return new GeometryDescription(string == null ? String.valueOf(jsonObject.hashCode()) : string, f, f2, vec3d, n, n2);
      };
   }

   public String identifier() {
      return this.identifier;
   }

   public Float visibleBoundsWidth() {
      return this.visibleBoundsWidth;
   }

   public Float visibleBoundsHeight() {
      return this.visibleBoundsHeight;
   }

   public Vec3d visibleBoundsOffset() {
      return this.visibleBoundsOffset;
   }

   public int textureWidth() {
      return this.textureWidth;
   }

   public int textureHeight() {
      return this.textureHeight;
   }
}

