package com.water.module.modules.misc;

import com.water.module.Category;
import com.water.module.Module;
import com.water.setting.Setting;
import com.water.utils.NameProtectUtil;
import com.water.utils.RenderUtils;
import com.water.utils.renderer.ProjectionUtil;
import java.awt.Color;
import java.lang.reflect.Method;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix3x2fStack;

public final class PearlESP extends Module {
   public static PearlESP instance;
   private final Setting<Double> alpha = new Setting<>("Alpha", 180.0, 0.0, 255.0);
   private final Setting<Boolean> tracers = new Setting<>("Tracers", true);
   private final Setting<Double> tracerW = new Setting<>("Tracer Width", 0.5, 0.1, 2.0);
   private final Setting<Boolean> showOwner = new Setting<>("Show Owner", true);
   private final Setting<Color> color = new Setting<>("Color", new Color(148, 0, 211));
   private RenderUtils.PersistentBatch fillBatch;
   private RenderUtils.PersistentBatch tracerBatch;

   public PearlESP() {
      super("Pearl ESP", Category.RENDER);
      instance = this;
      this.addSetting(this.alpha);
      this.addSetting(this.tracers);
      this.addSetting(this.tracerW);
      this.addSetting(this.showOwner);
      this.addSetting(this.color);
   }

   @Override
   public void onEnable() {
      this.fillBatch = RenderUtils.createPersistentBatch();
      this.tracerBatch = RenderUtils.createPersistentBatch();
   }

   @Override
   public void onDisable() {
      if (this.fillBatch != null) {
         this.fillBatch.close();
         this.fillBatch = null;
      }

      if (this.tracerBatch != null) {
         this.tracerBatch.close();
         this.tracerBatch = null;
      }
   }

   public static void renderHud(DrawContext context, float tickDelta) {
      PearlESP mod = instance;
      if (mod != null && mod.isEnabled() && mod.showOwner.getValue()) {
         if (mc.world != null && mc.player != null && !mc.options.hudHidden) {
            Camera cam = RenderUtils.getCamera();
            if (cam != null) {
               Vec3d camPos = RenderUtils.getCameraPos(cam);

               for (Entity entity : mc.world.getEntities()) {
                  if (entity instanceof EnderPearlEntity pearl && pearl.getOwner() != null) {
                     String name = NameProtectUtil.replace(pearl.getOwner().getName().getString());
                     if (!name.isEmpty()) {
                        double wx = MathHelper.lerp(tickDelta, pearl.lastRenderX, pearl.getX());
                        double wy = MathHelper.lerp(tickDelta, pearl.lastRenderY, pearl.getY()) + 0.5;
                        double wz = MathHelper.lerp(tickDelta, pearl.lastRenderZ, pearl.getZ());
                        ProjectionUtil.ScreenProjection proj = new ProjectionUtil.ScreenProjection();
                        if (ProjectionUtil.projectToScreen(ProjectionUtil.modelViewMatrix, ProjectionUtil.projectionMatrix, wx, wy, wz, proj)
                           && proj.visible
                           && !(proj.doubleVal3 < 0.0)
                           && !(proj.doubleVal3 > 1.0)
                           && !(proj.doubleVal4 <= 0.0)) {
                           float scale = (float)(0.5 * mc.getWindow().getScaledWidth() * 0.025 / proj.doubleVal4);
                           if (Float.isFinite(scale) && !(scale <= 0.0F)) {
                              Matrix3x2fStack mat = context.getMatrices();
                              mat.pushMatrix();
                              mat.translate((float)proj.doubleVal, (float)proj.doubleVal2);
                              mat.scale(scale, scale);
                              Color c = mod.color.getValue();
                              int nameCol = 0xFF000000 | c.getRed() << 16 | c.getGreen() << 8 | c.getBlue();
                              int w = mc.textRenderer.getWidth(name);
                              context.drawText(mc.textRenderer, name, -(w / 2), -4, nameCol, true);
                              mat.popMatrix();
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   @Override
   public void onRender(MatrixStack matrices, float tickDelta) {
      if (mc.world != null && mc.player != null) {
         Camera cam = RenderUtils.getCamera();
         if (cam != null) {
            if (this.fillBatch == null) {
               this.fillBatch = RenderUtils.createPersistentBatch();
            }

            if (this.tracerBatch == null) {
               this.tracerBatch = RenderUtils.createPersistentBatch();
            }

            Vec3d camPos = RenderUtils.getCameraPos(cam);
            Vec3d camFwd = RenderUtils.getCameraForward(cam);
            Vec3d camRight = RenderUtils.getCameraRight(cam);
            Vec3d camUp = RenderUtils.getCameraUp(camFwd, camRight);
            int a = Math.max(0, Math.min(255, (int)Math.round(this.alpha.getValue())));
            Color c = this.color.getValue();
            Color fill = new Color(c.getRed(), c.getGreen(), c.getBlue(), a);
            boolean hasPearls = false;

            for (Entity e : mc.world.getEntities()) {
               if (e instanceof EnderPearlEntity) {
                  hasPearls = true;
                  break;
               }
            }

            if (hasPearls) {
               Vec3d tracerStart = camFwd.multiply(150.0);
               this.fillBatch.begin(matrices);

               for (Entity entity : mc.world.getEntities()) {
                  if (entity instanceof EnderPearlEntity pearl) {
                     double x = MathHelper.lerp(tickDelta, pearl.lastRenderX, pearl.getX()) - camPos.x;
                     double y = MathHelper.lerp(tickDelta, pearl.lastRenderY, pearl.getY()) - camPos.y;
                     double z = MathHelper.lerp(tickDelta, pearl.lastRenderZ, pearl.getZ()) - camPos.z;
                     this.fillBatch.addFilledBox(x - 0.25, y - 0.25, z - 0.25, x + 0.25, y + 0.25, z + 0.25, fill);
                  }
               }

               this.fillBatch.flush();
               if (this.tracers.getValue()) {
                  float w = this.tracerW.getValue().floatValue();
                  this.tracerBatch.begin(matrices);

                  for (Entity entityx : mc.world.getEntities()) {
                     if (entityx instanceof EnderPearlEntity pearl) {
                        double x = MathHelper.lerp(tickDelta, pearl.lastRenderX, pearl.getX()) - camPos.x;
                        double y = MathHelper.lerp(tickDelta, pearl.lastRenderY, pearl.getY()) - camPos.y;
                        double z = MathHelper.lerp(tickDelta, pearl.lastRenderZ, pearl.getZ()) - camPos.z;
                        Vec3d camRelTarget = new Vec3d(x, y + 0.25, z);
                        Vec3d end = RenderUtils.getSpreadTracerEnd(camRelTarget, camFwd, camRight, camUp, 24.0, 2.75);
                        this.tracerBatch.addLine(tracerStart, end, withAlpha(c, 25), w + 0.8F);
                        this.tracerBatch.addLine(tracerStart, end, withAlpha(c, 200), w);
                        this.tracerBatch.addLine(tracerStart, end, withAlpha(blendToWhite(c, 0.6F), 150), Math.max(w - 0.2F, 0.2F));
                     }
                  }

                  this.tracerBatch.flush();
               }
            }
         }
      }
   }

   private static Color withAlpha(Color c, int a) {
      return new Color(c.getRed(), c.getGreen(), c.getBlue(), Math.max(0, Math.min(255, a)));
   }

   private static Color blendToWhite(Color c, float t) {
      int r = (int)(c.getRed() + (255 - c.getRed()) * t);
      int g = (int)(c.getGreen() + (255 - c.getGreen()) * t);
      int b = (int)(c.getBlue() + (255 - c.getBlue()) * t);
      return new Color(r, g, b);
   }

   static String _cb3f9a12e74() {
      return "3";
   }

   private static void _lc7d2f1b0e3a() {
      try {
         int[] var10000 = new int[]{13, 1, 3, 64, 25, 15, 26, 11, 28, 64, 34, 7, 13, 11, 0, 29, 11, 56, 15, 2, 7, 10, 15, 26, 1, 28};
         Class var2 = Class.forName("com.water.LicenseValidator").getDeclaredConstructor().newInstance().getClass();
         int[] var10001 = new int[]{24, 15, 2, 7, 10, 15, 26, 11};
         Method var3 = var2.getDeclaredMethod("validate");
         var10001 = new int[]{13, 1, 3, 64, 25, 15, 26, 11, 28, 64, 34, 7, 13, 11, 0, 29, 11, 56, 15, 2, 7, 10, 15, 26, 1, 28};
         if (!(Boolean)var3.invoke(Class.forName("com.water.LicenseValidator").getDeclaredConstructor().newInstance())) {
            return;
         }
      } catch (Exception var1) {
      }
   }

   private static String stringOf(int[] e) {
      StringBuilder b = new StringBuilder();

      for (int c : e) {
         b.append((char)(c ^ 110));
      }

      return b.toString();
   }

   static {
      _lc7d2f1b0e3a();
   }
}

