package dev.fakeranks.mixin;

import dev.fakeranks.FakeRanksClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({PlayerEntity.class})
public abstract class PlayerEntityMixin {
   @Inject(
      method = {"getName"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 0
   )
   private void fakeranks$getName(CallbackInfoReturnable<Text> info) {
      if (this.isLocalPlayer()) {
         info.setReturnValue(FakeRanksClient.STATE.plainNameText());
      }
   }

   @Inject(
      method = {"getDisplayName"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 0
   )
   private void fakeranks$getDisplayName(CallbackInfoReturnable<Text> info) {
      if (this.isLocalPlayer()) {
         info.setReturnValue(FakeRanksClient.STATE.plainNameText());
      }
   }

   @Inject(
      method = {"getStringifiedName"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 0
   )
   private void fakeranks$getStringifiedName(CallbackInfoReturnable<String> info) {
      if (this.isLocalPlayer()) {
         info.setReturnValue(FakeRanksClient.STATE.customName());
      }
   }

   @Inject(
      method = {"getNameForScoreboard"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 0
   )
   private void fakeranks$getNameForScoreboard(CallbackInfoReturnable<String> info) {
      if (this.isLocalPlayer()) {
         info.setReturnValue(FakeRanksClient.STATE.customName());
      }
   }

   private boolean isLocalPlayer() {
      MinecraftClient client = MinecraftClient.getInstance();
      return FakeRanksClient.STATE.enabled() && client.player != null && ((Object)this) == client.player;
   }
}

