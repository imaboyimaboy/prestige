package rtx.kimiko.api.mods.chatanim.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public final class ModConfig {
   private static ModConfig instance;
   private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
   private transient File configFile;
   public boolean enableMessageAnimation = true;
   public boolean enableTextFieldAnimation = true;
   public boolean removeMessageIndicator = true;
   public int fadeTimeMessage = 150;
   public int fadeTimeTextField = 170;

   public void load(File file) {
      this.configFile = file;
      if (!file.exists()) {
         this.save();
      } else {
         try (FileReader fileReader = new FileReader(file)) {
            ModConfig modConfig = (ModConfig)GSON.fromJson(fileReader, ModConfig.class);
            if (modConfig != null) {
               instance = modConfig;
               instance.configFile = file;
            }
         } catch (IOException var7) {
            var7.printStackTrace();
         }
      }
   }

   public void save() {
      if (this.configFile != null) {
         try (FileWriter fileWriter = new FileWriter(this.configFile)) {
            GSON.toJson(this, fileWriter);
         } catch (IOException var6) {
            var6.printStackTrace();
         }
      }
   }

   public static ModConfig getConfig() {
      if (instance == null) {
         instance = new ModConfig();
      }

      return instance;
   }
}

