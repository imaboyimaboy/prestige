package com.water.module.modules.misc;

import com.water.module.Category;
import com.water.module.Module;
import com.water.setting.Setting;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.text.Text;

public final class HomeSetter extends Module {
   private final Setting<Boolean> chatFeedback = new Setting<>("Chat Feedback", true);
   private final Setting<Float> homeSlot = new Setting<>("Home Slot", 1.0F, 1.0F, 5.0F);
   private volatile boolean running = false;

   public HomeSetter() {
      super("HomeSetter", Category.MISC);
      this.addSetting(this.chatFeedback);
      this.addSetting(this.homeSlot);
   }

   @Override
   public void onEnable() {
      super.onEnable();
      if (!this.running) {
         if (mc != null && mc.player != null && mc.world != null) {
            this.running = true;
            int slot = Math.round(this.homeSlot.getValue());
            mc.execute(() -> {
               this.sendServerCommand("/delhome " + slot);
               new Thread(() -> {
                  try {
                     Thread.sleep(750L);
                  } catch (InterruptedException var3) {
                  }

                  mc.execute(() -> {
                     this.sendServerCommand("/sethome " + slot);
                     if (this.chatFeedback.getValue()) {
                        try {
                           mc.inGameHud.getChatHud().addMessage(Text.literal("§aHome " + slot + " deleted and set successfully!"));
                        } catch (Exception var3x) {
                        }
                     }

                     this.running = false;
                     this.toggle();
                  });
               }, "HomeSetter-DelayThread").start();
            });
         } else {
            this.toggle();
         }
      }
   }

   @Override
   public void onDisable() {
      super.onDisable();
      this.running = false;
   }

   private void sendServerCommand(String command) {
      if (mc != null) {
         ClientPlayNetworkHandler nh = null;

         try {
            if (mc.player != null) {
               nh = mc.player.networkHandler;
            }
         } catch (Throwable var8) {
         }

         if (nh == null) {
            try {
               nh = mc.getNetworkHandler();
            } catch (Throwable var7) {
            }
         }

         if (nh != null) {
            String cmdNoSlash = command.startsWith("/") ? command.substring(1) : command;

            try {
               nh.sendChatCommand(cmdNoSlash);
            } catch (Throwable var6) {
               try {
                  nh.sendChatMessage(command);
               } catch (Throwable var5) {
               }
            }
         }
      }
   }
}

