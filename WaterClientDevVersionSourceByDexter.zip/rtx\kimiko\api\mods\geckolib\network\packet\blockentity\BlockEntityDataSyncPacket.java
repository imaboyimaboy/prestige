package rtx.kimiko.api.mods.geckolib.network.packet.blockentity;

import java.util.function.Consumer;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.network.packet.CustomPayload.Id;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import rtx.kimiko.api.mods.geckolib.GeckoLibConstants;
import rtx.kimiko.api.mods.geckolib.animatable.GeoBlockEntity;
import rtx.kimiko.api.mods.geckolib.constant.dataticket.SerializableDataTicket;
import rtx.kimiko.api.mods.geckolib.network.packet.MultiloaderPacket;
import rtx.kimiko.api.mods.geckolib.util.ClientUtil;

public final class BlockEntityDataSyncPacket<D> implements MultiloaderPacket {
   private BlockPos pos;
   private SerializableDataTicket<D> dataTicket;
   private D data;
   public static final Id<BlockEntityDataSyncPacket<?>> TYPE = new Id(GeckoLibConstants.id("blockentity_data_sync"));
   public static final PacketCodec<RegistryByteBuf, BlockEntityDataSyncPacket<?>> CODEC = PacketCodec.ofStatic(
      (registryByteBuf, blockEntityDataSyncPacket) -> {
         SerializableDataTicket.STREAM_CODEC.encode(registryByteBuf, blockEntityDataSyncPacket.dataTicket);
         registryByteBuf.writeBlockPos(blockEntityDataSyncPacket.pos);
         ((PacketCodec<RegistryByteBuf, Object>)(Object)blockEntityDataSyncPacket.dataTicket.streamCodec()).encode(registryByteBuf, blockEntityDataSyncPacket.data);
      },
      registryByteBuf -> {
         SerializableDataTicket serializableDataTicket = (SerializableDataTicket)SerializableDataTicket.STREAM_CODEC.decode(registryByteBuf);
         return new BlockEntityDataSyncPacket<>(
            registryByteBuf.readBlockPos(), serializableDataTicket, serializableDataTicket.streamCodec().decode(registryByteBuf)
         );
      }
   );

   public BlockEntityDataSyncPacket(BlockPos pos, SerializableDataTicket<D> dataTicket, D data) {
      this.pos = pos;
      this.dataTicket = dataTicket;
      this.data = data;
   }

   public Id<? extends CustomPayload> getId() {
      return TYPE;
   }

   @Override
   public void receiveMessage(PlayerEntity playerEntity, Consumer<Runnable> consumer) {
      consumer.accept(() -> {
         World world = ClientUtil.getLevel();
         BlockEntity blockEntity;
         if (world != null && (blockEntity = world.getBlockEntity(this.pos)) instanceof GeoBlockEntity) {
            GeoBlockEntity geoBlockEntity = (GeoBlockEntity)blockEntity;
            geoBlockEntity.setAnimData(this.dataTicket, this.data);
         }
      });
   }

   public BlockPos pos() {
      return this.pos;
   }

   public SerializableDataTicket<D> dataTicket() {
      return this.dataTicket;
   }

   public D data() {
      return this.data;
   }
}

