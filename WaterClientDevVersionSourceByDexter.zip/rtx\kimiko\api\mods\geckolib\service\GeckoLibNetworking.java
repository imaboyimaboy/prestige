package rtx.kimiko.api.mods.geckolib.service;

import java.util.Optional;
import net.minecraft.entity.Entity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload.Id;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import rtx.kimiko.api.mods.geckolib.GeckoLibServices;
import rtx.kimiko.api.mods.geckolib.animatable.SingletonGeoAnimatable;
import rtx.kimiko.api.mods.geckolib.cache.SyncedSingletonAnimatableCache;
import rtx.kimiko.api.mods.geckolib.constant.dataticket.SerializableDataTicket;
import rtx.kimiko.api.mods.geckolib.network.packet.MultiloaderPacket;
import rtx.kimiko.api.mods.geckolib.network.packet.blockentity.BlockEntityAnimTriggerPacket;
import rtx.kimiko.api.mods.geckolib.network.packet.blockentity.BlockEntityDataSyncPacket;
import rtx.kimiko.api.mods.geckolib.network.packet.blockentity.StatelessBlockEntityPlayAnimPacket;
import rtx.kimiko.api.mods.geckolib.network.packet.blockentity.StatelessBlockEntityStopAnimPacket;
import rtx.kimiko.api.mods.geckolib.network.packet.blockentity.StopTriggeredBlockEntityAnimPacket;
import rtx.kimiko.api.mods.geckolib.network.packet.entity.EntityAnimTriggerPacket;
import rtx.kimiko.api.mods.geckolib.network.packet.entity.EntityDataSyncPacket;
import rtx.kimiko.api.mods.geckolib.network.packet.entity.StatelessEntityPlayAnimPacket;
import rtx.kimiko.api.mods.geckolib.network.packet.entity.StatelessEntityStopAnimPacket;
import rtx.kimiko.api.mods.geckolib.network.packet.entity.StopTriggeredEntityAnimPacket;
import rtx.kimiko.api.mods.geckolib.network.packet.singleton.SingletonAnimTriggerPacket;
import rtx.kimiko.api.mods.geckolib.network.packet.singleton.SingletonDataSyncPacket;
import rtx.kimiko.api.mods.geckolib.network.packet.singleton.StatelessSingletonPlayAnimPacket;
import rtx.kimiko.api.mods.geckolib.network.packet.singleton.StatelessSingletonStopAnimPacket;
import rtx.kimiko.api.mods.geckolib.network.packet.singleton.StopTriggeredSingletonAnimPacket;

public interface GeckoLibNetworking {
   static void init() {
      registerPacket(BlockEntityDataSyncPacket.TYPE, BlockEntityDataSyncPacket.CODEC, true);
      registerPacket(EntityDataSyncPacket.TYPE, EntityDataSyncPacket.CODEC, true);
      registerPacket(SingletonDataSyncPacket.TYPE, SingletonDataSyncPacket.CODEC, true);
      registerPacket(BlockEntityAnimTriggerPacket.TYPE, BlockEntityAnimTriggerPacket.CODEC, true);
      registerPacket(SingletonAnimTriggerPacket.TYPE, SingletonAnimTriggerPacket.CODEC, true);
      registerPacket(EntityAnimTriggerPacket.TYPE, EntityAnimTriggerPacket.CODEC, true);
      registerPacket(StopTriggeredBlockEntityAnimPacket.TYPE, StopTriggeredBlockEntityAnimPacket.CODEC, true);
      registerPacket(StopTriggeredEntityAnimPacket.TYPE, StopTriggeredEntityAnimPacket.CODEC, true);
      registerPacket(StopTriggeredSingletonAnimPacket.TYPE, StopTriggeredSingletonAnimPacket.CODEC, true);
      registerPacket(StatelessEntityPlayAnimPacket.TYPE, StatelessEntityPlayAnimPacket.CODEC, true);
      registerPacket(StatelessBlockEntityPlayAnimPacket.TYPE, StatelessBlockEntityPlayAnimPacket.CODEC, true);
      registerPacket(StatelessSingletonPlayAnimPacket.TYPE, StatelessSingletonPlayAnimPacket.CODEC, true);
      registerPacket(StatelessEntityStopAnimPacket.TYPE, StatelessEntityStopAnimPacket.CODEC, true);
      registerPacket(StatelessBlockEntityStopAnimPacket.TYPE, StatelessBlockEntityStopAnimPacket.CODEC, true);
      registerPacket(StatelessSingletonStopAnimPacket.TYPE, StatelessSingletonStopAnimPacket.CODEC, true);
   }

   void sendToAllPlayersTrackingBlock(MultiloaderPacket var1, ServerWorld var2, BlockPos var3);

   default void stopTriggeredBlockEntityAnim(BlockPos blockPos, ServerWorld serverWorld, String string, String string2) {
      this.sendToAllPlayersTrackingBlock(
         new StopTriggeredBlockEntityAnimPacket(blockPos, Optional.ofNullable(string), Optional.ofNullable(string2)), serverWorld, blockPos
      );
   }

   void sendToAllPlayersTrackingEntity(MultiloaderPacket var1, Entity var2);

   <B extends PacketByteBuf, P extends MultiloaderPacket> void registerPacketInternal(Id<P> var1, PacketCodec<B, P> var2, boolean var3);

   void sendToPlayer(MultiloaderPacket var1, ServerPlayerEntity var2);

   default <D> void syncBlockEntityAnimData(BlockPos blockPos, SerializableDataTicket<D> serializableDataTicket, D d, ServerWorld serverWorld) {
      this.sendToAllPlayersTrackingBlock(new BlockEntityDataSyncPacket<>(blockPos, serializableDataTicket, d), serverWorld, blockPos);
   }

   default <D> void syncEntityAnimData(Entity entity, boolean bl, SerializableDataTicket<D> serializableDataTicket, D d) {
      this.sendToAllPlayersTrackingEntity(new EntityDataSyncPacket<>(entity.getId(), bl, serializableDataTicket, d), entity);
   }

   default <D> void syncSingletonAnimData(
      SingletonGeoAnimatable singletonGeoAnimatable, long l, SerializableDataTicket<D> serializableDataTicket, D d, Entity entity
   ) {
      this.sendToAllPlayersTrackingEntity(
         new SingletonDataSyncPacket<>(SyncedSingletonAnimatableCache.getOrCreateId(singletonGeoAnimatable), l, serializableDataTicket, d), entity
      );
   }

   private static <B extends PacketByteBuf, P extends MultiloaderPacket> void registerPacket(Id<P> id, PacketCodec<B, P> packetCodec, boolean bl) {
      GeckoLibServices.NETWORK.registerPacketInternal(id, packetCodec, bl);
   }

   default void triggerEntityAnim(Entity entity, boolean bl, String string, String string2) {
      this.sendToAllPlayersTrackingEntity(new EntityAnimTriggerPacket(entity.getId(), bl, Optional.ofNullable(string), string2), entity);
   }

   default void triggerBlockEntityAnim(BlockPos blockPos, ServerWorld serverWorld, String string, String string2) {
      this.sendToAllPlayersTrackingBlock(new BlockEntityAnimTriggerPacket(blockPos, Optional.ofNullable(string), string2), serverWorld, blockPos);
   }

   default void stopTriggeredEntityAnim(Entity entity, boolean bl, String string, String string2) {
      this.sendToAllPlayersTrackingEntity(
         new StopTriggeredEntityAnimPacket(entity.getId(), bl, Optional.ofNullable(string), Optional.ofNullable(string2)), entity
      );
   }

   default void triggerSingletonAnim(SingletonGeoAnimatable singletonGeoAnimatable, Entity entity, long l, String string, String string2) {
      this.sendToAllPlayersTrackingEntity(
         new SingletonAnimTriggerPacket(SyncedSingletonAnimatableCache.getOrCreateId(singletonGeoAnimatable), l, Optional.ofNullable(string), string2), entity
      );
   }

   default void stopTriggeredSingletonAnim(SingletonGeoAnimatable singletonGeoAnimatable, Entity entity, long l, String string, String string2) {
      this.sendToAllPlayersTrackingEntity(
         new StopTriggeredSingletonAnimPacket(
            SyncedSingletonAnimatableCache.getOrCreateId(singletonGeoAnimatable), l, Optional.ofNullable(string), Optional.ofNullable(string2)
         ),
         entity
      );
   }
}

