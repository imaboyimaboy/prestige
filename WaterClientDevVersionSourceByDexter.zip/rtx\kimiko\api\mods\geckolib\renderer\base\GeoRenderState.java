package rtx.kimiko.api.mods.geckolib.renderer.base;

import it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.client.MinecraftClient;
import rtx.kimiko.api.mods.geckolib.GeckoLibConstants;
import rtx.kimiko.api.mods.geckolib.constant.DataTickets;
import rtx.kimiko.api.mods.geckolib.constant.dataticket.DataTicket;
import rtx.kimiko.api.mods.geckolib.constant.dataticket.OverridingDataTicket;

public interface GeoRenderState {
   Map<DataTicket<?>, Object> getDataMap();

   default float getPartialTick() {
      return this.getOrDefaultGeckolibData(DataTickets.PARTIAL_TICK, MinecraftClient.getInstance().getRenderTickCounter().getTickProgress(false));
   }

   default int getPackedLight() {
      return this.getOrDefaultGeckolibData(DataTickets.PACKED_LIGHT, 15728880);
   }

   default double getAnimatableAge() {
      return this.getOrDefaultGeckolibData(DataTickets.TICK, 0.0);
   }

   default <D> D getOrDefaultGeckolibData(DataTicket<D> dataTicket, Supplier<D> defaultValue) {
      D data = this.getGeckolibData(dataTicket);
      if (data != null) {
         return data;
      } else {
         return (D)(dataTicket instanceof OverridingDataTicket<?, ?> overridingTicket && overridingTicket.canExtractFrom(this)
            ? overridingTicket.extractFromState(this)
            : defaultValue.get());
      }
   }

   default <D> D getOrDefaultGeckolibData(DataTicket<D> dataTicket, D defaultValue) {
      D data = this.getGeckolibData(dataTicket);
      if (data != null) {
         return data;
      } else {
         return (D)(dataTicket instanceof OverridingDataTicket<?, ?> overridingTicket && overridingTicket.canExtractFrom(this)
            ? overridingTicket.extractFromState(this)
            : defaultValue);
      }
   }

   default boolean hasGeckolibData(DataTicket<?> dataTicket) {
      return this.getDataMap().containsKey(dataTicket);
   }

   default <D> void addGeckolibData(DataTicket<D> dataTicket, D data) {
      this.getDataMap().put(dataTicket, data);
   }

   default <D> D getGeckolibData(DataTicket<D> dataTicket) {
      Object data = this.getDataMap().get(dataTicket);

      try {
         if (data != null) {
            return (D)data;
         } else {
            return (D)(dataTicket instanceof OverridingDataTicket<?, ?> overridingTicket && overridingTicket.canExtractFrom(this)
               ? overridingTicket.extractFromState(this)
               : null);
         }
      } catch (ClassCastException var4) {
         GeckoLibConstants.LOGGER.error("Attempted to retrieve incorrectly typed data from GeoRenderState. Expected: {}, found: {}", dataTicket, data, var4);
         throw var4;
      }
   }

   public final class Impl implements GeoRenderState {
      private final Map<DataTicket<?>, Object> dataMap;

      public Impl() {
         this(new Reference2ObjectOpenHashMap());
      }

      public Impl(Map<DataTicket<?>, Object> data) {
         this.dataMap = data;
      }

      @Override
      public Map<DataTicket<?>, Object> getDataMap() {
         return this.dataMap;
      }

      public Map<DataTicket<?>, Object> data() {
         return this.dataMap;
      }
   }
}

