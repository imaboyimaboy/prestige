package com.water.utils;

import com.water.module.modules.client.WaterPlus;
import net.minecraft.client.MinecraftClient;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

public final class WaterSounds {
   private static final Identifier GUI_OPEN_ID = Identifier.of("water", "ui.gui_open");
   private static final Identifier GUI_CLOSE_ID = Identifier.of("water", "ui.gui_close");
   private static final Identifier MODULE_ON_ID = Identifier.of("water", "ui.module_on");

   private WaterSounds() {
   }

   public static void guiOpen() {
      play(GUI_OPEN_ID, 0.85F, 1.0F);
   }

   public static void guiClose() {
      play(GUI_CLOSE_ID, 0.8F, 1.0F);
   }

   public static void moduleOn() {
      play(MODULE_ON_ID, 0.7F, 1.0F);
   }

   private static void play(Identifier id, float volume, float pitch) {
      if (WaterPlus.uiSoundsEnabled()) {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc != null && mc.player != null) {
            try {
               mc.player.playSound(SoundEvent.of(id), volume, pitch);
            } catch (Throwable var5) {
            }
         }
      }
   }
}

