package rtx.kimiko.api.mods.geckolib.network.packet.singleton;

import java.util.Optional;
import java.util.function.Consumer;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.network.packet.CustomPayload.Id;
import rtx.kimiko.api.mods.geckolib.GeckoLibConstants;
import rtx.kimiko.api.mods.geckolib.animatable.GeoAnimatable;
import rtx.kimiko.api.mods.geckolib.animatable.manager.AnimatableManager;
import rtx.kimiko.api.mods.geckolib.cache.SyncedSingletonAnimatableCache;
import rtx.kimiko.api.mods.geckolib.network.packet.MultiloaderPacket;

public final class StopTriggeredSingletonAnimPacket implements MultiloaderPacket {
   private String syncableId;
   private long instanceId;
   private Optional<String> controllerName;
   private Optional<String> animName;
   public static final Id<StopTriggeredSingletonAnimPacket> TYPE = new Id(GeckoLibConstants.id("stop_triggered_singleton_anim"));
   public static final PacketCodec<PacketByteBuf, StopTriggeredSingletonAnimPacket> CODEC = PacketCodec.tuple(
      PacketCodecs.STRING,
      StopTriggeredSingletonAnimPacket::syncableId,
      PacketCodecs.VAR_LONG,
      StopTriggeredSingletonAnimPacket::instanceId,
      PacketCodecs.STRING.collect(PacketCodecs::optional),
      StopTriggeredSingletonAnimPacket::controllerName,
      PacketCodecs.STRING.collect(PacketCodecs::optional),
      StopTriggeredSingletonAnimPacket::animName,
      StopTriggeredSingletonAnimPacket::new
   );

   public StopTriggeredSingletonAnimPacket(String syncableId, long instanceId, Optional<String> controllerName, Optional<String> animName) {
      this.syncableId = syncableId;
      this.instanceId = instanceId;
      this.controllerName = controllerName;
      this.animName = animName;
   }

   public Id<? extends CustomPayload> getId() {
      return TYPE;
   }

   @Override
   public void receiveMessage(PlayerEntity playerEntity, Consumer<Runnable> consumer) {
      consumer.accept(() -> {
         GeoAnimatable geoAnimatable = SyncedSingletonAnimatableCache.getSyncedAnimatable(this.syncableId);
         if (geoAnimatable != null) {
            AnimatableManager<?> animatableManager = geoAnimatable.getAnimatableInstanceCache().getManagerForId(this.instanceId);
            if (this.controllerName.isPresent()) {
               animatableManager.stopTriggeredAnimation(this.controllerName.get(), this.animName.orElse(null));
            } else {
               animatableManager.stopTriggeredAnimation(this.animName.orElse(null));
            }
         }
      });
   }

   public String syncableId() {
      return this.syncableId;
   }

   public long instanceId() {
      return this.instanceId;
   }

   public Optional<String> controllerName() {
      return this.controllerName;
   }

   public Optional<String> animName() {
      return this.animName;
   }
}

