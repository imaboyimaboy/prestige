package com.water.gui;

import com.water.module.Module;
import com.water.module.ModuleManager;
import com.water.module.modules.client.ConfigShare;
import com.water.module.modules.client.WaterPlus;
import com.water.utils.renderer.AwtFontRenderer;
import com.water.utils.renderer.RenderUtil;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;

public class ConfigShareScreen extends Screen {
   private static final int intVal = 430;
   private static final int intVal2 = 350;
   private static final int PAD = 18;
   private static final int ROW_H = 38;
   private static final int ROWS = 5;
   private static final int MAX_CFG = 5;
   private static int BG;
   private static int SURFACE;
   private static int SURFACE2;
   private static int BORDER;
   private static int ACCENT;
   private static int ACCENT2;
   private static final int TEXT = -1117441;
   private static final int TEXT2 = -7824982;
   private static final int TEXT3 = -12298906;
   private static final int GREEN = -14498466;
   private static final int GREEN_BG = -15914984;
   private static final int RED = -1096636;
   private static final int RED_BG = -13824498;
   private static final int AMBER = -680437;
   private static final int AMBER_BG = -13821184;
   private static int SEL_BG;
   private static int SEL_BD;
   private ConfigShareScreen.Tab tab = ConfigShareScreen.Tab.CONFIGS;
   private final List<String> configs = new ArrayList<>();
   private int sel = 0;
   private int scroll = 0;
   private boolean newOpen = false;
   private boolean importOpen = false;
   private String newName = "";
   private String importCode = "";
   private String status = "";
   private int statusCol = -7824982;
   private long statusAt = 0L;
   private int intVal3;
   private int intVal4;

   private static void syncColors() {
      int bg = WaterPlus.getBackgroundARGB();
      int acc = WaterPlus.getAccentARGB();
      BG = -368637682;
      SURFACE = -1257434855;
      SURFACE2 = blendArgb(-15920871, bg, 0.38F);
      BORDER = blendArgb(-14341578, acc, 0.18F);
      ACCENT = acc;
      ACCENT2 = darken(acc, 0.75F);
      SEL_BG = blendArgb(bg, acc, 0.2F);
      SEL_BD = blendArgb(bg, acc, 0.55F);
   }

   private static int darken(int argb, float f) {
      int r = Math.max(0, (int)((argb >> 16 & 0xFF) * f));
      int g = Math.max(0, (int)((argb >> 8 & 0xFF) * f));
      int b = Math.max(0, (int)((argb & 0xFF) * f));
      return argb & 0xFF000000 | r << 16 | g << 8 | b;
   }

   private static int blendArgb(int a, int b, float t) {
      int ar = a >> 16 & 0xFF;
      int ag = a >> 8 & 0xFF;
      int ab = a & 0xFF;
      int br = b >> 16 & 0xFF;
      int bg_ = b >> 8 & 0xFF;
      int bb = b & 0xFF;
      return 0xFF000000 | (int)(ar + (br - ar) * t) << 16 | (int)(ag + (bg_ - ag) * t) << 8 | (int)(ab + (bb - ab) * t);
   }

   private static float getFloat() {
      return WaterPlus.getGuiRoundness() + 6.0F;
   }

   private static float getFloat2() {
      return Math.max(4.0F, WaterPlus.getGuiRoundness());
   }

   private void run(DrawContext ctx, String s, int x, int y, int col) {
      AwtFontRenderer.INSTANCE.drawString(ctx, s, x, y, col);
   }

   private void run2(DrawContext ctx, String s, int cx, int y, int col) {
      int w = AwtFontRenderer.INSTANCE.getWidth(s);
      AwtFontRenderer.INSTANCE.drawString(ctx, s, cx - w / 2, y, col);
   }

   private int intOf(String s) {
      return AwtFontRenderer.INSTANCE.getWidth(s);
   }

   public ConfigShareScreen() {
      super(Text.literal("Water Configs"));
   }

   protected void init() {
      this.intVal3 = (this.width - 430) / 2;
      this.intVal4 = (this.height - 350) / 2;
      this.refreshConfigs();
   }

   public void render(DrawContext ctx, int mx, int my, float delta) {
      syncColors();
      ModuleManager.INSTANCE.getModules().stream().filter(m -> m instanceof WaterPlus).findFirst().ifPresent(m -> m.onTick());
      AwtFontRenderer.clearClip();
      RenderUtil.drawRoundedRect(ctx, (float)(this.intVal3 - 5), (float)(this.intVal4 - 5), 440.0F, 360.0F, getFloat() + 4.0F, 905969664, false);
      RenderUtil.drawRoundedRect(ctx, (float)(this.intVal3 - 2), (float)(this.intVal4 - 2), 434.0F, 354.0F, getFloat() + 2.0F, 1476395008, false);
      RenderUtil.drawRoundedRect(ctx, (float)this.intVal3, (float)this.intVal4, 430.0F, 350.0F, getFloat(), BG, false);
      RenderUtil.drawOutline(ctx, (float)this.intVal3, (float)this.intVal4, 430.0F, 350.0F, getFloat(), 1.0F, BORDER, false);
      this.renderHeader(ctx, mx, my);
      this.renderTabs(ctx, mx, my);
      if (this.tab == ConfigShareScreen.Tab.CONFIGS) {
         this.renderConfigs(ctx, mx, my);
      } else {
         this.renderShare(ctx, mx, my);
      }

      this.renderFooter(ctx, mx, my);
      if (!this.status.isEmpty() && System.currentTimeMillis() - this.statusAt < 3000L) {
         int sw = this.intOf(this.status) + 24;
         int sx = this.intVal3 + 215 - sw / 2;
         int sy = this.intVal4 + 350 - 36;
         RenderUtil.drawRoundedRect(ctx, (float)sx, (float)sy, (float)sw, 22.0F, 6.0F, -871756268, false);
         RenderUtil.drawOutline(ctx, (float)sx, (float)sy, (float)sw, 22.0F, 6.0F, 1.0F, this.statusCol & 1442840575, false);
         this.run2(ctx, this.status, this.intVal3 + 215, sy + 7, this.statusCol);
      }

      if (this.newOpen) {
         this.renderNewPopup(ctx, mx, my);
      }

      if (this.importOpen) {
         this.renderImportPopup(ctx, mx, my);
      }
   }

   private void renderHeader(DrawContext ctx, int mx, int my) {
      int y = this.intVal4 + 15;
      this.run(ctx, "Water+", this.intVal3 + 18, y, -1117441);
      this.run(ctx, "Configuration manager", this.intVal3 + 18 + this.intOf("Water+") + 10, y, -7824982);
      String cnt = this.configs.size() + " / 5";
      int cw = this.intOf(cnt) + 16;
      RenderUtil.drawRoundedRect(ctx, (float)(this.intVal3 + 430 - 18 - cw - 27), (float)(y - 4), (float)cw, 20.0F, 5.0F, SURFACE2, false);
      this.run2(ctx, cnt, this.intVal3 + 430 - 18 - 27 - cw / 2, y, -7824982);
      boolean xh = this.hov(mx, my, this.intVal3 + 430 - 28, y - 4, 20, 20);
      this.run(ctx, "x", this.intVal3 + 430 - 22, y, xh ? -1117441 : -7824982);
      ctx.fill(this.intVal3 + 18, this.intVal4 + 43, this.intVal3 + 430 - 18, this.intVal4 + 44, BORDER);
   }

   private void renderTabs(DrawContext ctx, int mx, int my) {
      int ty = this.intVal4 + 52;
      boolean t1a = this.tab == ConfigShareScreen.Tab.CONFIGS;
      int x1 = this.intVal3 + 18;
      int x2 = x1 + 194 + 6;
      RenderUtil.drawRoundedRect(ctx, (float)x1, (float)(ty - 4), (float)194, 25.0F, 6.0F, t1a ? SEL_BG : SURFACE, false);
      RenderUtil.drawRoundedRect(ctx, (float)x2, (float)(ty - 4), (float)194, 25.0F, 6.0F, !t1a ? SEL_BG : SURFACE, false);
      RenderUtil.drawOutline(ctx, (float)x1, (float)(ty - 4), (float)194, 25.0F, 6.0F, 1.0F, t1a ? SEL_BD : BORDER, false);
      RenderUtil.drawOutline(ctx, (float)x2, (float)(ty - 4), (float)194, 25.0F, 6.0F, 1.0F, !t1a ? SEL_BD : BORDER, false);
      this.run2(ctx, "My configs", x1 + 97, ty + 3, t1a ? -1117441 : -7824982);
      this.run2(ctx, "Share & import", x2 + 97, ty + 3, !t1a ? -1117441 : -7824982);
      int ux = t1a ? x1 : x2;
      RenderUtil.drawRoundedRect(ctx, (float)(ux + 14), (float)(ty + 18), (float)166, 2.0F, 1.0F, ACCENT, false);
   }

   private void renderConfigs(DrawContext ctx, int mx, int my) {
      int listY = this.intVal4 + 87;
      if (this.configs.isEmpty()) {
         this.run2(ctx, "No configs yet — create one below", this.intVal3 + 215, listY + 95 - 6, -12298906);
      } else {
         for (int i = 0; i < 5; i++) {
            int idx = i + this.scroll;
            if (idx >= this.configs.size()) {
               if (idx == this.configs.size() && this.configs.size() < 5) {
                  int ey = listY + i * 38 + 4;
                  RenderUtil.drawRoundedRect(ctx, (float)(this.intVal3 + 18), (float)ey, 394.0F, 30.0F, getFloat2(), 587202559, false);
                  RenderUtil.drawOutline(ctx, (float)(this.intVal3 + 18), (float)ey, 394.0F, 30.0F, getFloat2(), 1.0F, 587202559, false);
                  this.run2(ctx, "+ new config slot", this.intVal3 + 215, ey + 15 - 5, -12298906);
               }
            } else {
               int ry = listY + i * 38 + 4;
               boolean selected = idx == this.sel;
               boolean hovered = this.hov(mx, my, this.intVal3 + 18, ry, 394, 30);
               int bg = selected ? SEL_BG : (hovered ? SURFACE2 : SURFACE);
               int bd = selected ? SEL_BD : BORDER;
               RenderUtil.drawRoundedRect(ctx, (float)(this.intVal3 + 18), (float)ry, 394.0F, 30.0F, getFloat2(), bg, false);
               RenderUtil.drawOutline(ctx, (float)(this.intVal3 + 18), (float)ry, 394.0F, 30.0F, getFloat2(), 1.0F, bd, false);
               if (selected) {
                  RenderUtil.drawRoundedRect(ctx, (float)(this.intVal3 + 18), (float)(ry + 8), 3.0F, 14.0F, 2.0F, ACCENT, false);
               }

               this.run(ctx, this.configs.get(idx), this.intVal3 + 18 + (selected ? 14 : 10), ry + 15 - 5, selected ? -1117441 : -7824982);
               int btnY = ry + 15 - 10;
               int delX = this.intVal3 + 430 - 18 - 62;
               int relX = delX - 70;
               boolean rh = this.hov(mx, my, relX, btnY, 62, 20);
               RenderUtil.drawRoundedRect(ctx, (float)relX, (float)btnY, 62.0F, 20.0F, 5.0F, rh ? -15914984 : SURFACE, false);
               RenderUtil.drawOutline(ctx, (float)relX, (float)btnY, 62.0F, 20.0F, 5.0F, 1.0F, rh ? -14498466 : 872415231, false);
               this.run2(ctx, "Load", relX + 31, btnY + 5, -14498466);
               boolean dh = this.hov(mx, my, delX, btnY, 62, 20);
               RenderUtil.drawRoundedRect(ctx, (float)delX, (float)btnY, 62.0F, 20.0F, 5.0F, dh ? -13824498 : SURFACE, false);
               RenderUtil.drawOutline(ctx, (float)delX, (float)btnY, 62.0F, 20.0F, 5.0F, 1.0F, dh ? -1096636 : 872415231, false);
               this.run2(ctx, "Delete", delX + 31, btnY + 5, -1096636);
            }
         }
      }
   }

   private void renderShare(DrawContext ctx, int mx, int my) {
      ConfigShare cs = ConfigShare.getInstance();
      boolean busy = cs != null && (cs.uploading || cs.downloading);
      int bx = this.intVal3 + 18;
      int cy = this.intVal4 + 100;
      this.run2(ctx, "Move your setup between clients", this.intVal3 + 215, cy - 10, -7824982);
      cy += 12;
      boolean sh = !busy && this.hov(mx, my, bx, cy, 394, 36);
      RenderUtil.drawRoundedRect(ctx, (float)bx, (float)cy, (float)394, (float)36, getFloat2(), sh ? ACCENT2 : SURFACE2, false);
      RenderUtil.drawOutline(ctx, (float)bx, (float)cy, (float)394, (float)36, getFloat2(), 1.0F, sh ? ACCENT : BORDER, false);
      String shareLabel = cs != null && cs.uploading ? "Uploading..." : "Share Config";
      this.run2(ctx, shareLabel, this.intVal3 + 215, cy + 11, -1117441);
      cy += 44;
      boolean ih = !busy && this.hov(mx, my, bx, cy, 394, 36);
      RenderUtil.drawRoundedRect(ctx, (float)bx, (float)cy, (float)394, (float)36, getFloat2(), ih ? SURFACE2 : SURFACE, false);
      RenderUtil.drawOutline(ctx, (float)bx, (float)cy, (float)394, (float)36, getFloat2(), 1.0F, ih ? ACCENT : BORDER, false);
      String impLabel = cs != null && cs.downloading ? "Importing..." : "Import Config";
      this.run2(ctx, impLabel, this.intVal3 + 215, cy + 11, ih ? -1117441 : -7824982);
      cy += 48;
      if (cs != null && !cs.lastCode.isEmpty()) {
         String lbl = "Code: " + cs.lastCode + "  (copied)";
         int cw = this.intOf(lbl) + 24;
         int cx2 = this.intVal3 + 215 - cw / 2;
         RenderUtil.drawRoundedRect(ctx, (float)cx2, (float)cy, (float)cw, 26.0F, 6.0F, SURFACE2, false);
         RenderUtil.drawOutline(ctx, (float)cx2, (float)cy, (float)cw, 26.0F, 6.0F, 1.0F, ACCENT, false);
         this.run2(ctx, lbl, this.intVal3 + 215, cy + 8, ACCENT);
      }

      if (cs != null && !cs.lastError.isEmpty()) {
         this.run2(ctx, cs.lastError, this.intVal3 + 215, this.intVal4 + 350 - 70, -1096636);
      }
   }

   private void renderFooter(DrawContext ctx, int mx, int my) {
      int fy = this.intVal4 + 350 - 54;
      ctx.fill(this.intVal3 + 18, fy, this.intVal3 + 430 - 18, fy + 1, BORDER);
      fy += 14;
      if (this.tab == ConfigShareScreen.Tab.CONFIGS) {
         boolean atMax = this.configs.size() >= 5;
         boolean nh = !atMax && this.hov(mx, my, this.intVal3 + 18, fy, 110, 18);
         this.run(ctx, "+ New config", this.intVal3 + 18, fy + 2, nh ? ACCENT : (atMax ? -12298906 : -7824982));
         int rx = this.intVal3 + 430 - 18 - 90;
         boolean rh = this.hov(mx, my, rx, fy - 4, 90, 26);
         RenderUtil.drawRoundedRect(ctx, (float)rx, (float)(fy - 4), (float)90, 26.0F, 6.0F, rh ? -13821184 : SURFACE, false);
         RenderUtil.drawOutline(ctx, (float)rx, (float)(fy - 4), (float)90, 26.0F, 6.0F, 1.0F, rh ? -680437 : BORDER, false);
         this.run2(ctx, "Reset all", rx + 45, fy + 2, -680437);
      }
   }

   private void renderNewPopup(DrawContext ctx, int mx, int my) {
      int ppx = this.intVal3 + 215 - 170;
      int ppy = this.intVal4 + 175 - 65;
      RenderUtil.drawRoundedRect(ctx, (float)ppx, (float)ppy, (float)340, (float)130, 12.0F, BG, false);
      RenderUtil.drawOutline(ctx, (float)ppx, (float)ppy, (float)340, (float)130, 12.0F, 1.0F, BORDER, false);
      this.run2(ctx, "New Config Name", ppx + 170, ppy + 14, -1117441);
      RenderUtil.drawRoundedRect(ctx, (float)(ppx + 16), (float)(ppy + 40), (float)308, 30.0F, 6.0F, SURFACE2, false);
      RenderUtil.drawOutline(ctx, (float)(ppx + 16), (float)(ppy + 40), (float)308, 30.0F, 6.0F, 1.0F, this.newName.isEmpty() ? BORDER : ACCENT, false);
      String nd = this.newName.isEmpty() ? "Enter name..." : this.newName;
      this.run(ctx, nd, ppx + 26, ppy + 50, this.newName.isEmpty() ? -12298906 : -1117441);
      int bx = ppx + 170 - 55;
      boolean ok = this.hov(mx, my, bx, ppy + 88, 110, 28);
      RenderUtil.drawRoundedRect(ctx, (float)bx, (float)(ppy + 88), (float)110, 28.0F, 7.0F, ok ? ACCENT2 : SURFACE2, false);
      RenderUtil.drawOutline(ctx, (float)bx, (float)(ppy + 88), (float)110, 28.0F, 7.0F, 1.0F, ok ? ACCENT : BORDER, false);
      this.run2(ctx, "Create", bx + 55, ppy + 97, -1117441);
   }

   private void renderImportPopup(DrawContext ctx, int mx, int my) {
      int ppx = this.intVal3 + 215 - 190;
      int ppy = this.intVal4 + 175 - 65;
      RenderUtil.drawRoundedRect(ctx, (float)ppx, (float)ppy, (float)380, (float)130, 12.0F, BG, false);
      RenderUtil.drawOutline(ctx, (float)ppx, (float)ppy, (float)380, (float)130, 12.0F, 1.0F, BORDER, false);
      this.run2(ctx, "Enter Config Code", ppx + 190, ppy + 14, -1117441);
      RenderUtil.drawRoundedRect(ctx, (float)(ppx + 16), (float)(ppy + 40), (float)348, 30.0F, 6.0F, SURFACE2, false);
      RenderUtil.drawOutline(ctx, (float)(ppx + 16), (float)(ppy + 40), (float)348, 30.0F, 6.0F, 1.0F, this.importCode.isEmpty() ? BORDER : ACCENT, false);
      String id = this.importCode.isEmpty() ? "Paste code here (Ctrl+V)..." : this.importCode;
      this.run(ctx, id, ppx + 26, ppy + 50, this.importCode.isEmpty() ? -12298906 : -1117441);
      int bx = ppx + 190 - 55;
      boolean ok = this.hov(mx, my, bx, ppy + 88, 110, 28);
      RenderUtil.drawRoundedRect(ctx, (float)bx, (float)(ppy + 88), (float)110, 28.0F, 7.0F, ok ? ACCENT2 : SURFACE2, false);
      RenderUtil.drawOutline(ctx, (float)bx, (float)(ppy + 88), (float)110, 28.0F, 7.0F, 1.0F, ok ? ACCENT : BORDER, false);
      this.run2(ctx, "Import", bx + 55, ppy + 97, -1117441);
   }

   public boolean mouseClicked(Click click, boolean bl) {
      int mx = (int)click.x();
      int my = (int)click.y();
      int x = this.intVal3;
      int y = this.intVal4;
      if (this.newOpen) {
         int pw = 340;
         int ph = 130;
         int ppx = x + 215 - 170;
         int ppy = y + 175 - 65;
         int bx = ppx + 170 - 55;
         if (this.hov(mx, my, bx, ppy + 88, 110, 28)) {
            this.doCreate();
            return true;
         } else if (!this.hov(mx, my, ppx, ppy, pw, ph)) {
            this.newOpen = false;
            return true;
         } else {
            return true;
         }
      } else if (this.importOpen) {
         int pw = 380;
         int ph = 130;
         int ppx = x + 215 - 190;
         int ppy = y + 175 - 65;
         int bx = ppx + 190 - 55;
         if (this.hov(mx, my, bx, ppy + 88, 110, 28)) {
            this.doImport();
            return true;
         } else if (!this.hov(mx, my, ppx, ppy, pw, ph)) {
            this.importOpen = false;
            return true;
         } else {
            return true;
         }
      } else if (this.hov(mx, my, x + 430 - 28, y + 11, 20, 20)) {
         this.close();
         return true;
      } else {
         int segmentW = 194;
         if (this.hov(mx, my, x + 18, y + 48, segmentW, 25)) {
            this.tab = ConfigShareScreen.Tab.CONFIGS;
            return true;
         } else if (this.hov(mx, my, x + 18 + segmentW + 6, y + 48, segmentW, 25)) {
            this.tab = ConfigShareScreen.Tab.SHARE;
            return true;
         } else {
            if (this.tab == ConfigShareScreen.Tab.CONFIGS) {
               int listY = y + 87;

               for (int i = 0; i < 5; i++) {
                  int idx = i + this.scroll;
                  if (idx >= this.configs.size()) {
                     break;
                  }

                  int ry = listY + i * 38 + 4;
                  int btnY = ry + 15 - 10;
                  int delX = x + 430 - 18 - 62;
                  int relX = delX - 70;
                  if (this.hov(mx, my, relX, btnY, 62, 20)) {
                     this.sel = idx;
                     this.doReload();
                     return true;
                  }

                  if (this.hov(mx, my, delX, btnY, 62, 20)) {
                     this.sel = idx;
                     this.doDelete();
                     return true;
                  }

                  if (this.hov(mx, my, x + 18, ry, 394, 30)) {
                     this.sel = idx;
                     return true;
                  }
               }

               int fy = y + 350 - 54 + 14;
               boolean atMax = this.configs.size() >= 5;
               if (!atMax && this.hov(mx, my, x + 18, fy, 110, 18)) {
                  this.newOpen = true;
                  this.newName = "";
                  return true;
               }

               if (atMax && this.hov(mx, my, x + 18, fy, 110, 18)) {
                  this.setStatus("Max 5 configs!", -1096636);
                  return true;
               }

               int rw = 90;
               int rx = x + 430 - 18 - rw;
               if (this.hov(mx, my, rx, fy - 4, rw, 26)) {
                  this.doReset();
                  return true;
               }
            } else {
               ConfigShare cs = ConfigShare.getInstance();
               boolean busy = cs != null && (cs.uploading || cs.downloading);
               int bw = 394;
               int bh = 36;
               int bx2 = x + 18;
               int cy2 = y + 112;
               if (!busy && this.hov(mx, my, bx2, cy2, bw, bh)) {
                  this.doShare();
                  return true;
               }

               if (!busy && this.hov(mx, my, bx2, cy2 + bh + 8, bw, bh)) {
                  this.importOpen = true;
                  this.importCode = "";
                  return true;
               }
            }

            return super.mouseClicked(click, bl);
         }
      }
   }

   public boolean mouseScrolled(double mx, double my, double h, double v) {
      int max = Math.max(0, this.configs.size() - 5);
      this.scroll = (int)Math.max(0.0, Math.min((double)max, this.scroll - v));
      return true;
   }

   public boolean keyPressed(KeyInput input) {
      int kc = input.getKeycode();
      if (this.newOpen) {
         if (kc == 256) {
            this.newOpen = false;
            return true;
         } else if (kc == 257) {
            this.doCreate();
            return true;
         } else if (kc == 259 && !this.newName.isEmpty()) {
            this.newName = this.newName.substring(0, this.newName.length() - 1);
            return true;
         } else {
            return true;
         }
      } else if (this.importOpen) {
         if (kc == 256) {
            this.importOpen = false;
            return true;
         } else if (kc == 257) {
            this.doImport();
            return true;
         } else if (kc == 259 && !this.importCode.isEmpty()) {
            this.importCode = this.importCode.substring(0, this.importCode.length() - 1);
            return true;
         } else if (input.isPaste()) {
            String clip = MinecraftClient.getInstance().keyboard.getClipboard();
            if (clip != null) {
               this.importCode = clip.trim();
            }

            return true;
         } else {
            return true;
         }
      } else if (kc == 256) {
         this.close();
         return true;
      } else {
         return super.keyPressed(input);
      }
   }

   public boolean charTyped(CharInput input) {
      String c = input.asString();
      if (this.newOpen && this.newName.length() < 24) {
         this.newName = this.newName + c;
         return true;
      } else if (this.importOpen && this.importCode.length() < 64) {
         this.importCode = this.importCode + c;
         return true;
      } else {
         return super.charTyped(input);
      }
   }

   private void doReload() {
      Map<String, Boolean> before = this.snapshotEnabled();
      if (!this.configs.isEmpty() && this.sel < this.configs.size()) {
         ModuleManager.INSTANCE.setActiveConfigName(this.configs.get(this.sel));
      }

      ModuleManager.INSTANCE.loadConfig();
      this.syncModuleLifecycle(before, this.snapshotEnabled());
      this.setStatus("Config loaded: " + ModuleManager.INSTANCE.getActiveConfigName(), -14498466);
   }

   private void doDelete() {
      if (!this.configs.isEmpty()) {
         try {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc != null) {
               File f = new File(mc.runDirectory, "water_config_" + this.configs.get(this.sel) + ".txt");
               if (f.exists()) {
                  f.delete();
               }
            }
         } catch (Exception var3) {
         }

         this.configs.remove(this.sel);
         if (this.sel >= this.configs.size()) {
            this.sel = Math.max(0, this.configs.size() - 1);
         }

         this.setStatus("Config deleted.", -1096636);
      }
   }

   private void doReset() {
      ModuleManager.INSTANCE.getModules().forEach(m -> {
         if (m.isEnabled()) {
            m.toggle();
         }
      });
      this.setStatus("All modules disabled!", -680437);
   }

   private void doShare() {
      ConfigShare cs = ConfigShare.getInstance();
      if (cs != null) {
         if (!this.configs.isEmpty() && this.sel < this.configs.size()) {
            ModuleManager.INSTANCE.setActiveConfigName(this.configs.get(this.sel));
         }

         ModuleManager.INSTANCE.saveConfig();
         this.setStatus("Uploading...", -680437);
         cs.uploadConfig(() -> {
            if (cs.lastError.isEmpty()) {
               this.setStatus("Code copied: " + cs.lastCode, -14498466);
            } else {
               this.setStatus(cs.lastError, -1096636);
            }
         });
      }
   }

   private void doImport() {
      if (this.importCode.trim().isEmpty()) {
         this.setStatus("Paste a code first!", -1096636);
      } else {
         ConfigShare cs = ConfigShare.getInstance();
         if (cs != null) {
            this.setStatus("Loading...", -680437);
            cs.downloadConfig(this.importCode.trim(), () -> {
               this.importOpen = false;
               if (cs.lastError.isEmpty()) {
                  this.setStatus("Config imported!", -14498466);
               } else {
                  this.setStatus(cs.lastError, -1096636);
               }
            });
         }
      }
   }

   private void doCreate() {
      if (this.configs.size() >= 5) {
         this.setStatus("Max 5 configs!", -1096636);
      } else if (this.newName.trim().isEmpty()) {
         this.setStatus("Enter a name first!", -1096636);
      } else {
         String name = this.newName.trim();
         ModuleManager.INSTANCE.setActiveConfigName(name);
         ModuleManager.INSTANCE.saveConfig();
         if (!this.configs.contains(name)) {
            this.configs.add(name);
         }

         this.newOpen = false;
         this.newName = "";
         this.sel = this.configs.indexOf(name);
         this.setStatus("\"null\" saved!", -14498466);
      }
   }

   private void refreshConfigs() {
      this.configs.clear();

      try {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc != null) {
            File[] files = mc.runDirectory.listFiles(fx -> fx.isFile() && fx.getName().startsWith("water_config_") && fx.getName().endsWith(".txt"));
            if (files != null) {
               for (File f : files) {
                  this.configs.add(f.getName().replace("water_config_", "").replace(".txt", ""));
               }
            }
         }
      } catch (Exception var7) {
      }

      this.sel = 0;
   }

   private void setStatus(String m, int c) {
      this.status = m;
      this.statusCol = c;
      this.statusAt = System.currentTimeMillis();
   }

   private boolean hov(int mx, int my, int x, int y, int w, int h) {
      return mx >= x && mx <= x + w && my >= y && my <= y + h;
   }

   private Map<String, Boolean> snapshotEnabled() {
      Map<String, Boolean> map = new HashMap<>();

      for (Module m : ModuleManager.INSTANCE.getModules()) {
         map.put(m.getName(), m.isEnabled());
      }

      return map;
   }

   private void syncModuleLifecycle(Map<String, Boolean> before, Map<String, Boolean> after) {
      for (Module m : ModuleManager.INSTANCE.getModules()) {
         boolean was = before.getOrDefault(m.getName(), false);
         boolean now = after.getOrDefault(m.getName(), false);
         if (was != now) {
            try {
               if (now) {
                  m.onEnable();
               } else {
                  m.onDisable();
               }
            } catch (Throwable var8) {
            }
         }
      }
   }

   public boolean shouldPause() {
      return false;
   }

   public void renderBackground(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
   }

   enum Tab {
      CONFIGS,
      SHARE;

      private static ConfigShareScreen.Tab[] $values() {
         return new ConfigShareScreen.Tab[]{CONFIGS, SHARE};
      }
   }
}

