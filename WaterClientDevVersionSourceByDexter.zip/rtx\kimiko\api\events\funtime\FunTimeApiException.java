package rtx.kimiko.api.events.funtime;

public final class FunTimeApiException extends Exception {
   private int intVal;
   private String type;

   public FunTimeApiException(int n, String string, String string2) {
      super(string2);
      this.intVal = n;
      this.type = string == null ? "" : string;
   }

   public String type() {
      return this.type;
   }

   public int status() {
      return this.intVal;
   }

   public boolean isRateLimited() {
      return this.intVal == 429;
   }

   public boolean isUnauthorized() {
      return this.intVal == 401;
   }
}

