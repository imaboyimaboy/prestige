package rtx.kimiko.api.drags.components;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.client.gui.DrawContext;
import rtx.kimiko.api.drags.DragSystem;
import rtx.kimiko.api.drags.Draggable;
import rtx.kimiko.api.modules.Module;
import rtx.kimiko.api.modules.ModuleManager;
import rtx.kimiko.api.modules.impl.Interface.InterfaceModule;
import rtx.kimiko.utils.animations.Easing;
import rtx.kimiko.utils.animations.Easings;
import rtx.kimiko.utils.animations.SmoothAnimation;
import rtx.kimiko.utils.color.ColorUtil;
import rtx.kimiko.utils.render.others.RectUtil;
import rtx.kimiko.utils.render.render2d.Render2D;
import rtx.kimiko.utils.render.renderitem.RenderItem;

public abstract class ListHudComp extends Draggable {
   private static final String TITLE_FONT = "montserrat-semibold";
   private static final String ROW_FONT = "montserrat-medium";
   private static final float HEADER_HEIGHT = 22.0F;
   private static final float CONTENT_TOP = 5.0F;
   private static final float PAD_X = 9.0F;
   private static final float PAD_BOTTOM = 5.0F;
   private static final String ROW_CENTER_REFERENCE = "[H]";
   private static final float ROW_HEIGHT = 11.5F;
   private static final float TITLE_SIZE = 8.2F;
   private static final float ROW_SIZE = 6.5F;
   private static final float VALUE_GAP = 10.0F;
   private static final float HEADER_EXTRA_WIDTH = 10.0F;
   private static final float NAME_SLIDE = 7.0F;
   private static final float VALUE_SLIDE = 7.0F;
   private static final float ICON_SIZE = 8.5F;
   private static final float ICON_GAP = 4.0F;
   private static final String HEADER_ICON_FONT = "kimiko";
   private static final float HEADER_ICON_SIZE = 7.0F;
   private static final float HEADER_ICON_GAP = 6.0F;
   private static final float HEADER_ICON_SLIDE = 5.0F;
   private static final double HEADER_ICON_IN_SECONDS = 0.25;
   private static final double HEADER_ICON_OUT_SECONDS = 0.2;
   private static final float RADIUS = 7.0F;
   private static final float DIVIDER_HEIGHT = 0.5F;
   private static final float ROW_CLIP_PAD_Y = 2.0F;
   private static final double ROW_IN_SECONDS = 0.22;
   private static final double ROW_OUT_SECONDS = 0.18;
   private static final double WIDTH_SECONDS = 0.24;
   private static final double DIVIDER_IN_SECONDS = 0.24;
   private static final double DIVIDER_OUT_SECONDS = 0.14;
   private static final float MIN_TEXT_ALPHA = 0.003921569F;
   private static final float MIN_DIVIDER_ALPHA = 0.003921569F;
   private static final long FADE_OUT_DELAY_MS = 100L;
   private static final Easing ROW_EASING = d -> d * d * (3.0 - 2.0 * d);
   private static final int ROW_COLOR = -3355444;
   private static final int VALUE_COLOR = -3355444;
   private static final int DIVIDER_COLOR = -1997220937;
   private String title;
   private final Class<? extends Module> moduleType;
   private final Map<Object, ListHudComp.RowState> rows = new LinkedHashMap<>();
   private final SmoothAnimation visibility = new SmoothAnimation();
   private final SmoothAnimation widthAnimation = new SmoothAnimation();
   private final SmoothAnimation dividerAlpha = new SmoothAnimation();
   private final SmoothAnimation headerIconAnim = new SmoothAnimation();
   private boolean lastTargetVisible;
   private boolean lastDividerVisible;
   private boolean lastHeaderIconVisible;
   private boolean everHadContent;
   private long sizeCollapsedAtMs;
   private float titleWidthCache = -1.0F;
   private int activeCount;
   private float rowsProgress;
   private float currentWidth = 60.0F;
   private float currentHeight = 22.0F;

   protected ListHudComp(String string, String string2, Class<? extends Module> clazz, float f, float f2) {
      super(string, f, f2);
      this.title = string2;
      this.moduleType = clazz;
      this.visibility.set(0.0);
      this.widthAnimation.set(this.currentWidth);
      this.dividerAlpha.set(0.0);
      this.headerIconAnim.set(0.0);
   }

   private static float clamp(float f, float f2, float f3) {
      return Math.max(f2, Math.min(f3, f));
   }

   @Override
   public float width() {
      return this.currentWidth;
   }

   @Override
   public float height() {
      return this.currentHeight;
   }

   @Override
   public boolean isInteractive() {
      return this.shouldShow();
   }

   protected String headerIconGlyph() {
      return null;
   }

   protected abstract List<ListHudComp.Row> collectRows();

   protected float iconSlotSize() {
      return 8.5F;
   }

   private void updateDividerAlpha() {
      boolean bl = this.activeCount > 0;
      if (bl != this.lastDividerVisible) {
         this.dividerAlpha.run(bl ? 1.0 : 0.0, bl ? 0.24 : 0.14, ROW_EASING, false);
         this.lastDividerVisible = bl;
      }

      this.dividerAlpha.update();
   }

   private void refreshMetrics() {
      float f = this.headerMinWidth();
      float f2 = 22.0F;
      float f3 = this.dividerProgress();
      if (f3 > 0.001F) {
         f2 += 5.5F * f3;
      }

      for (ListHudComp.RowState rowState : this.rows.values()) {
         float f4 = rowProgress(rowState);
         if (!(f4 <= 0.001F) || rowState.active) {
            float f5 = rowState.icon != null ? this.iconSlotSize() + 4.0F : 0.0F;
            float f6 = Render2D.msdfWidth("montserrat-medium", rowState.name, 6.5F);
            float f7 = Render2D.msdfWidth("montserrat-medium", rowState.value, 6.5F);
            f = Math.max(f, 18.0F + f5 + f6 + 10.0F + f7);
            f2 += 11.5F * f4;
         }
      }

      if (f3 > 0.001F) {
         f2 += 5.0F * f3;
      }

      float f8 = Math.max(f, this.headerMinWidth());
      if (Math.abs(this.widthAnimation.getToValue() - f8) > 0.25) {
         this.widthAnimation.run(f8, 0.24, ROW_EASING, false);
      }

      this.currentHeight = Math.max(22.0F, f2);
   }

   private static boolean pushRoundedContentClip(DrawContext drawContext, float f, float f2, float f3, float f4, float f5, float f6, float f7) {
      float f8 = Math.max(f2, f6);
      float f9 = Math.min(f2 + f4, f6 + f7);
      if (!(f3 <= 0.5F) && !(f4 <= 0.5F) && !(f9 <= f8)) {
         float f10 = roundedHorizontalInset(f2, f4, f5, f8, f9);
         float f11 = f + f10;
         float f12 = f3 - f10 * 2.0F;
         if (f12 <= 0.5F) {
            return false;
         } else {
            Render2D.pushScissor(drawContext, f11, f8, f12, f9 - f8);
            return true;
         }
      } else {
         return false;
      }
   }

   private void updateHeaderIcon() {
      boolean bl = this.headerIconGlyph() != null && hudIconsEnabled();
      if (bl != this.lastHeaderIconVisible) {
         this.headerIconAnim.run(bl ? 1.0 : 0.0, bl ? 0.25 : 0.2, ROW_EASING, false);
         this.lastHeaderIconVisible = bl;
      }

      this.headerIconAnim.update();
   }

   private static float rowProgress(ListHudComp.RowState rowState) {
      return clamp(rowState.animation.get(), 0.0F, 1.0F);
   }

   private static float delayedProgress(float f, float f2) {
      return f <= f2 ? 0.0F : clamp((f - f2) / (1.0F - f2), 0.0F, 1.0F);
   }

   private float headerIconWidth() {
      String string = this.headerIconGlyph();
      if (string == null) {
         return 0.0F;
      } else {
         float[] fArray = textBounds("kimiko", string, 7.0F);
         return fArray[2] - fArray[0];
      }
   }

   private void renderDivider(float f, float f2, float f3) {
      float f4 = smoothstep(this.dividerProgress());
      float f5 = Math.max(0.0F, this.currentWidth - 18.0F);
      float f6 = f5 * f4;
      if (!(f4 <= 0.003921569F) && !(f6 <= 0.25F)) {
         Render2D.rect(f + (this.currentWidth - f6) * 0.5F, f2 + 22.0F, f6, 0.5F, 0.0F, ColorUtil.multAlpha(-1997220937, f3 * f4));
      }
   }

   private static float cornerInset(float f, float f2) {
      float f3 = clamp(f2, 0.0F, f);
      return f - (float)Math.sqrt(Math.max(0.0F, f * f - f3 * f3));
   }

   private float headerMinWidth() {
      float f = this.titleWidth() + 10.0F;
      float f2 = this.headerIconProgress();
      if (f2 <= 0.001F) {
         return f;
      } else {
         float[] fArray = textBounds("montserrat-semibold", this.title, 8.2F);
         float f3 = 18.0F + (fArray[2] - fArray[0]) + 6.0F + this.headerIconWidth();
         return f + Math.max(0.0F, f3 - f) * f2;
      }
   }

   private float dividerProgress() {
      return clamp(this.dividerAlpha.get(), 0.0F, 1.0F);
   }

   private static boolean hudIconsEnabled() {
      InterfaceModule interfaceModule = InterfaceModule.getInstance();
      return interfaceModule != null && interfaceModule.hudIcons.getValue();
   }

   private boolean computeTargetVisible() {
      boolean bl2 = this.shouldShow() && (this.activeCount > 0 || DragSystem.get().isDragModeActive());
      if (bl2) {
         this.everHadContent = true;
         this.sizeCollapsedAtMs = 0L;
         return true;
      } else if (!this.everHadContent) {
         return false;
      } else {
         boolean bl = this.rowsProgress > 0.001F
            || this.dividerProgress() > 0.003921569F
            || this.currentHeight > 22.5F
            || Math.abs(this.widthAnimation.get() - this.widthAnimation.getToValue()) > 0.5;
         if (bl) {
            this.sizeCollapsedAtMs = 0L;
            return true;
         } else {
            if (this.sizeCollapsedAtMs == 0L) {
               this.sizeCollapsedAtMs = System.currentTimeMillis();
            }

            return System.currentTimeMillis() - this.sizeCollapsedAtMs < 100L;
         }
      }
   }

   private float headerIconProgress() {
      return clamp(this.headerIconAnim.get(), 0.0F, 1.0F);
   }

   private static float roundedHorizontalInset(float f, float f2, float f3, float f4, float f5) {
      float f6 = Math.max(0.0F, Math.min(f3, f2 * 0.5F));
      if (f6 <= 0.0F) {
         return 0.0F;
      } else {
         float f7 = f + f2;
         float f8 = 0.0F;
         if (f4 < f + f6) {
            f8 = Math.max(f8, cornerInset(f6, f + f6 - Math.max(f, f4)));
         }

         if (f5 > f7 - f6) {
            f8 = Math.max(f8, cornerInset(f6, Math.min(f7, f5) - (f7 - f6)));
         }

         return f8;
      }
   }

   private static float clientRectRadius(float f, float f2) {
      InterfaceModule interfaceModule = InterfaceModule.getInstance();
      float f3 = interfaceModule == null ? 7.0F : interfaceModule.rectCornerRadius.getFloat();
      return Math.max(0.0F, Math.min(f3, Math.min(f, f2) * 0.5F));
   }

   @Override
   protected void render(DrawContext drawContext) {
      this.syncRows();
      this.updateDividerAlpha();
      this.updateHeaderIcon();
      this.refreshMetrics();
      this.widthAnimation.update();
      boolean bl = this.computeTargetVisible();
      if (bl != this.lastTargetVisible) {
         this.visibility.run(bl ? 1.0 : 0.0, bl ? 0.18 : 0.12, Easings.CUBIC_OUT, false);
         this.lastTargetVisible = bl;
      }

      this.visibility.update();
      float f = this.visibility.get();
      if (bl && f <= 0.01F) {
         f = 0.01F;
      }

      if (!(f <= 0.01F) || bl) {
         this.currentWidth = Math.max(this.headerMinWidth(), this.widthAnimation.get());
         float f2 = this.getX();
         float f3 = this.getY();
         float f4 = 0.96F + f * 0.04F;
         float f5 = f2 + this.currentWidth * 0.5F;
         float f6 = f3 + this.currentHeight * 0.5F;
         drawContext.getMatrices().pushMatrix();
         drawContext.getMatrices().translate(f5, f6);
         drawContext.getMatrices().scale(f4);
         drawContext.getMatrices().translate(-f5, -f6);
         RenderItem.beginFrame(drawContext);
         Render2D.beginFrame(drawContext);
         RectUtil.drawClientRect(f2, f3, this.currentWidth, this.currentHeight, 7.0F, f);
         float f7 = clientRectRadius(this.currentWidth, this.currentHeight);
         float f9 = f3 + (22.0F - 13.2F) * 0.5F;
         if (pushRoundedContentClip(drawContext, f2, f3, this.currentWidth, this.currentHeight, f7, f9, 13.2F)) {
            try {
               float f10 = this.headerIconProgress();
               float[] fArray = textBounds("montserrat-semibold", this.title, 8.2F);
               float f11 = fArray[2] - fArray[0];
               float f12 = f3 + 11.0F;
               float f13 = f12 - (fArray[1] + fArray[3]) * 0.5F;
               float f14 = f2 + (this.currentWidth - f11) * 0.5F - fArray[0];
               float f15 = f2 + 9.0F - fArray[0];
               float f16 = f14 + (f15 - f14) * f10;
               drawText("montserrat-semibold", this.title, f16, f13, 8.2F, titleColor(), f);
               String string = this.headerIconGlyph();
               if (string != null && f10 > 0.003921569F) {
                  float[] fArray2 = textBounds("kimiko", string, 7.0F);
                  float f17 = f2 + this.currentWidth - 9.0F - fArray2[2] + 5.0F * (1.0F - f10);
                  float f18 = f12 - (fArray2[1] + fArray2[3]) * 0.5F;
                  Render2D.msdfText("kimiko", string, f17, f18, 7.0F, ColorUtil.multAlpha(titleColor(), f * f10 * 0.8F));
               }
            } finally {
               Render2D.popScissor(drawContext);
            }
         }

         this.renderDivider(f2, f3, f);
         this.drawRows(drawContext, f2, f3, f, f7);
         Render2D.flush();
         RenderItem.flush();
         drawContext.getMatrices().popMatrix();
      }
   }

   private boolean shouldShow() {
      Module module = ModuleManager.get().get(this.moduleType);
      return module != null && module.isEnabled();
   }

   private void syncRows() {
      List<ListHudComp.Row> list = this.shouldShow() ? this.collectRows() : List.of();

      for (ListHudComp.RowState object2 : this.rows.values()) {
         object2.active = false;
      }

      this.activeCount = 0;

      for (ListHudComp.Row row : list) {
         if (row != null && row.id() != null) {
            ListHudComp.RowState rowState = this.rows.computeIfAbsent(row.id(), object -> new ListHudComp.RowState());
            rowState.active = true;
            rowState.name = row.name() == null ? "" : row.name();
            rowState.value = row.value() == null ? "" : row.value();
            rowState.icon = row.icon();
            rowState.pulse = row.pulse();
            rowState.color = row.color();
            this.activeCount++;
         }
      }

      this.rowsProgress = 0.0F;
      Iterator<Entry<Object, ListHudComp.RowState>> iterator = this.rows.entrySet().iterator();

      while (iterator.hasNext()) {
         ListHudComp.RowState rowState = iterator.next().getValue();
         if (rowState.active != rowState.lastActive) {
            rowState.animation.run(rowState.active ? 1.0 : 0.0, rowState.active ? 0.22 : 0.18, ROW_EASING, false);
            rowState.lastActive = rowState.active;
         }

         rowState.animation.update();
         float f = rowProgress(rowState);
         this.rowsProgress += f;
         if (!rowState.active && f <= 0.001F) {
            iterator.remove();
         }
      }

      this.rowsProgress = clamp(this.rowsProgress, 0.0F, 1.0F);
   }

   private static float[] textBounds(String string, String string2, float f) {
      float[] fArray = Render2D.msdfBounds(string, string2, f);
      return fArray != null && fArray.length >= 4 && fArray[3] - fArray[1] > 0.0F ? fArray : new float[]{0.0F, 0.0F, Render2D.msdfWidth(string, string2, f), f};
   }

   private static void drawText(String string, String string2, float f, float f2, float f3, int n, float f4) {
      float f5 = clamp(f4, 0.0F, 1.0F);
      if (!(f5 <= 0.003921569F) && string2 != null && !string2.isEmpty()) {
         Render2D.msdfText(string, string2, f, f2, f3, ColorUtil.multAlpha(n, f5));
      }
   }

   private void drawRows(DrawContext drawContext, float f, float f2, float f3, float f4) {
      float f5 = this.dividerProgress();
      float f6 = f2 + 22.0F + 5.5F * f5;
      float[] fArray = textBounds("montserrat-medium", "[H]", 6.5F);
      float f7 = (fArray[1] + fArray[3]) * 0.5F;

      for (ListHudComp.RowState rowState : this.rows.values()) {
         float f8 = rowProgress(rowState);
         if (!(f8 <= 0.001F)) {
            float f9 = rowState.pulse != null ? clamp(rowState.pulse.alpha(), 0.0F, 1.0F) : 1.0F;
            float f10 = f3 * f9;
            float f11 = f8;
            float f12 = delayedProgress(f8, 0.12F);
            float f13 = rowState.icon != null ? this.iconSlotSize() + 4.0F : 0.0F;
            float f14 = Render2D.msdfWidth("montserrat-medium", rowState.value, 6.5F);
            float f15 = f + 9.0F + f13 - 7.0F * (1.0F - f8);
            float f16 = f + this.currentWidth - 9.0F - f14 + 7.0F * (1.0F - f12);
            float f17 = 11.5F * f8;
            float f18 = f6 + f17 * 0.5F;
            float f19 = 15.5F * f8;
            float f20 = f18 - f19 * 0.5F;
            float f21 = f18 - f7;
            if (pushRoundedContentClip(drawContext, f, f2, this.currentWidth, this.currentHeight, f4, f20, f19)) {
               try {
                  drawContext.getMatrices().pushMatrix();

                  try {
                     drawContext.getMatrices().translate(0.0F, f18);
                     drawContext.getMatrices().scale(1.0F, f8);
                     drawContext.getMatrices().translate(0.0F, -f18);
                     if (rowState.icon != null) {
                        float f22 = f18 - this.iconSlotSize() * 0.5F;
                        rowState.icon.draw(drawContext, f + 9.0F, f22, this.iconSlotSize(), f10 * f11);
                     }

                     int n = rowState.color != 0 ? rowState.color : -3355444;
                     int n2 = rowState.color != 0 ? rowState.color : -3355444;
                     drawText("montserrat-medium", rowState.name, f15, f21, 6.5F, n, f10 * f11);
                     drawText("montserrat-medium", rowState.value, f16, f21, 6.5F, n2, f10 * f12);
                  } finally {
                     drawContext.getMatrices().popMatrix();
                  }
               } finally {
                  Render2D.popScissor(drawContext);
               }
            }

            f6 += f17;
         }
      }
   }

   private static int titleColor() {
      InterfaceModule interfaceModule = InterfaceModule.getInstance();
      int n = interfaceModule == null ? -1 : interfaceModule.clientPrimaryColorOpaque();
      return ColorUtil.lerpColor(-1, n, 0.1F);
   }

   private float titleWidth() {
      if (this.titleWidthCache <= 0.0F) {
         this.titleWidthCache = Render2D.msdfWidth("montserrat-semibold", this.title, 8.2F);
      }

      return this.titleWidthCache;
   }

   private static float smoothstep(float f) {
      float f2 = clamp(f, 0.0F, 1.0F);
      return f2 * f2 * (3.0F - 2.0F * f2);
   }

   @FunctionalInterface
   public interface AlphaPulse {
      float alpha();
   }

   @FunctionalInterface
   public interface IconDrawer {
      void draw(DrawContext var1, float var2, float var3, float var4, float var5);
   }

   public final class Row {
      private Object id;
      private String name;
      private String value;
      private ListHudComp.IconDrawer icon;
      private ListHudComp.AlphaPulse pulse;
      private int color;

      public Row(Object object, String string, String string2, ListHudComp.IconDrawer iconDrawer, ListHudComp.AlphaPulse alphaPulse) {
         this(object, string, string2, iconDrawer, alphaPulse, 0);
      }

      public Row(Object object, String string, String string2, ListHudComp.IconDrawer iconDrawer) {
         this(object, string, string2, iconDrawer, null, 0);
      }

      public Row(Object id, String name, String value, ListHudComp.IconDrawer icon, ListHudComp.AlphaPulse pulse, int color) {
         this.id = id;
         this.name = name;
         this.value = value;
         this.icon = icon;
         this.pulse = pulse;
         this.color = color;
      }

      public Object id() {
         return this.id;
      }

      public String name() {
         return this.name;
      }

      public String value() {
         return this.value;
      }

      public ListHudComp.IconDrawer icon() {
         return this.icon;
      }

      public ListHudComp.AlphaPulse pulse() {
         return this.pulse;
      }

      public int color() {
         return this.color;
      }
   }

   public final class RowState {
      final SmoothAnimation animation = new SmoothAnimation();
      boolean active;
      boolean lastActive;
      String name;
      String value;
      ListHudComp.IconDrawer icon;
      ListHudComp.AlphaPulse pulse;
      int color;
   }
}

