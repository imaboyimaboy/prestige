package com.water.gui;

import com.water.module.Module;
import com.water.module.ModuleManager;
import com.water.module.modules.render.BlockESP;
import com.water.module.modules.render.ExtraESP;
import com.water.module.modules.render.StorageESP;
import com.water.setting.BlocksSetting;
import java.awt.Color;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import net.minecraft.block.Block;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import rtx.kimiko.api.drags.Position;
import rtx.kimiko.api.ui.theme.ClientAccent;
import rtx.kimiko.utils.render.fonts.Fonts;
import rtx.kimiko.utils.render.others.RectUtil;
import rtx.kimiko.utils.render.render2d.Render2D;
import rtx.kimiko.utils.render.render2d.Render2DCoordinateSpace;
import rtx.kimiko.utils.render.render2d.blur.BlurFramebuffer;

public class BlockPickerScreen extends Screen {
   private static final int ROW = 36;
   private Screen parent;
   private Module module;
   private BlocksSetting setting;
   private Consumer<Map<Block, Color>> colorSave;
   private final Set<Block> selected = new LinkedHashSet<>();
   private final Map<Block, Color> colors = new LinkedHashMap<>();
   private List<Block> filtered = List.of();
   private String query = "";
   private boolean selectedOnly;
   private boolean searchFocused = true;
   private int scroll;
   private Block colorBlock;
   private String hex = "";
   private boolean hexFocused;
   private float hue;
   private float saturation;
   private float brightness;
   private int colorDrag;
   private boolean replaceHex;

   public BlockPickerScreen(Screen parent, Module module, BlocksSetting setting) {
      this(parent, module, setting, colorsFor(module), colorWriter(module));
   }

   public BlockPickerScreen(Screen parent, Module module, BlocksSetting setting, Map<Block, Color> colors, Consumer<Map<Block, Color>> save) {
      super(Text.literal("Block Selection"));
      this.parent = parent;
      this.module = module;
      this.setting = setting;
      this.colorSave = save;
      this.colors.putAll(colors);
      this.selected.addAll(setting.getSelectedBlocks());
      if (module instanceof StorageESP storage) {
         Map<Block, Color> builtin = storage.getBuiltinBlockColors();
         this.selected.addAll(builtin.keySet());
         this.colors.putAll(builtin);
      }

      this.rebuild();
   }

   private static Map<Block, Color> colorsFor(Module module) {
      if (module instanceof StorageESP storage) {
         return storage.getCustomBlockColors();
      } else if (module instanceof ExtraESP extra) {
         return extra.getBlockColors();
      } else {
         return module instanceof BlockESP blocks ? blocks.getBlockColors() : Map.of();
      }
   }

   private static Consumer<Map<Block, Color>> colorWriter(Module module) {
      if (module instanceof StorageESP storage) {
         return storage::setCustomBlockColors;
      } else if (module instanceof ExtraESP extra) {
         return extra::setBlockColors;
      } else {
         return module instanceof BlockESP blocks ? blocks::setBlockColors : null;
      }
   }

   private void openColor(Block block) {
      this.colorBlock = block;
      this.searchFocused = false;
      this.hexFocused = false;
      this.colorDrag = 0;
      this.hex = String.format("%06X", this.colors.getOrDefault(block, new Color(11115263)).getRGB() & 16777215);
      this.readHex();
   }

   private void applyHex() {
      if (this.colorBlock != null && this.hex.matches("[0-9a-fA-F]{6}")) {
         Color chosen = new Color(Integer.parseInt(this.hex, 16));
         this.colors.put(this.colorBlock, chosen);
         if (this.colorSave != null) {
            Map<Block, Color> committed = new LinkedHashMap<>(colorsFor(this.module));
            committed.put(this.colorBlock, chosen);
            this.colorSave.accept(committed);
            ModuleManager.INSTANCE.onSettingChanged();
         }

         this.colorBlock = null;
         this.hexFocused = false;
         this.colorDrag = 0;
         this.rebuild();
      }
   }

   private int colorX() {
      return ((int)Position.screenWidth() - 250) / 2;
   }

   private int colorY() {
      return ((int)Position.screenHeight() - 230) / 2;
   }

   private void readHex() {
      if (this.hex.matches("[0-9a-fA-F]{6}")) {
         Color c = new Color(Integer.parseInt(this.hex, 16));
         float[] hsb = Color.RGBtoHSB(c.getRed(), c.getGreen(), c.getBlue(), null);
         this.hue = hsb[0];
         this.saturation = hsb[1];
         this.brightness = hsb[2];
      }
   }

   private void updateColor(double mx, double my) {
      if (this.colorDrag == 1) {
         this.saturation = (float)Math.clamp((mx - this.colorX() - 14.0) / 180.0, 0.0, 1.0);
         this.brightness = 1.0F - (float)Math.clamp((my - this.colorY() - 36.0) / 132.0, 0.0, 1.0);
      }

      if (this.colorDrag == 2) {
         this.hue = (float)Math.clamp((my - this.colorY() - 36.0) / 132.0, 0.0, 1.0);
      }

      this.hex = String.format("%06X", Color.HSBtoRGB(this.hue, this.saturation, this.brightness) & 16777215);
   }

   private void renderColor(DrawContext c) {
      int x = this.colorX();
      int y = this.colorY();
      if (this.colorDrag != 0) {
         if (GLFW.glfwGetMouseButton(this.client.getWindow().getHandle(), 0) == 1) {
            this.updateColor(Position.mouseX(), Position.mouseY());
         } else {
            this.colorDrag = 0;
         }
      }

      Render2D.rect(this.getInt3(), this.getInt4(), this.getInt(), this.getInt2(), 12.0F, 1880101912);
      RectUtil.drawClientRect(x, y, 250.0F, 230.0F, 9.0F, 1.0F, 0.0F);
      this.text(c, this.trim(this.setting.getDisplayName(this.colorBlock), 220), x + 14, y + 14, -1);

      for (int row = 0; row < 24; row++) {
         for (int col = 0; col < 24; col++) {
            int rgb = Color.HSBtoRGB(this.hue, col / 23.0F, 1.0F - row / 23.0F);
            Render2D.rect(x + 14 + col * 7.5F, y + 36 + row * 5.5F, 7.6F, 5.6F, 0.0F, rgb);
         }
      }

      for (int row = 0; row < 48; row++) {
         Render2D.rect(x + 208, y + 36 + row * 2.75F, 20.0F, 2.85F, 0.0F, Color.HSBtoRGB(row / 47.0F, 1.0F, 1.0F));
      }

      Render2D.outline(x + 14 + this.saturation * 180.0F - 3.0F, y + 36 + (1.0F - this.brightness) * 132.0F - 3.0F, 6.0F, 6.0F, 3.0F, 1.0F, -1);
      Render2D.outline(x + 206, y + 36 + this.hue * 132.0F - 2.0F, 24.0F, 4.0F, 1.0F, 1.0F, -1);
      this.box(c, x + 14, y + 179, 180, 19, -2146429928);
      this.text(c, "#" + this.hex + (this.hexFocused ? "|" : ""), x + 21, y + 184, this.hex.matches("[0-9a-fA-F]{6}") ? -1 : -30584);
      this.box(c, x + 208, y + 179, 20, 19, Color.HSBtoRGB(this.hue, this.saturation, this.brightness));
      this.box(c, x + 14, y + 205, 94, 19, 1343231000);
      this.text(c, "Cancel", x + 40, y + 210, -1);
      this.box(c, x + 134, y + 205, 94, 19, ClientAccent.accentSoft(140.0F));
      this.text(c, "Apply", x + 165, y + 210, -1);
   }

   private int getInt() {
      return Math.max(220, Math.min(516, (int)Position.screenWidth() - 20));
   }

   private int getInt2() {
      return Math.max(180, Math.min(348, (int)Position.screenHeight() - 20));
   }

   private int getInt3() {
      return ((int)Position.screenWidth() - this.getInt()) / 2;
   }

   private int getInt4() {
      return ((int)Position.screenHeight() - this.getInt2()) / 2;
   }

   private int cols() {
      return this.getInt() >= 420 ? 3 : 2;
   }

   private int getInt5() {
      return (this.getInt() - 24) / this.cols();
   }

   private int rows() {
      return Math.max(1, (this.getInt2() - 132) / 36);
   }

   private int maxScroll() {
      return Math.max(0, (this.filtered.size() + this.cols() - 1) / this.cols() - this.rows());
   }

   private void rebuild() {
      this.filtered = this.setting.filter(this.query).stream().filter(b -> !this.selectedOnly || this.selected.contains(b)).toList();
      this.scroll = Math.min(this.scroll, this.maxScroll());
   }

   private boolean hit(double mx, double my, int x, int y, int w, int h) {
      return mx >= x && mx < x + w && my >= y && my < y + h;
   }

   private void box(DrawContext c, int x, int y, int w, int h, int color) {
      Render2D.rect(x, y, w, h, 6.0F, color);
   }

   private void text(DrawContext c, String t, int x, int y, int color) {
      Fonts.MONTSERRAT_MEDIUM.draw(t, x, y, 8.0F, color);
   }

   private String trim(String s, int w) {
      if (Fonts.MONTSERRAT_MEDIUM.width(s, 8.0F) <= w) {
         return s;
      } else {
         while (!s.isEmpty() && Fonts.MONTSERRAT_MEDIUM.width("null...", 8.0F) > w) {
            s = s.substring(0, s.offsetByCodePoints(s.length(), -1));
         }

         return "null...";
      }
   }

   public void renderBackground(DrawContext c, int mx, int my, float dt) {
   }

   public void render(DrawContext c, int mx, int my, float dt) {
      int x = this.getInt3();
      int y = this.getInt4();
      int w = this.getInt();
      int h = this.getInt2();
      Render2D.beginFrame(c);
      BlurFramebuffer.beginWorldScope();

      try {
         RectUtil.drawClientRect(x, y, w, h, 12.0F, 1.0F, 6.0F);
         this.text(c, "Blocks", x + 12, y + 12, -1);
         this.text(c, Integer.toString(this.selected.size()), x + w - 104, y + 16, -4478209);
         this.box(c, x + 12, y + 42, w - 140, 23, 1695552800);
         this.text(c, this.trim(this.query.isEmpty() ? "Search..." : this.query, w - 156), x + 19, y + 50, this.query.isEmpty() ? -7300177 : -1);
         this.box(c, x + w - 120, y + 42, 108, 23, this.selectedOnly ? ClientAccent.accentSoft(95.0F) : 806360088);
         this.text(c, this.selectedOnly ? "Selected only" : "All blocks", x + w - 111, y + 50, -1);
         int start = this.scroll * this.cols();
         int count = Math.min(this.filtered.size() - start, this.rows() * this.cols());

         for (int i = 0; i < count; i++) {
            Block block = this.filtered.get(start + i);
            int rx = x + 12 + i % this.cols() * this.getInt5();
            int ry = y + 74 + i / this.cols() * 36;
            boolean active = this.selected.contains(block);
            boolean hover = this.hit(Position.mouseX(), Position.mouseY(), rx, ry, this.getInt5() - 5, 32);
            this.box(c, rx, ry, this.getInt5() - 5, 32, active ? ClientAccent.accentSoft(60.0F) : (hover ? 1614166850 : 1208618000));
            this.text(
               c,
               this.trim(this.setting.getDisplayName(block), this.getInt5() - (this.colorSave != null ? 91 : 46)),
               rx + 30,
               ry + 11,
               active ? -1 : -1325400065
            );
            if (this.colorSave != null) {
               int rgb = this.colors.getOrDefault(block, new Color(11115263)).getRGB();
               this.box(c, rx + this.getInt5() - 56, ry + 5, 48, 22, -2146429928);
               this.box(c, rx + this.getInt5() - 52, ry + 10, 10, 10, rgb);
               this.text(c, "Color", rx + this.getInt5() - 39, ry + 11, -1);
            }

            if (active) {
               Render2D.outline(rx, ry, this.getInt5() - 5, 32.0F, 6.0F, 0.6F, ClientAccent.accentSoft(160.0F));
            }
         }

         Render2D.flush();
         c.getMatrices().pushMatrix();
         float itemScale = Render2DCoordinateSpace.guiIndependentScale();
         c.getMatrices().scale(itemScale, itemScale);

         for (int i = 0; i < count; i++) {
            Block blockx = this.filtered.get(start + i);
            int rxx = x + 12 + i % this.cols() * this.getInt5();
            int ryx = y + 74 + i / this.cols() * 36;
            c.drawItem(new ItemStack(blockx.asItem()), rxx + 7, ryx + 8);
         }

         c.getMatrices().popMatrix();
         if (this.filtered.isEmpty()) {
            this.text(c, "No blocks found", x + 16, y + 82, -5655355);
         }

         if (this.maxScroll() > 0) {
            int track = this.rows() * 36;
            this.box(c, x + w - 7, y + 74, 2, track, 1346456416);
            this.box(c, x + w - 7, y + 74 + (int)((track - 16) * ((float)this.scroll / this.maxScroll())), 2, 16, ClientAccent.accentSoft(230.0F));
         }

         this.box(c, x + 12, y + h - 30, 65, 21, 1074795544);
         this.text(c, "Clear", x + 24, y + h - 23, -3353632);
         if (w >= 380) {
            this.box(c, x + 83, y + h - 30, 91, 21, ClientAccent.accentSoft(55.0F));
            this.text(c, "Select results", x + 88, y + h - 23, -1910028);
         }

         this.box(c, x + w - 157, y + h - 30, 68, 21, 1074795544);
         this.text(c, "Cancel", x + w - 147, y + h - 23, -3353632);
         this.box(c, x + w - 81, y + h - 30, 69, 21, ClientAccent.accentSoft(100.0F));
         this.text(c, "Save", x + w - 60, y + h - 23, -1);
         if (this.colorBlock != null) {
            this.renderColor(c);
         }
      } finally {
         BlurFramebuffer.endWorldScope();
         Render2D.flush();
      }
   }

   public boolean mouseClicked(Click click, boolean doubled) {
      double mx = click.x() / Render2DCoordinateSpace.guiIndependentScale();
      double my = click.y() / Render2DCoordinateSpace.guiIndependentScale();
      int x = this.getInt3();
      int y = this.getInt4();
      int w = this.getInt();
      int h = this.getInt2();
      if (this.colorBlock != null) {
         if (click.button() != 0) {
            return true;
         } else {
            int cx = this.colorX();
            int cy = this.colorY();
            this.colorDrag = 0;
            if (this.hit(mx, my, cx + 14, cy + 36, 180, 132)) {
               this.colorDrag = 1;
               this.hexFocused = false;
               this.updateColor(mx, my);
               return true;
            } else if (this.hit(mx, my, cx + 208, cy + 36, 20, 132)) {
               this.colorDrag = 2;
               this.hexFocused = false;
               this.updateColor(mx, my);
               return true;
            } else if (this.hit(mx, my, cx + 14, cy + 179, 180, 19)) {
               this.hexFocused = true;
               this.replaceHex = true;
               return true;
            } else if (this.hit(mx, my, cx + 14, cy + 205, 94, 19)) {
               this.colorBlock = null;
               return true;
            } else if (this.hit(mx, my, cx + 134, cy + 205, 94, 19)) {
               this.applyHex();
               return true;
            } else {
               return true;
            }
         }
      } else {
         if (click.button() == 0) {
            this.searchFocused = this.hit(mx, my, x + 12, y + 42, w - 140, 23);
            if (this.searchFocused) {
               return true;
            }

            if (w >= 380 && this.hit(mx, my, x + 83, y + h - 30, 91, 21)) {
               this.selected.addAll(this.filtered);
               this.rebuild();
               return true;
            }

            if (this.hit(mx, my, x + w - 120, y + 42, 108, 23)) {
               this.selectedOnly = !this.selectedOnly;
               this.scroll = 0;
               this.rebuild();
               return true;
            }

            if (this.hit(mx, my, x + 12, y + h - 30, 65, 21)) {
               this.selected.clear();
               this.rebuild();
               return true;
            }

            if (this.hit(mx, my, x + w - 157, y + h - 30, 68, 21)) {
               this.close();
               return true;
            }

            if (this.hit(mx, my, x + w - 81, y + h - 30, 69, 21)) {
               this.save();
               return true;
            }
         }

         for (int i = 0; i < this.rows() * this.cols(); i++) {
            int index = this.scroll * this.cols() + i;
            if (index >= this.filtered.size()) {
               break;
            }

            int rx = x + 12 + i % this.cols() * this.getInt5();
            int ry = y + 74 + i / this.cols() * 36;
            if (this.hit(mx, my, rx, ry, this.getInt5() - 5, 32)) {
               Block b = this.filtered.get(index);
               if (this.colorSave == null || click.button() != 1 && (click.button() != 0 || !this.hit(mx, my, rx + this.getInt5() - 56, ry + 5, 48, 22))) {
                  if (click.button() == 0) {
                     if (!this.selected.remove(b)) {
                        this.selected.add(b);
                     }

                     this.rebuild();
                  }
               } else {
                  this.openColor(b);
               }

               return true;
            }
         }

         return true;
      }
   }

   public boolean charTyped(CharInput input) {
      if (this.colorBlock != null) {
         String value = input.asString();
         if (this.hexFocused && value.matches("[0-9a-fA-F]")) {
            if (this.replaceHex) {
               this.hex = "";
               this.replaceHex = false;
            }

            if (this.hex.length() < 6) {
               this.hex = this.hex + value.toUpperCase(Locale.ROOT);
               this.readHex();
            }
         }

         return true;
      } else {
         if (this.searchFocused && this.query.length() < 100) {
            this.query = this.query + input.asString();
            this.scroll = 0;
            this.rebuild();
         }

         return true;
      }
   }

   public boolean keyPressed(KeyInput input) {
      if (this.colorBlock != null && input.getKeycode() == 257) {
         this.applyHex();
         return true;
      } else if (this.colorBlock != null && this.hexFocused && input.getKeycode() == 259) {
         if (!this.hex.isEmpty()) {
            this.hex = this.hex.substring(0, this.hex.length() - 1);
         }

         this.replaceHex = false;
         return true;
      } else if (input.isEscape()) {
         if (this.colorBlock != null) {
            this.colorBlock = null;
         } else {
            this.close();
         }

         return true;
      } else if (this.searchFocused && input.getKeycode() == 259 && !this.query.isEmpty()) {
         this.query = this.query.substring(0, this.query.offsetByCodePoints(this.query.length(), -1));
         this.scroll = 0;
         this.rebuild();
         return true;
      } else if (input.getKeycode() == 257) {
         this.searchFocused = false;
         return true;
      } else {
         return super.keyPressed(input);
      }
   }

   public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
      if (this.colorBlock != null) {
         return true;
      } else if (this.hit(
         mx / Render2DCoordinateSpace.guiIndependentScale(),
         my / Render2DCoordinateSpace.guiIndependentScale(),
         this.getInt3(),
         this.getInt4() + 74,
         this.getInt(),
         this.rows() * 36
      )) {
         this.scroll = Math.clamp((long)(this.scroll + (vertical > 0.0 ? -1 : (vertical < 0.0 ? 1 : 0))), 0, this.maxScroll());
         return true;
      } else {
         return false;
      }
   }

   private void save() {
      if (this.module instanceof StorageESP storage) {
         storage.applySelectedBlocks(this.selected);
      } else {
         this.setting.setValue(new LinkedHashSet<>(this.selected));
      }

      if (this.colorSave != null) {
         this.colorSave.accept(new LinkedHashMap<>(this.colors));
      }

      ModuleManager.INSTANCE.onSettingChanged();
      this.close();
   }

   public void close() {
      this.client.setScreen(this.parent);
   }

   public boolean shouldPause() {
      return false;
   }
}

