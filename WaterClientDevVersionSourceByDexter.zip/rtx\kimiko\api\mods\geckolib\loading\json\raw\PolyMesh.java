package rtx.kimiko.api.mods.geckolib.loading.json.raw;

import com.google.gson.JsonDeserializer;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import net.minecraft.util.JsonHelper;
import rtx.kimiko.api.mods.geckolib.util.JsonUtil;

public final class PolyMesh {
   private Boolean normalizedUVs;
   private double[] normals;
   private PolysUnion polysUnion;
   private double[] positions;
   private double[] uvs;

   public PolyMesh(Boolean normalizedUVs, double[] normals, PolysUnion polysUnion, double[] positions, double[] uvs) {
      this.normalizedUVs = normalizedUVs;
      this.normals = normals;
      this.polysUnion = polysUnion;
      this.positions = positions;
      this.uvs = uvs;
   }

   public static JsonDeserializer<PolyMesh> deserializer() throws JsonParseException {
      return (jsonElement, type, jsonDeserializationContext) -> {
         JsonObject jsonObject = jsonElement.getAsJsonObject();
         Boolean bl = JsonUtil.getOptionalBoolean(jsonObject, "normalized_uvs");
         double[] dArray = JsonUtil.jsonArrayToDoubleArray(JsonHelper.getArray(jsonObject, "normals", null));
         PolysUnion polysUnion = (PolysUnion)JsonHelper.deserialize(jsonObject, "polys", null, jsonDeserializationContext, PolysUnion.class);
         double[] dArray2 = JsonUtil.jsonArrayToDoubleArray(JsonHelper.getArray(jsonObject, "positions", null));
         double[] dArray3 = JsonUtil.jsonArrayToDoubleArray(JsonHelper.getArray(jsonObject, "uvs", null));
         return new PolyMesh(bl, dArray, polysUnion, dArray2, dArray3);
      };
   }

   public Boolean normalizedUVs() {
      return this.normalizedUVs;
   }

   public double[] normals() {
      return this.normals;
   }

   public PolysUnion polysUnion() {
      return this.polysUnion;
   }

   public double[] positions() {
      return this.positions;
   }

   public double[] uvs() {
      return this.uvs;
   }
}

