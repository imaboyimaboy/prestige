package com.water.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.OrderedText;
import net.minecraft.text.StringVisitable;
import net.minecraft.text.Style;

public final class NameProtectUtil {
   private NameProtectUtil() {
   }

   public static String replace(String text) {
      if (text != null && isActive()) {
         String realName = getRealName();
         String fakeName = getFakeName();
         if (realName != null && fakeName != null && !realName.isBlank() && !realName.equals(fakeName)) {
            return text.contains(realName) ? text.replace(realName, fakeName) : text;
         } else {
            return text;
         }
      } else {
         return text;
      }
   }

   public static StringVisitable replace(StringVisitable visitable) {
      if (visitable != null && isActive()) {
         List<NameProtectUtil.StyledChunk> replaced = replaceChunks(collect(visitable));
         if (replaced == null) {
            return visitable;
         } else if (replaced.isEmpty()) {
            return StringVisitable.EMPTY;
         } else {
            List<StringVisitable> parts = new ArrayList<>(replaced.size());

            for (NameProtectUtil.StyledChunk chunk : replaced) {
               parts.add(StringVisitable.styled(chunk.text(), chunk.style()));
            }

            return StringVisitable.concat(parts);
         }
      } else {
         return visitable;
      }
   }

   public static OrderedText replace(OrderedText orderedText) {
      if (orderedText != null && isActive()) {
         List<NameProtectUtil.StyledChunk> replaced = replaceChunks(collect(orderedText));
         if (replaced == null) {
            return orderedText;
         } else if (replaced.isEmpty()) {
            return OrderedText.empty();
         } else {
            List<OrderedText> parts = new ArrayList<>(replaced.size());

            for (NameProtectUtil.StyledChunk chunk : replaced) {
               parts.add(OrderedText.styledForwardsVisitedString(chunk.text(), chunk.style()));
            }

            return OrderedText.concat(parts);
         }
      } else {
         return orderedText;
      }
   }

   private static boolean isActive() {
      Object instance = getNameProtectInstance();
      if (instance != null && getRealName() != null && !getRealName().isBlank()) {
         try {
            Object enabled = instance.getClass().getMethod("isEnabled").invoke(instance);
            return Boolean.TRUE.equals(enabled);
         } catch (ReflectiveOperationException var2) {
            return false;
         }
      } else {
         return false;
      }
   }

   private static String getRealName() {
      MinecraftClient client = MinecraftClient.getInstance();
      return client != null && client.getSession() != null ? client.getSession().getUsername() : null;
   }

   private static String getFakeName() {
      Object instance = getNameProtectInstance();
      if (instance == null) {
         return null;
      } else {
         try {
            return instance.getClass().getMethod("getFakeName").invoke(instance) instanceof String s ? s : null;
         } catch (ReflectiveOperationException var3) {
            return null;
         }
      }
   }

   private static Object getNameProtectInstance() {
      try {
         Class<?> type = Class.forName("com.water.module.modules.misc.NameProtect", false, NameProtectUtil.class.getClassLoader());
         return type.getField("instance").get(null);
      } catch (LinkageError | ReflectiveOperationException var1) {
         return null;
      }
   }

   private static List<NameProtectUtil.StyledChunk> collect(StringVisitable visitable) {
      List<NameProtectUtil.StyledChunk> chunks = new ArrayList<>();
      visitable.visit((style, text) -> {
         appendCodePoints(chunks, text, style);
         return Optional.empty();
      }, Style.EMPTY);
      return chunks;
   }

   private static List<NameProtectUtil.StyledChunk> collect(OrderedText orderedText) {
      List<NameProtectUtil.StyledChunk> chunks = new ArrayList<>();
      orderedText.accept((index, style, codePoint) -> {
         chunks.add(new StyledChunk(new String(Character.toChars(codePoint)), style));
         return true;
      });
      return chunks;
   }

   private static void appendCodePoints(List<NameProtectUtil.StyledChunk> chunks, String text, Style style) {
      if (text != null && !text.isEmpty()) {
         int offset = 0;

         while (offset < text.length()) {
            int codePoint = text.codePointAt(offset);
            chunks.add(new StyledChunk(new String(Character.toChars(codePoint)), style));
            offset += Character.charCount(codePoint);
         }
      }
   }

   private static List<NameProtectUtil.StyledChunk> replaceChunks(List<NameProtectUtil.StyledChunk> chunks) {
      String realName = getRealName();
      String fakeName = getFakeName();
      if (realName != null && fakeName != null && !realName.isBlank() && !realName.equals(fakeName)) {
         StringBuilder plainBuilder = new StringBuilder();
         List<Integer> chunkStarts = new ArrayList<>(chunks.size());

         for (NameProtectUtil.StyledChunk chunk : chunks) {
            chunkStarts.add(plainBuilder.length());
            plainBuilder.append(chunk.text());
         }

         String plain = plainBuilder.toString();
         if (!plain.contains(realName)) {
            return null;
         } else {
            List<NameProtectUtil.StyledChunk> replaced = new ArrayList<>();
            int chunkIndex = 0;
            int searchFrom = 0;

            int matchIndex;
            while ((matchIndex = plain.indexOf(realName, searchFrom)) >= 0) {
               while (chunkIndex < chunks.size() && chunkStarts.get(chunkIndex) < matchIndex) {
                  replaced.add(chunks.get(chunkIndex++));
               }

               Style style = chunkIndex < chunks.size() ? chunks.get(chunkIndex).style() : Style.EMPTY;
               replaced.add(new StyledChunk(fakeName, style));
               int matchEnd = matchIndex + realName.length();

               while (chunkIndex < chunks.size() && chunkStarts.get(chunkIndex) < matchEnd) {
                  chunkIndex++;
               }

               searchFrom = matchEnd;
            }

            while (chunkIndex < chunks.size()) {
               replaced.add(chunks.get(chunkIndex++));
            }

            return merge(replaced);
         }
      } else {
         return null;
      }
   }

   private static List<NameProtectUtil.StyledChunk> merge(List<NameProtectUtil.StyledChunk> chunks) {
      if (chunks.isEmpty()) {
         return chunks;
      } else {
         List<NameProtectUtil.StyledChunk> merged = new ArrayList<>(chunks.size());
         NameProtectUtil.StyledChunk current = chunks.getFirst();

         for (int i = 1; i < chunks.size(); i++) {
            NameProtectUtil.StyledChunk next = chunks.get(i);
            if (Objects.equals(current.style(), next.style())) {
               current = new StyledChunk(current.text() + next.text(), current.style());
            } else {
               merged.add(current);
               current = next;
            }
         }

         merged.add(current);
         return merged;
      }
   }

   final static class StyledChunk {
      private String text;
      private Style style;

      private StyledChunk(String text, Style style) {
         style = style == null ? Style.EMPTY : style;
         this.text = text;
         this.style = style;
      }

      public String text() {
         return this.text;
      }

      public Style style() {
         return this.style;
      }
   }
}

