package com.water.utils.renderer.rect;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;
import com.water.utils.renderer.RenderUtil;
import java.nio.ByteBuffer;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.UniformType;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import org.lwjgl.system.MemoryUtil;

public class RectPipeline {
   private static RenderPipeline pipeline;
   private static GpuBuffer uniformBuffer;
   private static final int UNIFORM_SIZE = 256;

   public static void init() {
      if (pipeline == null) {
         try {
            pipeline = RenderPipeline.builder(new Snippet[0])
               .withLocation(Identifier.of("water", "rectangle"))
               .withVertexShader(Identifier.of("water", "rectangle_vertex"))
               .withFragmentShader(Identifier.of("water", "rectangle_fragment"))
               .withVertexFormat(VertexFormat.builder().build(), DrawMode.TRIANGLES)
               .withUniform("Uniforms", UniformType.UNIFORM_BUFFER)
               .withBlend(BlendFunction.TRANSLUCENT)
               .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
               .withCull(false)
               .build();
            uniformBuffer = RenderSystem.getDevice().createBuffer(() -> "Rect2D Uniforms", 136, 256L);
         } catch (Exception var1) {
            System.err.println("[Rect2D] Failed to init: " + var1.getMessage());
            var1.printStackTrace();
         }
      }
   }

   public static void draw(Matrix4f matrix, float x, float y, float width, float height, float tl, float tr, float br, float bl, float z, int... colors) {
      if (pipeline == null) {
         init();
      }

      if (pipeline != null && uniformBuffer != null) {
         int[] finalColors = normalizeColors(colors);
         ByteBuffer buffer = MemoryUtil.memAlloc(256);
         buffer.putFloat(matrix.m00()).putFloat(matrix.m01()).putFloat(matrix.m02()).putFloat(matrix.m03());
         buffer.putFloat(matrix.m10()).putFloat(matrix.m11()).putFloat(matrix.m12()).putFloat(matrix.m13());
         buffer.putFloat(matrix.m20()).putFloat(matrix.m21()).putFloat(matrix.m22()).putFloat(matrix.m23());
         buffer.putFloat(matrix.m30()).putFloat(matrix.m31()).putFloat(matrix.m32()).putFloat(matrix.m33());
         buffer.position(64);
         buffer.putFloat(x).putFloat(y).putFloat(width).putFloat(height);
         buffer.putFloat(tr).putFloat(br).putFloat(tl).putFloat(bl);
         buffer.position(96);
         buffer.putFloat(z).putFloat(0.0F).putFloat(0.0F).putFloat(0.0F);
         buffer.position(112);

         for (int i = 0; i < 9; i++) {
            int color = finalColors[i];
            buffer.putFloat((color >> 16 & 0xFF) / 255.0F);
            buffer.putFloat((color >> 8 & 0xFF) / 255.0F);
            buffer.putFloat((color & 0xFF) / 255.0F);
            buffer.putFloat((color >> 24 & 0xFF) / 255.0F);
         }

         buffer.flip();
         CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
         encoder.writeToBuffer(uniformBuffer.slice(), buffer);
         MemoryUtil.memFree(buffer);
         Framebuffer framebuffer = MinecraftClient.getInstance().getFramebuffer();
         RenderPass pass = encoder.createRenderPass(
            () -> "Rect2D", framebuffer.getColorAttachmentView(), OptionalInt.empty(), framebuffer.getDepthAttachmentView(), OptionalDouble.of(1.0)
         );

         try {
            RenderUtil.applyScissor(pass);
            pass.setPipeline(pipeline);
            pass.setUniform("Uniforms", uniformBuffer);
            pass.draw(0, 6);
         } catch (Throwable var19) {
            if (pass != null) {
               try {
                  pass.close();
               } catch (Throwable var18) {
                  var19.addSuppressed(var18);
               }
            }

            throw var19;
         }

         if (pass != null) {
            pass.close();
         }
      }
   }

   private static int[] normalizeColors(int[] colors) {
      if (colors.length == 1) {
         int c = colors[0];
         return new int[]{c, c, c, c, c, c, c, c, c};
      } else if (colors.length >= 9) {
         return colors;
      } else {
         int[] result = new int[9];

         for (int i = 0; i < 9; i++) {
            result[i] = i < colors.length ? colors[i] : colors[colors.length - 1];
         }

         return result;
      }
   }

   public static void shutdown() {
      if (uniformBuffer != null) {
         uniformBuffer.close();
         uniformBuffer = null;
      }

      pipeline = null;
   }
}

