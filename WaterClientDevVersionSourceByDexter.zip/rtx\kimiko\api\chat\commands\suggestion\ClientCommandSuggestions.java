package rtx.kimiko.api.chat.commands.suggestion;

import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Stream;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.screen.ChatInputSuggestor;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import rtx.kimiko.api.chat.commands.CommandManager;
import rtx.kimiko.mixin.accessor.CommandSuggestionsAccessor;

public class ClientCommandSuggestions extends ChatInputSuggestor {
   private TextFieldWidget editBox;

   public ClientCommandSuggestions(
      MinecraftClient minecraftClient,
      Screen screen,
      TextFieldWidget textFieldWidget,
      TextRenderer textRenderer,
      boolean bl,
      boolean bl2,
      int n,
      int n2,
      boolean bl3,
      int n3
   ) {
      super(minecraftClient, screen, textFieldWidget, textRenderer, bl, bl2, n, n2, bl3, n3);
      this.editBox = textFieldWidget;
   }

   public void refresh() {
      String string = this.editBox.getText();
      String string3 = CommandManager.get().getPrefix();
      CommandSuggestionsAccessor commandSuggestionsAccessor = (CommandSuggestionsAccessor)this;
      if (!commandSuggestionsAccessor.isKeepSuggestions()) {
         if (!string.startsWith(string3)) {
            super.refresh();
         } else {
            CompletableFuture<Suggestions> completableFuture = commandSuggestionsAccessor.getPendingSuggestions();
            if (completableFuture != null) {
               completableFuture.cancel(false);
            }

            commandSuggestionsAccessor.setPendingSuggestions(null);
            commandSuggestionsAccessor.setCurrentParse(null);
            this.editBox.setSuggestion("");
            String string4 = string.substring(string3.length());
            int n2 = string.lastIndexOf(60);
            int n;
            if (n2 >= 0) {
               int n3 = 1;
               int n5 = n2 + (n2 * n2 << -67);
               int suggestionsBuilder = n5 - (n5 * n5 << -67);
               n5 = 536870913;
               int var12 = 1;
               n = suggestionsBuilder + var12;
            } else {
               n = 0;
            }

            SuggestionsBuilder suggestionsBuilder = new SuggestionsBuilder(string, n);
            Stream<String> stream = CommandManager.get().tabComplete(string4);
            if (n2 < 0) {
               stream.map(string2 -> "nullnull").forEach(arg_0 -> suggestionsBuilder.suggest(arg_0));
            } else {
               stream.forEach(arg_0 -> suggestionsBuilder.suggest(arg_0));
            }

            Suggestions suggestions = suggestionsBuilder.build();
            if (suggestions.isEmpty()) {
               this.clearWindow();
            } else {
               commandSuggestionsAccessor.setPendingSuggestions(CompletableFuture.completedFuture(suggestions));
               commandSuggestionsAccessor.invokeShowSuggestions(false);
            }
         }
      }
   }
}

