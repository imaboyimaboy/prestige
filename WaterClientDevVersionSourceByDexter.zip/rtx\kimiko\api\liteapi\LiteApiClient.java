package rtx.kimiko.api.liteapi;

import com.google.gson.JsonObject;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.Disconnect;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.Join;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.client.MinecraftClient;
import rtx.kimiko.Kimiko;
import rtx.kimiko.api.liteapi.packets.LiteApiPayload;

public final class LiteApiClient {
   public static final LiteApiClient INSTANCE = new LiteApiClient();
   private static final String CLIENT_ID = "kimiko";
   private static final long TIMEOUT_MS = 10000L;
   private volatile boolean started = false;
   private final Map<String, Long> pending = new ConcurrentHashMap<>();

   private LiteApiClient() {
   }

   public void start() {
      if (!this.started) {
         this.started = true;
         PayloadTypeRegistry.playC2S().register(LiteApiPayload.TYPE, LiteApiPayload.CODEC);
         PayloadTypeRegistry.playS2C().register(LiteApiPayload.TYPE, LiteApiPayload.CODEC);
         ClientPlayNetworking.registerGlobalReceiver(
            LiteApiPayload.TYPE, (liteApiPayload, context) -> context.client().execute(() -> this.handle(liteApiPayload.json()))
         );
         ClientPlayConnectionEvents.JOIN.register((Join)(clientPlayNetworkHandler, packetSender, minecraftClient) -> this.onJoin());
         ClientPlayConnectionEvents.DISCONNECT.register((Disconnect)(clientPlayNetworkHandler, minecraftClient) -> this.onDisconnect());
      }
   }

   private void handle(String string) {
      LiteApiCodec.Incoming incoming = LiteApiCodec.parse(string);
      if (incoming == null) {
         Kimiko.LOGGER.warn("[LiteAPI] Получен невалидный пакет (не JSON-объект)");
      } else if (incoming.isPushEvent()) {
         Kimiko.LOGGER.debug("[LiteAPI] push-событие: {}", incoming.event());
      } else if (incoming.id() != null && this.pending.remove(incoming.id()) != null) {
         if (!incoming.isEnabled()) {
            String string2 = incoming.error() == null ? "UNKNOWN" : incoming.error();
            String string3 = incoming.message() == null ? "" : ": " + incoming.message();
            Kimiko.LOGGER.warn("[LiteAPI] checkFeatures ошибка {}{}", string2, string3);
         } else {
            JsonObject jsonObject = incoming.payload();
            List<String> list = LiteApiCodec.blocklist(jsonObject);
            FeatureBlocklist.applyBlocklist(list);
            if (MinecraftClient.getInstance() != null && !list.isEmpty()) {
               Kimiko.LOGGER.info("[LiteAPI] Сервер заблокировал фичи: {}", list);
            }
         }
      }
   }

   public void stop() {
      this.onDisconnect();
      this.started = false;
   }

   private void onDisconnect() {
      this.pending.clear();
      FeatureBlocklist.clear();
   }

   private void purgeExpired() {
      long l = System.currentTimeMillis();
      this.pending.entrySet().removeIf(entry -> l - entry.getValue() > 10000L);
   }

   private void onJoin() {
      Set<String> set = FeatureBlocklist.knownFeatures();
      if (!set.isEmpty()) {
         this.purgeExpired();
         LiteApiCodec.Request request = LiteApiCodec.checkFeatures("kimiko", set);
         this.pending.put(request.id(), System.currentTimeMillis());

         try {
            ClientPlayNetworking.send(new LiteApiPayload(request.json()));
         } catch (RuntimeException var4) {
            this.pending.remove(request.id());
            Kimiko.LOGGER.warn("[LiteAPI] Не удалось отправить checkFeatures: {}", var4.toString());
         }
      }
   }
}

