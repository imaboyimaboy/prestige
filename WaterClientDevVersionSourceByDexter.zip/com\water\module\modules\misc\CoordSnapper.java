package com.water.module.modules.misc;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.water.WaterClient;
import com.water.gui.notification.NotificationManager;
import com.water.module.ActivatableModule;
import com.water.module.Category;
import com.water.setting.Setting;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpClient.Redirect;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Util;

public final class CoordSnapper extends ActivatableModule {
   private static final Duration HTTP_TIMEOUT = Duration.ofSeconds(8L);
   private static final int SUCCESS_COLOR = -11152222;
   private static final int ERROR_COLOR = -1938838;
   private static final int WARNING_COLOR = -1002662;
   private static final ItemStack NOTIFICATION_STACK = new ItemStack(Items.RECOVERY_COMPASS);
   private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss z", Locale.ROOT);
   private static final long TRIGGER_COOLDOWN_MS = 250L;
   private static final HttpClient HTTP_CLIENT = HttpClient.newBuilder().connectTimeout(HTTP_TIMEOUT).followRedirects(Redirect.NORMAL).build();
   private final Setting<String> webhookUrl = new Setting<String>("Webhook", "") {
      @Override
      public boolean matchesName(String settingName) {
         return super.matchesName(settingName) || "Webhook URL".equalsIgnoreCase(settingName);
      }
   };
   private final Setting<Boolean> notification = new Setting<>("Notification", true);
   private volatile long lastTriggerAt;

   public CoordSnapper() {
      super("CoordSnapper", Category.MISC);
      this.addSetting(this.webhookUrl);
      this.addSetting(this.notification);
   }

   @Override
   public void onActivationKeyPressed() {
      if (this.isEnabled() && mc.player != null) {
         long now = System.currentTimeMillis();
         if (now - this.lastTriggerAt >= 250L) {
            this.lastTriggerAt = now;
            String webhook = this.normalizeWebhook(this.webhookUrl.getValue());
            if (!this.isValidWebhook(webhook)) {
               this.showNotification("Webhook invalid", "Set a Discord webhook URL.", -1002662);
            } else {
               CoordSnapper.CoordSnapshot snapshot = this.captureSnapshot(webhook);
               CompletableFuture.runAsync(() -> this.sendWebhook(snapshot), Util.getIoWorkerExecutor().named("coordsnapper-send"))
                  .whenComplete((ignored, throwable) -> mc.execute(() -> {
                     if (throwable != null) {
                        this.showNotification("Send failed", this.getRootMessage(throwable), -1938838);
                     } else {
                        this.showNotification("Coords sent", snapshot.coordsInline(), -11152222);
                     }
                  }));
            }
         }
      }
   }

   private CoordSnapper.CoordSnapshot captureSnapshot(String webhook) {
      int blockX = mc.player.getBlockX();
      int blockY = mc.player.getBlockY();
      int blockZ = mc.player.getBlockZ();
      String playerName = mc.player.getName().getString();
      String serverIp = this.resolveServerIp();
      String time = TIME_FORMATTER.format(ZonedDateTime.now());
      String encodedName = this.encodeSkinName(playerName);
      String skinRenderUrl = "https://mc-heads.net/body/null";
      return new CoordSnapshot(webhook, playerName, blockX, blockY, blockZ, serverIp, time, "https://mc-heads.net/body/null");
   }

   private void sendWebhook(CoordSnapper.CoordSnapshot snapshot) {
      JsonObject payload = new JsonObject();
      payload.addProperty("username", "CoordSnapper");
      JsonObject embed = new JsonObject();
      embed.addProperty("title", "CoordSnapper");
      embed.addProperty("color", 5624994);
      JsonArray fields = new JsonArray();
      fields.add(this.createField("Name", snapshot.playerName(), false));
      fields.add(this.createField("Coords", snapshot.coordsField(), false));
      fields.add(this.createField("IP", snapshot.serverIp(), true));
      fields.add(this.createField("Time", snapshot.time(), true));
      embed.add("fields", fields);
      JsonObject thumbnail = new JsonObject();
      thumbnail.addProperty("url", snapshot.skinRenderUrl());
      embed.add("thumbnail", thumbnail);
      JsonArray embeds = new JsonArray();
      embeds.add(embed);
      payload.add("embeds", embeds);
      HttpRequest request = HttpRequest.newBuilder(this.buildWebhookUri(snapshot.webhook()))
         .timeout(HTTP_TIMEOUT)
         .header("Content-Type", "application/json")
         .header("Accept", "application/json")
         .header("User-Agent", "Water-CoordSnapper")
         .POST(BodyPublishers.ofString(payload.toString()))
         .build();

      HttpResponse<String> response;
      try {
         response = HTTP_CLIENT.send(request, BodyHandlers.ofString());
      } catch (Exception var11) {
         WaterClient.LOGGER.error("CoordSnapper webhook request failed", var11);
         throw new IllegalStateException("Webhook request failed", var11);
      }

      int status = response.statusCode();
      if (status >= 200 && status < 300) {
         WaterClient.LOGGER.info("CoordSnapper sent coords for {}", snapshot.playerName());
      } else {
         String body = response.body();
         if (body != null && !body.isBlank()) {
            WaterClient.LOGGER.warn("CoordSnapper webhook rejected with status {} and body {}", status, this.trimSingleLine(body, 240));
            throw new IllegalStateException("HTTP " + status + ": " + this.trimSingleLine(body, 120));
         } else {
            WaterClient.LOGGER.warn("CoordSnapper webhook rejected with status {}", status);
            throw new IllegalStateException("HTTP " + status);
         }
      }
   }

   private JsonObject createField(String name, String value, boolean inline) {
      JsonObject field = new JsonObject();
      field.addProperty("name", name);
      field.addProperty("value", value != null && !value.isBlank() ? value : "-");
      field.addProperty("inline", inline);
      return field;
   }

   private String resolveServerIp() {
      ServerInfo serverInfo = mc.getCurrentServerEntry();
      if (serverInfo != null && serverInfo.address != null && !serverInfo.address.isBlank()) {
         String host = this.normalizeHost(serverInfo.address);
         return host.isEmpty() ? "Singleplayer" : host;
      } else {
         return "Singleplayer";
      }
   }

   private String normalizeHost(String address) {
      String normalized = address == null ? "" : address.trim().toLowerCase(Locale.ROOT);
      int slashIndex = normalized.indexOf(47);
      if (slashIndex >= 0) {
         normalized = normalized.substring(0, slashIndex);
      }

      int colonIndex = normalized.indexOf(58);
      if (colonIndex >= 0) {
         normalized = normalized.substring(0, colonIndex);
      }

      return normalized;
   }

   private String normalizeWebhook(String value) {
      return value == null ? "" : value.trim();
   }

   private String encodeSkinName(String playerName) {
      return playerName != null && !playerName.isBlank() ? playerName.trim() : "Steve";
   }

   private URI buildWebhookUri(String webhook) {
      URI uri = URI.create(webhook);
      String query = uri.getQuery();
      if (query == null || query.isBlank()) {
         return URI.create("null?wait=true");
      } else {
         return query.contains("wait=") ? uri : URI.create("null&wait=true");
      }
   }

   private boolean isValidWebhook(String webhook) {
      if (webhook.isEmpty()) {
         return false;
      } else {
         try {
            URI uri = URI.create(webhook);
            String scheme = uri.getScheme();
            String host = uri.getHost();
            String path = uri.getPath();
            return ("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme))
               && host != null
               && !host.isBlank()
               && path != null
               && path.contains("/api/webhooks/");
         } catch (Exception var6) {
            return false;
         }
      }
   }

   private void showNotification(String message, String details, int accentColor) {
      if (mc != null && this.notification.getValue()) {
         mc.execute(() -> NotificationManager.INSTANCE.push(message, details, NOTIFICATION_STACK, accentColor));
      }
   }

   private String getRootMessage(Throwable throwable) {
      Throwable current = throwable;

      while (current.getCause() != null) {
         current = current.getCause();
      }

      String message = current.getMessage();
      return message != null && !message.isBlank() ? this.trimSingleLine(message, 120) : current.getClass().getSimpleName();
   }

   private String trimSingleLine(String value, int maxLength) {
      if (value == null) {
         return "";
      } else {
         String trimmed = value.replace('\n', ' ').replace('\r', ' ').trim();
         return trimmed.length() <= maxLength ? trimmed : trimmed.substring(0, Math.max(0, maxLength - 3)) + "...";
      }
   }

   final class CoordSnapshot {
      private String webhook;
      private String playerName;
      private int intVal;
      private int intVal2;
      private int intVal3;
      private String serverIp;
      private String time;
      private String skinRenderUrl;

      private CoordSnapshot(String webhook, String playerName, int x, int y, int z, String serverIp, String time, String skinRenderUrl) {
         this.webhook = webhook;
         this.playerName = playerName;
         this.intVal = x;
         this.intVal2 = y;
         this.intVal3 = z;
         this.serverIp = serverIp;
         this.time = time;
         this.skinRenderUrl = skinRenderUrl;
      }

      private String coordsField() {
         return "X: " + this.intVal + " Y: " + this.intVal2 + " Z: " + this.intVal3;
      }

      private String coordsInline() {
         return this.intVal + ", " + this.intVal2 + ", " + this.intVal3;
      }

      public String webhook() {
         return this.webhook;
      }

      public String playerName() {
         return this.playerName;
      }

      public int getInt() {
         return this.intVal;
      }

      public int getInt2() {
         return this.intVal2;
      }

      public int getInt3() {
         return this.intVal3;
      }

      public String serverIp() {
         return this.serverIp;
      }

      public String time() {
         return this.time;
      }

      public String skinRenderUrl() {
         return this.skinRenderUrl;
      }
   }
}

