package com.water.module.modules.misc;

import com.water.gui.notification.NotificationManager;
import com.water.module.Category;
import com.water.module.Module;
import com.water.setting.ModeSetting;
import com.water.setting.Setting;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;

public final class WeatherNotifier extends Module {
   private final ModeSetting notificationMode = new ModeSetting("Notification Mode", "Both", "Chat", "Toast", "Both");
   private final Setting<Boolean> notifyThunder = new Setting<>("Notify Thunder", true);
   private Boolean wasRaining = null;
   private Boolean wasThundering = null;

   public WeatherNotifier() {
      super("WeatherNotifier", Category.MISC);
      this.addSetting(this.notificationMode);
      this.addSetting(this.notifyThunder);
   }

   @Override
   public void onEnable() {
      this.wasRaining = null;
      this.wasThundering = null;
   }

   @Override
   public void onDisable() {
      this.wasRaining = null;
      this.wasThundering = null;
   }

   @Override
   public void onTick() {
      if (mc.world != null && mc.player != null) {
         boolean raining = mc.world.isRaining();
         boolean thundering = mc.world.isThundering();
         if (this.wasRaining == null) {
            this.wasRaining = raining;
            this.wasThundering = thundering;
         } else {
            if (raining && !this.wasRaining) {
               this.notify("The rain started.", "Rain Started", -10835482);
            } else if (!raining && this.wasRaining) {
               this.notify("The rain stopped.", "Rain Stopped", -340971);
            }

            if (this.notifyThunder.getValue()) {
               if (thundering && !this.wasThundering) {
                  this.notify("A thunderstorm started.", "Thunder Started", -4879105);
               } else if (!thundering && this.wasThundering) {
                  this.notify("The thunderstorm ended.", "Thunder Ended", -340971);
               }
            }

            this.wasRaining = raining;
            this.wasThundering = thundering;
         }
      }
   }

   private void notify(String chatMessage, String toastTitle, int accent) {
      String mode = this.notificationMode.getValue();
      boolean toChat = "Chat".equalsIgnoreCase(mode) || "Both".equalsIgnoreCase(mode);
      boolean toToast = "Toast".equalsIgnoreCase(mode) || "Both".equalsIgnoreCase(mode);
      if (toChat) {
         try {
            mc.inGameHud.getChatHud().addMessage(Text.literal("[WeatherNotifier] null"));
         } catch (Throwable var8) {
         }
      }

      if (toToast) {
         NotificationManager.INSTANCE.push("WeatherNotifier", toastTitle, ItemStack.EMPTY, accent);
      }
   }
}

