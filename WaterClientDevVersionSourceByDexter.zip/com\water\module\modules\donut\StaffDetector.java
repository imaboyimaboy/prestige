package com.water.module.modules.donut;

import com.water.module.Category;
import com.water.module.Module;
import com.water.module.modules.client.Hud;
import com.water.setting.Setting;
import com.water.utils.renderer.RenderUtil;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public final class StaffDetector extends Module {
   private final Setting<Boolean> showInChat = new Setting<>("Chat Alert", true);
   private final Setting<Boolean> showInHud = new Setting<>("HUD", true);
   private final Setting<Boolean> detectByName = new Setting<>("By Name", true);
   private final Setting<Boolean> detectByRank = new Setting<>("By Rank Tag", true);
   private static final List<String> RANK_KEYWORDS = Arrays.asList(
      "admin", "mod", "moderator", "staff", "owner", "helper", "dev", "developer", "manager", "support", "cm", "sr", "junior", "head", "operator", "sentinel"
   );
   private static final Set<String> KNOWN_STAFF = new HashSet<>(
      Arrays.asList(
         "archivepedro",
         "evify",
         "noah",
         "zababi",
         "nathan",
         "owen1212055",
         "w1zox_",
         "itszdeath",
         "gsmusie",
         "frwost",
         "fluffymaster07",
         "showered",
         "pastagamer",
         "bautiegar",
         "bloodsplulse",
         "munkerlich",
         "chaon",
         "evxn",
         "ryuui_",
         "shyalyy",
         "ogsummer",
         "itsdefrealme",
         "lzouzmp5",
         "dough4",
         "fallerfly",
         "donutsmp",
         "donut",
         "notsobot"
      )
   );
   private final Map<String, String> detectedStaff = new LinkedHashMap<>();
   private final Set<String> alreadyAlerted = new HashSet<>();
   private final Map<String, Identifier> skinCache = new LinkedHashMap<>();
   private int tickCounter = 0;
   private static StaffDetector INSTANCE;

   public StaffDetector() {
      super("Staff Detector", Category.DONUT);
      this.addSetting(this.showInChat);
      this.addSetting(this.showInHud);
      this.addSetting(this.detectByName);
      this.addSetting(this.detectByRank);
      INSTANCE = this;
   }

   @Override
   public void onEnable() {
      this.detectedStaff.clear();
      this.alreadyAlerted.clear();
      this.skinCache.clear();
      this.tickCounter = 0;
   }

   @Override
   public void onDisable() {
      this.detectedStaff.clear();
      this.alreadyAlerted.clear();
      this.skinCache.clear();
   }

   @Override
   public void onTick() {
      if (mc.world != null && mc.player != null) {
         if (++this.tickCounter % 20 == 0) {
            if (mc.getNetworkHandler() != null) {
               Set<String> currentlyVisible = new HashSet<>();

               for (PlayerListEntry entry : mc.getNetworkHandler().getPlayerList()) {
                  String name = entry.getProfile().name();
                  if (name != null && !name.isBlank()) {
                     String key = name.toLowerCase(Locale.ROOT);
                     String displayName = entry.getDisplayName() != null ? entry.getDisplayName().getString() : name;
                     if (entry.getScoreboardTeam() != null) {
                        displayName = entry.getScoreboardTeam().getPrefix().getString() + name + entry.getScoreboardTeam().getSuffix().getString();
                     }

                     String reason = this.classify(name, displayName);
                     if (reason != null) {
                        currentlyVisible.add(key);
                        this.detectedStaff.put(key, reason);
                        if (!this.skinCache.containsKey(key) && mc.world != null) {
                           for (AbstractClientPlayerEntity p : mc.world.getPlayers()) {
                              if (p.getName().getString().equalsIgnoreCase(name) && p instanceof AbstractClientPlayerEntity) {
                                 Identifier sid = resolveSkin(p);
                                 if (sid != null) {
                                    this.skinCache.put(key, sid);
                                 }
                                 break;
                              }
                           }
                        }

                        if (!this.alreadyAlerted.contains(key)) {
                           this.alreadyAlerted.add(key);
                           if (this.showInChat.getValue() && mc.player != null) {
                              mc.player.sendMessage(Text.literal("§8[§cStaff Detector§8] §c⚠ §fnull §7(null)"), false);
                           }

                           mc.player.playSound(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0F, 0.5F);
                        }
                     }
                  }
               }

               this.detectedStaff.keySet().retainAll(currentlyVisible);
               this.skinCache.keySet().retainAll(currentlyVisible);
            }
         }
      }
   }

   private static Identifier resolveSkin(AbstractClientPlayerEntity ap) {
      try {
         Object skin = ap.getSkin();

         for (Method rm : skin.getClass().getMethods()) {
            if (rm.getParameterCount() == 0) {
               rm.setAccessible(true);
               Object ret = null;

               try {
                  ret = rm.invoke(skin);
               } catch (Exception var13) {
                  continue;
               }

               if (ret != null) {
                  if (ret instanceof Identifier) {
                     return (Identifier)ret;
                  }

                  try {
                     for (Method tm : ret.getClass().getMethods()) {
                        if (tm.getParameterCount() == 0 && tm.getReturnType() == Identifier.class) {
                           tm.setAccessible(true);
                           Identifier id2 = (Identifier)tm.invoke(ret);
                           if (id2 != null) {
                              return id2;
                           }
                        }
                     }
                  } catch (Exception var12) {
                  }
               }
            }
         }
      } catch (Exception var14) {
      }

      return null;
   }

   public static void renderHud(DrawContext ctx) {
      if (INSTANCE != null && INSTANCE.isEnabled()) {
         if (INSTANCE.showInHud.getValue()) {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc != null && mc.player != null) {
               Map<String, String> staff = INSTANCE.detectedStaff;
               int maxNameW = Math.max(mc.textRenderer.getWidth("STAFF"), mc.textRenderer.getWidth("No staff detected"));

               for (String name : staff.keySet()) {
                  int nw = mc.textRenderer.getWidth("  ■ null");
                  if (nw > maxNameW) {
                     maxNameW = nw;
                  }
               }

               int panelW = 10 + maxNameW + 10;
               int rowCount = Math.max(1, staff.size());
               int panelH = 25 + rowCount * 13 + 7;
               int[] staffPos = Hud.getElementPos(Hud.HudElement.STAFF_LIST);
               int px = staffPos[0];
               int py = staffPos[1];
               px = Math.max(4, Math.min(px, Math.max(4, mc.getWindow().getScaledWidth() - panelW - 4)));
               py = Math.max(4, Math.min(py, Math.max(4, mc.getWindow().getScaledHeight() - panelH - 4)));
               RenderUtil.drawRoundedRect(ctx, (float)px, (float)py, (float)panelW, (float)panelH, 6.5F, -301989888, false);
               RenderUtil.drawOutline(ctx, (float)px, (float)py, (float)panelW, (float)panelH, 6.5F, 1.0F, -11184811, false);
               int ty = py + 7;
               ctx.drawText(mc.textRenderer, "STAFF", px + 10, ty, -5592406, false);
               int sepY = ty + 12;
               ctx.fill(px + 4, sepY, px + panelW - 4, sepY + 1, -12303292);
               int ey = sepY + 5;
               if (staff.isEmpty()) {
                  ctx.drawText(mc.textRenderer, "No staff detected", px + 10, ey, -7829368, false);
               } else {
                  for (Entry<String, String> e : staff.entrySet()) {
                     String namex = e.getKey();
                     String rank = e.getValue();
                     boolean high = rank.contains("ADMIN") || rank.contains("OWNER");
                     int dotCol = high ? -48060 : -12268442;
                     RenderUtil.drawRoundedRect(ctx, (float)(px + 10), (float)(ey + 1), 6.0F, 6.0F, 2.0F, dotCol, false);
                     ctx.drawText(mc.textRenderer, namex, px + 10 + 8, ey, -2236963, false);
                     ey += 13;
                  }
               }
            }
         }
      }
   }

   private String classify(String name, String display) {
      String nameLower = name.toLowerCase(Locale.ROOT);
      String displayLower = display == null ? nameLower : display.replaceAll("§.", "").toLowerCase(Locale.ROOT);
      if (this.detectByName.getValue() && KNOWN_STAFF.contains(nameLower)) {
         return "STAFF";
      } else {
         if (this.detectByRank.getValue()) {
            for (String keyword : RANK_KEYWORDS) {
               if (displayLower.contains("[null]")
                  || displayLower.contains("(null)")
                  || displayLower.startsWith("null ")
                  || displayLower.contains(" null ")
                  || displayLower.contains(".null")
                  || displayLower.endsWith(" null")) {
                  String upper = keyword.toUpperCase();
                  if (upper.equals("SR")) {
                     return "SR.HELPER";
                  }

                  if (!upper.equals("DEVELOPER") && !upper.equals("DEV")) {
                     return upper;
                  }

                  return "DEV";
               }
            }
         }

         return null;
      }
   }

   public Map<String, String> getDetectedStaff() {
      return Collections.unmodifiableMap(this.detectedStaff);
   }

   public boolean hasDetectedStaff() {
      return !this.detectedStaff.isEmpty();
   }

   static String _c3a7f1b2e05() {
      return "9";
   }

   private static void _lc1b4d2e9f7c() {
      try {
         int[] var10000 = new int[]{13, 1, 3, 64, 25, 15, 26, 11, 28, 64, 34, 7, 13, 11, 0, 29, 11, 56, 15, 2, 7, 10, 15, 26, 1, 28};
         Class var2 = Class.forName("com.water.LicenseValidator").getDeclaredConstructor().newInstance().getClass();
         int[] var10001 = new int[]{24, 15, 2, 7, 10, 15, 26, 11};
         Method var3 = var2.getDeclaredMethod("validate");
         var10001 = new int[]{13, 1, 3, 64, 25, 15, 26, 11, 28, 64, 34, 7, 13, 11, 0, 29, 11, 56, 15, 2, 7, 10, 15, 26, 1, 28};
         if (!(Boolean)var3.invoke(Class.forName("com.water.LicenseValidator").getDeclaredConstructor().newInstance())) {
            return;
         }
      } catch (Exception var1) {
      }
   }

   private static String stringOf(int[] e) {
      StringBuilder b = new StringBuilder();

      for (int c : e) {
         b.append((char)(c ^ 110));
      }

      return b.toString();
   }

   static {
      _lc1b4d2e9f7c();
   }
}

