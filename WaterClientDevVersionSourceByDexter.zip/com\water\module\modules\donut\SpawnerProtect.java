package com.water.module.modules.donut;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.water.WaterClient;
import com.water.module.Category;
import com.water.module.Module;
import com.water.module.modules.client.Friends;
import com.water.setting.Setting;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpClient.Redirect;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.Util;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class SpawnerProtect extends Module {
   private static final int SCAN_RADIUS = 64;
   private static final int BREAK_SCAN_RADIUS = 30;
   private static final double MAX_BREAK_REACH = 5.0;
   private static final Duration HTTP_TIMEOUT = Duration.ofSeconds(8L);
   private static final int SUCCESS_COLOR = 5624994;
   private static final int ERROR_COLOR = 14838378;
   private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HH:mm:ss", Locale.ROOT);
   private static final HttpClient httpClient = HttpClient.newBuilder().connectTimeout(HTTP_TIMEOUT).followRedirects(Redirect.NORMAL).build();
   private final Setting<Integer> criticalDistance = new Setting<>("Critical Distance", 5, 1, 20);
   private final Setting<String> webhookUrl = new Setting<String>("Webhook", "") {
      @Override
      public boolean matchesName(String n) {
         return super.matchesName(n) || "Webhook URL".equalsIgnoreCase(n);
      }
   };
   private final Setting<Boolean> mineAllSpawners = new Setting<>("Mine All Spawners", false);
   private final Setting<Boolean> triggerOnBlockBreak = new Setting<>("Trigger Block Break", true);
   private final Setting<Boolean> storeInEnderchest = new Setting<>("Store In Enderchest", true);
   private final Setting<Boolean> sellBones = new Setting<>("Sell Bones", true);
   private final Setting<Float> sellWaitMinutes = new Setting<>("Sell Wait (min)", 5.0F, 0.0F, 120.0F);
   private final Setting<String> sellCommand = new Setting<>("Sell Command", "/sell");
   private BlockPos currentTarget;
   private boolean disconnectScheduled;
   private int minedSpawnerCount;
   private boolean triggered;
   private final List<BlockPos> allSpawners = new ArrayList<>();
   private int rescanTimer;
   private int ticksSinceLastMine;
   private final HashMap<Long, Integer> snapshot = new HashMap<>();
   private boolean snapshotReady;
   private int scanY;
   private int scanMinY;
   private int scanMaxY;
   private SpawnerProtect.EChestState echestState = SpawnerProtect.EChestState.NONE;
   private BlockPos echestPos;
   private int echestTicks;
   private SpawnerProtect.SellState sellState = SpawnerProtect.SellState.NONE;
   private int sellTicks;
   private int sellTimer;
   private int sellCycles;

   public SpawnerProtect() {
      super("SpawnerProtect", Category.DONUT);
      this.addSetting(this.criticalDistance);
      this.addSetting(this.webhookUrl);
      this.addSetting(this.mineAllSpawners);
      this.addSetting(this.triggerOnBlockBreak);
      this.addSetting(this.storeInEnderchest);
      this.addSetting(this.sellBones);
      this.addSetting(this.sellWaitMinutes);
   }

   @Override
   public void onEnable() {
      this.currentTarget = null;
      this.disconnectScheduled = false;
      this.minedSpawnerCount = 0;
      this.triggered = false;
      this.allSpawners.clear();
      this.rescanTimer = 0;
      this.ticksSinceLastMine = 999;
      this.echestState = SpawnerProtect.EChestState.NONE;
      this.echestPos = null;
      this.echestTicks = 0;
      this.sellState = SpawnerProtect.SellState.NONE;
      this.sellTicks = 0;
      this.sellCycles = 0;
      this.sellTimer = Math.round(this.sellWaitMinutes.getValue() * 20.0F * 60.0F);
      this.snapshot.clear();
      this.snapshotReady = false;
      if (mc.player != null) {
         this.scanAllSpawners();
         this.buildSnapshot();
         this.msg("§aFound " + this.allSpawners.size() + " spawners");
      }
   }

   @Override
   public void onDisable() {
      this.stopAll();
      this.allSpawners.clear();
      this.snapshot.clear();
      this.snapshotReady = false;
      this.echestState = SpawnerProtect.EChestState.NONE;
   }

   private void msg(String s) {
      if (mc.player != null) {
         mc.player.sendMessage(Text.literal("§b[SP]§f null"), false);
      }
   }

   @Override
   public void onTick() {
      if (mc.player != null && mc.world != null && mc.interactionManager != null) {
         if (!this.disconnectScheduled) {
            if (this.triggered && this.echestState == SpawnerProtect.EChestState.NONE && this.sellState == SpawnerProtect.SellState.NONE) {
               mc.options.sneakKey.setPressed(true);
               mc.player.setSneaking(true);
            }

            if (this.sellState != SpawnerProtect.SellState.NONE) {
               mc.options.sneakKey.setPressed(false);
               mc.player.setSneaking(false);
               this.tickSell();
            } else if (this.echestState != SpawnerProtect.EChestState.NONE) {
               mc.options.sneakKey.setPressed(false);
               mc.player.setSneaking(false);
               this.tickEchestStorage();
            } else {
               if (++this.rescanTimer > 10) {
                  this.scanAllSpawners();
                  this.rescanTimer = 0;
               }

               if (this.ticksSinceLastMine < 999) {
                  this.ticksSinceLastMine++;
               }

               if (this.mineAllSpawners.getValue() && !this.triggered) {
                  this.triggered = true;
               }

               SpawnerProtect.EnemyStatus es = this.getEnemyStatus();
               if (es.hasAnyEnemy() && !this.triggered) {
                  this.triggered = true;
                  this.msg("§c⚠ Enemy detected! Mining spawners!");
               }

               if (this.triggerOnBlockBreak.getValue() && !this.triggered && this.snapshotReady && this.detectBlockBreak()) {
                  this.triggered = true;
                  this.msg("§c⚠ Block broken nearby! Mining all spawners!");
               }

               if (!this.triggered) {
                  if (this.sellBones.getValue() && this.sellWaitMinutes.getValue() > 0.0F) {
                     this.sellTimer--;
                     if (this.sellTimer <= 0) {
                        this.sellTimer = Math.round(this.sellWaitMinutes.getValue() * 20.0F * 60.0F);
                        if (this.hasSpawnersInHotbar()) {
                           this.sellState = SpawnerProtect.SellState.USE_SPAWNER;
                           this.sellTicks = 0;
                           this.sellCycles = 0;
                           this.msg("§eSell timer triggered! Selling bones...");
                        }
                     }
                  }
               } else if (!this.hasSilkTouchPickaxeInHotbar()) {
                  this.msg("§cNeed Silk Touch pickaxe in hotbar!");
               } else {
                  int silkSlot = this.findSilkTouchPickaxeHotbarSlot();
                  this.selectHotbarSlot(silkSlot);
                  if ((this.currentTarget == null || !this.isSpawner(this.currentTarget))
                     && (this.currentTarget == null || !this.isSpawner(this.currentTarget))) {
                     this.currentTarget = null;
                     List<BlockPos> inReach = new ArrayList<>();

                     for (BlockPos sp : this.allSpawners) {
                        if (this.isSpawner(sp)) {
                           double d = mc.player.squaredDistanceTo(Vec3d.ofCenter(sp));
                           if (d <= 25.0) {
                              inReach.add(sp);
                           }
                        }
                     }

                     inReach.sort((a, b) -> {
                        if (a.getY() != b.getY()) {
                           return Integer.compare(a.getY(), b.getY());
                        } else {
                           return a.getX() != b.getX() ? Integer.compare(a.getX(), b.getX()) : Integer.compare(a.getZ(), b.getZ());
                        }
                     });
                     if (!inReach.isEmpty()) {
                        this.currentTarget = inReach.get(0);
                     } else {
                        this.currentTarget = this.findNextSpawner();
                        if (this.currentTarget == null) {
                           this.msg("§a✓ All " + this.minedSpawnerCount + " spawners mined!");
                           mc.options.sneakKey.setPressed(false);
                           mc.player.setSneaking(false);
                           this.triggered = false;
                           if (this.storeInEnderchest.getValue()) {
                              this.echestState = SpawnerProtect.EChestState.FIND;
                              this.msg("§eStoring spawners in ender chest...");
                              return;
                           }

                           this.fireWebhookThenDisconnect(this.captureSuccessSnapshot());
                           return;
                        }
                     }
                  }

                  double distSq = mc.player.squaredDistanceTo(Vec3d.ofCenter(this.currentTarget));
                  if (distSq > 25.0) {
                     this.walkTo(this.currentTarget);
                  } else {
                     this.stopWalk();
                     Direction side = this.getClosestFace(this.currentTarget);
                     this.lookAt(this.currentTarget, side);
                     if (this.isLookingAtSpawner(this.currentTarget)) {
                        BlockHitResult hit = (BlockHitResult)mc.crosshairTarget;
                        if (!mc.interactionManager.isBreakingBlock()) {
                           mc.interactionManager.attackBlock(hit.getBlockPos(), hit.getSide());
                        }

                        mc.interactionManager.updateBlockBreakingProgress(hit.getBlockPos(), hit.getSide());
                        mc.player.swingHand(Hand.MAIN_HAND);
                     }

                     if (!this.isSpawner(this.currentTarget)) {
                        this.minedSpawnerCount++;
                        this.ticksSinceLastMine = 0;
                        BlockPos justMined = this.currentTarget;
                        this.msg("§aMined #" + this.minedSpawnerCount);
                        if (this.isSpawner(justMined)) {
                           this.currentTarget = justMined;
                        } else {
                           this.currentTarget = null;
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private static long packPos(int x, int y, int z) {
      return (long)(x & 67108863) << 38 | (long)(z & 67108863) << 12 | y & 4095;
   }

   private void buildSnapshot() {
      this.snapshot.clear();
      if (mc.player != null && mc.world != null) {
         BlockPos c = mc.player.getBlockPos();
         this.scanMinY = c.getY() - 100;
         this.scanMaxY = c.getY() + 100;
         this.scanY = this.scanMinY;

         for (int dy = -100; dy <= 100; dy++) {
            for (int x = -30; x <= 30; x++) {
               for (int z = -30; z <= 30; z++) {
                  int bx = c.getX() + x;
                  int by = c.getY() + dy;
                  int bz = c.getZ() + z;
                  BlockState st = mc.world.getBlockState(new BlockPos(bx, by, bz));
                  if (!st.isAir()) {
                     this.snapshot.put(packPos(bx, by, bz), Block.getRawIdFromState(st));
                  }
               }
            }
         }

         this.snapshotReady = true;
      }
   }

   private boolean detectBlockBreak() {
      if (mc.player != null && mc.world != null) {
         BlockPos c = mc.player.getBlockPos();
         int minY = c.getY() - 100;
         int maxY = c.getY() + 100;
         if (this.scanY < minY || this.scanY > maxY) {
            this.scanY = minY;
         }

         for (int slice = 0; slice < 16; slice++) {
            if (this.scanY > maxY) {
               this.scanY = minY;
               return false;
            }

            for (int x = -30; x <= 30; x++) {
               for (int z = -30; z <= 30; z++) {
                  int bx = c.getX() + x;
                  int bz = c.getZ() + z;
                  long key = packPos(bx, this.scanY, bz);
                  Integer oldId = this.snapshot.get(key);
                  if (oldId != null) {
                     BlockState now = mc.world.getBlockState(new BlockPos(bx, this.scanY, bz));
                     if (now.isAir()) {
                        return true;
                     }
                  }
               }
            }

            this.scanY++;
         }

         return false;
      } else {
         return false;
      }
   }

   private void tickEchestStorage() {
      if (mc.player != null && mc.world != null) {
         this.echestTicks++;
         switch (this.echestState) {
            case FIND:
               this.echestPos = this.findNearestEnderChest();
               if (this.echestPos != null) {
                  this.echestState = SpawnerProtect.EChestState.WALK;
                  this.msg("§eFound ender chest at " + this.echestPos.toShortString());
               } else if (this.echestTicks > 100) {
                  this.msg("§cNo ender chest found after 5s. Disconnecting...");
                  this.fireWebhookThenDisconnect(this.captureSuccessSnapshot());
                  this.echestState = SpawnerProtect.EChestState.NONE;
               }
               break;
            case WALK:
               double dist = mc.player.squaredDistanceTo(Vec3d.ofCenter(this.echestPos));
               if (dist <= 25.0) {
                  this.stopWalk();
                  this.echestState = SpawnerProtect.EChestState.OPEN;
                  this.echestTicks = 0;
               } else {
                  this.walkTo(this.echestPos);
               }

               if (this.echestTicks > 200) {
                  this.msg("§cCan't reach ender chest! Disconnecting...");
                  this.fireWebhookThenDisconnect(this.captureSuccessSnapshot());
                  this.echestState = SpawnerProtect.EChestState.NONE;
               }
               break;
            case OPEN:
               mc.options.sneakKey.setPressed(false);
               mc.player.setSneaking(false);
               Direction face = this.getClosestFace(this.echestPos);
               this.lookAt(this.echestPos, face);
               if (this.echestTicks >= 2) {
                  BlockHitResult hit = new BlockHitResult(Vec3d.ofCenter(this.echestPos), face, this.echestPos, false);
                  mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
                  this.echestState = SpawnerProtect.EChestState.WAIT_GUI;
                  this.echestTicks = 0;
               }
               break;
            case WAIT_GUI:
               if (mc.currentScreen instanceof GenericContainerScreen) {
                  this.echestState = SpawnerProtect.EChestState.STORE;
                  this.echestTicks = 0;
               }

               if (this.echestTicks > 20) {
                  this.echestState = SpawnerProtect.EChestState.OPEN;
                  this.echestTicks = 0;
               }
               break;
            case STORE:
               if (!(mc.currentScreen instanceof GenericContainerScreen)) {
                  this.echestState = SpawnerProtect.EChestState.OPEN;
                  this.echestTicks = 0;
                  return;
               }

               GenericContainerScreenHandler handler = (GenericContainerScreenHandler)((GenericContainerScreen)mc.currentScreen).getScreenHandler();
               int echestSlots = handler.getRows() * 9;
               int moved = 0;

               for (int i = echestSlots; i < handler.slots.size(); i++) {
                  ItemStack stack = handler.getSlot(i).getStack();
                  if (!stack.isEmpty() && stack.isOf(Blocks.SPAWNER.asItem())) {
                     mc.interactionManager.clickSlot(handler.syncId, i, 0, SlotActionType.QUICK_MOVE, mc.player);
                     moved++;
                  }
               }

               this.msg("§a✓ " + moved + " stacks stored!");
               this.echestState = SpawnerProtect.EChestState.CLOSE;
               this.echestTicks = 0;
               break;
            case CLOSE:
               if (mc.currentScreen != null) {
                  mc.player.closeHandledScreen();
                  mc.setScreen(null);
               }

               mc.options.sneakKey.setPressed(false);
               mc.player.setSneaking(false);
               if (this.echestTicks < 5) {
                  return;
               }

               if (this.echestTicks < 65) {
                  this.walkToNearestGroundSpawner();
                  return;
               }

               this.stopWalk();
               int invSpawners = this.countSpawnersInInventory();
               if (invSpawners > 0) {
                  this.msg("§ePicked up " + invSpawners + " spawners, storing again...");
                  this.echestState = SpawnerProtect.EChestState.OPEN;
                  this.echestTicks = 0;
                  return;
               }

               if (this.echestTicks > 200) {
                  this.msg("§a✓ Done! Disconnecting...");
                  this.echestState = SpawnerProtect.EChestState.NONE;
                  this.stopAll();
                  this.fireWebhookThenDisconnect(this.captureSuccessSnapshot());
                  return;
               }

               this.msg("§a✓ All spawners stored!");
               this.echestState = SpawnerProtect.EChestState.NONE;
               if (this.sellBones.getValue() && this.hasSpawnersInHotbar()) {
                  this.msg("§eSelling bones before disconnect...");
                  this.sellState = SpawnerProtect.SellState.USE_SPAWNER;
                  this.sellTicks = 0;
                  this.sellCycles = 0;
                  return;
               }

               this.stopAll();
               this.fireWebhookThenDisconnect(this.captureSuccessSnapshot());
         }
      }
   }

   private BlockPos findNearestEnderChest() {
      BlockPos center = mc.player.getBlockPos();
      BlockPos best = null;
      double bestDist = Double.MAX_VALUE;

      for (int x = -64; x <= 64; x++) {
         for (int y = -10; y <= 10; y++) {
            for (int z = -64; z <= 64; z++) {
               BlockPos p = center.add(x, y, z);
               if (mc.world.getBlockState(p).isOf(Blocks.ENDER_CHEST)) {
                  double d = mc.player.squaredDistanceTo(Vec3d.ofCenter(p));
                  if (d < bestDist) {
                     bestDist = d;
                     best = p;
                  }
               }
            }
         }
      }

      return best;
   }

   private void tickSell() {
      if (mc.player != null && mc.world != null) {
         this.sellTicks++;
         switch (this.sellState) {
            case USE_SPAWNER:
               int slot = this.findSpawnerHotbarSlot();
               if (slot == -1) {
                  for (int i = 9; i < 36; i++) {
                     ItemStack s = mc.player.getInventory().getStack(i);
                     if (!s.isEmpty() && s.isOf(Blocks.SPAWNER.asItem())) {
                        mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, i, 0, SlotActionType.SWAP, mc.player);
                        this.sellTicks = 0;
                        return;
                     }
                  }

                  this.msg("§aNo more spawners to sell!");
                  this.sellState = SpawnerProtect.SellState.NONE;
                  if (this.minedSpawnerCount > 0) {
                     this.stopAll();
                     this.fireWebhookThenDisconnect(this.captureSuccessSnapshot());
                  }

                  return;
               }

               if (this.sellTicks == 1) {
                  this.selectHotbarSlot(slot);
                  return;
               }

               if (this.sellTicks < 4) {
                  return;
               }

               mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
               mc.player.swingHand(Hand.MAIN_HAND);
               this.sellState = SpawnerProtect.SellState.WAIT_SELL_GUI;
               this.sellTicks = 0;
               break;
            case WAIT_SELL_GUI:
               if (mc.currentScreen instanceof GenericContainerScreen) {
                  this.sellState = SpawnerProtect.SellState.CLICK_SELL_ALL;
                  this.sellTicks = 0;
               }

               if (this.sellTicks > 40) {
                  this.msg("§cSell GUI didn't open");
                  this.sellState = SpawnerProtect.SellState.NONE;
               }
               break;
            case CLICK_SELL_ALL:
               if (!(mc.currentScreen instanceof GenericContainerScreen)) {
                  this.sellState = SpawnerProtect.SellState.USE_SPAWNER;
                  this.sellTicks = 0;
                  return;
               }

               if (this.sellTicks < 3) {
                  return;
               }

               GenericContainerScreenHandler handler = (GenericContainerScreenHandler)((GenericContainerScreen)mc.currentScreen).getScreenHandler();
               int upper = handler.getRows() * 9;

               for (int ixxx = 0; ixxx < upper; ixxx++) {
                  ItemStack stack = handler.getSlot(ixxx).getStack();
                  if (!stack.isEmpty()) {
                     String name = stack.getName().getString().toLowerCase();
                     if (name.contains("sell all") || name.contains("click to sell")) {
                        mc.interactionManager.clickSlot(handler.syncId, ixxx, 0, SlotActionType.PICKUP, mc.player);
                        this.sellState = SpawnerProtect.SellState.WAIT_CONFIRM_GUI;
                        this.sellTicks = 0;
                        return;
                     }
                  }
               }

               if (this.sellTicks > 20) {
                  mc.player.closeHandledScreen();
                  this.sellState = SpawnerProtect.SellState.USE_SPAWNER;
                  this.sellTicks = 0;
               }
               break;
            case WAIT_CONFIRM_GUI:
               if (mc.currentScreen instanceof GenericContainerScreen) {
                  handler = (GenericContainerScreenHandler)((GenericContainerScreen)mc.currentScreen).getScreenHandler();
                  boolean isConfirm = false;
                  upper = handler.getRows() * 9;

                  for (int ix = 0; ix < upper; ix++) {
                     ItemStack stack = handler.getSlot(ix).getStack();
                     if (!stack.isEmpty()) {
                        String name = stack.getName().getString().toLowerCase();
                        if (name.contains("confirm") || name.contains("click to sell") || name.contains("44.")) {
                           isConfirm = true;
                           break;
                        }
                     }
                  }

                  if (isConfirm) {
                     this.sellState = SpawnerProtect.SellState.CLICK_CONFIRM;
                     this.sellTicks = 0;
                  }
               }

               if (this.sellTicks > 40) {
                  this.sellState = SpawnerProtect.SellState.NONE;
               }
               break;
            case CLICK_CONFIRM:
               if (!(mc.currentScreen instanceof GenericContainerScreen)) {
                  this.sellState = SpawnerProtect.SellState.DONE;
                  this.sellTicks = 0;
                  return;
               }

               if (this.sellTicks < 3) {
                  return;
               }

               handler = (GenericContainerScreenHandler)((GenericContainerScreen)mc.currentScreen).getScreenHandler();
               upper = handler.getRows() * 9;

               for (int ixxxx = 0; ixxxx < upper; ixxxx++) {
                  ItemStack stack = handler.getSlot(ixxxx).getStack();
                  if (!stack.isEmpty()) {
                     String name = stack.getName().getString().toLowerCase();
                     String id = Registries.ITEM.getId(stack.getItem()).getPath();
                     if (name.contains("click to sell")
                        || name.contains("confirm")
                        || (id.contains("green") || id.contains("lime")) && (id.contains("dye") || id.contains("wool") || id.contains("stained_glass_pane"))) {
                        mc.interactionManager.clickSlot(handler.syncId, ixxxx, 0, SlotActionType.PICKUP, mc.player);
                        this.sellCycles++;
                        this.msg("§aSold! (cycle #" + this.sellCycles + ")");
                        this.sellState = SpawnerProtect.SellState.DONE;
                        this.sellTicks = 0;
                        return;
                     }
                  }
               }

               if (this.sellTicks > 20) {
                  mc.player.closeHandledScreen();
                  this.sellState = SpawnerProtect.SellState.NONE;
               }
               break;
            case DONE:
               if (mc.currentScreen != null) {
                  mc.player.closeHandledScreen();
                  mc.setScreen(null);
               }

               if (this.sellTicks >= 5) {
                  if (this.hasSpawnersInHotbar()) {
                     this.sellState = SpawnerProtect.SellState.USE_SPAWNER;
                     this.sellTicks = 0;
                  } else {
                     boolean anyInInv = false;

                     for (int ixx = 9; ixx < 36; ixx++) {
                        ItemStack s = mc.player.getInventory().getStack(ixx);
                        if (!s.isEmpty() && s.isOf(Blocks.SPAWNER.asItem())) {
                           mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, ixx, 0, SlotActionType.SWAP, mc.player);
                           anyInInv = true;
                           this.sellState = SpawnerProtect.SellState.USE_SPAWNER;
                           this.sellTicks = 0;
                           break;
                        }
                     }

                     if (!anyInInv) {
                        this.msg("§aAll spawners sold! (" + this.sellCycles + " cycles)");
                        this.sellState = SpawnerProtect.SellState.NONE;
                        if (this.minedSpawnerCount > 0) {
                           this.stopAll();
                           this.fireWebhookThenDisconnect(this.captureSuccessSnapshot());
                        }
                     }
                  }
               }
         }
      }
   }

   private boolean hasSpawnersInHotbar() {
      if (mc.player == null) {
         return false;
      } else {
         for (int i = 0; i < 9; i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            if (!s.isEmpty() && s.isOf(Blocks.SPAWNER.asItem())) {
               return true;
            }
         }

         return false;
      }
   }

   private int findSpawnerHotbarSlot() {
      if (mc.player == null) {
         return -1;
      } else {
         for (int i = 0; i < 9; i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            if (!s.isEmpty() && s.isOf(Blocks.SPAWNER.asItem())) {
               return i;
            }
         }

         return -1;
      }
   }

   private void scanAllSpawners() {
      this.allSpawners.clear();
      if (mc.player != null && mc.world != null) {
         BlockPos c = mc.player.getBlockPos();

         for (int x = -64; x <= 64; x++) {
            for (int y = -64; y <= 64; y++) {
               for (int z = -64; z <= 64; z++) {
                  BlockPos p = c.add(x, y, z);
                  if (this.isSpawner(p)) {
                     this.allSpawners.add(p.toImmutable());
                  }
               }
            }
         }

         this.allSpawners.sort(Comparator.comparingDouble(this::distSqTo));
      }
   }

   private BlockPos findNextSpawner() {
      this.allSpawners.removeIf(p -> {
         double d = this.distSqTo(p);
         return d < 2304.0 && !this.isSpawner(p);
      });
      if (!this.allSpawners.isEmpty()) {
         this.allSpawners.sort(Comparator.comparingDouble(this::distSqTo));
         return this.allSpawners.get(0);
      } else {
         this.scanAllSpawners();
         if (!this.allSpawners.isEmpty()) {
            this.allSpawners.sort(Comparator.comparingDouble(this::distSqTo));
            return this.allSpawners.get(0);
         } else {
            return null;
         }
      }
   }

   private void walkTo(BlockPos target) {
      double dx = target.getX() + 0.5 - mc.player.getX();
      double dz = target.getZ() + 0.5 - mc.player.getZ();
      double dist = Math.sqrt(dx * dx + dz * dz);
      float tYaw = (float)(MathHelper.atan2(dz, dx) * 180.0F / (float)Math.PI) - 90.0F;
      float yd = MathHelper.wrapDegrees(tYaw - mc.player.getYaw());
      float jitter = (float)(Math.random() - 0.5) * 1.0F;
      mc.player.setYaw(mc.player.getYaw() + MathHelper.clamp(yd + jitter, -8.0F, 8.0F));
      mc.options.forwardKey.setPressed(Math.abs(yd) < 40.0F);
      mc.options.sprintKey.setPressed(dist > 5.0 && Math.abs(yd) < 20.0F);
      if (!mc.player.isOnGround() || !mc.player.horizontalCollision && target.getY() <= mc.player.getBlockPos().getY()) {
         mc.options.jumpKey.setPressed(false);
      } else {
         mc.options.jumpKey.setPressed(true);
      }
   }

   private void stopWalk() {
      mc.options.forwardKey.setPressed(false);
      mc.options.sprintKey.setPressed(false);
      mc.options.jumpKey.setPressed(false);
   }

   private void stopAll() {
      this.currentTarget = null;
      if (mc.interactionManager != null && mc.interactionManager.isBreakingBlock()) {
         mc.interactionManager.cancelBlockBreaking();
      }

      if (mc.player != null) {
         mc.options.sneakKey.setPressed(false);
         mc.player.setSneaking(false);
         this.stopWalk();
      }
   }

   private SpawnerProtect.EnemyStatus getEnemyStatus() {
      double cdSq = square(this.criticalDistance.getValue());
      boolean any = false;
      boolean crit = false;
      PlayerEntity threat = null;
      double td = -1.0;

      for (PlayerEntity o : mc.world.getPlayers()) {
         if (o != mc.player && !o.isSpectator() && !o.isTeammate(mc.player) && (!Friends.isSpawnerProtect() || !Friends.isFriend(o.getName().getString()))) {
            any = true;
            double dSq = mc.player.squaredDistanceTo(o);
            if (dSq <= cdSq) {
               crit = true;
               double d = Math.sqrt(dSq);
               threat = o;
               td = d;
               break;
            }
         }
      }

      return new EnemyStatus(any, crit, threat, td);
   }

   private boolean hasSilkTouchPickaxeInHotbar() {
      return this.findSilkTouchPickaxeHotbarSlot() != -1;
   }

   private int findSilkTouchPickaxeHotbarSlot() {
      for (int i = 0; i < 9; i++) {
         if (this.isSilkTouchPickaxe(mc.player.getInventory().getStack(i))) {
            return i;
         }
      }

      return -1;
   }

   private boolean isSilkTouchPickaxe(ItemStack s) {
      if (s != null && !s.isEmpty()) {
         if (!Registries.ITEM.getId(s.getItem()).getPath().endsWith("_pickaxe")) {
            return false;
         } else {
            RegistryEntry<Enchantment> st = mc.world
               .getRegistryManager()
               .getOrThrow(RegistryKeys.ENCHANTMENT)
               .getEntry((Enchantment)mc.world.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT).get(Enchantments.SILK_TOUCH));
            return st != null && EnchantmentHelper.getLevel(st, s) > 0;
         }
      } else {
         return false;
      }
   }

   private boolean isSpawner(BlockPos p) {
      return mc.world != null && mc.world.getBlockState(p).isOf(Blocks.SPAWNER);
   }

   private int countSpawnersOnGround() {
      int count = 0;

      for (Entity e : mc.world.getEntities()) {
         if (e instanceof ItemEntity item && item.getStack().isOf(Blocks.SPAWNER.asItem()) && mc.player.squaredDistanceTo(item) < 900.0) {
            count += item.getStack().getCount();
         }
      }

      return count;
   }

   private void walkToNearestGroundSpawner() {
      ItemEntity nearest = null;
      double bestDist = Double.MAX_VALUE;

      for (Entity e : mc.world.getEntities()) {
         if (e instanceof ItemEntity item && item.getStack().isOf(Blocks.SPAWNER.asItem())) {
            double d = mc.player.squaredDistanceTo(item);
            if (d < bestDist) {
               bestDist = d;
               nearest = item;
            }
         }
      }

      if (nearest != null && bestDist > 2.0) {
         this.walkTo(nearest.getBlockPos());
      }
   }

   private Direction getClosestFace(BlockPos p) {
      Vec3d d = mc.player.getEyePos().subtract(Vec3d.ofCenter(p));
      return Direction.getFacing(d.x, d.y, d.z);
   }

   private boolean lookAt(BlockPos pos, Direction dir) {
      Vec3d eye = mc.player.getEyePos();
      Vec3d t = Vec3d.ofCenter(pos);
      double dx = t.x - eye.x;
      double dy = t.y - eye.y;
      double dz = t.z - eye.z;
      double h = Math.sqrt(dx * dx + dz * dz);
      float targetYaw = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
      float targetPitch = (float)(-Math.toDegrees(Math.atan2(dy, h)));
      float yd = MathHelper.wrapDegrees(targetYaw - mc.player.getYaw());
      float pd = MathHelper.wrapDegrees(targetPitch - mc.player.getPitch());
      boolean aimed = Math.abs(yd) < 3.0F && Math.abs(pd) < 3.0F;
      mc.player.setYaw(mc.player.getYaw() + yd * 0.9F);
      mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + pd * 0.9F, -90.0F, 90.0F));
      return aimed;
   }

   private boolean isLookingAtSpawner(BlockPos target) {
      if (mc.crosshairTarget == null) {
         return false;
      } else if (mc.crosshairTarget.getType() != Type.BLOCK) {
         return false;
      } else {
         BlockHitResult hit = (BlockHitResult)mc.crosshairTarget;
         return hit.getBlockPos().equals(target);
      }
   }

   private void selectHotbarSlot(int s) {
      if (s >= 0 && s < 9 && mc.player.getInventory().getSelectedSlot() != s) {
         mc.player.getInventory().setSelectedSlot(s);
      }
   }

   private int countSpawnersInInventory() {
      int c = 0;

      for (int i = 0; i < mc.player.getInventory().size(); i++) {
         ItemStack s = mc.player.getInventory().getStack(i);
         if (!s.isEmpty() && s.isOf(Blocks.SPAWNER.asItem())) {
            c += s.getCount();
         }
      }

      return c;
   }

   private void disconnectAndDisable(String r) {
      if (mc.getNetworkHandler() != null && mc.getNetworkHandler().getConnection() != null) {
         mc.getNetworkHandler().getConnection().disconnect(Text.literal(r));
      }

      this.setEnabled(false);
   }

   private double distSqTo(BlockPos p) {
      return mc.player.squaredDistanceTo(Vec3d.ofCenter(p));
   }

   private static double square(int v) {
      return (double)v * v;
   }

   private void fireWebhookThenDisconnect(SpawnerProtect.WebhookSnapshot snap) {
      this.stopAll();
      String wh = this.norm(this.webhookUrl.getValue());
      if (!this.validWh(wh)) {
         this.disconnectScheduled = false;
         this.disconnectAndDisable(snap.reason());
      } else {
         this.disconnectScheduled = true;
         CompletableFuture.runAsync(() -> this.sendWh(snap), Util.getIoWorkerExecutor().named("sp-wh")).whenComplete((i, t) -> mc.execute(() -> {
            this.disconnectScheduled = false;
            this.disconnectAndDisable(snap.reason());
         }));
      }
   }

   private SpawnerProtect.WebhookSnapshot captureSuccessSnapshot() {
      return new WebhookSnapshot(
         this.norm(this.webhookUrl.getValue()),
         "[SpawnerProtect]",
         "All spawners collected.",
         5624994,
         mc.player.getName().getString(),
         "",
         "",
         this.countSpawnersInInventory(),
         true,
         this.serverIp(),
         TIME_FMT.format(LocalTime.now()),
         "https://mc-heads.net/body/" + mc.player.getName().getString(),
         "SpawnerProtect finished"
      );
   }

   private void sendWh(SpawnerProtect.WebhookSnapshot s) {
      JsonObject p = new JsonObject();
      p.addProperty("username", "SpawnerProtect");
      JsonObject e = new JsonObject();
      e.addProperty("title", s.title());
      e.addProperty("description", s.desc());
      e.addProperty("color", s.color());
      JsonArray f = new JsonArray();
      f.add(this.field("Player", s.player(), false));
      f.add(this.field("Spawners", s.spawners() + "", false));
      f.add(this.field("All mined", s.allMined() ? "✅" : "❌", true));
      e.add("fields", f);
      JsonArray es = new JsonArray();
      es.add(e);
      p.add("embeds", es);

      try {
         httpClient.send(
            HttpRequest.newBuilder(URI.create(s.getString() + (s.getString().contains("?") ? "&" : "?") + "wait=true"))
               .timeout(HTTP_TIMEOUT)
               .header("Content-Type", "application/json")
               .POST(BodyPublishers.ofString(p.toString()))
               .build(),
            BodyHandlers.ofString()
         );
      } catch (Exception var7) {
         WaterClient.LOGGER.error("SP webhook failed", var7);
      }
   }

   private JsonObject field(String n, String v, boolean i) {
      JsonObject f = new JsonObject();
      f.addProperty("name", n);
      f.addProperty("value", v != null && !v.isBlank() ? v : "-");
      f.addProperty("inline", i);
      return f;
   }

   private String norm(String v) {
      return v == null ? "" : v.trim();
   }

   private boolean validWh(String w) {
      if (w.isEmpty()) {
         return false;
      } else {
         try {
            URI u = URI.create(w);
            return "https".equalsIgnoreCase(u.getScheme()) && u.getPath() != null && u.getPath().contains("/api/webhooks/");
         } catch (Exception var3) {
            return false;
         }
      }
   }

   private String serverIp() {
      ServerInfo si = mc.getCurrentServerEntry();
      if (si != null && si.address != null) {
         String h = si.address.trim().toLowerCase(Locale.ROOT);
         int s = h.indexOf(47);
         if (s >= 0) {
            h = h.substring(0, s);
         }

         int c = h.indexOf(58);
         if (c >= 0) {
            h = h.substring(0, c);
         }

         return h.isEmpty() ? "SP" : h;
      } else {
         return "SP";
      }
   }

   enum EChestState {
      NONE,
      FIND,
      WALK,
      OPEN,
      WAIT_GUI,
      STORE,
      CLOSE;

      private static SpawnerProtect.EChestState[] $values() {
         return new SpawnerProtect.EChestState[]{NONE, FIND, WALK, OPEN, WAIT_GUI, STORE, CLOSE};
      }
   }

   static final class EnemyStatus {
      private boolean hasAnyEnemy;
      private boolean hasCriticalThreat;
      private PlayerEntity threat;
      private double distance;

      private EnemyStatus(boolean hasAnyEnemy, boolean hasCriticalThreat, PlayerEntity threat, double distance) {
         this.hasAnyEnemy = hasAnyEnemy;
         this.hasCriticalThreat = hasCriticalThreat;
         this.threat = threat;
         this.distance = distance;
      }

      public boolean hasAnyEnemy() {
         return this.hasAnyEnemy;
      }

      public boolean hasCriticalThreat() {
         return this.hasCriticalThreat;
      }

      public PlayerEntity threat() {
         return this.threat;
      }

      public double distance() {
         return this.distance;
      }
   }

   enum SellState {
      NONE,
      USE_SPAWNER,
      WAIT_SELL_GUI,
      CLICK_SELL_ALL,
      WAIT_CONFIRM_GUI,
      CLICK_CONFIRM,
      DONE;

      private static SpawnerProtect.SellState[] $values() {
         return new SpawnerProtect.SellState[]{NONE, USE_SPAWNER, WAIT_SELL_GUI, CLICK_SELL_ALL, WAIT_CONFIRM_GUI, CLICK_CONFIRM, DONE};
      }
   }

   final class WebhookSnapshot {
      private String string;
      private String title;
      private String desc;
      private int color;
      private String player;
      private String threatName;
      private String dist;
      private int spawners;
      private boolean allMined;
      private String server;
      private String time;
      private String skin;
      private String reason;

      private WebhookSnapshot(
         String wh,
         String title,
         String desc,
         int color,
         String player,
         String threatName,
         String dist,
         int spawners,
         boolean allMined,
         String server,
         String time,
         String skin,
         String reason
      ) {
         this.string = wh;
         this.title = title;
         this.desc = desc;
         this.color = color;
         this.player = player;
         this.threatName = threatName;
         this.dist = dist;
         this.spawners = spawners;
         this.allMined = allMined;
         this.server = server;
         this.time = time;
         this.skin = skin;
         this.reason = reason;
      }

      public String getString() {
         return this.string;
      }

      public String title() {
         return this.title;
      }

      public String desc() {
         return this.desc;
      }

      public int color() {
         return this.color;
      }

      public String player() {
         return this.player;
      }

      public String threatName() {
         return this.threatName;
      }

      public String dist() {
         return this.dist;
      }

      public int spawners() {
         return this.spawners;
      }

      public boolean allMined() {
         return this.allMined;
      }

      public String server() {
         return this.server;
      }

      public String time() {
         return this.time;
      }

      public String skin() {
         return this.skin;
      }

      public String reason() {
         return this.reason;
      }
   }
}

