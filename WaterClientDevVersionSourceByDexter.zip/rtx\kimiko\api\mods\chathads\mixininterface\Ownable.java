package rtx.kimiko.api.mods.chathads.mixininterface;

import net.minecraft.client.network.PlayerListEntry;

public interface Ownable {
   void chatheads_setOwner(PlayerListEntry var1);

   PlayerListEntry chatheads_getOwner();
}

