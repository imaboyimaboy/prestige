package dev.fakeranks;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents.AllowChat;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.Disconnect;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.Join;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

public class FakeRanksClient implements ClientModInitializer {
   public static final FakeRanksState STATE = new FakeRanksState();

   public void onInitializeClient() {
      ClientPlayConnectionEvents.JOIN.register((Join)(handler, sender, client) -> STATE.requestSkinForCurrentName());
      ClientPlayConnectionEvents.JOIN.register((Join)(handler, sender, client) -> STATE.requestTiersForCurrentName());
      ClientPlayConnectionEvents.DISCONNECT.register((Disconnect)(handler, client) -> STATE.skinStealer().clear());
      ClientReceiveMessageEvents.ALLOW_CHAT.register((AllowChat)(message, signedMessage, sender, params, receptionTimestamp) -> {
         MinecraftClient client = MinecraftClient.getInstance();
         if (STATE.config().enabled && STATE.config().chatPrefixEnabled && client.player != null) {
            if (!sender.id().equals(client.getGameProfile().id())) {
               return true;
            } else {
               client.inGameHud.getChatHud().addMessage(STATE.localChatLine(signedMessage.getContent().getString()));
               return false;
            }
         } else {
            return true;
         }
      });
   }

   public static void openScreen() {
   }

   public static void setEnabled(boolean enabled) {
      STATE.config().enabled = enabled;
      STATE.config().save();
      if (enabled) {
         STATE.requestSkinForCurrentName();
         STATE.requestTiersForCurrentName();
      } else {
         STATE.skinStealer().clear();
      }
   }

   public static Text decoratedName() {
      return STATE.decoratedNameText();
   }
}

