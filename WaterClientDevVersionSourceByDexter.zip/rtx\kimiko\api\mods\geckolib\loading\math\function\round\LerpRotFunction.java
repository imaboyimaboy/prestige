package rtx.kimiko.api.mods.geckolib.loading.math.function.round;

import rtx.kimiko.api.mods.geckolib.animation.state.ControllerState;
import rtx.kimiko.api.mods.geckolib.loading.math.MathValue;
import rtx.kimiko.api.mods.geckolib.loading.math.function.MathFunction;
import rtx.kimiko.api.mods.geckolib.util.MiscUtil;

public final class LerpRotFunction extends MathFunction {
   private MathValue min;
   private MathValue max;
   private MathValue delta;

   public LerpRotFunction(MathValue... mathValueArray) {
      super(mathValueArray);
      this.min = mathValueArray[0];
      this.max = mathValueArray[1];
      this.delta = mathValueArray[2];
   }

   @Override
   public String getName() {
      return "math.lerprotate";
   }

   @Override
   public double compute(ControllerState controllerState) {
      return MiscUtil.lerpYaw(this.delta.get(controllerState), this.min.get(controllerState), this.max.get(controllerState));
   }

   @Override
   public MathValue[] getArgs() {
      return new MathValue[]{this.min, this.max, this.delta};
   }

   @Override
   public int getMinArgs() {
      return 3;
   }
}

