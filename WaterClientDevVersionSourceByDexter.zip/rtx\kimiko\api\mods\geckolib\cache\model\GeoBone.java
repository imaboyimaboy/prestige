package rtx.kimiko.api.mods.geckolib.cache.model;

import java.util.Arrays;
import java.util.Objects;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import rtx.kimiko.api.mods.geckolib.animation.state.BoneSnapshot;
import rtx.kimiko.api.mods.geckolib.constant.DataTickets;
import rtx.kimiko.api.mods.geckolib.renderer.base.GeoRenderState;
import rtx.kimiko.api.mods.geckolib.renderer.base.RenderPassInfo;
import rtx.kimiko.api.mods.geckolib.util.MiscUtil;
import rtx.kimiko.api.mods.geckolib.util.RenderUtil;

public abstract class GeoBone {
   protected GeoBone geoBone;
   protected String string;
   protected GeoBone[] geoBoneArray;
   protected float floatVal;
   protected float floatVal2;
   protected float floatVal3;
   protected float floatVal4;
   protected float floatVal5;
   protected float floatVal6;
   public BoneSnapshot frameSnapshot = null;
   public RenderPassInfo.BonePositionListener[] positionListeners = null;

   protected GeoBone(GeoBone geoBone, String string, GeoBone[] geoBoneArray, float f, float f2, float f3, float f4, float f5, float f6) {
      this.geoBone = geoBone;
      this.string = string;
      this.geoBoneArray = geoBoneArray;
      this.floatVal = f;
      this.floatVal2 = f2;
      this.floatVal3 = f3;
      this.floatVal4 = f4;
      this.floatVal5 = f5;
      this.floatVal6 = f6;
   }

   public String name() {
      return this.string;
   }

   public GeoBone parent() {
      return this.geoBone;
   }

   @Override
   public boolean equals(Object object) {
      if (this == object) {
         return true;
      } else if (object != null && this.getClass() == object.getClass()) {
         GeoBone geoBone = (GeoBone)object;
         if (this.geoBone != geoBone.geoBone) {
            return false;
         } else if (!this.string.equals(geoBone.string)) {
            return false;
         } else {
            return MiscUtil.areFloatsEqual(this.floatVal, geoBone.floatVal)
                  && MiscUtil.areFloatsEqual(this.floatVal2, geoBone.floatVal2)
                  && MiscUtil.areFloatsEqual(this.floatVal3, geoBone.floatVal3)
               ? Arrays.equals((Object[])this.geoBoneArray, (Object[])geoBone.geoBoneArray)
               : false;
         }
      } else {
         return false;
      }
   }

   @Override
   public int hashCode() {
      return Objects.hash(
         this.geoBone == null ? "" : this.geoBone, this.string, Arrays.hashCode((Object[])this.geoBoneArray), this.floatVal, this.floatVal2, this.floatVal3
      );
   }

   public GeoBone[] children() {
      return this.geoBoneArray;
   }

   public float pivotX() {
      return this.floatVal;
   }

   public float pivotY() {
      return this.floatVal2;
   }

   public abstract <R extends GeoRenderState> void render(RenderPassInfo<R> var1, MatrixStack var2, VertexConsumer var3, int var4, int var5, int var6);

   public float baseRotY() {
      return this.floatVal5;
   }

   public float baseRotZ() {
      return this.floatVal6;
   }

   public float pivotZ() {
      return this.floatVal3;
   }

   public float baseRotX() {
      return this.floatVal4;
   }

   public void updateBonePositionListeners(MatrixStack matrixStack, RenderPassInfo<?> renderPassInfo) {
      if (this.positionListeners != null) {
         Matrix4f matrix4f = new Matrix4f(matrixStack.peek().getPositionMatrix());
         Matrix4f matrix4f2 = RenderUtil.extractPoseFromRoot(matrix4f, renderPassInfo.getPreRenderMatrixState());
         Matrix4f matrix4f3 = RenderUtil.extractPoseFromRoot(matrix4f, renderPassInfo.getModelRenderMatrixState());
         Vec3d vec3d = renderPassInfo.renderState().getGeckolibData(DataTickets.POSITION);
         Matrix4f matrix4f4 = vec3d == null ? null : RenderUtil.addPosToMatrix(new Matrix4f(matrix4f2), vec3d);
         Vec3d vec3d2 = RenderUtil.renderPoseToPosition(matrix4f2, 1.0F, 1.0F, 1.0F);
         Vec3d vec3d3 = RenderUtil.renderPoseToPosition(matrix4f3, -16.0F, 16.0F, 16.0F);
         Vec3d vec3d4 = matrix4f4 == null ? null : RenderUtil.renderPoseToPosition(matrix4f4, 1.0F, 1.0F, 1.0F);

         for (int i = 0; i < this.positionListeners.length; i++) {
            this.positionListeners[i].accept(vec3d4, vec3d3, vec3d2);
         }
      }
   }

   public void translateAwayFromPivotPoint(MatrixStack matrixStack) {
      matrixStack.translate(-this.pivotX() / 16.0F, -this.pivotY() / 16.0F, -this.pivotZ() / 16.0F);
   }

   public <R extends GeoRenderState> void positionAndRender(RenderPassInfo<R> renderPassInfo, VertexConsumer vertexConsumer, int n, int n2, int n3) {
      MatrixStack matrixStack = renderPassInfo.poseStack();
      matrixStack.push();
      RenderUtil.prepMatrixForBone(matrixStack, this);
      this.updateBonePositionListeners(matrixStack, renderPassInfo);
      this.render(renderPassInfo, matrixStack, vertexConsumer, n, n2, n3);
      this.renderChildren(renderPassInfo, matrixStack, vertexConsumer, n, n2, n3);
      matrixStack.pop();
   }

   public void renderChildren(RenderPassInfo<?> renderPassInfo, MatrixStack matrixStack, VertexConsumer vertexConsumer, int n, int n2, int n3) {
      if (this.frameSnapshot == null || !this.frameSnapshot.areChildrenHidden()) {
         for (GeoBone geoBone : this.geoBoneArray) {
            matrixStack.push();
            RenderUtil.prepMatrixForBoneAndUpdateListeners(matrixStack, geoBone, renderPassInfo);
            geoBone.render(renderPassInfo, matrixStack, vertexConsumer, n, n2, n3);
            geoBone.renderChildren(renderPassInfo, matrixStack, vertexConsumer, n, n2, n3);
            matrixStack.pop();
         }
      }
   }

   public void translateToPivotPoint(MatrixStack matrixStack) {
      matrixStack.translate(this.pivotX() / 16.0F, this.pivotY() / 16.0F, this.pivotZ() / 16.0F);
   }
}

