package com.water.module.modules.donut;

import com.water.module.Category;
import com.water.module.Module;
import com.water.setting.Setting;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardEntry;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.Team;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public final class OldDonutScoreboard extends Module {
   public static OldDonutScoreboard INSTANCE;
   private final Setting<Boolean> hideVanilla = new Setting<>("Hide Vanilla", true);
   private final Setting<Double> scale = new Setting<>("Scale", 1.0, 0.5, 3.0);
   private final Setting<Integer> x = new Setting<>("X", -1, -1, 3000);
   private final Setting<Integer> y = new Setting<>("Y", -1, -1, 3000);
   private int lastKnownPing;
   private long lastPingUpdateMs;

   public OldDonutScoreboard() {
      super("Old Donut Scoreboard", Category.DONUT);
      this.addSetting(this.hideVanilla);
      this.addSetting(this.scale);
      this.addSetting(this.x);
      this.addSetting(this.y);
      INSTANCE = this;
   }

   public static boolean shouldHideVanillaSidebar() {
      OldDonutScoreboard module = INSTANCE;
      return module != null && module.isEnabled() && module.hideVanilla.getValue();
   }

   public static void renderHud(DrawContext context) {
      OldDonutScoreboard module = INSTANCE;
      if (module != null && module.isEnabled()) {
         module.renderScoreboard(context);
      }
   }

   private void renderScoreboard(DrawContext context) {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client != null && client.player != null && client.world != null && client.textRenderer != null) {
         OldDonutScoreboard.ScoreboardData data = this.readScoreboard(client);
         List<Text> rows = new ArrayList<>(8);
         rows.add(Text.empty());
         rows.add(statRow("$", "Money", safe(data.money), 65280, true));
         rows.add(statRow("★", "Shards", safe(data.shards), 10813692, false));
         rows.add(statRow("⚔", "Kills", safe(data.kills), 16711680, false));
         rows.add(statRow("☠", "Deaths", safe(data.deaths), 16546163, false));
         rows.add(statRow("⌚", "Playtime", safe(data.playtime), 16766464, false));
         rows.add(Text.empty());
         rows.add(footerRow(safe(data.ping)));
         Text title = donutTitle();
         int maxWidth = client.textRenderer.getWidth(title);

         for (Text row : rows) {
            maxWidth = Math.max(maxWidth, client.textRenderer.getWidth(row));
         }

         int padding = 3;
         int lineHeight = 9;
         int boxWidth = maxWidth + 6;
         int titleH = 11;
         int boxHeight = 11 + rows.size() * lineHeight + 2;
         float sc = Math.max(0.5F, Math.min(3.0F, this.scale.getValue().floatValue()));
         int drawW = Math.round(boxWidth * sc);
         int drawH = Math.round(boxHeight * sc);
         int left = this.x.getValue() < 0 ? context.getScaledWindowWidth() - drawW - 2 : this.x.getValue();
         int top = this.y.getValue() < 0 ? (context.getScaledWindowHeight() - drawH) / 2 : this.y.getValue();
         context.getMatrices().pushMatrix();
         context.getMatrices().translate(left, top);
         context.getMatrices().scale(sc, sc);
         context.fill(0, 0, boxWidth, 11, Integer.MIN_VALUE);
         context.fill(0, 11, boxWidth, boxHeight, 1610612736);
         context.drawText(client.textRenderer, title, (boxWidth - client.textRenderer.getWidth(title)) / 2, 2, -1, false);
         int rowY = 12;

         for (Text row : rows) {
            context.drawText(client.textRenderer, row, padding, rowY, -1, false);
            rowY += lineHeight;
         }

         context.getMatrices().popMatrix();
      }
   }

   private OldDonutScoreboard.ScoreboardData readScoreboard(MinecraftClient client) {
      OldDonutScoreboard.ScoreboardData data = new OldDonutScoreboard.ScoreboardData();

      try {
         Scoreboard scoreboard = client.world.getScoreboard();
         ScoreboardObjective objective = scoreboard.getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR);
         if (objective == null) {
            data.ping = String.valueOf(this.currentPing(client));
            return data;
         }

         Collection<ScoreboardEntry> entryCollection = scoreboard.getScoreboardEntries(objective);
         List<ScoreboardEntry> entries = new ArrayList<>(entryCollection);
         entries.sort(Comparator.comparingInt(ScoreboardEntry::value).reversed());
         boolean[] found = new boolean[5];
         int matched = 0;

         for (ScoreboardEntry entry : entries) {
            String text = this.plain(scoreboard, entry);
            if (!text.isEmpty()) {
               String lower = text.toLowerCase();
               if (!found[0] && matchesAny(text, lower, "$", "money", "balance", "coins", "bal")) {
                  data.money = extractValue(text);
                  found[0] = true;
                  matched++;
               } else if (!found[1] && matchesAny(text, lower, "*", "shard", "nirmata", "gem")) {
                  data.shards = extractValue(text);
                  found[1] = true;
                  matched++;
               } else if (!found[2] && matchesAny(text, lower, "kill")) {
                  data.kills = extractValue(text);
                  found[2] = true;
                  matched++;
               } else if (!found[3] && matchesAny(text, lower, "death")) {
                  data.deaths = extractValue(text);
                  found[3] = true;
                  matched++;
               } else if (!found[4] && matchesAny(text, lower, "playtime", "play time", "time played", "uptime")) {
                  data.playtime = extractPlaytime(text);
                  found[4] = true;
                  matched++;
               }
            }
         }

         if (matched < 3) {
            this.positionFallback(scoreboard, entries, data, found);
         }

         data.ping = String.valueOf(this.currentPing(client));
      } catch (Throwable var13) {
         data.ping = String.valueOf(this.currentPing(client));
      }

      return data;
   }

   private void positionFallback(Scoreboard scoreboard, List<ScoreboardEntry> sorted, OldDonutScoreboard.ScoreboardData data, boolean[] found) {
      List<String> values = new ArrayList<>();

      for (ScoreboardEntry entry : sorted) {
         String text = this.plain(scoreboard, entry);
         if (!text.isEmpty() && !looksLikeSeparator(text)) {
            values.add(text);
         }
      }

      int start = !values.isEmpty() && !hasDigit(values.getFirst()) ? 1 : 0;
      String[] slots = new String[5];

      for (int i = 0; i + start < values.size() && i < slots.length; i++) {
         slots[i] = values.get(i + start);
      }

      if (!found[0] && slots[0] != null) {
         data.money = extractValue(slots[0]);
      }

      if (!found[1] && slots[1] != null) {
         data.shards = extractValue(slots[1]);
      }

      if (!found[2] && slots[2] != null) {
         data.kills = extractValue(slots[2]);
      }

      if (!found[3] && slots[3] != null) {
         data.deaths = extractValue(slots[3]);
      }

      if (!found[4] && slots[4] != null) {
         data.playtime = extractPlaytime(slots[4]);
      }
   }

   private String plain(Scoreboard scoreboard, ScoreboardEntry entry) {
      Text base = entry.name();
      if (base == null) {
         base = Text.literal(entry.owner() == null ? "" : entry.owner());
      }

      Text decorated = base;

      try {
         Team team = scoreboard.getScoreHolderTeam(entry.owner());
         if (team != null) {
            decorated = team.decorateName(base);
         }
      } catch (Throwable var6) {
      }

      return sanitise(decorated.getString());
   }

   private int currentPing(MinecraftClient client) {
      int ping = this.readPing(client);
      long now = System.currentTimeMillis();
      if (ping > 0) {
         this.lastKnownPing = ping;
         this.lastPingUpdateMs = now;
         return ping;
      } else {
         return this.lastKnownPing > 0 && now - this.lastPingUpdateMs < 60000L ? this.lastKnownPing : 0;
      }
   }

   private int readPing(MinecraftClient client) {
      if (client.player != null && client.getNetworkHandler() != null) {
         try {
            UUID uuid = client.player.getUuid();
            String name = client.player.getName().getString();
            PlayerListEntry entry = client.getNetworkHandler().getPlayerListEntry(uuid);
            if (entry != null && entry.getLatency() > 0) {
               return entry.getLatency();
            }

            for (PlayerListEntry player : client.getNetworkHandler().getPlayerList()) {
               if (player != null && player.getProfile() != null) {
                  if (uuid.equals(player.getProfile().id()) && player.getLatency() > 0) {
                     return player.getLatency();
                  }

                  if (name.equals(player.getProfile().name()) && player.getLatency() > 0) {
                     return player.getLatency();
                  }
               }
            }

            for (PlayerListEntry playerx : client.getNetworkHandler().getPlayerList()) {
               if (playerx != null && playerx.getLatency() > 0) {
                  return playerx.getLatency();
               }
            }
         } catch (Throwable var7) {
         }

         return 0;
      } else {
         return 0;
      }
   }

   private static MutableText statRow(String icon, String label, String value, int color, boolean boldIcon) {
      return Text.empty()
         .append(Text.literal(icon).setStyle(Style.EMPTY.withColor(color).withBold(boldIcon)))
         .append(Text.literal(" null ").formatted(Formatting.GRAY))
         .append(Text.literal(value).styled(s -> s.withColor(color)));
   }

   private static MutableText footerRow(String ping) {
      return Text.empty()
         .append(Text.literal("EU Central ").styled(s -> s.withColor(11184810)))
         .append(Text.literal("(nullms)").styled(s -> s.withColor(42751)));
   }

   private static MutableText donutTitle() {
      int[] colors = new int[]{32252, 35068, 37628, 40444, 43260, 46076, 48892, 51708, 54524};
      MutableText out = Text.empty();

      for (int i = 0; i < 9; i++) {
         int color = colors[Math.min(i, colors.length - 1)];
         out.append(Text.literal(String.valueOf("Donut SMP".charAt(i))).styled(s -> s.withColor(color).withBold(true)));
      }

      return out;
   }

   private static boolean matchesAny(String original, String lower, String... needles) {
      for (String needle : needles) {
         if (needle != null && !needle.isEmpty()) {
            if (original.contains(needle)) {
               return true;
            }

            if (isLetterWord(needle) && lower.contains(needle.toLowerCase())) {
               return true;
            }
         }
      }

      return false;
   }

   private static boolean isLetterWord(String s) {
      for (int i = 0; i < s.length(); i++) {
         if (Character.isLetter(s.charAt(i))) {
            return true;
         }
      }

      return false;
   }

   private static boolean looksLikeSeparator(String s) {
      String t = sanitise(s);
      return t.isEmpty() || t.chars().allMatch(c -> c == 32 || c == 45 || c == 95 || c == 46 || c == 42);
   }

   private static boolean hasDigit(String s) {
      for (int i = 0; i < s.length(); i++) {
         if (Character.isDigit(s.charAt(i))) {
            return true;
         }
      }

      return false;
   }

   private static String extractValue(String text) {
      String cleaned = sanitise(text);
      if (cleaned.isEmpty()) {
         return "0";
      } else {
         String[] parts = cleaned.split("\\s+");

         for (int i = parts.length - 1; i >= 0; i--) {
            if (hasDigit(parts[i])) {
               return parts[i];
            }
         }

         for (int ix = parts.length - 1; ix >= 0; ix--) {
            if (!parts[ix].isEmpty()) {
               return parts[ix];
            }
         }

         return "0";
      }
   }

   private static String extractPlaytime(String text) {
      String cleaned = sanitise(text);
      if (cleaned.isEmpty()) {
         return "0";
      } else {
         String[] parts = cleaned.split("\\s+");
         List<String> tail = new ArrayList<>();

         for (int i = parts.length - 1; i >= 0; i--) {
            String p = parts[i];
            if (!p.matches("\\d+[dhmsy]") && !p.matches("\\d+")) {
               break;
            }

            tail.add(0, p);
         }

         return !tail.isEmpty() ? String.join(" ", tail) : extractValue(cleaned);
      }
   }

   private static String sanitise(String s) {
      if (s == null) {
         return "";
      } else {
         StringBuilder out = new StringBuilder(s.length());

         for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == 167) {
               i++;
            } else {
               int type = Character.getType(c);
               if (type != 15 && type != 16 && type != 19 && c != 8203 && c != 8204 && c != 8205 && c != '\ufeff') {
                  out.append(c);
               } else {
                  out.append(' ');
               }
            }
         }

         return out.toString().trim();
      }
   }

   private static String safe(String value) {
      return value != null && !value.isEmpty() ? value : "0";
   }

   final class ScoreboardData {
      private String money = "0";
      private String shards = "0";
      private String kills = "0";
      private String deaths = "0";
      private String playtime = "0";
      private String ping = "0";

      private ScoreboardData() {
      }
   }
}

