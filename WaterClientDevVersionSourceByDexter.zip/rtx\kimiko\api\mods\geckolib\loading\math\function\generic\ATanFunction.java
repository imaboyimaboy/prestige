package rtx.kimiko.api.mods.geckolib.loading.math.function.generic;

import rtx.kimiko.api.mods.geckolib.animation.state.ControllerState;
import rtx.kimiko.api.mods.geckolib.loading.math.MathValue;
import rtx.kimiko.api.mods.geckolib.loading.math.function.MathFunction;

public final class ATanFunction extends MathFunction {
   private MathValue value;

   public ATanFunction(MathValue... mathValueArray) {
      super(mathValueArray);
      this.value = mathValueArray[0];
   }

   @Override
   public String getName() {
      return "math.atan";
   }

   @Override
   public double compute(ControllerState controllerState) {
      return Math.atan(this.value.get(controllerState) * (float) (Math.PI / 180.0));
   }

   @Override
   public MathValue[] getArgs() {
      return new MathValue[]{this.value};
   }

   @Override
   public int getMinArgs() {
      return 1;
   }
}

