package com.water.module.modules.client;

import com.water.gui.ConfigShareScreen;
import com.water.module.Category;
import com.water.module.Module;
import com.water.module.ModuleManager;
import com.water.setting.Setting;
import com.water.setting.ThresholdSetting;
import java.awt.Color;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import net.minecraft.client.MinecraftClient;

public final class ConfigShare extends Module {
   private static ConfigShare INSTANCE;
   public volatile String lastCode = "";
   public volatile String lastError = "";
   public volatile boolean uploading = false;
   public volatile boolean downloading = false;

   public ConfigShare() {
      super("Config Share", Category.CLIENT);
      INSTANCE = this;
   }

   @Override
   public void onEnable() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc != null) {
         mc.execute(() -> {
            mc.setScreen(new ConfigShareScreen());
            this.setEnabled(false);
         });
      }
   }

   public static ConfigShare getInstance() {
      return INSTANCE;
   }

   public void uploadConfig(Runnable onDone) {
      this.uploading = true;
      this.lastCode = "";
      this.lastError = "";
      new Thread(() -> {
         try {
            String raw = this.buildConfigString();
            ByteArrayOutputStream bos = new ByteArrayOutputStream();

            try (GZIPOutputStream gz = new GZIPOutputStream(bos)) {
               gz.write(raw.getBytes(StandardCharsets.UTF_8));
            }

            String var24 = Base64.getUrlEncoder().withoutPadding().encodeToString(bos.toByteArray());
            HttpURLConnection conn = (HttpURLConnection)new URI("https://dpaste.com/api/v2/").toURL().openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setConnectTimeout(6000);
            conn.setReadTimeout(6000);
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            String body = "content=" + URLEncoder.encode(var24, StandardCharsets.UTF_8) + "&syntax=text&expiry_days=365";

            try (OutputStream responseUrl = conn.getOutputStream()) {
               responseUrl.write(body.getBytes(StandardCharsets.UTF_8));
            }

            String responseUrl = new String(conn.getInputStream().readAllBytes(), StandardCharsets.UTF_8).trim();
            conn.disconnect();
            String key = responseUrl.replaceAll("https?://dpaste\\.com/", "").replace("/", "").trim();
            this.lastCode = key;
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc != null) {
               mc.execute(() -> mc.keyboard.setClipboard(key));
            }
         } catch (Exception var22) {
            this.lastError = "Upload failed: " + var22.getMessage();
         } finally {
            this.uploading = false;
            MinecraftClient mc = MinecraftClient.getInstance();
            if (onDone != null && mc != null) {
               mc.execute(onDone);
            }
         }
      }, "water-config-export").start();
   }

   public void downloadConfig(String code, Runnable onDone) {
      this.downloading = true;
      this.lastError = "";
      new Thread(() -> {
         try {
            try {
               String key = code.trim().replaceAll("\\s+", "");
               if (key.isEmpty()) {
                  this.lastError = "Enter a code first!";
                  return;
               }

               HttpURLConnection conn = (HttpURLConnection)new URI("https://dpaste.com/null.txt").toURL().openConnection();
               conn.setConnectTimeout(6000);
               conn.setReadTimeout(6000);
               String compressed = new String(conn.getInputStream().readAllBytes(), StandardCharsets.UTF_8).trim();
               conn.disconnect();

               byte[] bytes;
               try {
                  bytes = Base64.getUrlDecoder().decode(compressed);
               } catch (Exception var24) {
                  try {
                     bytes = Base64.getDecoder().decode(compressed);
                  } catch (Exception var23) {
                     this.lastError = "Invalid code!";
                     return;
                  }
               }

               String raw;
               try (GZIPInputStream gz = new GZIPInputStream(new ByteArrayInputStream(bytes))) {
                  raw = new String(gz.readAllBytes(), StandardCharsets.UTF_8);
               } catch (Exception var22) {
                  this.lastError = "Invalid code!";
                  return;
               }

               this.applyConfigString(raw);
               ModuleManager.INSTANCE.saveConfig();
            } catch (Exception var25) {
               this.lastError = "Load error: " + var25.getMessage();
            }
         } finally {
            this.downloading = false;
            MinecraftClient mc = MinecraftClient.getInstance();
            if (onDone != null && mc != null) {
               mc.execute(onDone);
            }
         }
      }, "water-config-import").start();
   }

   private String buildConfigString() {
      ModuleManager.INSTANCE.saveConfig();

      try {
         Path path = ModuleManager.INSTANCE.getCurrentConfigPath();
         if (path != null && Files.isRegularFile(path)) {
            return Files.readString(path, StandardCharsets.UTF_8);
         }
      } catch (IOException var2) {
      }

      return "";
   }

   private void applyConfigString(String raw) {
      if (raw != null && !raw.isBlank()) {
         Map<String, Boolean> before = this.snapshotEnabled();
         Path tmp = null;

         try {
            Path target = ModuleManager.INSTANCE.getCurrentConfigPath();
            tmp = target.resolveSibling(target.getFileName().toString() + ".import");
            Files.writeString(tmp, raw, StandardCharsets.UTF_8);
            if (ModuleManager.INSTANCE.applyConfigFromPath(tmp)) {
               this.syncModuleLifecycle(before, this.snapshotEnabled());
               return;
            }
         } catch (IOException var15) {
            return;
         } finally {
            if (tmp != null) {
               try {
                  Files.deleteIfExists(tmp);
               } catch (IOException var14) {
               }
            }
         }
      }
   }

   private Map<String, Boolean> snapshotEnabled() {
      Map<String, Boolean> map = new HashMap<>();

      for (Module m : ModuleManager.INSTANCE.getModules()) {
         map.put(m.getName(), m.isEnabled());
      }

      return map;
   }

   private void syncModuleLifecycle(Map<String, Boolean> before, Map<String, Boolean> after) {
      for (Module m : ModuleManager.INSTANCE.getModules()) {
         boolean was = before.getOrDefault(m.getName(), false);
         boolean now = after.getOrDefault(m.getName(), false);
         if (was != now) {
            try {
               if (now) {
                  m.onEnable();
               } else {
                  m.onDisable();
               }
            } catch (Throwable var8) {
            }
         }
      }
   }

   private String serialize(Setting<?> s) {
      Object v = s.getValue();
      if (s instanceof ThresholdSetting ts) {
         return ts.serialize();
      } else if (v instanceof Boolean) {
         return (Boolean)v ? "1" : "0";
      } else if (v instanceof Float) {
         return String.valueOf((Float)v);
      } else if (v instanceof Double) {
         return String.valueOf((Double)v);
      } else if (v instanceof Integer) {
         return String.valueOf((Integer)v);
      } else if (v instanceof String) {
         return ((String)v).replace(",", "").replace("\n", "");
      } else {
         return v instanceof Color c ? String.format("%02x%02x%02x%02x", c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()) : "";
      }
   }

   private void deserialize(Setting<?> s, String v) {
      try {
         Object cur = s.getValue();
         if (s instanceof ThresholdSetting ts) {
            ts.deserialize(v);
         } else if (cur instanceof Boolean) {
            ((Setting<Boolean>)s).setValue(v.equals("1"));
         } else if (cur instanceof Float) {
            ((Setting<Float>)s).setValue(Float.parseFloat(v));
         } else if (cur instanceof Double) {
            ((Setting<Double>)s).setValue(Double.parseDouble(v));
         } else if (cur instanceof Integer) {
            ((Setting<Integer>)s).setValue(Integer.parseInt(v));
         } else if (cur instanceof String) {
            ((Setting<String>)s).setValue(v);
         } else if (cur instanceof Color && v.length() == 8) {
            ((Setting<Color>)s).setValue(
               new Color(
                  Integer.parseInt(v.substring(0, 2), 16),
                  Integer.parseInt(v.substring(2, 4), 16),
                  Integer.parseInt(v.substring(4, 6), 16),
                  Integer.parseInt(v.substring(6, 8), 16)
               )
            );
         }
      } catch (Exception var5) {
      }
   }
}

