package rtx.kimiko.api.mods.geckolib.animation.object;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import rtx.kimiko.api.mods.geckolib.animatable.GeoAnimatable;
import rtx.kimiko.api.mods.geckolib.animation.AnimationController;
import rtx.kimiko.api.mods.geckolib.animation.state.AnimationPoint;
import rtx.kimiko.api.mods.geckolib.animation.state.AnimationTimeline;
import rtx.kimiko.api.mods.geckolib.renderer.base.GeoRenderState;

public interface LoopType {
   Map<String, LoopType> LOOP_TYPES = new ConcurrentHashMap<>(4);
   LoopType DEFAULT = (geoAnimatable, animationPoint, stage, geoRenderState, animationController) -> animationPoint.animation()
      .loopType()
      .shouldKeepPlaying(geoAnimatable, animationPoint, stage, geoRenderState, animationController);
   LoopType PLAY_ONCE = register("play_once", register("false", (geoAnimatable, animationPoint, stage, geoRenderState, animationController) -> false));
   LoopType HOLD_ON_LAST_FRAME = register("hold_on_last_frame", (geoAnimatable, animationPoint, stage, geoRenderState, animationController) -> {
      animationController.setTimelineTime(stage.endTime());
      return true;
   });
   LoopType LOOP = register("loop", register("true", (geoAnimatable, animationPoint, stage, geoRenderState, animationController) -> {
      animationController.setTimelineTime(stage.startTime() + (animationController.getCurrentTimelineTime() - stage.endTime()));
      return true;
   }));

   static LoopType register(String string, LoopType loopType) {
      LOOP_TYPES.put(string, loopType);
      return loopType;
   }

   default String getId() throws IllegalStateException {
      for (String string : LOOP_TYPES.keySet()) {
         if (LOOP_TYPES.get(string) == this) {
            return string;
         }
      }

      throw new IllegalStateException("LoopType has not been registered before being used!");
   }

   static LoopType fromString(String string) {
      return LOOP_TYPES.getOrDefault(string, PLAY_ONCE);
   }

   boolean shouldKeepPlaying(
      GeoAnimatable var1, AnimationPoint var2, AnimationTimeline.Stage var3, GeoRenderState var4, AnimationController<? extends GeoAnimatable> var5
   );

   static LoopType fromJson(JsonElement jsonElement) {
      if (jsonElement != null && jsonElement.isJsonPrimitive()) {
         JsonPrimitive jsonPrimitive = jsonElement.getAsJsonPrimitive();
         if (jsonPrimitive.isBoolean()) {
            return jsonPrimitive.getAsBoolean() ? LOOP : PLAY_ONCE;
         } else {
            return jsonPrimitive.isString() ? fromString(jsonPrimitive.getAsString()) : PLAY_ONCE;
         }
      } else {
         return PLAY_ONCE;
      }
   }
}

