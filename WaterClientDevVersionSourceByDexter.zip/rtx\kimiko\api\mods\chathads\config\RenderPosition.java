package rtx.kimiko.api.mods.chathads.config;

public enum RenderPosition {
   BEFORE_LINE,
   BEFORE_NAME;

   private static RenderPosition[] $values() {
      return new RenderPosition[]{BEFORE_LINE, BEFORE_NAME};
   }
}

