package com.water.module.modules;

import com.water.module.Category;
import com.water.module.Module;

public class StubModule extends Module {
   public StubModule(String name, Category category) {
      super(name, category);
   }
}

