package com.water.mixin;

import com.water.module.modules.combat.Hitbox;
import com.water.module.modules.misc.NameTags;
import com.water.utils.NametagRenderState;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({EntityRenderer.class})
public class EntityRendererMixin {
   @Inject(
      method = {"updateRenderState"},
      at = {@At("TAIL")}
   )
   private void water$updateNametagState(Entity entity, EntityRenderState state, float tickDelta, CallbackInfo ci) {
      if (entity instanceof LivingEntity living && NameTags.isActive()) {
         NameTags module = NameTags.instance;
         if (module != null && module.shouldRenderForState(living, state.squaredDistanceToCamera) && !state.invisible) {
            NametagRenderState.mark(state);
         } else {
            NametagRenderState.clear(state);
         }
      } else {
         NametagRenderState.clear(state);
      }
   }

   @Inject(
      method = {"renderLabelIfPresent"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void water$renderCustomNametag(
      EntityRenderState state, MatrixStack matrices, OrderedRenderCommandQueue queue, CameraRenderState cameraRenderState, CallbackInfo ci
   ) {
      if (NametagRenderState.hasEntry(state)) {
         ci.cancel();
      }
   }

   @Inject(
      method = {"getShadowRadius"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void water$hitbox(EntityRenderState state, CallbackInfoReturnable<Float> cir) {
      Hitbox module = Hitbox.INSTANCE;
      if (module != null && module.isEnabled()) {
         cir.setReturnValue((Float)cir.getReturnValue() + module.size.getValue());
      }
   }
}

