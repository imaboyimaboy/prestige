package rtx.kimiko.api.mods.geckolib.cache.animation.keyframeevent;

import java.util.Objects;

public abstract class KeyFrameData {
   private double animationTime;

   public KeyFrameData() {
      this(0.0);
   }

   public KeyFrameData(double d) {
      this.animationTime = d;
   }

   @Override
   public boolean equals(Object object) {
      if (this == object) {
         return true;
      } else {
         return object != null && this.getClass() == object.getClass() ? this.hashCode() == object.hashCode() : false;
      }
   }

   @Override
   public int hashCode() {
      return Objects.hashCode(this.animationTime);
   }

   public double getTime() {
      return this.animationTime;
   }
}

