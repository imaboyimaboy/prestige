package com.water.module.modules.misc;

import com.water.module.Category;
import com.water.module.Module;

public final class Sprint extends Module {
   private boolean hadSprintToggled = false;

   public Sprint() {
      super("Sprint", Category.MISC);
   }

   @Override
   public void onEnable() {
      if (mc != null && mc.options != null) {
         this.hadSprintToggled = this.getSprintToggledOption();
         this.setSprintToggledOption(false);
      }
   }

   @Override
   public void onDisable() {
      if (mc != null && mc.options != null) {
         this.setSprintToggledOption(this.hadSprintToggled);

         try {
            mc.options.sprintKey.setPressed(false);
         } catch (Throwable var2) {
         }
      }
   }

   @Override
   public void onTick() {
      if (mc != null && mc.player != null && mc.options != null) {
         this.setSprintToggledOption(false);

         try {
            mc.options.sprintKey.setPressed(true);
         } catch (Throwable var2) {
         }
      }
   }

   private boolean getSprintToggledOption() {
      try {
         Object opt = mc.options.getClass().getMethod("getSprintToggled").invoke(mc.options);
         return opt == null ? false : opt.getClass().getMethod("getValue").invoke(opt) instanceof Boolean b && b;
      } catch (Throwable var4) {
         return false;
      }
   }

   private void setSprintToggledOption(boolean value) {
      try {
         Object opt = mc.options.getClass().getMethod("getSprintToggled").invoke(mc.options);
         if (opt == null) {
            return;
         }

         opt.getClass().getMethod("setValue", Object.class).invoke(opt, value);
      } catch (Throwable var3) {
      }
   }
}

