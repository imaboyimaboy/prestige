package com.water.module.modules.donut;

import com.water.module.Category;
import com.water.module.Module;
import com.water.setting.Setting;
import com.water.utils.RenderUtils;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.PointedDripstoneBlock;
import net.minecraft.block.SweetBerryBushBlock;
import net.minecraft.block.VineBlock;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.Heightmap.Type;
import net.minecraft.world.chunk.WorldChunk;

public final class GrowthFinder extends Module {
   private final Setting<Boolean> renderVines = new Setting<>("Render Vines", true);
   private final Setting<Boolean> renderDripstone = new Setting<>("Render Dripstone", true);
   private final Setting<Boolean> renderBerries = new Setting<>("Render Berries", true);
   private final Setting<Boolean> renderStandardChunks = new Setting<>("Render Gray Chunks", true);
   private final Setting<Float> alpha = new Setting<>("Alpha", 80.0F, 0.0F, 255.0F);
   private static final int SCAN_RADIUS = 8;
   private static final int CHUNKS_PER_TICK = 12;
   private static final int MIN_VINE_LENGTH = 6;
   private static final int MAX_VINE_SCAN_PER_CHUNK = 2;
   private static final double PLATE_HEIGHT = 0.08;
   private static final Color HIGH_SUSPICION_GRAY = new Color(135, 135, 135);
   private static final Color LOW_SUSPICION_GRAY = new Color(100, 100, 100);
   private static final Color SOURCE_PLATE_COLOR_BASE = new Color(203, 64, 255);
   private static final Color EXTREME_PLATE_COLOR_BASE = new Color(255, 198, 64);
   private final Set<ChunkPos> scannedChunks = new HashSet<>();
   private final Map<ChunkPos, GrowthFinder.SuspiciousGrowthData> suspiciousChunks = new HashMap<>();
   private final List<ChunkPos> scanQueue = new ArrayList<>();
   private ChunkPos lastQueueCenter = null;
   private int scanCursor = 0;
   private final List<ChunkPos> lockedBaseChunks = new ArrayList<>();
   private final Map<ChunkPos, Double> sourceHistory = new HashMap<>();

   public GrowthFinder() {
      super("Growth Finder", Category.DONUT);
      this.addSetting(this.renderVines);
      this.addSetting(this.renderDripstone);
      this.addSetting(this.renderBerries);
      this.addSetting(this.renderStandardChunks);
      this.addSetting(this.alpha);
   }

   @Override
   public void onEnable() {
      this.clearData();
   }

   @Override
   public void onDisable() {
      this.clearData();
   }

   private void clearData() {
      this.suspiciousChunks.clear();
      this.scannedChunks.clear();
      this.scanQueue.clear();
      this.scanCursor = 0;
      this.lastQueueCenter = null;
      this.lockedBaseChunks.clear();
      this.sourceHistory.clear();
   }

   @Override
   public void onTick() {
      if (mc.player != null && mc.world != null) {
         ChunkPos playerChunk = new ChunkPos(mc.player.getBlockPos());
         this.rebuildScanQueueIfNeeded(playerChunk);
         this.processChunkBatch(mc.world);
         this.pruneFarChunks(playerChunk, 8);
         if (mc.world.getTime() % 20L == 0L) {
            this.refreshLockedBaseChunk();
         }
      }
   }

   private void rebuildScanQueueIfNeeded(ChunkPos playerChunk) {
      if (this.lastQueueCenter == null
         || playerChunk.x != this.lastQueueCenter.x
         || playerChunk.z != this.lastQueueCenter.z
         || this.scanCursor >= this.scanQueue.size()) {
         this.scanQueue.clear();

         for (int x = -8; x <= 8; x++) {
            for (int z = -8; z <= 8; z++) {
               this.scanQueue.add(new ChunkPos(playerChunk.x + x, playerChunk.z + z));
            }
         }

         this.scanCursor = 0;
         this.lastQueueCenter = playerChunk;
      }
   }

   private void processChunkBatch(World world) {
      int processed = 0;

      while (this.scanCursor < this.scanQueue.size() && processed < 12) {
         ChunkPos chunkPos = this.scanQueue.get(this.scanCursor++);
         if (!this.scannedChunks.contains(chunkPos)) {
            WorldChunk chunk = world.getChunkManager().getWorldChunk(chunkPos.x, chunkPos.z, false);
            if (chunk != null) {
               this.analyzeChunk(chunk, chunkPos);
               this.scannedChunks.add(chunkPos);
            }

            processed++;
         }
      }
   }

   private void pruneFarChunks(ChunkPos playerChunk, int radius) {
      int maxDistance = radius + 2;
      int pX = playerChunk.x;
      int pZ = playerChunk.z;
      this.suspiciousChunks.entrySet().removeIf(entry -> Math.abs(entry.getKey().x - pX) > maxDistance || Math.abs(entry.getKey().z - pZ) > maxDistance);
      this.scannedChunks.removeIf(chunkPos -> Math.abs(chunkPos.x - pX) > maxDistance || Math.abs(chunkPos.z - pZ) > maxDistance);
   }

   private void refreshLockedBaseChunk() {
      if (this.suspiciousChunks.isEmpty()) {
         this.sourceHistory.clear();
      } else {
         for (GrowthFinder.SuspiciousGrowthData data : this.suspiciousChunks.values()) {
            ChunkPos sourceChunk = data.baseChunk;
            this.sourceHistory.merge(sourceChunk, (double)data.suspicionLevel, Double::sum);
         }

         this.sourceHistory.entrySet().removeIf(e -> {
            double val = e.getValue() * 0.95;
            e.setValue(val);
            return val < 0.5;
         });
         List<Entry<ChunkPos, Double>> ranked = new ArrayList<>(this.sourceHistory.entrySet());
         ranked.sort((a, b) -> Double.compare(b.getValue(), a.getValue()));
         this.lockedBaseChunks.clear();

         for (int i = 0; i < Math.min(2, ranked.size()); i++) {
            this.lockedBaseChunks.add(ranked.get(i).getKey());
         }
      }
   }

   private void analyzeChunk(WorldChunk chunk, ChunkPos chunkPos) {
      int xStart = chunkPos.getStartX();
      int zStart = chunkPos.getStartZ();
      List<GrowthFinder.VineCluster> vineClusters = this.renderVines.getValue() ? this.detectTallGroundedVines(chunk, xStart, zStart) : Collections.emptyList();
      List<GrowthFinder.DripstoneCluster> dripstoneClusters = this.renderDripstone.getValue()
         ? this.detectMaxDripstoneClusters(chunk, xStart, zStart)
         : Collections.emptyList();
      List<GrowthFinder.BerryCluster> berryClusters = this.renderBerries.getValue()
         ? this.detectMaxGrownBerries(chunk, xStart, zStart)
         : Collections.emptyList();
      List<GrowthFinder.WeightedEvidence> evidencePoints = new ArrayList<>();
      double vineWeight = 0.0;
      int maxVineLength = 0;

      for (GrowthFinder.VineCluster cluster : vineClusters) {
         double weight = cluster.length;
         vineWeight += weight;
         if (cluster.length > maxVineLength) {
            maxVineLength = cluster.length;
         }

         evidencePoints.add(new WeightedEvidence(cluster.centroid(), weight));
      }

      double dripWeight = 0.0;

      for (GrowthFinder.DripstoneCluster cluster : dripstoneClusters) {
         dripWeight += 2.5;
         evidencePoints.add(new WeightedEvidence(cluster.center, 2.5));
      }

      double berryWeight = 0.0;

      for (GrowthFinder.BerryCluster cluster : berryClusters) {
         berryWeight++;
         evidencePoints.add(new WeightedEvidence(cluster.pos, 1.0));
      }

      int suspicionLevel = (int)Math.round(vineWeight * 0.5 + dripWeight * 0.75 + berryWeight * 1.0);
      if (suspicionLevel > 0) {
         BlockPos estimatedSource = this.calculateWeightedSource(evidencePoints, chunkPos);
         boolean isExtreme = maxVineLength >= 100;
         boolean isSource = maxVineLength >= 25;
         this.suspiciousChunks
            .put(chunkPos, new SuspiciousGrowthData(chunkPos, suspicionLevel, new ChunkPos(estimatedSource), isExtreme, isSource, maxVineLength));
      } else {
         this.suspiciousChunks.remove(chunkPos);
      }
   }

   private List<GrowthFinder.VineCluster> detectTallGroundedVines(WorldChunk chunk, int xStart, int zStart) {
      List<GrowthFinder.VineCluster> clusters = new ArrayList<>();
      Set<BlockPos> visited = new HashSet<>();
      int groundY = chunk.getBottomY();
      int tallClusters = 0;

      for (int x = xStart; x < xStart + 16; x += 2) {
         for (int z = zStart; z < zStart + 16 && tallClusters < 2; z += 2) {
            int y = chunk.getHeightmap(Type.MOTION_BLOCKING).get(x - xStart, z - zStart);

            while (y >= groundY) {
               BlockPos pos = new BlockPos(x, y, z);
               if (visited.contains(pos)) {
                  y--;
               } else {
                  BlockState state = chunk.getBlockState(pos);
                  if (!this.isVineBlock(state.getBlock())) {
                     y--;
                  } else {
                     List<BlockPos> positions = new ArrayList<>();

                     BlockPos currTrace;
                     for (currTrace = pos;
                        currTrace.getY() >= groundY && this.isVineBlock(chunk.getBlockState(currTrace).getBlock());
                        currTrace = currTrace.down()
                     ) {
                        visited.add(currTrace);
                        positions.add(currTrace);
                     }

                     if (positions.size() >= 6) {
                        clusters.add(new VineCluster(positions));
                        tallClusters++;
                     }

                     y = currTrace.getY() - 1;
                  }
               }
            }
         }
      }

      return clusters;
   }

   private boolean isVineBlock(Block block) {
      return block instanceof VineBlock
         || block == Blocks.CAVE_VINES
         || block == Blocks.CAVE_VINES_PLANT
         || block == Blocks.WEEPING_VINES
         || block == Blocks.WEEPING_VINES_PLANT
         || block == Blocks.TWISTING_VINES
         || block == Blocks.TWISTING_VINES_PLANT;
   }

   private List<GrowthFinder.DripstoneCluster> detectMaxDripstoneClusters(WorldChunk chunk, int xStart, int zStart) {
      List<GrowthFinder.DripstoneCluster> clusters = new ArrayList<>();

      for (int x = xStart; x < xStart + 16; x += 4) {
         for (int z = zStart; z < zStart + 16; z += 4) {
            int heightmapY = chunk.getHeightmap(Type.MOTION_BLOCKING).get(x - xStart, z - zStart);

            for (int y = -64; y <= heightmapY; y += 4) {
               BlockPos pos = new BlockPos(x, y, z);
               if (chunk.getBlockState(pos).getBlock() instanceof PointedDripstoneBlock) {
                  clusters.add(new DripstoneCluster(pos));
                  break;
               }
            }
         }
      }

      return clusters;
   }

   private List<GrowthFinder.BerryCluster> detectMaxGrownBerries(WorldChunk chunk, int xStart, int zStart) {
      List<GrowthFinder.BerryCluster> clusters = new ArrayList<>();

      for (int x = xStart; x < xStart + 16; x += 2) {
         for (int z = zStart; z < zStart + 16; z += 2) {
            int heightmapY = chunk.getHeightmap(Type.MOTION_BLOCKING).get(x - xStart, z - zStart);

            for (int y = heightmapY; y >= heightmapY - 5; y--) {
               BlockPos pos = new BlockPos(x, y, z);
               BlockState state = chunk.getBlockState(pos);
               if (state.getBlock() instanceof SweetBerryBushBlock) {
                  try {
                     if ((Integer)state.get(SweetBerryBushBlock.AGE) == 3) {
                        clusters.add(new BerryCluster(pos));
                     }
                  } catch (Exception var12) {
                  }
               }
            }
         }
      }

      return clusters;
   }

   private BlockPos calculateWeightedSource(List<GrowthFinder.WeightedEvidence> evidencePoints, ChunkPos chunkPos) {
      if (evidencePoints.isEmpty()) {
         return new BlockPos(chunkPos.getStartX() + 8, 30, chunkPos.getStartZ() + 8);
      } else {
         double sumX = 0.0;
         double sumY = 0.0;
         double sumZ = 0.0;
         double sumW = 0.0;

         for (GrowthFinder.WeightedEvidence e : evidencePoints) {
            sumX += e.pos.getX() * e.weight;
            sumY += e.pos.getY() * e.weight;
            sumZ += e.pos.getZ() * e.weight;
            sumW += e.weight;
         }

         return new BlockPos((int)(sumX / sumW), (int)(sumY / sumW), (int)(sumZ / sumW));
      }
   }

   @Override
   public void onRender(MatrixStack matrices, float tickDelta) {
      if (mc.world != null && mc.player != null) {
         if (!this.suspiciousChunks.isEmpty()) {
            Camera cam = RenderUtils.getCamera();
            if (cam != null) {
               Vec3d camPos = RenderUtils.getCameraPos(cam);
               int alphaInt = Math.max(0, Math.min(255, this.alpha.getValue().intValue()));
               matrices.push();
               RenderUtils.WorldBatch batch = RenderUtils.beginWorldBatch(matrices);

               for (GrowthFinder.SuspiciousGrowthData data : this.suspiciousChunks.values()) {
                  boolean isStandard = !data.extreme && !data.source;
                  if (!isStandard || this.renderStandardChunks.getValue()) {
                     Color baseColor;
                     if (data.extreme) {
                        baseColor = EXTREME_PLATE_COLOR_BASE;
                     } else if (data.source) {
                        baseColor = SOURCE_PLATE_COLOR_BASE;
                     } else if (data.suspicionLevel < 5 && data.maxVineLength < 4) {
                        baseColor = LOW_SUSPICION_GRAY;
                     } else {
                        baseColor = HIGH_SUSPICION_GRAY;
                     }

                     Color finalColor = new Color(baseColor.getRed(), baseColor.getGreen(), baseColor.getBlue(), alphaInt);
                     double startX = data.chunkPos.getStartX();
                     double startZ = data.chunkPos.getStartZ();
                     double x1 = startX - camPos.x;
                     double z1 = startZ - camPos.z;
                     double x2 = startX + 16.0 - camPos.x;
                     double z2 = startZ + 16.0 - camPos.z;
                     double y1 = 30.0 - camPos.y;
                     double y2 = 30.0 + 0.08 - camPos.y;
                     batch.renderFilledBox(x1, y1, z1, x2, y2, z2, finalColor);
                  }
               }

               batch.flush();
               matrices.pop();
            }
         }
      }
   }

   final class BerryCluster {
      private BlockPos pos;

      private BerryCluster(BlockPos pos) {
         this.pos = pos;
      }

      public BlockPos pos() {
         return this.pos;
      }
   }

   class DripstoneCluster {
      final BlockPos center;

      DripstoneCluster(BlockPos c) {
         this.center = c;
      }
   }

   final class SuspiciousGrowthData {
      private ChunkPos chunkPos;
      private int suspicionLevel;
      private ChunkPos baseChunk;
      private boolean extreme;
      private boolean source;
      private int maxVineLength;

      private SuspiciousGrowthData(ChunkPos chunkPos, int suspicionLevel, ChunkPos baseChunk, boolean extreme, boolean source, int maxVineLength) {
         this.chunkPos = chunkPos;
         this.suspicionLevel = suspicionLevel;
         this.baseChunk = baseChunk;
         this.extreme = extreme;
         this.source = source;
         this.maxVineLength = maxVineLength;
      }

      public ChunkPos chunkPos() {
         return this.chunkPos;
      }

      public int suspicionLevel() {
         return this.suspicionLevel;
      }

      public ChunkPos baseChunk() {
         return this.baseChunk;
      }

      public boolean extreme() {
         return this.extreme;
      }

      public boolean source() {
         return this.source;
      }

      public int maxVineLength() {
         return this.maxVineLength;
      }
   }

   class VineCluster {
      final int length;
      final List<BlockPos> positions;

      VineCluster(List<BlockPos> p) {
         this.positions = p;
         this.length = p.size();
      }

      BlockPos centroid() {
         long x = 0L;
         long y = 0L;
         long z = 0L;

         for (BlockPos p : this.positions) {
            x += p.getX();
            y += p.getY();
            z += p.getZ();
         }

         return new BlockPos((int)(x / this.positions.size()), (int)(y / this.positions.size()), (int)(z / this.positions.size()));
      }
   }

   final class WeightedEvidence {
      private BlockPos pos;
      private double weight;

      private WeightedEvidence(BlockPos pos, double weight) {
         this.pos = pos;
         this.weight = weight;
      }

      public BlockPos pos() {
         return this.pos;
      }

      public double weight() {
         return this.weight;
      }
   }
}

