package com.water.mixin;

import com.water.module.modules.render.DevSpawnerVisuals;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin({DrawContext.class})
public class DrawContextMixin {
   @ModifyVariable(
      method = {"drawItem(Lnet/minecraft/item/ItemStack;II)V"},
      at = @At("HEAD"),
      argsOnly = true,
      ordinal = 0
   )
   private ItemStack water$devSpawnerIcon(ItemStack stack) {
      return DevSpawnerVisuals.spoofedStack(stack);
   }

   @ModifyVariable(
      method = {"drawItem(Lnet/minecraft/item/ItemStack;III)V"},
      at = @At("HEAD"),
      argsOnly = true,
      ordinal = 0
   )
   private ItemStack water$devSpawnerIconWithSeed(ItemStack stack) {
      return DevSpawnerVisuals.spoofedStack(stack);
   }

   @ModifyVariable(
      method = {"drawItemWithoutEntity(Lnet/minecraft/item/ItemStack;II)V"},
      at = @At("HEAD"),
      argsOnly = true,
      ordinal = 0
   )
   private ItemStack water$devSpawnerIconWithoutEntity(ItemStack stack) {
      return DevSpawnerVisuals.spoofedStack(stack);
   }

   @ModifyVariable(
      method = {"drawItemWithoutEntity(Lnet/minecraft/item/ItemStack;III)V"},
      at = @At("HEAD"),
      argsOnly = true,
      ordinal = 0
   )
   private ItemStack water$devSpawnerIconWithoutEntityWithSeed(ItemStack stack) {
      return DevSpawnerVisuals.spoofedStack(stack);
   }

   @ModifyVariable(
      method = {"drawItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;III)V"},
      at = @At("HEAD"),
      argsOnly = true,
      ordinal = 0
   )
   private ItemStack water$devSpawnerIconWithEntity(ItemStack stack) {
      return DevSpawnerVisuals.spoofedStack(stack);
   }
}

