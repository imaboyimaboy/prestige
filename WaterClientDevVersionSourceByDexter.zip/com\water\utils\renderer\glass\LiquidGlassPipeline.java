package com.water.utils.renderer.glass;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;
import com.water.utils.renderer.RenderUtil;
import java.nio.ByteBuffer;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.GpuSampler;
import net.minecraft.client.gl.UniformType;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import org.lwjgl.system.MemoryUtil;

public class LiquidGlassPipeline {
   private static RenderPipeline pipeline;
   private static GpuBuffer uniformBuffer;
   private static final int UNIFORM_SIZE = 176;

   public static void init() {
      if (pipeline == null) {
         try {
            pipeline = RenderPipeline.builder(new Snippet[0])
               .withLocation(Identifier.of("water", "liquidglass"))
               .withVertexShader(Identifier.of("water", "liquidglass_vertex"))
               .withFragmentShader(Identifier.of("water", "liquidglass_fragment"))
               .withVertexFormat(VertexFormat.builder().build(), DrawMode.TRIANGLES)
               .withUniform("Uniforms", UniformType.UNIFORM_BUFFER)
               .withSampler("Sampler0")
               .withBlend(BlendFunction.TRANSLUCENT)
               .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
               .withCull(false)
               .build();
            uniformBuffer = RenderSystem.getDevice().createBuffer(() -> "LiquidGlass Uniforms", 136, 176L);
         } catch (Exception var1) {
            System.err.println("[LiquidGlass] Failed to init: " + var1.getMessage());
            var1.printStackTrace();
         }
      }
   }

   public static void draw(
      Matrix4f projection,
      float x,
      float y,
      float width,
      float height,
      float[] radii,
      int color,
      float globalAlpha,
      float fresnelPower,
      int fresnelColor,
      float baseAlpha,
      boolean fresnelInvert,
      float fresnelMix,
      float distortStrength,
      float squirt,
      float z
   ) {
      if (pipeline == null) {
         init();
      }

      if (pipeline != null && uniformBuffer != null) {
         MinecraftClient client = MinecraftClient.getInstance();
         Framebuffer fb = client.getFramebuffer();
         if (fb != null && fb.getColorAttachmentView() != null) {
            float fr = (fresnelColor >> 16 & 0xFF) / 255.0F;
            float fg = (fresnelColor >> 8 & 0xFF) / 255.0F;
            float fbCol = (fresnelColor & 0xFF) / 255.0F;
            float fa = (fresnelColor >> 24 & 0xFF) / 255.0F;
            float r0 = radii.length > 0 ? radii[0] : 0.0F;
            float r1 = radii.length > 1 ? radii[1] : r0;
            float r2 = radii.length > 2 ? radii[2] : r0;
            float r3 = radii.length > 3 ? radii[3] : r0;
            int texW = fb.textureWidth;
            int texH = fb.textureHeight;
            ByteBuffer buffer = MemoryUtil.memAlloc(176);
            buffer.putFloat(projection.m00()).putFloat(projection.m01()).putFloat(projection.m02()).putFloat(projection.m03());
            buffer.putFloat(projection.m10()).putFloat(projection.m11()).putFloat(projection.m12()).putFloat(projection.m13());
            buffer.putFloat(projection.m20()).putFloat(projection.m21()).putFloat(projection.m22()).putFloat(projection.m23());
            buffer.putFloat(projection.m30()).putFloat(projection.m31()).putFloat(projection.m32()).putFloat(projection.m33());
            buffer.position(64);
            buffer.putFloat(x).putFloat(y).putFloat(width).putFloat(height);
            buffer.putFloat(texW).putFloat(texH);
            buffer.position(96);
            buffer.putFloat(r0).putFloat(r1).putFloat(r2).putFloat(r3);
            buffer.position(112);
            buffer.putFloat(squirt);
            buffer.putFloat(2.0F);
            buffer.putFloat(globalAlpha);
            buffer.putFloat(fresnelPower);
            buffer.position(128);
            buffer.putFloat(fr).putFloat(fg).putFloat(fbCol).putFloat(fa);
            buffer.position(144);
            buffer.putFloat(baseAlpha);
            buffer.putInt(fresnelInvert ? 1 : 0);
            buffer.putFloat(fresnelMix);
            buffer.putFloat(distortStrength);
            buffer.putFloat(z);
            buffer.putFloat(0.0F);
            buffer.flip();
            CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
            encoder.writeToBuffer(uniformBuffer.slice(), buffer);
            MemoryUtil.memFree(buffer);
            GpuSampler sampler = RenderSystem.getSamplerCache().get(FilterMode.LINEAR);
            RenderPass pass = encoder.createRenderPass(
               () -> "LiquidGlass", fb.getColorAttachmentView(), OptionalInt.empty(), fb.getDepthAttachmentView(), OptionalDouble.of(1.0)
            );

            try {
               RenderUtil.applyScissor(pass);
               pass.setPipeline(pipeline);
               pass.setUniform("Uniforms", uniformBuffer);
               pass.bindTexture("Sampler0", fb.getColorAttachmentView(), sampler);
               pass.draw(0, 6);
            } catch (Throwable var35) {
               if (pass != null) {
                  try {
                     pass.close();
                  } catch (Throwable var34) {
                     var35.addSuppressed(var34);
                  }
               }

               throw var35;
            }

            if (pass != null) {
               pass.close();
            }
         }
      }
   }

   public static void shutdown() {
      if (uniformBuffer != null) {
         uniformBuffer.close();
         uniformBuffer = null;
      }

      pipeline = null;
   }
}

