package rtx.kimiko.api.mods.geckolib;

import com.mojang.serialization.Codec;
import java.util.function.Supplier;
import net.minecraft.component.ComponentType;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.util.Identifier;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public final class GeckoLibConstants {
   public static final Logger LOGGER = LogManager.getLogger("GeckoLib");
   public static final String MODID = "geckolib";
   public static final Supplier<ComponentType<Long>> STACK_ANIMATABLE_ID_COMPONENT = GeckoLibServices.PLATFORM
      .registerDataComponent("stack_animatable_id", builder -> builder.codec(Codec.LONG).packetCodec(PacketCodecs.VAR_LONG));

   public static Identifier id(String string) {
      return Identifier.of("geckolib", string);
   }

   public static void init() {
   }

   public static RuntimeException exception(Identifier identifier, String string) {
      return new RuntimeException(identifier + ": " + string);
   }

   public static RuntimeException exception(Identifier identifier, String string, Throwable throwable) {
      return new RuntimeException(identifier + ": " + string, throwable);
   }
}

