package com.water.mixin;

import com.water.module.modules.misc.GambleRig;
import com.water.module.modules.render.DevSpawnerVisuals;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({ClientPlayerInteractionManager.class})
public class ClientPlayerInteractionManagerMixin {
   @Inject(
      method = {"interactBlock"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void water$devSpawnerBeforeInteract(ClientPlayerEntity player, Hand hand, BlockHitResult hitResult, CallbackInfoReturnable<ActionResult> cir) {
      GambleRig.setLastInteractedBlock(hitResult.getBlockPos());
      if (GambleRig.handleBlockClick(hitResult.getBlockPos())) {
         cir.setReturnValue(ActionResult.SUCCESS);
      } else if (DevSpawnerVisuals.openFakeSpawnerScreen(player, hitResult)) {
         cir.setReturnValue(ActionResult.SUCCESS);
      } else {
         DevSpawnerVisuals.previewPlacement(player, hand, hitResult);
      }
   }
}

