package rtx.kimiko.api.mods.geckolib.loading.math.value;

import rtx.kimiko.api.mods.geckolib.animation.state.ControllerState;
import rtx.kimiko.api.mods.geckolib.loading.math.MathValue;

public final class Constant implements MathValue {
   private double value;

   public Constant(double value) {
      this.value = value;
   }

   @Override
   public String toString() {
      return String.valueOf(this.value);
   }

   @Override
   public double get(ControllerState controllerState) {
      return this.value;
   }

   @Override
   public boolean isMutable() {
      return false;
   }

   public double value() {
      return this.value;
   }
}

