package rtx.kimiko.api.mods.chathads.config;

import java.util.Map;

public interface ChatHeadsConfig {
   boolean drawShadow();

   boolean smartHeuristics();

   boolean detectNameAliases();

   boolean offsetNonPlayerText();

   SenderDetection senderDetection();

   RenderPosition renderPosition();

   void addNameAlias(String var1, String var2);

   Map<String, String> getNameAliases();

   float threeDeeNess();

   void setThreeDeeNess(float var1);

   boolean handleSystemMessages();
}

