package rtx.kimiko.api.mods.geckolib.loading.json.raw;

import com.google.gson.JsonDeserializer;
import com.google.gson.JsonObject;
import net.minecraft.util.JsonHelper;
import net.minecraft.util.math.Direction;

public final class UVFaces {
   private FaceUV north;
   private FaceUV south;
   private FaceUV east;
   private FaceUV west;
   private FaceUV faceUV;
   private FaceUV down;

   public UVFaces(FaceUV north, FaceUV south, FaceUV east, FaceUV west, FaceUV up, FaceUV down) {
      this.north = north;
      this.south = south;
      this.east = east;
      this.west = west;
      this.faceUV = up;
      this.down = down;
   }

   public FaceUV fromDirection(Direction direction) {
      return switch (direction) {
         case NORTH -> this.north;
         case SOUTH -> this.south;
         case EAST -> this.east;
         case WEST -> this.west;
         case UP -> this.faceUV;
         case DOWN -> this.down;
         default -> throw new MatchException(null, null);
      };
   }

   public static JsonDeserializer<UVFaces> deserializer() {
      return (jsonElement, type, jsonDeserializationContext) -> {
         JsonObject jsonObject = jsonElement.getAsJsonObject();
         FaceUV faceUV = (FaceUV)JsonHelper.deserialize(jsonObject, "north", null, jsonDeserializationContext, FaceUV.class);
         FaceUV faceUV2 = (FaceUV)JsonHelper.deserialize(jsonObject, "south", null, jsonDeserializationContext, FaceUV.class);
         FaceUV faceUV3 = (FaceUV)JsonHelper.deserialize(jsonObject, "east", null, jsonDeserializationContext, FaceUV.class);
         FaceUV faceUV4 = (FaceUV)JsonHelper.deserialize(jsonObject, "west", null, jsonDeserializationContext, FaceUV.class);
         FaceUV faceUV5 = (FaceUV)JsonHelper.deserialize(jsonObject, "up", null, jsonDeserializationContext, FaceUV.class);
         FaceUV faceUV6 = (FaceUV)JsonHelper.deserialize(jsonObject, "down", null, jsonDeserializationContext, FaceUV.class);
         return new UVFaces(faceUV, faceUV2, faceUV3, faceUV4, faceUV5, faceUV6);
      };
   }

   public FaceUV north() {
      return this.north;
   }

   public FaceUV south() {
      return this.south;
   }

   public FaceUV east() {
      return this.east;
   }

   public FaceUV west() {
      return this.west;
   }

   public FaceUV getFaceUV() {
      return this.faceUV;
   }

   public FaceUV down() {
      return this.down;
   }
}

