package com.water.module.modules.misc;

import com.water.mixin.MinecraftClientAccessor;
import com.water.module.Category;
import com.water.module.Module;
import com.water.setting.Setting;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.RangedWeaponItem;

public final class FastPlace extends Module {
   private final Setting<Boolean> onlyXP = new Setting<>("Only XP", false);
   private final Setting<Boolean> allowBlocks = new Setting<>("Blocks", true);
   private final Setting<Boolean> allowItems = new Setting<>("Items", true);
   private final Setting<Float> useDelay = new Setting<>("Delay", 0.0F, 0.0F, 10.0F);

   public FastPlace() {
      super("Fast Place", Category.MISC);
      this.addSetting(this.onlyXP);
      this.addSetting(this.allowBlocks);
      this.addSetting(this.allowItems);
      this.addSetting(this.useDelay);
   }

   @Override
   public void onTick() {
      if (mc.player != null && mc.currentScreen == null) {
         if (mc.options.useKey.isPressed()) {
            ItemStack mainHand = mc.player.getMainHandStack();
            ItemStack offHand = mc.player.getOffHandStack();
            if (this.shouldAffectCooldown(mainHand, offHand)) {
               MinecraftClientAccessor accessor = (MinecraftClientAccessor)mc;
               int targetCooldown = Math.max(0, this.useDelay.getValue().intValue());
               if (accessor.water$getItemUseCooldown() != targetCooldown) {
                  accessor.water$setItemUseCooldown(targetCooldown);
               }
            }
         }
      }
   }

   private boolean shouldAffectCooldown(ItemStack mainHand, ItemStack offHand) {
      boolean mainXp = mainHand.isOf(Items.EXPERIENCE_BOTTLE);
      boolean offXp = offHand.isOf(Items.EXPERIENCE_BOTTLE);
      if (this.onlyXP.getValue()) {
         return mainXp || offXp;
      } else {
         Item mainItem = mainHand.getItem();
         Item offItem = offHand.getItem();
         if (this.isFood(mainHand) || this.isFood(offHand)) {
            return false;
         } else if (mainHand.isOf(Items.RESPAWN_ANCHOR)
            || mainHand.isOf(Items.GLOWSTONE)
            || offHand.isOf(Items.RESPAWN_ANCHOR)
            || offHand.isOf(Items.GLOWSTONE)) {
            return false;
         } else if (!(mainItem instanceof RangedWeaponItem) && !(offItem instanceof RangedWeaponItem)) {
            boolean hasBlockItem = mainItem instanceof BlockItem || offItem instanceof BlockItem;
            return hasBlockItem ? this.allowBlocks.getValue() : this.allowItems.getValue();
         } else {
            return false;
         }
      }
   }

   private boolean isFood(ItemStack stack) {
      return stack.getComponents().contains(DataComponentTypes.FOOD);
   }
}

