package com.water.gui;

import com.water.module.modules.render.BlockESP;
import com.water.setting.BlocksSetting;
import net.minecraft.client.gui.screen.Screen;

public final class BlockColorScreen extends BlockPickerScreen {
   public BlockColorScreen(BlockESP module, Screen parent) {
      super(parent, module, module.getSettings().stream().filter(BlocksSetting.class::isInstance).map(BlocksSetting.class::cast).findFirst().orElseThrow());
   }
}

