package rtx.kimiko.api.mods.acountswiher.ru.vidtu.ias.screen;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

public final class AccountScreen extends Screen {
   private Screen parent;
   private final List<AccountScreen.ServerShortcut> serverShortcuts = new ArrayList<>();
   private TextFieldWidget search;
   private AccountScreen.AccountList list;
   private ButtonWidget login;
   private ButtonWidget offlineLogin;
   private ButtonWidget edit;
   private ButtonWidget delete;

   public AccountScreen(Screen parent) {
      super(Text.literal("Account Switcher"));
      this.parent = parent;
   }

   protected void init() {
      super.init();
      this.addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b -> {
         if (this.client != null) {
            this.client.setScreen(this.parent);
         }
      }).dimensions(this.width / 2 - 100, this.height - 28, 200, 20).build());
   }

   public void close() {
      if (this.client != null) {
         this.client.setScreen(this.parent);
      }
   }

   public void render(DrawContext context, int mouseX, int mouseY, float delta) {
      super.render(context, mouseX, mouseY, delta);
      context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 20, 16777215);
   }

   public final class AccountList {
   }

   public final class ServerShortcut {
      private String name;
      private String address;

      public ServerShortcut(String name, String address) {
         this.name = name;
         this.address = address;
      }

      public String name() {
         return this.name;
      }

      public String address() {
         return this.address;
      }
   }
}

