package rtx.kimiko.api.drags.components;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import rtx.kimiko.api.drags.Draggable;
import rtx.kimiko.api.modules.ModuleManager;
import rtx.kimiko.api.modules.impl.Interface.InterfaceModule;
import rtx.kimiko.api.modules.impl.Interface.WatermarkModule;
import rtx.kimiko.api.ui.settings.Setting;
import rtx.kimiko.api.ui.settings.impl.BoolSetting;
import rtx.kimiko.api.ui.theme.ClientAccent;
import rtx.kimiko.utils.animations.Easings;
import rtx.kimiko.utils.animations.SmoothAnimation;
import rtx.kimiko.utils.color.ColorUtil;
import rtx.kimiko.utils.render.others.RectUtil;
import rtx.kimiko.utils.render.render2d.Render2D;

public final class WatermarkComp extends Draggable {
   private static final float PAD_X = 9.0F;
   private static final float PAD_Y = 6.0F;
   private static final float FONT = 8.0F;
   private static final float BRAND_FONT_SIZE = 11.0F;
   private static final float floatVal = 20.0F;
   private static final String BRAND_FONT = "montserrat-medium";
   private static final String INFO_FONT = "montserrat-medium";
   private static final String[] BRAND_GLYPHS = new String[]{"W", "a", "t", "e", "r"};
   private static final String SEPARATOR = " | ";
   private static final float TEXT_Y_LIFT = 1.0F;
   private static final float MIN_TEXT_ALPHA = 0.003921569F;
   private static final long INDEXED_GRADIENT_PERIOD_MS = 1200L;
   private static final float INDEXED_GRADIENT_STEP = 15.0F;
   private static final int FALLBACK_BRAND_COLOR = -2234369;
   private static final float DOT_RADIUS = 1.0F;
   private static final float DOT_GAP = 6.0F;
   private static final String FALLBACK_NAME = "Player";
   private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH);
   private final SmoothAnimation visibility = new SmoothAnimation();
   private boolean lastTargetVisible;
   private float currentWidth = 80.0F;
   private boolean staticMetricsReady;
   private float brandWidth;
   private final float[] brandGlyphWidths = new float[BRAND_GLYPHS.length];
   private float separatorWidth;
   private String cachedName = "";
   private float nameWidth;
   private String timeText = "";
   private float timeWidth;
   private float discordBlockWidth;

   public WatermarkComp() {
      super("watermark", 5.0F, 5.0F);
      this.visibility.set(0.0);
   }

   @Override
   public String displayName() {
      return "Watermark";
   }

   @Override
   public float width() {
      return this.currentWidth;
   }

   @Override
   public float height() {
      return 20.0F;
   }

   @Override
   public boolean isInteractive() {
      return this.shouldShow();
   }

   @Override
   protected List<Setting> buildHudSettings() {
      List<Setting> list = super.buildHudSettings();
      WatermarkModule watermarkModule = ModuleManager.get().get(WatermarkModule.class);
      if (watermarkModule != null) {
         list.add(new BoolSetting(watermarkModule.showNick));
         list.add(new BoolSetting(watermarkModule.showTime));
      }

      return list;
   }

   private static int indexedPaletteColor(int[] nArray, float f) {
      int n = nArray.length;
      if (n <= 1) {
         return nArray[0];
      } else {
         float f2 = normalizedCycle(f) / 360.0F;
         float f3 = f2 < 0.5F ? f2 * 2.0F : (1.0F - f2) * 2.0F;
         float f4 = f3 * (n - 1);
         int n2 = (int)f4;
         if (n2 > n - 2) {
            n2 = n - 2;
         }

         return ColorUtil.lerpColor(nArray[n2], nArray[n2 + 1], f4 - n2);
      }
   }

   private static int[] watermarkPalette(InterfaceModule interfaceModule) {
      int[] nArray = ClientAccent.currentPalette();
      if (nArray != null && nArray.length != 0) {
         int[] nArray2 = new int[nArray.length];

         for (int i = 0; i < nArray.length; i++) {
            nArray2[i] = ColorUtil.lerpColor(opaque(nArray[i]), -1, 0.18F);
         }

         return nArray2;
      } else {
         int n = ColorUtil.lerpColor(-2234369, -1, 0.18F);
         return new int[]{n, ColorUtil.lerpColor(n, -1, 0.46F)};
      }
   }

   private static void drawIndexedGradientGlyph(String string, String string2, float f, float f2, float f3, int n, int[] nArray, float f4, float f5) {
      float f6 = Math.max(0.0F, Math.min(1.0F, f4));
      if (!(f6 <= 0.003921569F) && string2 != null && !string2.isEmpty()) {
         int n2 = ColorUtil.multAlpha(indexedPaletteColor(nArray, f5 + n * 15.0F), f6);
         Render2D.msdfText(string, string2, f, f2, f3, n2);
      }
   }

   private float drawInfoBlock(float f, float f2, float f3, float f4, float f5, int[] nArray, float f6) {
      WatermarkModule watermarkModule = ModuleManager.get().get(WatermarkModule.class);
      boolean bl = watermarkModule == null || watermarkModule.showNick.getValue();
      boolean bl2 = watermarkModule == null || watermarkModule.showTime.getValue();
      float f7 = f2 + 10.0F + 0.5F;
      float f8 = f4 + 0.5F;
      int n = Math.round(this.nameWidth / 8.0F);
      int n3 = n + 1;
      if (bl) {
         float var17;
         Render2D.circle((var17 = f3 + 6.0F) + 1.0F, f7, 1.0F, gradientDotColor(nArray, f6, 0, f5));
         drawGradientString("montserrat-medium", this.cachedName, f3 = var17 + 8.0F, f8, 8.0F, 1, nArray, f5, f6);
         f3 += this.nameWidth;
      }

      if (bl2) {
         float var19;
         Render2D.circle((var19 = f3 + 6.0F) + 1.0F, f7, 1.0F, gradientDotColor(nArray, f6, n3, f5));
         int n4 = n3 + 1;
         drawGradientString("montserrat-medium", this.timeText, f3 = var19 + 8.0F, f8, 8.0F, n4, nArray, f5, f6);
         f3 += this.timeWidth;
      }

      return f3;
   }

   private static float indexedGradientPhase() {
      return (float)(System.currentTimeMillis() % 1200L) / 1200.0F * 360.0F;
   }

   private static float normalizedCycle(float f) {
      float f2 = f % 360.0F;
      return f2 < 0.0F ? f2 + 360.0F : f2;
   }

   private void updateTextCache() {
      if (!this.staticMetricsReady) {
         this.brandWidth = 0.0F;

         for (int i = 0; i < BRAND_GLYPHS.length; i++) {
            float f;
            this.brandGlyphWidths[i] = f = Render2D.msdfWidth("montserrat-medium", BRAND_GLYPHS[i], 11.0F);
            this.brandWidth += f;
         }

         this.separatorWidth = Render2D.msdfWidth("montserrat-medium", " | ", 8.0F);
         this.staticMetricsReady = true;
      }

      this.updateInfoCache();
   }

   private static void drawIndexedGradientText(
      String string, String[] stringArray, float[] fArray, float f, float f2, float f3, int n, int[] nArray, float f4, float f5
   ) {
      float f6 = Math.max(0.0F, Math.min(1.0F, f4));
      if (!(f6 <= 0.003921569F) && stringArray != null && stringArray.length != 0) {
         float f7 = f;

         for (int i = 0; i < stringArray.length; i++) {
            String string2 = stringArray[i];
            if (string2 != null && !string2.isEmpty()) {
               drawIndexedGradientGlyph(string, string2, f7, f2, f3, n + i, nArray, f6, f5);
            }

            f7 += i < fArray.length ? fArray[i] : Render2D.msdfWidth(string, string2, f3);
         }
      }
   }

   private static int gradientDotColor(int[] nArray, float f, int n, float f2) {
      int n2 = indexedPaletteColor(nArray, f + n * 15.0F);
      return ColorUtil.multAlpha(n2, Math.max(0.0F, Math.min(1.0F, f2)));
   }

   private void updateInfoCache() {
      String string2 = playerName();
      if (!string2.equals(this.cachedName)) {
         this.cachedName = string2;
         this.nameWidth = Render2D.msdfWidth("montserrat-medium", string2, 8.0F);
      }

      String string;
      if (!(string = LocalTime.now().format(TIME_FORMAT)).equals(this.timeText)) {
         this.timeText = string;
         this.timeWidth = Render2D.msdfWidth("montserrat-medium", string, 8.0F);
      }

      WatermarkModule watermarkModule;
      boolean bl = (watermarkModule = ModuleManager.get().get(WatermarkModule.class)) == null || watermarkModule.showNick.getValue();
      boolean bl2 = watermarkModule == null || watermarkModule.showTime.getValue();
      this.discordBlockWidth = (bl ? 14.0F + this.nameWidth : 0.0F) + (bl2 ? 14.0F + this.timeWidth : 0.0F);
   }

   private static void drawGradientString(String string, String string2, float f, float f2, float f3, int n, int[] nArray, float f4, float f5) {
      float f6 = Math.max(0.0F, Math.min(1.0F, f4));
      if (!(f6 <= 0.003921569F) && string2 != null && !string2.isEmpty()) {
         float f7 = f;
         int n3 = n;
         int i = 0;

         while (i < string2.length()) {
            int n4 = string2.codePointAt(i);
            int n2 = Character.charCount(n4);
            String string3 = string2.substring(i, i + n2);
            drawIndexedGradientGlyph(string, string3, f7, f2, f3, n3, nArray, f6, f5);
            f7 += Render2D.msdfWidth(string, string3, f3);
            n3++;
            i += n2;
         }
      }
   }

   @Override
   protected void render(DrawContext drawContext) {
      boolean bl = this.shouldShow();
      if (bl != this.lastTargetVisible) {
         this.visibility.run(bl ? 1.0 : 0.0, bl ? 0.18 : 0.12, Easings.CUBIC_OUT, false);
         this.lastTargetVisible = bl;
      }

      this.visibility.update();
      float f = this.visibility.get();
      if (bl && f <= 0.01F) {
         f = 0.01F;
      }

      if (!(f <= 0.01F) || bl) {
         this.updateTextCache();
         this.currentWidth = this.brandWidth + this.discordBlockWidth + 18.0F;
         float f2 = 0.92F + f * 0.08F;
         float f3 = this.getX() + this.currentWidth * 0.5F;
         float f4 = this.getY() + 10.0F;
         drawContext.getMatrices().pushMatrix();
         drawContext.getMatrices().translate(f3, f4);
         drawContext.getMatrices().scale(f2);
         drawContext.getMatrices().translate(-f3, -f4);
         Render2D.beginFrame(drawContext);
         float f5 = this.getX();
         float f6 = this.getY();
         RectUtil.drawClientRect(f5, f6, this.currentWidth, 20.0F, 10.0F, f);
         InterfaceModule interfaceModule = InterfaceModule.getInstance();
         int[] nArray = watermarkPalette(interfaceModule);
         float f7 = indexedGradientPhase();
         float f8 = f5 + 9.0F;
         float f9 = f6 + 6.0F - 1.0F;
         drawIndexedGradientText("montserrat-medium", BRAND_GLYPHS, this.brandGlyphWidths, f8, f9, 11.0F, 1, nArray, f, f7);
         float var14;
         this.drawInfoBlock(f5, f6, var14 = f8 + this.brandWidth, f9, f, nArray, f7);
         Render2D.flush();
         drawContext.getMatrices().popMatrix();
      }
   }

   private static String playerName() {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      if (minecraftClient.getSession() != null && minecraftClient.getSession().getUsername() != null && !minecraftClient.getSession().getUsername().isBlank()) {
         return minecraftClient.getSession().getUsername();
      } else {
         String string;
         return minecraftClient.player != null && (string = minecraftClient.player.getGameProfile().name()) != null && !string.isBlank() ? string : "Player";
      }
   }

   private boolean shouldShow() {
      WatermarkModule watermarkModule = ModuleManager.get().get(WatermarkModule.class);
      return watermarkModule != null && watermarkModule.isEnabled();
   }

   private static int opaque(int n) {
      return n & 16777215 | 0xFF000000;
   }
}

