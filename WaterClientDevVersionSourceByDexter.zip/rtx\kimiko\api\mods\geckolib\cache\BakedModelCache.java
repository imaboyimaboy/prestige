package rtx.kimiko.api.mods.geckolib.cache;

import java.util.Map;
import net.minecraft.util.Identifier;
import rtx.kimiko.api.mods.geckolib.GeckoLibConstants;
import rtx.kimiko.api.mods.geckolib.cache.model.BakedGeoModel;

public final class BakedModelCache {
   private Map<Identifier, BakedGeoModel> cache;

   public BakedModelCache(Map<Identifier, BakedGeoModel> cache) {
      this.cache = cache;
   }

   private static Identifier stripLegacyPath(Identifier identifier) {
      String string = identifier.getPath();
      if (string.startsWith("geckolib/")) {
         string = string.substring(9);
      }

      if (string.startsWith("models/")) {
         string = string.substring(7);
      }

      if (string.endsWith(".json")) {
         string = string.substring(0, string.length() - 5);
      }

      if (string.endsWith(".geo")) {
         string = string.substring(0, string.length() - 4);
      }

      return !string.equals(identifier.getPath()) ? identifier.withPath(string) : identifier;
   }

   public BakedGeoModel getModel(Identifier identifier) {
      BakedGeoModel bakedGeoModel = this.cache.get(identifier);
      if (bakedGeoModel == null) {
         Identifier identifier2 = stripLegacyPath(identifier);
         if (!identifier.equals(identifier2)) {
            GeckoLibConstants.LOGGER.error("Superfluous prefix or suffix found in model resource path: '{}'. Should be '{}'", identifier, identifier2);
            bakedGeoModel = this.cache.get(identifier2);
         }

         if (bakedGeoModel == null) {
            throw new IllegalArgumentException("Unable to find model file: " + identifier);
         }
      }

      return bakedGeoModel;
   }

   public Map<Identifier, BakedGeoModel> cache() {
      return this.cache;
   }
}

