package com.water.utils.renderer;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;
import java.awt.Color;
import java.util.OptionalInt;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BuiltBuffer;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector4f;

public final class StorageTracerRenderer implements AutoCloseable {
   private static final int STROKE_COUNT = 3;
   private static final RenderPipeline PIPELINE = RenderPipeline.builder(new Snippet[0])
      .withLocation(Identifier.of("water", "storage_tracer_overlay"))
      .withVertexShader(Identifier.of("water", "storage_tracer_overlay"))
      .withFragmentShader(Identifier.of("water", "storage_tracer_overlay"))
      .withVertexFormat(VertexFormats.POSITION_COLOR, DrawMode.TRIANGLES)
      .withBlend(BlendFunction.TRANSLUCENT)
      .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
      .withDepthWrite(false)
      .withCull(false)
      .build();
   private final BufferAllocator allocator = new BufferAllocator(1048576);
   private BufferBuilder vertices;
   private Matrix4f projection;
   private int width;
   private int height;

   public void begin(MatrixStack matrices) {
      Framebuffer framebuffer = MinecraftClient.getInstance().getFramebuffer();
      this.width = framebuffer.textureWidth;
      this.height = framebuffer.textureHeight;
      this.projection = new Matrix4f(ProjectionUtil.projectionMatrix).mul(matrices.peek().getPositionMatrix());
      this.vertices = new BufferBuilder(this.allocator, DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);
   }

   public void addLine(Vec3d start, Vec3d end, Color color, float lineWidth) {
      Vector4f a = this.projection.transform(new Vector4f((float)start.x, (float)start.y, (float)start.z, 1.0F));
      Vector4f b = this.projection.transform(new Vector4f((float)end.x, (float)end.y, (float)end.z, 1.0F));
      float da = a.z + a.w;
      float db = b.z + b.w;
      if (!(da < 0.0F) || !(db < 0.0F)) {
         if (da < 0.0F) {
            a.lerp(b, da / (da - db));
         } else if (db < 0.0F) {
            b.lerp(a, db / (db - da));
         }

         if (!(a.w <= 1.0E-6F) && !(b.w <= 1.0E-6F)) {
            a.div(a.w);
            b.div(b.w);
            float dx = (b.x - a.x) * this.width;
            float dy = (b.y - a.y) * this.height;
            float length = (float)Math.sqrt(dx * dx + dy * dy);
            if (Float.isFinite(length) && !(length < 1.0E-5F)) {
               float strokeWidth = Math.max(lineWidth, 1.0F);
               float nx = -dy / length * strokeWidth / this.width;
               float ny = dx / length * strokeWidth / this.height;
               int strokeAlpha = (int)Math.round(255.0 * (1.0 - Math.pow(1.0 - color.getAlpha() / 255.0, 0.3333333333333333)));
               int rgb = color.getRGB() & 16777215 | strokeAlpha << 24;

               for (int line = 0; line < 3; line++) {
                  this.vertex(a, nx, ny, rgb);
                  this.vertex(a, -nx, -ny, rgb);
                  this.vertex(b, -nx, -ny, rgb);
                  this.vertex(a, nx, ny, rgb);
                  this.vertex(b, -nx, -ny, rgb);
                  this.vertex(b, nx, ny, rgb);
               }
            }
         }
      }
   }

   private void vertex(Vector4f point, float x, float y, int color) {
      this.vertices.vertex(point.x + x, point.y + y, point.z).color(color);
   }

   public void flush() {
      BuiltBuffer mesh = this.vertices.endNullable();

      label80: {
         try {
            if (mesh == null) {
               break label80;
            }

            GpuDevice device = RenderSystem.getDevice();
            Framebuffer framebuffer = MinecraftClient.getInstance().getFramebuffer();
            GpuBuffer buffer = device.createBuffer(() -> "Storage tracer vertices", 32, mesh.getBuffer());

            try {
               RenderPass pass = device.createCommandEncoder()
                  .createRenderPass(() -> "Storage tracer overlay", framebuffer.getColorAttachmentView(), OptionalInt.empty());

               try {
                  pass.setPipeline(PIPELINE);
                  pass.setVertexBuffer(0, buffer);
                  pass.draw(0, mesh.getDrawParameters().vertexCount());
               } catch (Throwable var11) {
                  if (pass != null) {
                     try {
                        pass.close();
                     } catch (Throwable var10) {
                        var11.addSuppressed(var10);
                     }
                  }

                  throw var11;
               }

               if (pass != null) {
                  pass.close();
               }
            } catch (Throwable var12) {
               if (buffer != null) {
                  try {
                     buffer.close();
                  } catch (Throwable var9) {
                     var12.addSuppressed(var9);
                  }
               }

               throw var12;
            }

            if (buffer != null) {
               buffer.close();
            }
         } catch (Throwable var13) {
            if (mesh != null) {
               try {
                  mesh.close();
               } catch (Throwable var8) {
                  var13.addSuppressed(var8);
               }
            }

            throw var13;
         }

         if (mesh != null) {
            mesh.close();
         }

         return;
      }

      if (mesh != null) {
         mesh.close();
      }
   }

   @Override
   public void close() {
      this.allocator.close();
   }
}

