package rtx.kimiko.api.mods.geckolib.loading.math.value;

import java.util.Set;
import rtx.kimiko.api.mods.geckolib.animation.state.ControllerState;
import rtx.kimiko.api.mods.geckolib.loading.math.MathValue;

public final class Group implements MathValue {
   private MathValue value;

   public Group(MathValue value) {
      this.value = value;
   }

   @Override
   public double get(ControllerState state) {
      return this.value.get(state);
   }

   @Override
   public Set<Variable> getUsedVariables() {
      return this.value.getUsedVariables();
   }

   public MathValue value() {
      return this.value;
   }
}

