package rtx.kimiko.api.liteapi;

public @interface Feature {
   String[] value();
}

