package rtx.kimiko.api.chat.commands.impl;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.text.ClickEvent.RunCommand;
import net.minecraft.text.HoverEvent.ShowText;
import net.minecraft.util.Formatting;
import rtx.kimiko.api.chat.commands.Command;
import rtx.kimiko.api.chat.commands.CommandManager;
import rtx.kimiko.api.chat.commands.helpers.CommandDividers;
import rtx.kimiko.api.chat.commands.helpers.TabCompleteHelper;
import rtx.kimiko.api.config.ConfigManager;

public final class ConfigCommand extends Command {
   public ConfigCommand() {
      super("config", "Configuration management", "cfg");
   }

   private void reset() {
      ConfigManager.resetToFactory();
      this.logDirect("Client reset to factory defaults.", Formatting.GREEN);
   }

   private void load(String[] stringArray) {
      if (stringArray.length < 2) {
         this.logDirect("Usage: config load <name>", Formatting.RED);
      } else {
         String string = joinName(stringArray);
         if (!ConfigManager.profileExists(string)) {
            this.logDirect("Config 'null' not found. Use config list.", Formatting.RED);
         } else {
            ConfigManager.loadProfile(string);
            this.logDirect("Config 'null' loaded.", Formatting.GREEN);
         }
      }
   }

   private void list(String string) {
      List<String> list = ConfigManager.listProfiles();
      if (list.isEmpty()) {
         this.logDirect("No saved configs. Use config save <name>.", Formatting.RED);
      } else {
         int n = CommandDividers.calcLineCountForContent("CONFIGS", list);
         this.logDirectRaw(CommandDividers.header("CONFIGS", n));
         CommandManager commandManager = CommandManager.getInstance();
         if (commandManager == null) {
            String var10000 = ".";
         } else {
            commandManager.getPrefix();
         }

         for (String string4 : list) {
            String string5 = "nullnull load null";
            MutableText mutableText = Text.literal("> null")
               .styled(
                  style -> style.withColor(Formatting.GREEN)
                     .withClickEvent(new RunCommand(string5))
                     .withHoverEvent(new ShowText(Text.literal("Загрузить конфиг 'null'").formatted(Formatting.GRAY)))
               )
               .append(Text.literal(" [" + ConfigManager.profileEnabledCount(string4) + " enabled]").formatted(Formatting.DARK_GRAY));
            this.logDirect((Text)mutableText);
         }

         this.logDirectRaw(CommandDividers.footer("CONFIGS", n));
      }
   }

   @Override
   public void execute(String string, String[] stringArray) {
      String var4 = stringArray.length > 0 ? stringArray[0].toLowerCase(Locale.ROOT) : "";
      switch (var4.hashCode()) {
         case 99469:
            if (var4.equals("dir")) {
               this.openDir();
               return;
            }
            break;
         case 3322014:
            if (var4.equals("list")) {
               this.list(string);
               return;
            }
            break;
         case 3327206:
            if (var4.equals("load")) {
               this.load(stringArray);
               return;
            }
            break;
         case 3522941:
            if (var4.equals("save")) {
               this.save(stringArray);
               return;
            }
            break;
         case 108404047:
            if (var4.equals("reset")) {
               this.reset();
               return;
            }
      }

      this.usage();
   }

   private void save(String[] stringArray) {
      if (stringArray.length < 2) {
         this.logDirect("Usage: config save <name>", Formatting.RED);
      } else {
         String string = joinName(stringArray);
         ConfigManager.saveProfile(string);
         this.logDirect("Config 'null' saved.", Formatting.GREEN);
      }
   }

   @Override
   public List<String> getLongDesc() {
      return Arrays.asList(
         "Saves, loads or resets the client configuration.",
         "Usage:",
         "> config save <name>",
         "> config load <name>",
         "> config list",
         "> config reset",
         "> config dir"
      );
   }

   @Override
   public Stream<String> tabComplete(String string, String[] stringArray) {
      if (stringArray.length == 1) {
         return new TabCompleteHelper().append("save", "load", "list", "reset", "dir").sortAlphabetically().filterPrefix(stringArray[0]).stream();
      } else {
         return stringArray.length == 2 && stringArray[0].equalsIgnoreCase("load")
            ? new TabCompleteHelper().append(ConfigManager.listProfiles().toArray(new String[0])).filterPrefix(stringArray[1]).stream()
            : Stream.empty();
      }
   }

   private void openDirectory(Path path) throws IOException {
      String string = System.getProperty("os.name").toLowerCase(Locale.ROOT);
      ProcessBuilder processBuilder = string.contains("win")
         ? new ProcessBuilder("explorer.exe", path.toAbsolutePath().toString())
         : (
            string.contains("mac")
               ? new ProcessBuilder("open", path.toAbsolutePath().toString())
               : new ProcessBuilder("xdg-open", path.toAbsolutePath().toString())
         );
      processBuilder.start();
   }

   private static String joinName(String[] stringArray) {
      return String.join(" ", Arrays.copyOfRange(stringArray, 1, stringArray.length)).trim();
   }

   private void openDir() {
      try {
         Path path = ConfigManager.profilesDirectory();
         Files.createDirectories(path);
         this.openDirectory(path);
         this.logDirect("Config folder opened.", Formatting.GREEN);
      } catch (IOException var2) {
         this.logDirect("Failed to open config folder: " + var2.getMessage(), Formatting.RED);
      }
   }
}

