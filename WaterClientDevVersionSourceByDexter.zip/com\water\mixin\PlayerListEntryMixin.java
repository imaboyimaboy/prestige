package com.water.mixin;

import com.mojang.authlib.GameProfile;
import com.water.module.modules.donut.FakeRoles;
import com.water.module.modules.misc.SkinChanger;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.player.SkinTextures;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({PlayerListEntry.class})
public abstract class PlayerListEntryMixin {
   @Shadow
   public abstract GameProfile getProfile();

   @Inject(
      method = {"getSkinTextures"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void water$overrideListEntrySkin(CallbackInfoReturnable<SkinTextures> cir) {
      GameProfile profile = this.getProfile();
      if (profile != null && profile.id() != null) {
         SkinTextures override = SkinChanger.getOverrideSkin(profile.id());
         if (override != null) {
            cir.setReturnValue(override);
         }
      }
   }

   @Inject(
      method = {"getDisplayName"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void water$fakeRoleDisplayName(CallbackInfoReturnable<Text> cir) {
      if (FakeRoles.isActive()) {
         GameProfile profile = this.getProfile();
         MinecraftClient client = MinecraftClient.getInstance();
         if (profile != null && profile.id() != null && client != null && client.player != null) {
            if (profile.id().equals(client.player.getUuid())) {
               Text prefixed = FakeRoles.buildPrefixedDisplayName(profile.name());
               if (prefixed != null) {
                  cir.setReturnValue(prefixed);
               }
            }
         }
      }
   }
}

