package rtx.kimiko.api.mods.acountswiher.ru.vidtu.ias.auth.handlers;

import java.util.concurrent.CompletableFuture;
import rtx.kimiko.api.mods.acountswiher.ru.vidtu.ias.auth.LoginData;

public interface LoginHandler {
   void error(Throwable var1);

   boolean cancelled();

   void stage(String var1, Object... var2);

   void success(LoginData var1, boolean var2);

   CompletableFuture<String> password();
}

