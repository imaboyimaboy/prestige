package com.water.setting;

public final class ConfirmBooleanSetting extends Setting<Boolean> {
   private String confirmTitle;
   private String confirmMessage;

   public ConfirmBooleanSetting(String name, boolean value, String confirmTitle, String confirmMessage) {
      super(name, value);
      this.confirmTitle = confirmTitle;
      this.confirmMessage = confirmMessage;
   }

   public String getConfirmTitle() {
      return this.confirmTitle;
   }

   public String getConfirmMessage() {
      return this.confirmMessage;
   }
}

