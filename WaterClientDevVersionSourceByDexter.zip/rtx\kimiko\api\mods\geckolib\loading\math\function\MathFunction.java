package rtx.kimiko.api.mods.geckolib.loading.math.function;

import java.util.Set;
import java.util.StringJoiner;
import rtx.kimiko.api.mods.geckolib.animation.state.ControllerState;
import rtx.kimiko.api.mods.geckolib.loading.math.MathValue;
import rtx.kimiko.api.mods.geckolib.loading.math.value.Variable;

public abstract class MathFunction implements MathValue {
   private boolean mutable;
   private Set<Variable> usedVariables;
   private double cachedValue = Double.MIN_VALUE;

   protected MathFunction(MathValue... mathValueArray) {
      this.validate(mathValueArray);
      this.mutable = this.isMutable(mathValueArray);
      this.usedVariables = MathValue.collectUsedVariables(mathValueArray);
   }

   @Override
   public String toString() {
      MathValue[] mathValueArray = this.getArgs();
      StringJoiner stringJoiner = new StringJoiner(", ", "(", ")");

      for (MathValue mathValue : mathValueArray) {
         stringJoiner.add(mathValue.toString());
      }

      return this.getName() + stringJoiner;
   }

   public abstract String getName();

   @Override
   public final double get(ControllerState controllerState) {
      if (this.mutable) {
         return this.compute(controllerState);
      } else {
         if (this.cachedValue == Double.MIN_VALUE) {
            this.cachedValue = this.compute(controllerState);
         }

         return this.cachedValue;
      }
   }

   public void validate(MathValue... mathValueArray) throws IllegalArgumentException {
      int n = this.getMinArgs();
      if (mathValueArray.length < n) {
         throw new IllegalArgumentException(String.format("Function '%s' at least %s arguments. Only %s given!", this.getName(), n, mathValueArray.length));
      }
   }

   public abstract double compute(ControllerState var1);

   public abstract MathValue[] getArgs();

   @Override
   public Set<Variable> getUsedVariables() {
      return this.usedVariables;
   }

   public abstract int getMinArgs();

   @Override
   public final boolean isMutable() {
      return this.mutable;
   }

   public boolean isMutable(MathValue... mathValueArray) {
      for (MathValue mathValue : mathValueArray) {
         if (mathValue.isMutable()) {
            return true;
         }
      }

      return false;
   }

   public interface Factory<T extends MathFunction> {
      T create(MathValue... var1);
   }
}

