package rtx.kimiko.api.mods.geckolib.loading.json;

import com.google.common.base.Suppliers;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.util.Util;

public enum ModelFormatVersion {
   V_1_12_0("1.12.0"),
   V_1_14_0("1.14.0"),
   V_1_21_0("1.21.0");

   private static final Supplier<Map<String, ModelFormatVersion>> LOOKUP = Suppliers.memoize(() -> (Map)Util.make(new Object2ObjectOpenHashMap(), map -> {
      for (ModelFormatVersion modelFormatVersion : values()) {
         map.put(modelFormatVersion.serializedName, modelFormatVersion);
         map.put(modelFormatVersion.name(), modelFormatVersion);
      }
   }));
   private String serializedName;
   private boolean supported;
   private String errorMessage;

   private ModelFormatVersion(String serializedName, String errorMessage) {
      this.serializedName = serializedName;
      this.supported = errorMessage == null;
      this.errorMessage = errorMessage;
   }

   private ModelFormatVersion(String serializedName) {
      this(serializedName, null);
   }

   public static ModelFormatVersion match(String string) {
      return LOOKUP.get().get(string);
   }

   public boolean isSupported() {
      return this.supported;
   }

   public String getSerializedName() {
      return this.serializedName;
   }

   public String getErrorMessage() {
      return this.errorMessage;
   }

   private static ModelFormatVersion[] $values() {
      return new ModelFormatVersion[]{V_1_12_0, V_1_14_0, V_1_21_0};
   }
}

