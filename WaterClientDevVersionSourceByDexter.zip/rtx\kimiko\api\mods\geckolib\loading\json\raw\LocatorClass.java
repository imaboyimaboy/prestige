package rtx.kimiko.api.mods.geckolib.loading.json.raw;

import com.google.gson.JsonDeserializer;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import net.minecraft.util.JsonHelper;
import rtx.kimiko.api.mods.geckolib.util.JsonUtil;

public final class LocatorClass {
   private Boolean ignoreInheritedScale;
   private double[] offset;
   private double[] rotation;

   public LocatorClass(Boolean ignoreInheritedScale, double[] offset, double[] rotation) {
      this.ignoreInheritedScale = ignoreInheritedScale;
      this.offset = offset;
      this.rotation = rotation;
   }

   public static JsonDeserializer<LocatorClass> deserializer() throws JsonParseException {
      return (jsonElement, type, jsonDeserializationContext) -> {
         JsonObject jsonObject = jsonElement.getAsJsonObject();
         Boolean bl = JsonUtil.getOptionalBoolean(jsonObject, "ignore_inherited_scale");
         double[] dArray = JsonUtil.jsonArrayToDoubleArray(JsonHelper.getArray(jsonObject, "offset", null));
         double[] dArray2 = JsonUtil.jsonArrayToDoubleArray(JsonHelper.getArray(jsonObject, "rotation", null));
         return new LocatorClass(bl, dArray, dArray2);
      };
   }

   public Boolean ignoreInheritedScale() {
      return this.ignoreInheritedScale;
   }

   public double[] offset() {
      return this.offset;
   }

   public double[] rotation() {
      return this.rotation;
   }
}

