package com.water.setting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import net.minecraft.item.ItemStack;

public final class OptionMultiSelectSetting extends Setting<Set<String>> {
   private List<OptionEntry> options;

   public OptionMultiSelectSetting(String name, OptionEntry... options) {
      super(name, new LinkedHashSet<>());
      this.options = List.of(options);
   }

   public void setValue(Set<String> value) {
      LinkedHashSet<String> next = new LinkedHashSet<>();
      if (value != null) {
         for (String rawValue : value) {
            if (rawValue != null) {
               for (OptionEntry option : this.options) {
                  if (option.value().equalsIgnoreCase(rawValue)) {
                     next.add(option.value());
                     break;
                  }
               }
            }
         }
      }

      super.setValue(next);
   }

   public List<OptionEntry> getOptions() {
      return this.options;
   }

   public List<OptionEntry> filter(String query) {
      String normalized = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
      if (normalized.isEmpty()) {
         return this.options;
      } else {
         List<OptionEntry> filtered = new ArrayList<>();

         for (OptionEntry option : this.options) {
            String value = option.value() == null ? "" : option.value().toLowerCase(Locale.ROOT);
            String label = option.label() == null ? "" : option.label().toLowerCase(Locale.ROOT);
            if (value.contains(normalized) || label.contains(normalized)) {
               filtered.add(option);
            }
         }

         return filtered;
      }
   }

   public void toggle(String value) {
      if (value != null) {
         LinkedHashSet<String> next = new LinkedHashSet<>(this.getValue());
         String canonical = null;

         for (OptionEntry option : this.options) {
            if (option.value().equalsIgnoreCase(value)) {
               canonical = option.value();
               break;
            }
         }

         if (canonical != null) {
            if (!next.add(canonical)) {
               next.remove(canonical);
            }

            this.setValue(next);
         }
      }
   }

   public void clear() {
      if (!this.getValue().isEmpty()) {
         this.setValue(Collections.emptySet());
      }
   }

   public boolean contains(String value) {
      if (value == null) {
         return false;
      } else {
         for (String selected : this.getValue()) {
            if (selected.equalsIgnoreCase(value)) {
               return true;
            }
         }

         return false;
      }
   }

   public boolean isSelected(OptionEntry option) {
      return option != null && this.contains(option.value());
   }

   public int size() {
      return this.getValue().size();
   }

   public List<OptionEntry> getSelectedOptions() {
      List<OptionEntry> selected = new ArrayList<>();

      for (OptionEntry option : this.options) {
         if (this.contains(option.value())) {
            selected.add(option);
         }
      }

      return selected;
   }

   public String getSummary() {
      List<OptionEntry> selected = this.getSelectedOptions();
      if (selected.isEmpty()) {
         return "Choose";
      } else {
         OptionEntry first = selected.getFirst();
         int extra = selected.size() - 1;
         return extra > 0 ? first.label() + " +" + extra : first.label();
      }
   }

   public ItemStack getPreviewStack() {
      List<OptionEntry> selected = this.getSelectedOptions();
      return selected.isEmpty() ? ItemStack.EMPTY : selected.getFirst().getPreviewStack();
   }
}

