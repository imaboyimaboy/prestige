package com.water.module.modules.client;

import com.water.module.Category;
import com.water.module.Module;
import rtx.kimiko.utils.discord.rpc.DiscordRPCManager;

public final class Discordrpc extends Module {
   private static Discordrpc instance;

   public Discordrpc() {
      super("DiscordRPC", Category.CLIENT);
      instance = this;
   }

   public static boolean isActive() {
      return instance != null && instance.isEnabled();
   }

   @Override
   public void onEnable() {
      DiscordRPCManager.start();
   }

   @Override
   public void onDisable() {
      DiscordRPCManager.stop();
   }
}

