package rtx.kimiko.api.mods.chathads;

import net.minecraft.client.font.GlyphMetrics;

public class PaddedChatGlyph implements GlyphMetrics {
   public GlyphMetrics glyphInfo;

   public PaddedChatGlyph(GlyphMetrics glyphMetrics) {
      this.glyphInfo = glyphMetrics;
   }

   public float getAdvance() {
      return this.glyphInfo.getAdvance() + (ChatHeads.customHeadRendering ? 1.0F + 2.0F * ChatHeads.CONFIG.threeDeeNess() : 0.0F);
   }
}

