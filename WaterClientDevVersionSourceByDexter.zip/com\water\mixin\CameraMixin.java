package com.water.mixin;

import com.water.module.modules.misc.Freelook;
import com.water.module.modules.render.Freecam;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({Camera.class})
public abstract class CameraMixin {
   @Shadow
   protected abstract void setPos(double var1, double var3, double var5);

   @Shadow
   protected abstract void setRotation(float var1, float var2);

   @Shadow
   protected abstract float clipToSpace(float var1);

   @Shadow
   protected abstract void moveBy(float var1, float var2, float var3);

   @Inject(
      method = {"update"},
      at = {@At("TAIL")}
   )
   private void onUpdate(World area, Entity focusedEntity, boolean thirdPerson, boolean inverseView, float tickDelta, CallbackInfo ci) {
      if (Freecam.instance != null && Freecam.instance.isEnabled()) {
         double x = Freecam.instance.getInterpolatedX(tickDelta);
         double y = Freecam.instance.getInterpolatedY(tickDelta);
         double z = Freecam.instance.getInterpolatedZ(tickDelta);
         float yaw = Freecam.instance.getInterpolatedYaw(tickDelta);
         float pitch = Freecam.instance.getInterpolatedPitch(tickDelta);
         this.setPos(x, y, z);
         this.setRotation(yaw, pitch);
      } else {
         Freelook module = Freelook.instance;
         if (module != null && module.isCameraActive() && focusedEntity != null) {
            Vec3d eyePos = focusedEntity.getCameraPosVec(tickDelta);
            this.setRotation(module.getCameraYaw(), module.getCameraPitch());
            this.setPos(eyePos.x, eyePos.y, eyePos.z);
            float distance = module.getDistance();
            if (!module.shouldWallClip()) {
               distance = this.clipToSpace(distance);
            }

            this.moveBy(-distance, 0.0F, 0.0F);
         }
      }
   }

   @Inject(
      method = {"isThirdPerson"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onIsThirdPerson(CallbackInfoReturnable<Boolean> cir) {
      if (Freecam.instance != null && Freecam.instance.isEnabled()) {
         cir.setReturnValue(true);
      } else {
         if (Freelook.instance != null && Freelook.instance.isCameraActive()) {
            cir.setReturnValue(true);
         }
      }
   }
}

