package com.water.module.modules.render;

import com.water.gui.FakeSpawnerScreen;
import com.water.module.Category;
import com.water.module.Module;
import com.water.setting.BlocksSetting;
import com.water.setting.ModeSetting;
import com.water.setting.Setting;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.EntityType;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ChunkDeltaUpdateS2CPacket;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.world.chunk.WorldChunk;

public final class DevSpawnerVisuals extends Module {
   public static DevSpawnerVisuals INSTANCE;
   private static final long SEEN_TTL_MS = 900L;
   private static final int SCAN_RADIUS_CHUNKS = 64;
   private static final int CHUNKS_PER_TICK = 4;
   private static final int FAST_RESCAN_RADIUS_CHUNKS = 2;
   private static final Map<BlockPos, Long> renderedTargets = new ConcurrentHashMap<>();
   private final Map<BlockPos, BlockState> swappedStates = new ConcurrentHashMap<>();
   private final Map<BlockPos, MobSpawnerBlockEntity> fakeSpawners = new ConcurrentHashMap<>();
   private final Deque<Long> chunkQueue = new ArrayDeque<>();
   private final Set<Long> queuedChunks = new HashSet<>();
   private final Set<Long> scannedChunks = new HashSet<>();
   private boolean internalVisualWrite;
   private final BlocksSetting blocks = new BlocksSetting("Blocks", Blocks.DIAMOND_BLOCK);
   private final Setting<String> spawnerCount = new Setting<>("Spawner Count", "1");
   private final ModeSetting rightClick = new ModeSetting("Right Click", "Open Menu", "Open Menu", "Place Only");
   private final Setting<Boolean> inventory = new Setting<>("Inventory", true);
   private final Setting<Boolean> world = new Setting<>("World", true);
   private int lastCenterChunkX = Integer.MIN_VALUE;
   private int lastCenterChunkZ = Integer.MIN_VALUE;
   private long lastBlocksVersion = -1L;
   private int tickCounter;
   private ClientWorld lastWorld;
   private long boneGenerationStartedAt;

   public DevSpawnerVisuals() {
      super("Fake Spawner", Category.RENDER);
      this.addSetting(this.blocks);
      this.addSetting(this.spawnerCount);
      this.addSetting(this.rightClick);
      this.addSetting(this.inventory);
      this.addSetting(this.world);
      INSTANCE = this;
   }

   @Override
   public void onEnable() {
      this.boneGenerationStartedAt = System.currentTimeMillis();
      this.restoreSwappedStates();
      renderedTargets.clear();
      this.fakeSpawners.clear();
      this.resetScanState();
      this.lastWorld = mc.world;
      if (mc.world != null && mc.player != null && this.world.getValue()) {
         ChunkPos center = mc.player.getChunkPos();
         this.lastCenterChunkX = center.x;
         this.lastCenterChunkZ = center.z;
         this.lastBlocksVersion = this.blocks.getVersion();
         this.enqueueVisibleChunks(center, 64);
         this.enqueueNearPlayerForRescan(center);
      }
   }

   @Override
   public void onDisable() {
      this.boneGenerationStartedAt = 0L;
      this.restoreSwappedStates();
      renderedTargets.clear();
      this.resetScanState();
   }

   @Override
   public void onTick() {
      if (mc.world != null && mc.player != null) {
         if (mc.world != this.lastWorld) {
            this.restoreSwappedStates();
            renderedTargets.clear();
            this.fakeSpawners.clear();
            this.resetScanState();
            this.lastWorld = mc.world;
            if (this.world.getValue()) {
               ChunkPos center = mc.player.getChunkPos();
               this.lastCenterChunkX = center.x;
               this.lastCenterChunkZ = center.z;
               this.lastBlocksVersion = this.blocks.getVersion();
               this.enqueueNearPlayerForRescan(center);
               this.enqueueVisibleChunks(center, 64);
            }
         }

         if (!this.world.getValue()) {
            this.restoreSwappedStates();
            this.resetScanState();
         } else {
            this.tickFakeSpawners();
            this.syncClientWorldSpawners();
         }
      } else {
         this.restoreSwappedStates();
         this.lastWorld = null;
      }
   }

   @Override
   public void onPacketReceive(Packet<?> packet) {
      if (mc.world != null && mc.player != null && this.isEnabled() && this.world.getValue()) {
         if (packet instanceof BlockUpdateS2CPacket update) {
            this.trySwapAt(update.getPos());
            this.forceRescan(update.getPos());
         } else if (packet instanceof ChunkDeltaUpdateS2CPacket delta) {
            delta.visitUpdates((pos, state) -> {
               this.trySwapAt(pos);
               this.forceRescan(pos);
            });
         }
      }
   }

   @Override
   public boolean onPacketSend(Packet<?> packet) {
      if (mc.world != null && mc.player != null && this.isEnabled() && this.world.getValue()) {
         if (packet instanceof PlayerInteractBlockC2SPacket interact) {
            ItemStack held = interact.getHand() == Hand.OFF_HAND ? mc.player.getOffHandStack() : mc.player.getMainHandStack();
            if (shouldSpoofInventory(held)) {
               BlockPos placePos = interact.getBlockHitResult().getBlockPos().offset(interact.getBlockHitResult().getSide());
               this.trySwapAt(placePos, held);
               this.forceRescan(placePos);
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public static boolean shouldRenderAsSpawner(BlockState state) {
      DevSpawnerVisuals module = INSTANCE;
      if (module == null || !module.isEnabled() || !module.world.getValue()) {
         return false;
      } else {
         return state != null && !state.isAir() && !state.isOf(Blocks.SPAWNER) ? module.blocks.contains(state.getBlock()) : false;
      }
   }

   public static boolean shouldSpoofInventory(ItemStack stack) {
      DevSpawnerVisuals module = INSTANCE;
      if (module != null && module.isEnabled() && module.inventory.getValue()) {
         if (stack != null && !stack.isEmpty() && stack.getItem() instanceof BlockItem item) {
            Block block = item.getBlock();
            return block != Blocks.SPAWNER && module.blocks.contains(block);
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public static ItemStack spoofedStack(ItemStack original) {
      if (!shouldSpoofInventory(original)) {
         return original;
      } else {
         ItemStack stack = new ItemStack(Items.SPAWNER, 1);
         stack.set(DataComponentTypes.CUSTOM_NAME, Text.literal("Spawner"));
         return stack;
      }
   }

   public static BlockState visualStateForPlacement(BlockPos pos, BlockState state) {
      DevSpawnerVisuals module = INSTANCE;
      if (module == null || !module.isEnabled() || !module.world.getValue()) {
         return state;
      } else if (module.internalVisualWrite) {
         return state;
      } else if (state != null && !state.isAir() && !state.isOf(Blocks.SPAWNER)) {
         if (!module.blocks.contains(state.getBlock())) {
            return state;
         } else {
            BlockPos immutable = pos == null ? null : pos.toImmutable();
            if (immutable != null) {
               module.installVisualAt(immutable, state);
            }

            return Blocks.SPAWNER.getDefaultState();
         }
      } else {
         return state;
      }
   }

   public static void previewPlacement(ClientPlayerEntity player, Hand hand, BlockHitResult hitResult) {
      DevSpawnerVisuals module = INSTANCE;
      if (module != null && player != null && hitResult != null) {
         if (module.isEnabled() && module.world.getValue()) {
            ItemStack held = hand == Hand.OFF_HAND ? player.getOffHandStack() : player.getMainHandStack();
            if (shouldSpoofInventory(held)) {
               BlockPos placePos = hitResult.getBlockPos().offset(hitResult.getSide());
               module.trySwapAt(placePos, held);
               module.forceRescan(placePos);
            }
         }
      }
   }

   public static boolean openFakeSpawnerScreen(ClientPlayerEntity player, BlockHitResult hitResult) {
      DevSpawnerVisuals module = INSTANCE;
      if (module == null || player == null || hitResult == null) {
         return false;
      } else if (!module.isEnabled() || !module.world.getValue() || mc.world == null) {
         return false;
      } else if (!module.rightClick.check("Open Menu")) {
         return false;
      } else {
         BlockPos pos = hitResult.getBlockPos().toImmutable();
         BlockState state = mc.world.getBlockState(pos);
         if (!state.isOf(Blocks.SPAWNER)) {
            return false;
         } else {
            int count = module.getSpawnerCountValue();
            MinecraftClient.getInstance().execute(() -> MinecraftClient.getInstance().setScreen(new FakeSpawnerScreen(count)));
            return true;
         }
      }
   }

   private int getSpawnerCountValue() {
      try {
         String raw = this.spawnerCount.getValue() == null ? "1" : this.spawnerCount.getValue().trim();
         int value = Integer.parseInt(raw);
         return Math.max(1, Math.min(999, value));
      } catch (Throwable var3) {
         return 1;
      }
   }

   public static int getGeneratedBoneStacks() {
      DevSpawnerVisuals module = INSTANCE;
      if (module != null && module.isEnabled() && module.boneGenerationStartedAt > 0L) {
         long elapsed = Math.max(0L, System.currentTimeMillis() - module.boneGenerationStartedAt);
         return Math.min(45, (int)(elapsed / 60000L));
      } else {
         return 0;
      }
   }

   public static boolean ownsBlocksSetting(BlocksSetting setting) {
      DevSpawnerVisuals module = INSTANCE;
      return module != null && setting == module.blocks;
   }

   public static void markRendered(BlockPos pos) {
      if (pos != null) {
         renderedTargets.put(pos.toImmutable(), System.currentTimeMillis());
      }
   }

   @Override
   public void onRender(MatrixStack matrices, float tickDelta) {
      if (mc.world != null && mc.player != null) {
         this.purgeOldEntries();
      }
   }

   private void tickFakeSpawners() {
      for (MobSpawnerBlockEntity spawner : this.fakeSpawners.values()) {
         try {
            MobSpawnerBlockEntity.clientTick(mc.world, spawner.getPos(), Blocks.SPAWNER.getDefaultState(), spawner);
         } catch (Throwable var4) {
         }
      }
   }

   private void purgeOldEntries() {
      long cutoff = System.currentTimeMillis() - 900L;
      Iterator<Entry<BlockPos, Long>> it = renderedTargets.entrySet().iterator();

      while (it.hasNext()) {
         Entry<BlockPos, Long> entry = it.next();
         if (entry.getValue() < cutoff) {
            it.remove();
         }
      }
   }

   private void syncClientWorldSpawners() {
      ChunkPos center = mc.player.getChunkPos();
      if (center.x != this.lastCenterChunkX || center.z != this.lastCenterChunkZ || this.blocks.getVersion() != this.lastBlocksVersion) {
         if (this.blocks.getVersion() != this.lastBlocksVersion) {
            this.restoreSwappedStates();
         }

         this.lastCenterChunkX = center.x;
         this.lastCenterChunkZ = center.z;
         this.lastBlocksVersion = this.blocks.getVersion();
         this.enqueueVisibleChunks(center, 64);
      }

      this.tickCounter++;
      if (this.tickCounter % 5 == 0) {
         this.enqueueNearPlayerForRescan(center);
      }

      for (int i = 0; i < 4 && !this.chunkQueue.isEmpty(); i++) {
         long packed = this.chunkQueue.pollFirst();
         this.queuedChunks.remove(packed);
         if (this.scannedChunks.add(packed)) {
            int cx = ChunkPos.getPackedX(packed);
            int cz = ChunkPos.getPackedZ(packed);
            WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(cx, cz, false);
            if (chunk != null) {
               this.scanChunk(chunk);
            } else {
               this.scannedChunks.remove(packed);
               if (this.queuedChunks.add(packed)) {
                  this.chunkQueue.addLast(packed);
               }
            }
         }
      }

      this.keepRenderedTargetsFresh();
      this.pruneFarSwaps(center, 66);
   }

   private void enqueueVisibleChunks(ChunkPos center, int radius) {
      for (int r = 0; r <= radius; r++) {
         for (int dx = -r; dx <= r; dx++) {
            this.enqueueChunk(center.x + dx, center.z - r);
            this.enqueueChunk(center.x + dx, center.z + r);
         }

         for (int dz = -r + 1; dz <= r - 1; dz++) {
            this.enqueueChunk(center.x - r, center.z + dz);
            this.enqueueChunk(center.x + r, center.z + dz);
         }
      }
   }

   private void enqueueChunk(int cx, int cz) {
      long packed = ChunkPos.toLong(cx, cz);
      if (!this.scannedChunks.contains(packed) && this.queuedChunks.add(packed)) {
         this.chunkQueue.addLast(packed);
      }
   }

   private void forceRescan(BlockPos pos) {
      if (pos != null) {
         this.forceRescanChunk(new ChunkPos(pos));
      }
   }

   private void forceRescanChunk(ChunkPos chunkPos) {
      long packed = chunkPos.toLong();
      this.scannedChunks.remove(packed);
      if (this.queuedChunks.remove(packed)) {
         this.chunkQueue.remove(packed);
      }

      this.queuedChunks.add(packed);
      this.chunkQueue.addFirst(packed);
   }

   private boolean trySwapAt(BlockPos pos) {
      return this.trySwapAt(pos, null);
   }

   private boolean trySwapAt(BlockPos pos, ItemStack expectedStack) {
      if (mc.world != null && pos != null) {
         WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(pos.getX() >> 4, pos.getZ() >> 4, false);
         if (chunk == null) {
            return false;
         } else {
            BlockState state = chunk.getBlockState(pos);
            if (state.isOf(Blocks.SPAWNER)) {
               this.installSkeletonSpawner(chunk, pos.toImmutable());
               markRendered(pos);
               return true;
            } else {
               BlockState originalState = state;
               if (state.isAir() && expectedStack != null && expectedStack.getItem() instanceof BlockItem blockItem) {
                  originalState = blockItem.getBlock().getDefaultState();
               } else if (state.isAir() || !this.blocks.contains(state.getBlock())) {
                  return false;
               }

               return this.installVisualAt(pos.toImmutable(), originalState);
            }
         }
      } else {
         return false;
      }
   }

   private boolean installVisualAt(BlockPos pos, BlockState originalState) {
      if (mc.world != null && pos != null && originalState != null) {
         WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(pos.getX() >> 4, pos.getZ() >> 4, false);
         if (chunk == null) {
            return false;
         } else {
            BlockState before = chunk.getBlockState(pos);
            this.swappedStates.putIfAbsent(pos, originalState);

            try {
               this.internalVisualWrite = true;
               if (!before.isOf(Blocks.SPAWNER)) {
                  chunk.setBlockState(pos, Blocks.SPAWNER.getDefaultState(), 0);
               }
            } finally {
               this.internalVisualWrite = false;
            }

            this.installSkeletonSpawner(chunk, pos);
            mc.world.scheduleBlockRerenderIfNeeded(pos, before, Blocks.SPAWNER.getDefaultState());
            mc.world.updateListeners(pos, before, Blocks.SPAWNER.getDefaultState(), 3);
            markRendered(pos);
            return true;
         }
      } else {
         return false;
      }
   }

   private void enqueueNearPlayerForRescan(ChunkPos center) {
      for (int dx = -2; dx <= 2; dx++) {
         for (int dz = -2; dz <= 2; dz++) {
            this.forceRescanChunk(new ChunkPos(center.x + dx, center.z + dz));
         }
      }
   }

   private void scanChunk(WorldChunk chunk) {
      int startX = chunk.getPos().getStartX();
      int startZ = chunk.getPos().getStartZ();
      int bottom = mc.world.getBottomY();
      int top = bottom + mc.world.getHeight();
      Mutable pos = new Mutable();

      for (int y = bottom; y < top; y++) {
         for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
               pos.set(startX + x, y, startZ + z);
               BlockState state = chunk.getBlockState(pos);
               if (state.isOf(Blocks.SPAWNER) && this.swappedStates.containsKey(pos.toImmutable())) {
                  this.installSkeletonSpawner(chunk, pos.toImmutable());
                  markRendered(pos);
               } else if (this.blocks.contains(state.getBlock())) {
                  this.trySwapAt(pos);
               }
            }
         }
      }
   }

   private void installSkeletonSpawner(WorldChunk chunk, BlockPos pos) {
      if (!this.fakeSpawners.containsKey(pos)) {
         try {
            if (chunk.getBlockEntity(pos) instanceof MobSpawnerBlockEntity spawner) {
               spawner.setEntityType(EntityType.SKELETON, mc.world.getRandom());
               this.fakeSpawners.put(pos, spawner);
               return;
            }

            MobSpawnerBlockEntity spawner = new MobSpawnerBlockEntity(pos, Blocks.SPAWNER.getDefaultState());
            spawner.setEntityType(EntityType.SKELETON, mc.world.getRandom());
            chunk.setBlockEntity(spawner);
            mc.world.loadBlockEntity(spawner);
            this.fakeSpawners.put(pos, spawner);
         } catch (Throwable var5) {
         }
      }
   }

   private void keepRenderedTargetsFresh() {
      for (BlockPos pos : this.swappedStates.keySet()) {
         markRendered(pos);
      }
   }

   private void pruneFarSwaps(ChunkPos center, int radius) {
      for (BlockPos pos : new ArrayList<>(this.swappedStates.keySet())) {
         ChunkPos cp = new ChunkPos(pos);
         if (Math.abs(cp.x - center.x) > radius || Math.abs(cp.z - center.z) > radius) {
            this.restoreOne(pos);
         }
      }
   }

   private void resetScanState() {
      this.chunkQueue.clear();
      this.queuedChunks.clear();
      this.scannedChunks.clear();
      this.lastCenterChunkX = Integer.MIN_VALUE;
      this.lastCenterChunkZ = Integer.MIN_VALUE;
      this.lastBlocksVersion = -1L;
   }

   private void restoreSwappedStates() {
      for (BlockPos pos : new ArrayList<>(this.swappedStates.keySet())) {
         this.restoreOne(pos);
      }
   }

   private void restoreOne(BlockPos pos) {
      if (mc.world != null && pos != null) {
         BlockState original = this.swappedStates.remove(pos);
         this.fakeSpawners.remove(pos);
         if (original != null) {
            try {
               BlockState current = mc.world.getBlockState(pos);
               if (current.isOf(Blocks.SPAWNER)) {
                  mc.world.setBlockState(pos, original, 3);
                  mc.world.scheduleBlockRerenderIfNeeded(pos, current, original);
                  mc.world.updateListeners(pos, current, original, 3);
               }
            } catch (Throwable var4) {
            }
         }
      } else {
         this.swappedStates.remove(pos);
      }
   }
}

