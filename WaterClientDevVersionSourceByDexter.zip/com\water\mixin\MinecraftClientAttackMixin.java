package com.water.mixin;

import com.water.module.modules.combat.SpearSwap;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({MinecraftClient.class})
public class MinecraftClientAttackMixin {
   @Inject(
      method = {"handleInputEvents"},
      at = {@At("HEAD")},
      require = 0
   )
   private void water$preInput(CallbackInfo ci) {
      SpearSwap m = SpearSwap.INSTANCE;
      if (m != null && m.isEnabled()) {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc != null && mc.player != null && mc.options != null) {
            if (mc.currentScreen == null) {
               if (mc.options.attackKey.isPressed()) {
                  m.preAttack();
               } else {
                  m.noAttack();
               }
            }
         }
      }
   }
}

