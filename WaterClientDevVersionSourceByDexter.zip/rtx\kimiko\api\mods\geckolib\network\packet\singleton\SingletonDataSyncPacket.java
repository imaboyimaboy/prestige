package rtx.kimiko.api.mods.geckolib.network.packet.singleton;

import java.util.function.Consumer;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.network.packet.CustomPayload.Id;
import rtx.kimiko.api.mods.geckolib.GeckoLibConstants;
import rtx.kimiko.api.mods.geckolib.animatable.GeoAnimatable;
import rtx.kimiko.api.mods.geckolib.animatable.SingletonGeoAnimatable;
import rtx.kimiko.api.mods.geckolib.cache.SyncedSingletonAnimatableCache;
import rtx.kimiko.api.mods.geckolib.constant.dataticket.SerializableDataTicket;
import rtx.kimiko.api.mods.geckolib.network.packet.MultiloaderPacket;
import rtx.kimiko.api.mods.geckolib.util.ClientUtil;

public final class SingletonDataSyncPacket<D> implements MultiloaderPacket {
   private String syncableId;
   private long instanceId;
   private SerializableDataTicket<D> dataTicket;
   private D data;
   public static final Id<SingletonDataSyncPacket<?>> TYPE = new Id(GeckoLibConstants.id("singleton_data_sync"));
   public static final PacketCodec<RegistryByteBuf, SingletonDataSyncPacket<?>> CODEC = PacketCodec.ofStatic(
      (registryByteBuf, singletonDataSyncPacket) -> {
         SerializableDataTicket.STREAM_CODEC.encode(registryByteBuf, singletonDataSyncPacket.dataTicket);
         registryByteBuf.writeString(singletonDataSyncPacket.syncableId);
         registryByteBuf.writeVarLong(singletonDataSyncPacket.instanceId);
         ((PacketCodec<RegistryByteBuf, Object>)(Object)singletonDataSyncPacket.dataTicket.streamCodec()).encode(registryByteBuf, singletonDataSyncPacket.data);
      },
      registryByteBuf -> {
         SerializableDataTicket serializableDataTicket = (SerializableDataTicket)SerializableDataTicket.STREAM_CODEC.decode(registryByteBuf);
         return new SingletonDataSyncPacket<>(
            registryByteBuf.readString(), registryByteBuf.readVarLong(), serializableDataTicket, serializableDataTicket.streamCodec().decode(registryByteBuf)
         );
      }
   );

   public SingletonDataSyncPacket(String syncableId, long instanceId, SerializableDataTicket<D> dataTicket, D data) {
      this.syncableId = syncableId;
      this.instanceId = instanceId;
      this.dataTicket = dataTicket;
      this.data = data;
   }

   public Id<? extends CustomPayload> getId() {
      return TYPE;
   }

   @Override
   public void receiveMessage(PlayerEntity playerEntity, Consumer<Runnable> consumer) {
      consumer.accept(() -> {
         PlayerEntity clientPlayer = ClientUtil.getClientPlayer();
         GeoAnimatable geoAnimatable;
         if (clientPlayer != null && (geoAnimatable = SyncedSingletonAnimatableCache.getSyncedAnimatable(this.syncableId)) != null) {
            if (geoAnimatable instanceof SingletonGeoAnimatable singletonGeoAnimatable) {
               singletonGeoAnimatable.setAnimData(clientPlayer, this.instanceId, this.dataTicket, this.data);
            }
         }
      });
   }

   public String syncableId() {
      return this.syncableId;
   }

   public long instanceId() {
      return this.instanceId;
   }

   public SerializableDataTicket<D> dataTicket() {
      return this.dataTicket;
   }

   public D data() {
      return this.data;
   }
}

