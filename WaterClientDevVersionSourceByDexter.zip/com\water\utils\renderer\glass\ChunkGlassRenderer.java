package com.water.utils.renderer.glass;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;
import java.awt.Color;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.OptionalInt;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.SimpleFramebuffer;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import org.lwjgl.system.MemoryStack;

public final class ChunkGlassRenderer {
   private static RenderPipeline pipeline;
   private static GpuBuffer uniforms;
   private static SimpleFramebuffer scene;

   public static void draw(Matrix4f matrix, List<ChunkGlassRenderer.Pane> panes) {
      if (!panes.isEmpty()) {
         Framebuffer target = MinecraftClient.getInstance().getFramebuffer();
         if (target != null && target.getColorAttachment() != null) {
            if (pipeline == null) {
               pipeline = RenderPipeline.builder(new Snippet[0])
                  .withLocation(Identifier.of("water", "chunk_glass"))
                  .withVertexShader(Identifier.of("water", "chunk_glass"))
                  .withFragmentShader(Identifier.of("water", "chunk_glass"))
                  .withVertexFormat(VertexFormats.EMPTY, DrawMode.TRIANGLES)
                  .withUniform("Glass", UniformType.UNIFORM_BUFFER)
                  .withSampler("Scene")
                  .withBlend(BlendFunction.TRANSLUCENT)
                  .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                  .withDepthWrite(false)
                  .withCull(false)
                  .build();
               uniforms = RenderSystem.getDevice().createBuffer(() -> "Chunk glass uniforms", 136, 112L);
            }

            if (scene == null || scene.textureWidth != target.textureWidth || scene.textureHeight != target.textureHeight) {
               if (scene != null) {
                  scene.delete();
               }

               scene = new SimpleFramebuffer("Water chunk glass scene", target.textureWidth, target.textureHeight, false);
            }

            CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
            encoder.copyTextureToTexture(target.getColorAttachment(), scene.getColorAttachment(), 0, 0, 0, 0, 0, target.textureWidth, target.textureHeight);

            for (ChunkGlassRenderer.Pane pane : panes) {
               MemoryStack stack = MemoryStack.stackPush();

               try {
                  ByteBuffer data = stack.calloc(112);
                  matrix.get(0, data);
                  data.putFloat(64, (float)pane.doubleVal)
                     .putFloat(68, (float)pane.doubleVal3)
                     .putFloat(72, (float)pane.doubleVal4)
                     .putFloat(76, (float)pane.doubleVal5);
                  data.putFloat(80, pane.tint.getRed() / 255.0F)
                     .putFloat(84, pane.tint.getGreen() / 255.0F)
                     .putFloat(88, pane.tint.getBlue() / 255.0F)
                     .putFloat(92, pane.tint.getAlpha() / 255.0F);
                  data.putFloat(96, (float)pane.doubleVal2)
                     .putFloat(100, pane.intensity)
                     .putFloat(104, target.textureWidth)
                     .putFloat(108, target.textureHeight);
                  encoder.writeToBuffer(uniforms.slice(), data);
               } catch (Throwable var12) {
                  if (stack != null) {
                     try {
                        stack.close();
                     } catch (Throwable var10) {
                        var12.addSuppressed(var10);
                     }
                  }

                  throw var12;
               }

               if (stack != null) {
                  stack.close();
               }

               RenderPass pass = encoder.createRenderPass(() -> "Water refractive chunk glass", target.getColorAttachmentView(), OptionalInt.empty());

               try {
                  pass.setPipeline(pipeline);
                  pass.setUniform("Glass", uniforms);
                  pass.bindTexture("Scene", scene.getColorAttachmentView(), RenderSystem.getSamplerCache().get(FilterMode.LINEAR));
                  pass.draw(0, 6);
               } catch (Throwable var11) {
                  if (pass != null) {
                     try {
                        pass.close();
                     } catch (Throwable var9) {
                        var11.addSuppressed(var9);
                     }
                  }

                  throw var11;
               }

               if (pass != null) {
                  pass.close();
               }
            }
         }
      }
   }

   public static final class Pane {
      private double doubleVal;
      private double doubleVal2;
      private double doubleVal3;
      private double doubleVal4;
      private double doubleVal5;
      private Color tint;
      private float intensity;

      public Pane(double x1, double y, double z1, double x2, double z2, Color tint, float intensity) {
         this.doubleVal = x1;
         this.doubleVal2 = y;
         this.doubleVal3 = z1;
         this.doubleVal4 = x2;
         this.doubleVal5 = z2;
         this.tint = tint;
         this.intensity = intensity;
      }

      public double getDouble() {
         return this.doubleVal;
      }

      public double getDouble2() {
         return this.doubleVal2;
      }

      public double getDouble3() {
         return this.doubleVal3;
      }

      public double getDouble4() {
         return this.doubleVal4;
      }

      public double getDouble5() {
         return this.doubleVal5;
      }

      public Color tint() {
         return this.tint;
      }

      public float intensity() {
         return this.intensity;
      }
   }
}

