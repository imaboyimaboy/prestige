package com.water.gui;

import com.water.module.Category;
import com.water.module.Module;
import com.water.module.ModuleManager;
import com.water.module.modules.client.Hud;
import com.water.module.modules.client.SpotifyHud;
import com.water.module.modules.client.WaterPlus;
import com.water.utils.renderer.RenderUtil;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import org.lwjgl.glfw.GLFW;

public final class HudEditor {
   public static final HudEditor INSTANCE = new HudEditor();
   private static final int HANDLE_SIZE = 8;
   private String dragging = null;
   private int grabOffsetX;
   private int grabOffsetY;
   private boolean isDragging = false;
   private String resizing = null;
   private int resizeStartX;
   private int resizeStartY;
   private float resizeStartScale;
   public static volatile boolean isEditing = false;

   private HudEditor() {
   }

   private static float getFloat() {
      return Hud.getHudScale();
   }

   public boolean onMouseClick(double mouseX, double mouseY, int button) {
      if (button != 0 && button != 1) {
         return false;
      } else {
         for (Hud.HudElement el : Hud.HudElement.values()) {
            if (Hud.isElementVisible(el) && hasContent(el)) {
               int[] pos = handlePos(el);
               int w = handleW(el);
               int h = handleH(el);
               if (button == 0 && isOnResizeHandle(mouseX, mouseY, pos, w, h)) {
                  this.resizing = el.name();
                  this.resizeStartX = (int)mouseX;
                  this.resizeStartY = (int)mouseY;
                  this.resizeStartScale = elementScale(el);
                  this.isDragging = false;
                  this.dragging = null;
                  isEditing = true;
                  return true;
               }

               if (mouseX >= pos[0] && mouseX <= pos[0] + w && mouseY >= pos[1] && mouseY <= pos[1] + h) {
                  if (button == 1 && el == Hud.HudElement.SPOTIFY_HUD) {
                     MinecraftClient mc = MinecraftClient.getInstance();
                     if (mc != null) {
                        mc.setScreen(new SpotifyBrowserScreen(mc.currentScreen));
                     }

                     return true;
                  }

                  if (button == 0) {
                     this.dragging = el.name();
                     this.grabOffsetX = (int)(mouseX - pos[0]);
                     this.grabOffsetY = (int)(mouseY - pos[1]);
                     this.isDragging = true;
                     this.resizing = null;
                     isEditing = true;
                     return true;
                  }
               }
            }
         }

         if (button == 0) {
            this.dragging = null;
            this.isDragging = false;
            this.resizing = null;
         }

         return false;
      }
   }

   public boolean isDragging() {
      return this.dragging != null && this.isDragging || this.resizing != null;
   }

   public boolean isResizing() {
      return this.resizing != null;
   }

   public void onMouseDrag(double mouseX, double mouseY) {
      MinecraftClient mc = MinecraftClient.getInstance();
      boolean held = mc != null && mc.getWindow() != null && GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), 0) == 1;
      if (!held) {
         this.onMouseRelease();
      } else if (this.resizing != null) {
         try {
            Hud.HudElement el = Hud.HudElement.valueOf(this.resizing);
            double dx = mouseX - this.resizeStartX;
            double dy = mouseY - this.resizeStartY;
            double delta = dx + dy;
            float newScale = Math.max(0.5F, Math.min(3.0F, this.resizeStartScale + (float)(delta * 0.006F)));
            Hud.setElementScale(el, newScale);
         } catch (Exception var16) {
         }
      } else if (this.dragging != null && this.isDragging) {
         try {
            Hud.HudElement el = Hud.HudElement.valueOf(this.dragging);
            float s = Hud.getElementScale(el);
            if (el == Hud.HudElement.SPOTIFY_HUD) {
               int newLeft = (int)Math.round(mouseX - this.grabOffsetX);
               int newTop = (int)Math.round(mouseY - this.grabOffsetY);
               if (mc != null && mc.getWindow() != null) {
                  int sw = mc.getWindow().getScaledWidth();
                  int sh = mc.getWindow().getScaledHeight();
                  int cw = SpotifyHud.getCardW();
                  int ch = SpotifyHud.getCardH();
                  newLeft = Math.max(0, Math.min(newLeft, sw - cw));
                  newTop = Math.max(0, Math.min(newTop, sh - ch));
               }

               Hud.setElementPos(el, newLeft, newTop);
            } else {
               int newLeft = (int)Math.round((mouseX - this.grabOffsetX) / s);
               int newTop = (int)Math.round((mouseY - this.grabOffsetY) / s);
               if (mc != null && mc.getWindow() != null) {
                  int sw = mc.getWindow().getScaledWidth();
                  int sh = mc.getWindow().getScaledHeight();
                  int[] b = el == Hud.HudElement.MODULE_LIST ? Hud.getModuleListBounds() : Hud.getElementBounds(el);
                  int w = b[2];
                  int h = b[3];
                  if (w < 1) {
                     w = 1;
                  }

                  if (h < 1) {
                     h = 1;
                  }

                  if (sw > 0) {
                     newLeft = Math.max(0, Math.min(newLeft, (int)((sw - w * s) / s)));
                  }

                  if (sh > 0) {
                     newTop = Math.max(0, Math.min(newTop, (int)((sh - h * s) / s)));
                  }
               }

               if (el == Hud.HudElement.MODULE_LIST) {
                  int[] bx = Hud.getModuleListBounds();
                  Hud.setElementPos(el, newLeft + bx[2], newTop);
               } else {
                  Hud.setElementPos(el, newLeft, newTop);
               }
            }
         } catch (Exception var17) {
         }
      }
   }

   public void onMouseRelease() {
      this.dragging = null;
      this.isDragging = false;
      this.resizing = null;
      isEditing = false;
   }

   public boolean onMouseScroll(double mouseX, double mouseY, double amount) {
      if (amount == 0.0) {
         return false;
      } else if (!Hud.isElementVisible(Hud.HudElement.SPOTIFY_HUD)) {
         return false;
      } else {
         int[] pos = Hud.getElementPos(Hud.HudElement.SPOTIFY_HUD);
         int w = SpotifyHud.getCardW();
         int h = SpotifyHud.getCardH();
         if (!(mouseX < pos[0]) && !(mouseX > pos[0] + w) && !(mouseY < pos[1]) && !(mouseY > pos[1] + h)) {
            SpotifyHud.setScale(SpotifyHud.getScale() + (float)(amount * 0.08));
            return true;
         } else {
            return false;
         }
      }
   }

   public void render(DrawContext context, int mouseX, int mouseY) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc != null) {
         int accent = WaterPlus.getAccentARGB();
         float radius = WaterPlus.getGuiRoundness();

         for (Hud.HudElement el : Hud.HudElement.values()) {
            if (Hud.isElementVisible(el) && (hasContent(el) || el == Hud.HudElement.SPOTIFY_HUD)) {
               int[] pos = handlePos(el);
               int w = handleW(el);
               int h = handleH(el);
               if (el == Hud.HudElement.MODULE_LIST) {
                  int[] b = Hud.getModuleListBounds();
                  RenderUtil.drawOutline(context, (float)b[0], (float)b[1], (float)b[2], (float)b[3], 3.0F, 1.0F, accent, false);
               } else if (el == Hud.HudElement.POTION_EFFECTS) {
                  if (mc.player == null) {
                     continue;
                  }

                  TextRenderer tr = mc.textRenderer;
                  List<StatusEffectInstance> effects = new ArrayList<>(mc.player.getStatusEffects());
                  effects.sort(Comparator.comparingInt(e -> tr.getWidth(Hud.getEffectName(e))));
                  int[] elPos = Hud.getElementPos(Hud.HudElement.POTION_EFFECTS);
                  int by = elPos[1];

                  for (StatusEffectInstance eff : effects) {
                     String name = Hud.getEffectName(eff);
                     int bw = tr.getWidth(name) + 14;
                     RenderUtil.drawOutline(context, (float)elPos[0], (float)by, (float)bw, (float)14, 5.0F, 1.0F, accent, false);
                     by += 17;
                  }
               } else {
                  RenderUtil.drawOutline(context, (float)pos[0], (float)pos[1], (float)w, (float)h, radius, 1.0F, accent, false);
               }

               if (el != Hud.HudElement.MODULE_LIST && el != Hud.HudElement.POTION_EFFECTS) {
                  boolean hovering = isOnResizeHandle(mouseX, mouseY, pos, w, h);
                  boolean activeResize = this.resizing != null && this.resizing.equals(el.name());
                  int handleColor = activeResize ? accent : (hovering ? blendArgb(accent, -1, 0.3F) : accent & 16777215 | -1728053248);
                  float hx = pos[0] + w - 8;
                  float hy = pos[1] + h - 8;
                  RenderUtil.drawRoundedRect(context, hx, hy, 8.0F, 8.0F, Math.min(radius, 4.0F), handleColor, false);
                  int lineColor = -855638017;
                  context.fill((int)(hx + 2.0F), (int)(hy + 8.0F - 3.0F), (int)(hx + 8.0F - 1.0F), (int)(hy + 8.0F - 2.0F), lineColor);
                  context.fill((int)(hx + 2.0F), (int)(hy + 8.0F - 5.0F), (int)(hx + 8.0F - 3.0F), (int)(hy + 8.0F - 4.0F), lineColor);
               }
            }
         }
      }
   }

   private static boolean isOnResizeHandle(double mouseX, double mouseY, int[] pos, int w, int h) {
      return mouseX >= pos[0] + w - 8 && mouseX <= pos[0] + w && mouseY >= pos[1] + h - 8 && mouseY <= pos[1] + h;
   }

   private static float elementScale(Hud.HudElement el) {
      return Hud.getElementScale(el);
   }

   private static int blendArgb(int a, int b, float t) {
      int ar = a >> 16 & 0xFF;
      int ag = a >> 8 & 0xFF;
      int ab = a & 0xFF;
      int aa = a >> 24 & 0xFF;
      int br = b >> 16 & 0xFF;
      int bg = b >> 8 & 0xFF;
      int bb = b & 0xFF;
      int ba = b >> 24 & 0xFF;
      return (int)(aa + (ba - aa) * t) << 24 | (int)(ar + (br - ar) * t) << 16 | (int)(ag + (bg - ag) * t) << 8 | (int)(ab + (bb - ab) * t);
   }

   private static boolean hasContent(Hud.HudElement el) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null) {
         return false;
      } else {
         return switch (el) {
            case ARMOR -> {
               if (mc.player == null) {
                  yield false;
               } else {
                  EquipmentSlot[] slots = new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

                  for (EquipmentSlot sl : slots) {
                     ItemStack s = mc.player.getEquippedStack(sl);
                     if (s != null && !s.isEmpty()) {
                        yield true;
                     }
                  }

                  yield false;
               }
            }
            case POTION_EFFECTS -> mc.player == null ? false : !mc.player.getStatusEffects().isEmpty();
            case MODULE_LIST -> {
               for (Module m : ModuleManager.INSTANCE.getModules()) {
                  if (m.isEnabled() && m.getCategory() != Category.CLIENT) {
                     yield true;
                  }
               }

               yield false;
            }
            case KEYBINDS -> {
               for (Module m : ModuleManager.INSTANCE.getModules()) {
                  if (m.getBind() != 0) {
                     yield true;
                  }
               }

               yield false;
            }
            default -> true;
         };
      }
   }

   private static int[] handlePos(Hud.HudElement el) {
      float s = Hud.getElementScale(el);
      if (el == Hud.HudElement.MODULE_LIST) {
         int[] b = Hud.getModuleListBounds();
         return new int[]{b[0], b[1]};
      } else if (el == Hud.HudElement.SPOTIFY_HUD) {
         int[] p = Hud.getElementPos(el);
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc != null && mc.getWindow() != null) {
            int maxX = Math.max(0, mc.getWindow().getScaledWidth() - SpotifyHud.getCardW());
            int maxY = Math.max(0, mc.getWindow().getScaledHeight() - SpotifyHud.getCardH());
            return new int[]{Math.max(0, Math.min(p[0], maxX)), Math.max(0, Math.min(p[1], maxY))};
         } else {
            return new int[]{p[0], p[1]};
         }
      } else {
         int[] p = Hud.getElementPos(el);
         return new int[]{Math.round(p[0] * s), Math.round(p[1] * s)};
      }
   }

   private static int handleW(Hud.HudElement el) {
      float s = Hud.getElementScale(el);
      if (el == Hud.HudElement.MODULE_LIST) {
         return Math.round(Hud.getModuleListBounds()[2] * s);
      } else {
         return el == Hud.HudElement.SPOTIFY_HUD ? SpotifyHud.getCardW() : Math.round(Hud.getElementBounds(el)[2] * s);
      }
   }

   private static int handleH(Hud.HudElement el) {
      float s = Hud.getElementScale(el);
      if (el == Hud.HudElement.MODULE_LIST) {
         return Math.round(Hud.getModuleListBounds()[3] * s);
      } else {
         return el == Hud.HudElement.SPOTIFY_HUD ? SpotifyHud.getCardH() : Math.round(Hud.getElementBounds(el)[3] * s);
      }
   }

   static String _c4e6cf034db() {
      return "A";
   }
}

