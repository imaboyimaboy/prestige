package rtx.kimiko.api.chat.commands.impl;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;
import net.minecraft.util.Formatting;
import rtx.kimiko.api.chat.commands.Command;
import rtx.kimiko.api.chat.commands.helpers.CommandDividers;
import rtx.kimiko.api.chat.commands.helpers.TabCompleteHelper;
import rtx.kimiko.api.modules.Module;
import rtx.kimiko.api.modules.ModuleManager;
import rtx.kimiko.api.modules.impl.Interface.ClickGui;
import rtx.kimiko.utils.chat.ChatMessage;
import rtx.kimiko.utils.key.KeyBind;
import rtx.kimiko.utils.key.KeyHelper;

public final class BindCommand extends Command {
   public BindCommand() {
      super("bind", "Manage module binds", "b");
   }

   @Override
   public void execute(String string, String[] stringArray) {
      ModuleManager moduleManager = ModuleManager.get();
      if (stringArray.length == 0) {
         this.usage();
      } else {
         label56: {
            label57: {
               String var5 = stringArray[0].toLowerCase(Locale.ROOT);
               switch (var5.hashCode()) {
                  case -1335458389:
                     if (var5.equals("delete")) {
                        break label57;
                     }
                     break;
                  case -934610812:
                     if (var5.equals("remove")) {
                        break label57;
                     }
                     break;
                  case 96417:
                     if (var5.equals("add")) {
                        break label56;
                     }
                     break;
                  case 99339:
                     if (var5.equals("del")) {
                        break label57;
                     }
                     break;
                  case 113762:
                     if (var5.equals("set")) {
                        break label56;
                     }
                     break;
                  case 3322014:
                     if (var5.equals("list")) {
                        this.listBinds(moduleManager);
                        return;
                     }
                     break;
                  case 94746189:
                     if (var5.equals("clear")) {
                        this.clearAll(moduleManager);
                        return;
                     }
               }

               this.usage();
               return;
            }

            this.clearBind(moduleManager, stringArray);
            return;
         }

         this.setBind(moduleManager, stringArray);
      }
   }

   @Override
   public List<String> getLongDesc() {
      return Arrays.asList("Manages module key binds.", "Usage:", "> bind add <module> <key>", "> bind remove <module>", "> bind list", "> bind clear");
   }

   @Override
   public Stream<String> tabComplete(String string, String[] stringArray) {
      if (stringArray.length == 1) {
         return new TabCompleteHelper().append("add", "remove", "list", "clear").sortAlphabetically().filterPrefix(stringArray[0]).stream();
      } else if (stringArray.length >= 2 && isAddAction(stringArray[0])) {
         String string2 = joinArgs(stringArray, 1, stringArray.length - 1);
         if (stringArray.length >= 3 && ModuleManager.get().findByName(string2) != null) {
            return new TabCompleteHelper().append(KeyHelper.getAllKeyNames().toArray(new String[0])).filterPrefix(stringArray[stringArray.length - 1]).stream();
         } else {
            String string3 = joinArgs(stringArray, 1, stringArray.length);
            return new TabCompleteHelper()
               .append(ModuleManager.get().getAll().stream().map(Module::getName).toArray(String[]::new))
               .filterPrefix(string3)
               .stream();
         }
      } else if (stringArray.length >= 2 && isRemoveAction(stringArray[0])) {
         String string4 = joinArgs(stringArray, 1, stringArray.length);
         return new TabCompleteHelper()
            .append(
               ModuleManager.get()
                  .getAll()
                  .stream()
                  .filter(module -> module.getBind().isBound() && !(module instanceof ClickGui))
                  .map(Module::getName)
                  .toArray(String[]::new)
            )
            .filterPrefix(string4)
            .stream();
      } else {
         return Stream.empty();
      }
   }

   private static boolean isAddAction(String string) {
      return "add".equalsIgnoreCase(string) || "set".equalsIgnoreCase(string);
   }

   private static boolean isRemoveAction(String string) {
      return "remove".equalsIgnoreCase(string) || "del".equalsIgnoreCase(string) || "delete".equalsIgnoreCase(string);
   }

   private void setBind(ModuleManager moduleManager, String[] stringArray) {
      if (stringArray.length < 3) {
         this.logDirect("Usage: bind add <module> <key>", Formatting.RED);
      } else {
         String string = stringArray[stringArray.length - 1];
         String string2 = joinArgs(stringArray, 1, stringArray.length - 1);
         Module module = moduleManager.findByName(string2);
         if (module == null) {
            this.logDirect("Module not found: null", Formatting.RED);
         } else {
            int n = KeyHelper.getKeyCode(string);
            if (n != -1 && n >= 0) {
               module.setBind(KeyHelper.isMouse(n) ? KeyBind.mouse(n) : KeyBind.keyboard(n));
               this.logDirect(ChatMessage.accentGradient(module.getName() + " bound to " + module.getBind().getDisplayName()));
            } else {
               this.logDirect("Unknown key: null", Formatting.RED);
            }
         }
      }
   }

   private void listBinds(ModuleManager moduleManager) {
      List<Module> list = moduleManager.getAll()
         .stream()
         .filter(module -> module.getBind().isBound())
         .filter(module -> !(module instanceof ClickGui))
         .sorted(Comparator.comparing(Module::getName, String.CASE_INSENSITIVE_ORDER))
         .toList();
      if (list.isEmpty()) {
         this.logDirect("No module binds.", Formatting.RED);
      } else {
         List<String> list2 = list.stream().map(module -> module.getName() + " -> " + module.getBind().getDisplayName()).toList();
         int n = CommandDividers.calcLineCountForContent("BINDS", list2);
         this.logDirectRaw(CommandDividers.header("BINDS", n));

         for (Module module2 : list) {
            this.logDirect(module2.getName() + " -> " + module2.getBind().getDisplayName());
         }

         this.logDirectRaw(CommandDividers.footer("BINDS", n));
      }
   }

   private static String joinArgs(String[] stringArray, int n, int n2) {
      return n >= n2 ? "" : String.join(" ", Arrays.copyOfRange(stringArray, n, n2));
   }

   private void clearBind(ModuleManager moduleManager, String[] stringArray) {
      if (stringArray.length < 2) {
         this.logDirect("Usage: bind remove <module>", Formatting.RED);
      } else {
         String string = joinArgs(stringArray, 1, stringArray.length);
         Module module = moduleManager.findByName(string);
         if (module == null) {
            this.logDirect("Module not found: null", Formatting.RED);
         } else if (module instanceof ClickGui) {
            this.logDirect("ClickGui bind is protected and cannot be removed.", Formatting.RED);
         } else {
            module.setBind(KeyBind.NONE);
            this.logDirect(ChatMessage.accentGradient(module.getName() + " bind removed."));
         }
      }
   }

   private void clearAll(ModuleManager moduleManager) {
      for (Module module : moduleManager.getAll()) {
         if (!(module instanceof ClickGui)) {
            module.setBind(KeyBind.NONE);
         }
      }

      this.logDirect("All binds removed.");
   }
}

