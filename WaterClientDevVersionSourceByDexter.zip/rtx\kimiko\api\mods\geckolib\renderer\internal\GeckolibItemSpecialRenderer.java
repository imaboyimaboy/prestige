package rtx.kimiko.api.mods.geckolib.renderer.internal;

import com.mojang.serialization.MapCodec;
import java.util.function.Consumer;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.item.model.special.SpecialModelRenderer;
import net.minecraft.client.render.item.model.special.SpecialModelRenderer.BakeContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.Item;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.item.ItemStack;
import org.joml.Vector3fc;
import rtx.kimiko.api.mods.geckolib.animatable.GeoAnimatable;

public class GeckolibItemSpecialRenderer<T extends Item & GeoAnimatable> implements SpecialModelRenderer<Item> {
   private T makeCovariantItem(Item item) {
      return (T)(item instanceof GeoAnimatable ? item : null);
   }

   public Item getData(ItemStack stack) {
      return stack.getItem();
   }

   public void render(
      Item data, ItemDisplayContext displayContext, MatrixStack matrices, OrderedRenderCommandQueue queue, int light, int overlay, boolean glint, int seed
   ) {
   }

   public void collectVertices(Consumer<Vector3fc> consumer) {
   }

   public Object extractArgument(ItemStack itemStack, Object renderState, ItemDisplayContext displayContext, Object level, Object itemOwner) {
      return this.getData(itemStack);
   }

   public static class Unbaked implements net.minecraft.client.render.item.model.special.SpecialModelRenderer.Unbaked {
      public static final MapCodec<GeckolibItemSpecialRenderer.Unbaked> MAP_CODEC = MapCodec.unit(GeckolibItemSpecialRenderer.Unbaked::new);

      public SpecialModelRenderer<?> bake(BakeContext context) {
         return new GeckolibItemSpecialRenderer();
      }

      public MapCodec<? extends net.minecraft.client.render.item.model.special.SpecialModelRenderer.Unbaked> getCodec() {
         return MAP_CODEC;
      }
   }
}

