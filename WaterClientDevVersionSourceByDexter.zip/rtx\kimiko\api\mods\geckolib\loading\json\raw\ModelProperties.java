package rtx.kimiko.api.mods.geckolib.loading.json.raw;

import net.minecraft.util.math.Vec3d;
import rtx.kimiko.api.mods.geckolib.loading.definition.geometry.GeometryDescription;

public final class ModelProperties {
   private String identifier;
   private Float visibleBoundsWidth;
   private Float visibleBoundsHeight;
   private Vec3d visibleBoundsOffset;
   private int textureWidth;
   private int textureHeight;

   public ModelProperties(
      String identifier, Float visibleBoundsWidth, Float visibleBoundsHeight, Vec3d visibleBoundsOffset, int textureWidth, int textureHeight
   ) {
      this.identifier = identifier;
      this.visibleBoundsWidth = visibleBoundsWidth;
      this.visibleBoundsHeight = visibleBoundsHeight;
      this.visibleBoundsOffset = visibleBoundsOffset;
      this.textureWidth = textureWidth;
      this.textureHeight = textureHeight;
   }

   public static ModelProperties fromDescription(GeometryDescription geometryDescription) {
      return new ModelProperties(
         geometryDescription.identifier(),
         geometryDescription.visibleBoundsWidth(),
         geometryDescription.visibleBoundsHeight(),
         geometryDescription.visibleBoundsOffset(),
         geometryDescription.textureWidth(),
         geometryDescription.textureHeight()
      );
   }

   public String identifier() {
      return this.identifier;
   }

   public Float visibleBoundsWidth() {
      return this.visibleBoundsWidth;
   }

   public Float visibleBoundsHeight() {
      return this.visibleBoundsHeight;
   }

   public Vec3d visibleBoundsOffset() {
      return this.visibleBoundsOffset;
   }

   public int textureWidth() {
      return this.textureWidth;
   }

   public int textureHeight() {
      return this.textureHeight;
   }
}

