package rtx.kimiko.api.events.impl.inventory;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.screen.slot.Slot;
import rtx.kimiko.api.events.CancellableEvent;

public final class HandledScreenEvent extends CancellableEvent {
   private Slot slotHover;
   private DrawContext drawContext;
   private int intVal;
   private int intVal2;

   public HandledScreenEvent(Slot slotHover) {
      this.slotHover = slotHover;
      this.drawContext = null;
      this.intVal = 0;
      this.intVal2 = 0;
   }

   public HandledScreenEvent(DrawContext drawContext, int x, int y, Slot slotHover) {
      this.drawContext = drawContext;
      this.intVal = x;
      this.intVal2 = y;
      this.slotHover = slotHover;
   }

   public Slot getSlotHover() {
      return this.slotHover;
   }

   public DrawContext getDrawContext() {
      return this.drawContext;
   }

   public int getX() {
      return this.intVal;
   }

   public int getY() {
      return this.intVal2;
   }
}

