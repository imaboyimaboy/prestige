package rtx.kimiko.api.mods.acountswiher.ru.vidtu.ias.config;

public enum TextAlign {
   LEFT("ias.config.textAlign.left"),
   CENTER("ias.config.textAlign.center"),
   RIGHT("ias.config.textAlign.right");

   private String key;

   private TextAlign(String key) {
      this.key = key;
   }

   @Override
   public String toString() {
      return this.key;
   }

   private static TextAlign[] $values() {
      return new TextAlign[]{LEFT, CENTER, RIGHT};
   }
}

