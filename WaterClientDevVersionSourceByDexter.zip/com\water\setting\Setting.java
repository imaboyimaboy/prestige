package com.water.setting;

import com.water.module.ModuleManager;
import java.util.Objects;
import java.util.function.Supplier;

public class Setting<T> {
   private String name;
   private T defaultValue;
   private T value;
   private T min;
   private T max;
   private Supplier<Boolean> visibility = () -> true;

   public Setting(String name, T value) {
      this.name = name;
      this.value = value;
      this.defaultValue = value;
   }

   public Setting(String name, T value, T min, T max) {
      this.name = name;
      this.value = value;
      this.defaultValue = value;
      this.min = min;
      this.max = max;
   }

   public String getName() {
      return this.name;
   }

   public T getValue() {
      return this.value;
   }

   public T getDefaultValue() {
      return this.defaultValue;
   }

   public boolean matchesName(String settingName) {
      return this.name.equalsIgnoreCase(settingName);
   }

   public Setting<T> visibleWhen(Supplier<Boolean> visibility) {
      this.visibility = visibility == null ? () -> true : visibility;
      return this;
   }

   public boolean isVisible() {
      try {
         return this.visibility == null || this.visibility.get();
      } catch (Exception var2) {
         return true;
      }
   }

   public void setValue(T value) {
      if (!Objects.equals(this.value, value)) {
         this.value = value;
         ModuleManager.INSTANCE.onSettingChanged();
      }
   }

   public T getMin() {
      return this.min;
   }

   public T getMax() {
      return this.max;
   }

   static String _cf6ce2f6d19() {
      return "1";
   }
}

