package com.water.module.modules.misc;

import com.water.module.Category;
import com.water.module.Module;
import com.water.setting.ModeSetting;
import com.water.setting.Setting;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;

public final class AutoTPA extends Module {
   private final Setting<String> playerName = new Setting<>("Player", "Player");
   private final ModeSetting mode = new ModeSetting("Mode", "tpahere", "tpa", "tpahere");
   private final Setting<Float> minDelay = new Setting<>("Min Delay", 10.0F, 1.0F, 100.0F);
   private final Setting<Float> maxDelay = new Setting<>("Max Delay", 30.0F, 1.0F, 100.0F);
   private int delayCounter = 0;
   private int pauseCounter = 0;
   private boolean paused = false;
   private int lastHitTick = -1;
   private int lastAttackedTick = -1;
   private static final int PAUSE_TICKS = 400;

   public AutoTPA() {
      super("AutoTPA", Category.MISC);
      this.addSetting(this.playerName);
      this.addSetting(this.mode);
      this.addSetting(this.minDelay);
      this.addSetting(this.maxDelay);
   }

   @Override
   public void onEnable() {
      this.delayCounter = 0;
      this.pauseCounter = 0;
      this.paused = false;
      this.lastHitTick = mc.player != null ? mc.player.getLastAttackedTime() : -1;
      this.lastAttackedTick = mc.player != null ? mc.player.getLastAttackTime() : -1;
   }

   @Override
   public void onDisable() {
      this.delayCounter = 0;
      this.pauseCounter = 0;
      this.paused = false;
      this.lastHitTick = -1;
      this.lastAttackedTick = -1;
   }

   @Override
   public void onPacketReceive(Packet<?> packet) {
      if (mc.player != null) {
         if (packet instanceof EntityVelocityUpdateS2CPacket p && p.getEntityId() == mc.player.getId()) {
            this.triggerPause();
         }
      }
   }

   @Override
   public void onTick() {
      if (mc.player != null && mc.getNetworkHandler() != null) {
         int currentHitTick = mc.player.getLastAttackedTime();
         if (currentHitTick > 0 && currentHitTick != this.lastHitTick) {
            this.lastHitTick = currentHitTick;
            if (mc.player.getLastAttacker() instanceof PlayerEntity attacker && attacker != mc.player && !attacker.isSpectator()) {
               this.triggerPause();
            }
         }

         int currentAttackedTick = mc.player.getLastAttackTime();
         if (currentAttackedTick > 0 && currentAttackedTick != this.lastAttackedTick) {
            this.lastAttackedTick = currentAttackedTick;
            this.triggerPause();
         }

         if (this.paused) {
            if (this.pauseCounter > 0) {
               this.pauseCounter--;
               return;
            }

            this.paused = false;
            this.delayCounter = 0;
         }

         if (this.delayCounter > 0) {
            this.delayCounter--;
         } else {
            mc.getNetworkHandler().sendChatCommand(this.mode.getValue() + " " + this.playerName.getValue().trim());
            int min = this.minDelay.getValue().intValue();
            int max = Math.max(min, this.maxDelay.getValue().intValue());
            this.delayCounter = min + (int)(Math.random() * (max - min + 1));
         }
      }
   }

   private void triggerPause() {
      this.paused = true;
      this.pauseCounter = 400;
      this.delayCounter = 0;
   }
}

