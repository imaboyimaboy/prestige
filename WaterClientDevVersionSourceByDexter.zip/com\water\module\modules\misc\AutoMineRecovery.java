package com.water.module.modules.misc;

import java.util.List;
import java.util.function.Predicate;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.FallingBlockEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

final class AutoMineRecovery {
   private final MinecraftClient mc = MinecraftClient.getInstance();
   private int phase;
   private int ticks;
   private int savedSlot = -1;
   private int swappedSlot = -1;
   private int hotbarSlot;
   private boolean pearl;
   private boolean confirmed;
   private boolean failed;
   private BlockPos destination;
   private float yaw;
   private float pitch;
   private final AutoMineRotation rotation = new AutoMineRotation();
   private String failure = "No safe pearl path to the upper layer";

   String failure() {
      return this.failure;
   }

   boolean hasFailed() {
      return this.failed;
   }

   void pause() {
      if (this.mc.options != null) {
         this.mc.options.useKey.setPressed(false);
      }
   }

   void reset() {
      this.rotation.reset();
      this.pause();
      this.restore();
      this.phase = 0;
      this.ticks = 0;
      this.failed = false;
      this.destination = null;
   }

   void serverUpdate(BlockPos pos, BlockState state) {
      if (!this.pearl && this.phase != 0 && pos.equals(this.destination) && !state.isAir() && state.getFluidState().isEmpty()) {
         this.confirmed = true;
      }
   }

   boolean tick() {
      if (this.phase == 0) {
         return false;
      } else if (this.mc.player != null && this.mc.world != null) {
         this.mc.options.forwardKey.setPressed(false);
         this.mc.options.attackKey.setPressed(false);
         if (this.phase == 1) {
            if (!this.pearl) {
               Vec3d eye = this.mc.player.getEyePos();
               Vec3d aim = this.supportAim(this.destination, eye);
               if (aim == null) {
                  this.failure = "Support face changed; retrying placement";
                  this.failed = true;
                  this.resetInput();
                  return true;
               }

               Vec3d d = aim.subtract(eye);
               this.yaw = (float)Math.toDegrees(Math.atan2(d.z, d.x)) - 90.0F;
               this.pitch = (float)(-Math.toDegrees(Math.atan2(d.y, Math.hypot(d.x, d.z))));
            }

            float[] next = this.rotation.step(this.mc.player.getYaw(), this.mc.player.getPitch(), this.yaw, this.pitch);
            this.mc.player.setYaw(next[0]);
            this.mc.player.setPitch(next[1]);
            if (Math.abs(MathHelper.wrapDegrees(this.yaw - next[0])) > 0.5F || Math.abs(this.pitch - next[1]) > 0.5F) {
               this.ticks = 0;
               return true;
            } else if (++this.ticks < 3) {
               return true;
            } else {
               if (!this.pearl) {
                  HitResult hit = this.mc.player.raycast(this.mc.player.getBlockInteractionRange(), 1.0F, false);
                  if (!(hit instanceof BlockHitResult b) || hit.getType() != Type.BLOCK || !b.getBlockPos().offset(b.getSide()).equals(this.destination)) {
                     this.failure = "Support face is no longer reachable";
                     this.failed = true;
                     this.resetInput();
                     return true;
                  }
               }

               this.mc.options.useKey.setPressed(true);
               this.phase = 2;
               this.ticks = 0;
               return true;
            }
         } else if (this.phase == 2) {
            this.pause();
            this.phase = 3;
            this.ticks = 0;
            return true;
         } else {
            if (this.phase == 3) {
               this.ticks++;
               boolean landed = this.pearl
                  && this.mc.player.isOnGround()
                  && this.mc.player.getY() >= this.destination.getY() + 0.8
                  && this.mc.player.squaredDistanceTo(Vec3d.ofCenter(this.destination.up())) < 16.0;
               if (landed || !this.pearl && this.confirmed) {
                  this.restore();
                  this.phase = 0;
                  return true;
               }

               if (this.ticks > (this.pearl ? 180 : 60)) {
                  this.failure = this.pearl ? "Pearl did not return to the upper layer" : "Server did not confirm the support block";
                  this.failed = true;
                  this.resetInput();
               }
            }

            return true;
         }
      } else {
         return true;
      }
   }

   private void resetInput() {
      this.pause();
      this.restore();
      this.phase = 0;
   }

   private boolean equip(Predicate<ItemStack> predicate) {
      if (this.mc.player.currentScreenHandler != this.mc.player.playerScreenHandler) {
         return false;
      } else {
         this.savedSlot = this.mc.player.getInventory().getSelectedSlot();

         for (int i = 0; i < 36; i++) {
            if (predicate.test(this.mc.player.getInventory().getStack(i))) {
               if (i < 9) {
                  this.hotbarSlot = i;
               } else {
                  this.hotbarSlot = 8;
                  this.swappedSlot = i;
                  this.mc.interactionManager.clickSlot(this.mc.player.playerScreenHandler.syncId, i, this.hotbarSlot, SlotActionType.SWAP, this.mc.player);
               }

               this.mc.player.getInventory().setSelectedSlot(this.hotbarSlot);
               return true;
            }
         }

         this.savedSlot = -1;
         return false;
      }
   }

   private void restore() {
      if (this.mc.player == null) {
         this.savedSlot = this.swappedSlot = -1;
      } else {
         if (this.swappedSlot >= 0 && this.mc.interactionManager != null && this.mc.player.currentScreenHandler == this.mc.player.playerScreenHandler) {
            this.mc
               .interactionManager
               .clickSlot(this.mc.player.playerScreenHandler.syncId, this.swappedSlot, this.hotbarSlot, SlotActionType.SWAP, this.mc.player);
            this.swappedSlot = -1;
         }

         if (this.savedSlot >= 0) {
            this.mc.player.getInventory().setSelectedSlot(this.savedSlot);
            this.savedSlot = -1;
         }
      }
   }

   private boolean supportItem(ItemStack stack) {
      return stack.isOf(Items.COBBLESTONE)
         || stack.isOf(Items.DIRT)
         || stack.isOf(Items.STONE)
         || stack.isOf(Items.DEEPSLATE)
         || stack.isOf(Items.COBBLED_DEEPSLATE)
         || stack.isOf(Items.NETHERRACK);
   }

   boolean hasSupportBlocks() {
      for (int i = 0; i < 36; i++) {
         if (this.supportItem(this.mc.player.getInventory().getStack(i))) {
            return true;
         }
      }

      return false;
   }

   boolean placeSupport(BlockPos pos) {
      if (this.phase != 0) {
         return true;
      } else if (this.replaceableSupport(pos)
         && this.mc.world.getOtherEntities(null, new Box(pos), entity -> entity instanceof LivingEntity || entity instanceof FallingBlockEntity).isEmpty()) {
         Vec3d eye = this.mc.player.getEyePos();
         Vec3d aim = this.supportAim(pos, eye);
         if (aim == null) {
            return false;
         } else if (!this.equip(this::supportItem)) {
            this.failure = "No solid support blocks in inventory";
            return false;
         } else {
            Vec3d d = aim.subtract(eye);
            this.yaw = (float)Math.toDegrees(Math.atan2(d.z, d.x)) - 90.0F;
            this.pitch = (float)(-Math.toDegrees(Math.atan2(d.y, Math.hypot(d.x, d.z))));
            this.destination = pos.toImmutable();
            this.pearl = false;
            this.confirmed = false;
            this.phase = 1;
            this.ticks = 0;
            this.rotation.reset();
            return true;
         }
      } else {
         return false;
      }
   }

   boolean replaceableSupport(BlockPos pos) {
      BlockState state = this.mc.world.getBlockState(pos);
      return state.isAir() || state.isReplaceable() && !state.getFluidState().isEmpty();
   }

   boolean canPlaceSupportFrom(BlockPos pos, Vec3d eye) {
      return this.replaceableSupport(pos) && this.supportAim(pos, eye) != null;
   }

   private Vec3d supportAim(BlockPos pos, Vec3d eye) {
      for (Direction side : Direction.values()) {
         BlockPos neighbor = pos.offset(side.getOpposite());
         BlockState state = this.mc.world.getBlockState(neighbor);
         if (!state.isAir() && !state.hasBlockEntity() && state.isFullCube(this.mc.world, neighbor)) {
            Vec3d aim = Vec3d.ofCenter(neighbor).add(Vec3d.of(side.getVector()).multiply(0.5));
            if (!(eye.squaredDistanceTo(aim) > Math.pow(this.mc.player.getBlockInteractionRange(), 2.0))) {
               BlockHitResult hit = this.mc
                  .world
                  .raycast(
                     new RaycastContext(eye, aim.add(aim.subtract(eye).normalize().multiply(0.01)), ShapeType.OUTLINE, FluidHandling.NONE, this.mc.player)
                  );
               if (hit.getType() == Type.BLOCK && hit.getBlockPos().equals(neighbor) && hit.getSide() == side) {
                  return aim;
               }
            }
         }
      }

      return null;
   }

   boolean pearlTo(List<BlockPos> landings) {
      if (this.phase != 0) {
         return true;
      } else if (this.mc.player.getVelocity().horizontalLengthSquared() > 0.01) {
         return true;
      } else {
         Vec3d eye = this.mc.player.getEyePos().add(0.0, -0.1, 0.0);

         for (BlockPos landing : landings) {
            if (!this.mc.world.getBlockState(landing).isAir()) {
               Vec3d d = Vec3d.ofCenter(landing).subtract(eye);
               float direction = (float)Math.toDegrees(Math.atan2(d.z, d.x)) - 90.0F;

               for (int angle = -85; angle <= -5; angle += 2) {
                  double yr = Math.toRadians(direction);
                  double pr = Math.toRadians(angle);
                  Vec3d velocity = new Vec3d(-Math.sin(yr) * Math.cos(pr), -Math.sin(pr), Math.cos(yr) * Math.cos(pr)).multiply(1.5);
                  Vec3d point = eye;

                  for (int step = 0; step < 160; step++) {
                     Vec3d next = point.add(velocity);
                     BlockHitResult hit = this.mc.world.raycast(new RaycastContext(point, next, ShapeType.COLLIDER, FluidHandling.NONE, this.mc.player));
                     if (hit.getType() == Type.BLOCK) {
                        if (hit.getBlockPos().equals(landing) && hit.getSide() == Direction.UP) {
                           if (!this.equip(stack -> stack.isOf(Items.ENDER_PEARL))) {
                              this.failure = "No ender pearl in inventory";
                              return false;
                           }

                           this.destination = landing.toImmutable();
                           this.pearl = true;
                           this.confirmed = false;
                           this.yaw = direction;
                           this.pitch = angle;
                           this.phase = 1;
                           this.ticks = 0;
                           this.rotation.reset();
                           return true;
                        }
                        break;
                     }

                     point = next;
                     velocity = velocity.multiply(0.99).add(0.0, -0.03, 0.0);
                  }
               }
            }
         }

         this.failure = "No unobstructed pearl landing on the top layer";
         return false;
      }
   }
}

