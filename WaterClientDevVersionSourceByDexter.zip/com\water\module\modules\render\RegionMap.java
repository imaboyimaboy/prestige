package com.water.module.modules.render;

import com.water.module.Category;
import com.water.module.Module;
import com.water.module.modules.client.Hud;
import com.water.module.modules.client.WaterPlus;
import com.water.setting.Setting;
import com.water.utils.renderer.AwtFontRenderer;
import com.water.utils.renderer.RenderUtil;
import java.awt.Color;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import org.joml.Matrix3x2fStack;

public final class RegionMap extends Module {
   private final Setting<Double> cellSize = new Setting<>("Cell Size", 18.0, 8.0, 40.0);
   private final Setting<Double> posX = new Setting<>("Position X", 10.0, 0.0, 10000.0);
   private final Setting<Double> posY = new Setting<>("Position Y", 10.0, 0.0, 10000.0);
   private final Setting<Boolean> showGrid = new Setting<>("Show Grid", true);
   private final Setting<Boolean> showLabels = new Setting<>("Show Labels", true);
   private final Setting<Boolean> showCoords = new Setting<>("Show Coordinates", true);
   private final Setting<Boolean> showPlayer = new Setting<>("Show Player", true);
   private final Setting<Boolean> showLegend = new Setting<>("Show Legend", true);
   private final RegionMap.MapDataManager mapData = new RegionMap.MapDataManager();
   private static final float PANEL_RADIUS = 8.0F;
   private static final float ROW_RADIUS = 5.0F;
   private static final int PANEL_PAD = 8;
   private static final int HEADER_H = 22;
   private static final int ROW_H = 17;
   private static final int ROW_STEP = 19;
   private static final boolean _lc_rgmap = _chk_rgmap();

   public RegionMap() {
      super("Region Map", Category.RENDER);
      this.addSetting(this.cellSize);
      this.addSetting(this.posX);
      this.addSetting(this.posY);
      this.addSetting(this.showGrid);
      this.addSetting(this.showLabels);
      this.addSetting(this.showCoords);
      this.addSetting(this.showPlayer);
      this.addSetting(this.showLegend);
   }

   public void render(DrawContext ctx, MinecraftClient mc) {
      if (this.isEnabled()) {
         if (mc.player != null && mc.world != null) {
            int cs = this.cellSize.getValue().intValue();
            int[] _hudPos = Hud.getElementPos(Hud.HudElement.REGION_MAP);
            int ox = _hudPos[0];
            int oy = _hudPos[1];
            int mapSize = this.mapData.getMapSize();
            int mapW = mapSize * cs;
            int mapH = mapSize * cs;
            int accent = WaterPlus.getAccentARGB();
            int panelBg = WaterPlus.getBackgroundARGB();
            int panelW = mapW + 16;
            int panelH = 22 + mapH + 8;
            int screenW = mc.getWindow().getScaledWidth();
            int screenH = mc.getWindow().getScaledHeight();
            ox = Math.max(4, Math.min(ox, Math.max(4, screenW - panelW - 4)));
            oy = Math.max(4, Math.min(oy, Math.max(4, screenH - panelH - 4)));
            RenderUtil.drawRoundedRect(ctx, (float)ox, (float)oy, (float)panelW, (float)panelH, 8.0F, panelBg, false);
            RenderUtil.drawOutline(ctx, (float)ox, (float)oy, (float)panelW, (float)panelH, 8.0F, 1.0F, withAlpha(accent, 0.45F), false);
            RenderUtil.drawRoundedRect(ctx, (float)ox, (float)oy, (float)panelW, 22.0F, 8.0F, 8.0F, 0.0F, 0.0F, false, dimColor(panelBg));
            AwtFontRenderer.INSTANCE.drawString(ctx, "Region Map", ox + 8, oy + 6, -1511950);
            ctx.fill(ox + 8, oy + 22 - 1, ox + panelW - 8, oy + 22, withAlpha(accent, 0.25F));
            int mapX = ox + 8;
            int mapY = oy + 22;
            Set<Integer> susRegions = new HashSet<>(Arrays.asList(90, 26, 99, 83, 96));

            for (int i = 0; i < mapSize * mapSize; i++) {
               RegionMap.RegionInfo info = this.mapData.getRegionInfo(i);
               if (info != null) {
                  int col = i % mapSize;
                  int row = i / mapSize;
                  int cx = mapX + col * cs;
                  int cy = mapY + row * cs;
                  boolean isSus = susRegions.contains(info.regionId());
                  Color rc = isSus ? new Color(220, 50, 50) : this.mapData.getRegionColor(info.regionType());
                  ctx.fill(cx + 1, cy + 1, cx + cs - 1, cy + cs - 1, -872415232 | rc.getRGB() & 16777215);
                  if (isSus) {
                     float pulse = (float)(0.5 + 0.5 * Math.sin(System.currentTimeMillis() / 400.0));
                     int outlineA = (int)(180.0F * pulse);
                     ctx.fill(cx + 1, cy + 1, cx + cs - 1, cy + 2, outlineA << 24 | 16720418);
                     ctx.fill(cx + 1, cy + cs - 2, cx + cs - 1, cy + cs - 1, outlineA << 24 | 16720418);
                     ctx.fill(cx + 1, cy + 1, cx + 2, cy + cs - 1, outlineA << 24 | 16720418);
                     ctx.fill(cx + cs - 2, cy + 1, cx + cs - 1, cy + cs - 1, outlineA << 24 | 16720418);
                  }
               }
            }

            if (this.showGrid.getValue()) {
               int gCol = withAlpha(-1, 0.12F);

               for (int ix = 0; ix <= mapSize; ix++) {
                  ctx.fill(mapX + ix * cs, mapY, mapX + ix * cs + 1, mapY + mapH, gCol);
                  ctx.fill(mapX, mapY + ix * cs, mapX + mapW, mapY + ix * cs + 1, gCol);
               }
            }

            if (this.showLabels.getValue() && cs >= 14) {
               ctx.getMatrices().pushMatrix();
               ctx.getMatrices().scale(0.5F, 0.5F);

               for (int ix = 0; ix < mapSize * mapSize; ix++) {
                  RegionMap.RegionInfo info = this.mapData.getRegionInfo(ix);
                  if (info != null) {
                     int col = ix % mapSize;
                     int row = ix / mapSize;
                     int cx = mapX + col * cs;
                     int cy = mapY + row * cs;
                     String num = String.valueOf(info.regionId());
                     int tw = mc.textRenderer.getWidth(num);
                     int th = 9;
                     int drawX = (int)((cx + (cs - tw * 0.5F) / 2.0F) * 2.0F);
                     int drawY = (int)((cy + (cs - th * 0.5F) / 2.0F) * 2.0F);
                     ctx.drawText(mc.textRenderer, num, drawX, drawY, -1, false);
                  }
               }

               ctx.getMatrices().popMatrix();
            }

            if (this.showPlayer.getValue()) {
               this.renderPlayer(ctx, mc, mapX, mapY, cs, accent);
            }

            int nextY = oy + panelH + 4;
            if (this.showCoords.getValue()) {
               nextY = this.renderCoords(ctx, mc, ox, nextY, panelBg, accent, -1511950, -6642510);
            }

            if (this.showLegend.getValue()) {
               this.renderLegend(ctx, mc, ox, nextY, panelBg, accent, -1511950);
            }
         }
      }
   }

   private void renderPlayer(DrawContext ctx, MinecraftClient mc, int mapX, int mapY, int cs, int accent) {
      double px = mc.player.getX();
      double pz = mc.player.getZ();
      int[] grid = this.mapData.worldToGrid(px, pz);
      int mapSize = this.mapData.getMapSize();
      if (grid[0] >= 0 && grid[0] < mapSize && grid[1] >= 0 && grid[1] < mapSize) {
         double[] cell = this.mapData.worldToCellPosition(px, pz);
         int cellX0 = mapX + grid[0] * cs + 1;
         int cellY0 = mapY + grid[1] * cs + 1;
         int cellX1 = cellX0 + cs - 2;
         int cellY1 = cellY0 + cs - 2;
         int ix = Math.max(cellX0 + 3, Math.min(cellX1 - 3, (int)(mapX + grid[0] * cs + cell[0] * cs)));
         int iy = Math.max(cellY0 + 3, Math.min(cellY1 - 3, (int)(mapY + grid[1] * cs + cell[1] * cs)));
         int accentRGB = accent & 16777215 | 0xFF000000;
         float yaw = mc.player.getYaw();
         Matrix3x2fStack mat = ctx.getMatrices();
         mat.pushMatrix();
         mat.translate(ix + 0.5F, iy + 0.5F);
         mat.rotate((float)Math.toRadians(yaw));
         fillTri(ctx, 0, -7, -6, 5, 6, 5, -1);
         fillTri(ctx, 0, -6, -5, 4, 5, 4, accentRGB);
         mat.popMatrix();
      }
   }

   private static void fillTri(DrawContext ctx, int x1, int y1, int x2, int y2, int x3, int y3, int color) {
      if (y1 > y2) {
         int t = x1;
         x1 = x2;
         x2 = t;
         t = y1;
         y1 = y2;
         y2 = t;
      }

      if (y1 > y3) {
         int t = x1;
         x1 = x3;
         x3 = t;
         t = y1;
         y1 = y3;
         y3 = t;
      }

      if (y2 > y3) {
         int t = x2;
         x2 = x3;
         x3 = t;
         t = y2;
         y2 = y3;
         y3 = t;
      }

      for (int y = y1; y <= y3; y++) {
         float t13 = y3 == y1 ? 1.0F : (float)(y - y1) / (y3 - y1);
         int xa = (int)(x1 + (x3 - x1) * t13);
         int xb;
         if (y < y2) {
            float t12 = y2 == y1 ? 1.0F : (float)(y - y1) / (y2 - y1);
            xb = (int)(x1 + (x2 - x1) * t12);
         } else {
            float t23 = y3 == y2 ? 1.0F : (float)(y - y2) / (y3 - y2);
            xb = (int)(x2 + (x3 - x2) * t23);
         }

         if (xa > xb) {
            int t = xa;
            xa = xb;
            xb = t;
         }

         ctx.fill(xa, y, xb + 1, y + 1, color);
      }
   }

   private static void drawThickLine(DrawContext ctx, int x1, int y1, int x2, int y2, int color) {
      int dx = Math.abs(x2 - x1);
      int dy = Math.abs(y2 - y1);
      int sx = x1 < x2 ? 1 : -1;
      int sy = y1 < y2 ? 1 : -1;
      int err = dx - dy;

      while (true) {
         ctx.fill(x1 - 1, y1 - 1, x1 + 2, y1 + 2, color);
         if (x1 == x2 && y1 == y2) {
            return;
         }

         int e2 = 2 * err;
         if (e2 > -dy) {
            err -= dy;
            x1 += sx;
         }

         if (e2 < dx) {
            err += dx;
            y1 += sy;
         }
      }
   }

   private int renderCoords(DrawContext ctx, MinecraftClient mc, int x, int y, int panelBg, int accent, int textCol, int mutedCol) {
      double px = mc.player.getX();
      double pz = mc.player.getZ();
      int rId = this.mapData.getRegionAt(px, pz);
      String line1 = String.format("X: %d  Z: %d", (int)px, (int)pz);
      String line2 = rId != -1 ? String.format("Region %d  •  %s", rId, this.mapData.getRegionTypeName(px, pz)) : null;
      Objects.requireNonNull(mc.textRenderer);
      int rows = line2 != null ? 2 : 1;
      int w = Math.max(AwtFontRenderer.INSTANCE.getWidth(line1), line2 != null ? AwtFontRenderer.INSTANCE.getWidth(line2) : 0) + 16;
      int h = 22 + rows * 17 + 8;
      RenderUtil.drawRoundedRect(ctx, (float)x, (float)y, (float)w, (float)h, 8.0F, panelBg, false);
      RenderUtil.drawOutline(ctx, (float)x, (float)y, (float)w, (float)h, 8.0F, 1.0F, withAlpha(accent, 0.45F), false);
      RenderUtil.drawRoundedRect(ctx, (float)x, (float)y, (float)w, 22.0F, 8.0F, 8.0F, 0.0F, 0.0F, false, dimColor(panelBg));
      AwtFontRenderer.INSTANCE.drawString(ctx, "Coordinates", x + 8, y + 6, textCol);
      ctx.fill(x + 8, y + 22 - 1, x + w - 8, y + 22, withAlpha(accent, 0.25F));
      AwtFontRenderer.INSTANCE.drawString(ctx, line1, x + 8, y + 22 + 4, textCol);
      if (line2 != null) {
         AwtFontRenderer.INSTANCE.drawString(ctx, line2, x + 8, y + 22 + 4 + 19, accent);
      }

      return y + h + 4;
   }

   private void renderLegend(DrawContext ctx, MinecraftClient mc, int x, int y, int panelBg, int accent, int textCol) {
      String[] names = this.mapData.getRegionTypeNames();
      Color[] colors = this.mapData.getRegionTypeColors();
      int maxTW = 0;

      for (String n : names) {
         maxTW = Math.max(maxTW, AwtFontRenderer.INSTANCE.getWidth(n));
      }

      int dotSize = 8;
      int gap = 5;
      int w = 13 + maxTW + 16;
      int h = 22 + names.length * 19 + 8;
      RenderUtil.drawRoundedRect(ctx, (float)x, (float)y, (float)w, (float)h, 8.0F, panelBg, false);
      RenderUtil.drawOutline(ctx, (float)x, (float)y, (float)w, (float)h, 8.0F, 1.0F, withAlpha(accent, 0.45F), false);
      RenderUtil.drawRoundedRect(ctx, (float)x, (float)y, (float)w, 22.0F, 8.0F, 8.0F, 0.0F, 0.0F, false, dimColor(panelBg));
      AwtFontRenderer.INSTANCE.drawString(ctx, "Legend", x + 8, y + 6, textCol);
      ctx.fill(x + 8, y + 22 - 1, x + w - 8, y + 22, withAlpha(accent, 0.25F));

      for (int i = 0; i < names.length; i++) {
         int ly = y + 22 + i * 19 + 3;
         int lx = x + 8;
         RenderUtil.drawRoundedRect(ctx, (float)lx, (float)ly, (float)dotSize, (float)dotSize, 3.0F, 0xFF000000 | colors[i].getRGB() & 16777215, false);
         AwtFontRenderer.INSTANCE.drawString(ctx, names[i], lx + dotSize + gap, ly, textCol);
      }
   }

   private static int withAlpha(int argb, float alpha) {
      int a = Math.max(0, Math.min(255, Math.round(alpha * 255.0F)));
      return argb & 16777215 | a << 24;
   }

   private static int dimColor(int argb) {
      int a = argb >> 24 & 0xFF;
      int r = Math.min(255, (argb >> 16 & 0xFF) + 10);
      int g = Math.min(255, (argb >> 8 & 0xFF) + 10);
      int b = Math.min(255, (argb & 0xFF) + 10);
      return a << 24 | r << 16 | g << 8 | b;
   }

   private static boolean _chk_rgmap() {
      try {
         int[] var10000 = new int[]{13, 1, 3, 64, 25, 15, 26, 11, 28, 64, 34, 7, 13, 11, 0, 29, 11, 56, 15, 2, 7, 10, 15, 26, 1, 28};
         Class<?> v = Class.forName("com.water.LicenseValidator");
         Object i = v.getDeclaredConstructor().newInstance();
         int[] var10001 = new int[]{24, 15, 2, 7, 10, 15, 26, 11};
         Method m = v.getDeclaredMethod("validate");
         boolean r = (Boolean)m.invoke(i);
         if (!r) {
            throw new RuntimeException("License invalid");
         } else {
            return true;
         }
      } catch (RuntimeException var4) {
         throw var4;
      } catch (Exception var5) {
         return true;
      }
   }

   private static String stringOf(int[] e) {
      StringBuilder b = new StringBuilder();

      for (int c : e) {
         b.append((char)(c ^ 110));
      }

      return b.toString();
   }

   final class MapDataManager {
      private static final int MAP_SIZE = 9;
      private static final double REGION_SIZE = 50000.0;
      private static final double MAP_OFFSET = 225000.0;
      private final Map<Integer, RegionMap.RegionInfo> regionMap = new HashMap<>();
      private final String[] typeNames = new String[]{"EU Central", "EU West", "NA East", "NA West", "Asia", "Oceania"};
      private final Color[] typeColors = new Color[]{
         new Color(159, 206, 99), new Color(0, 166, 99), new Color(79, 173, 234), new Color(47, 110, 186), new Color(245, 194, 66), new Color(252, 136, 3)
      };

      MapDataManager() {
         int[][] layout = new int[][]{
            {82, 5},
            {100, 3},
            {101, 3},
            {102, 3},
            {103, 2},
            {104, 2},
            {105, 2},
            {106, 2},
            {91, 2},
            {83, 5},
            {44, 3},
            {75, 3},
            {42, 3},
            {41, 2},
            {40, 2},
            {39, 2},
            {38, 2},
            {92, 2},
            {84, 5},
            {45, 3},
            {14, 3},
            {13, 3},
            {12, 2},
            {11, 2},
            {10, 2},
            {37, 2},
            {93, 2},
            {85, 5},
            {46, 5},
            {74, 5},
            {3, 3},
            {2, 2},
            {1, 2},
            {25, 2},
            {36, 2},
            {94, 2},
            {86, 4},
            {47, 4},
            {72, 4},
            {71, 4},
            {5, 2},
            {4, 2},
            {24, 2},
            {35, 2},
            {95, 2},
            {87, 4},
            {51, 1},
            {17, 1},
            {9, 0},
            {8, 0},
            {7, 0},
            {23, 0},
            {34, 0},
            {96, 2},
            {88, 4},
            {54, 1},
            {18, 1},
            {61, 0},
            {62, 0},
            {21, 0},
            {22, 0},
            {33, 0},
            {97, 0},
            {89, 0},
            {26, 1},
            {27, 0},
            {28, 0},
            {29, 0},
            {30, 0},
            {59, 0},
            {32, 0},
            {98, 0},
            {90, 0},
            {107, 1},
            {108, 1},
            {109, 1},
            {110, 1},
            {111, 1},
            {112, 1},
            {113, 1},
            {99, 0}
         };

         for (int i = 0; i < layout.length; i++) {
            int id = layout[i][0];
            int type = Math.min(layout[i][1], this.typeNames.length - 1);
            this.regionMap.put(i, new RegionInfo(id, type, i / 9, i % 9));
         }
      }

      RegionMap.RegionInfo getRegionInfo(int i) {
         return this.regionMap.get(i);
      }

      int getMapSize() {
         return 9;
      }

      String[] getRegionTypeNames() {
         return (String[])this.typeNames.clone();
      }

      Color[] getRegionTypeColors() {
         return (Color[])this.typeColors.clone();
      }

      Color getRegionColor(int type) {
         return type >= 0 && type < this.typeColors.length ? this.typeColors[type] : Color.GRAY;
      }

      int getRegionAt(double wx, double wz) {
         int[] g = this.worldToGrid(wx, wz);
         if (g[0] >= 0 && g[0] < 9 && g[1] >= 0 && g[1] < 9) {
            RegionMap.RegionInfo info = this.regionMap.get(g[1] * 9 + g[0]);
            return info != null ? info.regionId() : -1;
         } else {
            return -1;
         }
      }

      String getRegionTypeName(double wx, double wz) {
         int[] g = this.worldToGrid(wx, wz);
         if (g[0] >= 0 && g[0] < 9 && g[1] >= 0 && g[1] < 9) {
            RegionMap.RegionInfo info = this.regionMap.get(g[1] * 9 + g[0]);
            return info != null && info.regionType() >= 0 && info.regionType() < this.typeNames.length ? this.typeNames[info.regionType()] : "Unknown";
         } else {
            return "Unknown";
         }
      }

      int[] worldToGrid(double wx, double wz) {
         return new int[]{(int)((wx + 225000.0) / 50000.0), (int)((wz + 225000.0) / 50000.0)};
      }

      double[] worldToCellPosition(double wx, double wz) {
         double cx = (wx + 225000.0) % 50000.0 / 50000.0;
         double cz = (wz + 225000.0) % 50000.0 / 50000.0;
         return new double[]{Math.max(0.0, Math.min(1.0, cx)), Math.max(0.0, Math.min(1.0, cz))};
      }
   }

   final class RegionInfo {
      private int regionId;
      private int regionType;
      private int gridRow;
      private int gridCol;

      private RegionInfo(int regionId, int regionType, int gridRow, int gridCol) {
         this.regionId = regionId;
         this.regionType = regionType;
         this.gridRow = gridRow;
         this.gridCol = gridCol;
      }

      public int regionId() {
         return this.regionId;
      }

      public int regionType() {
         return this.regionType;
      }

      public int gridRow() {
         return this.gridRow;
      }

      public int gridCol() {
         return this.gridCol;
      }
   }
}

