package rtx.kimiko.api.chat.commands;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import rtx.kimiko.utils.chat.ChatMessage;
import rtx.kimiko.utils.sounds.Sounds;

public abstract class Command {
   protected final MinecraftClient mc = MinecraftClient.getInstance();
   private String name;
   private String description;
   private List<String> aliases;

   protected Command(String string, String string2, String... stringArray) {
      this.name = string.toLowerCase();
      this.description = string2 == null ? "" : string2;
      this.aliases = Arrays.asList(stringArray == null ? new String[0] : stringArray);
   }

   public String getName() {
      return this.name;
   }

   public boolean matches(String string) {
      return this.name.equalsIgnoreCase(string) ? true : this.aliases.stream().anyMatch(string2 -> string2.equalsIgnoreCase(string));
   }

   public abstract void execute(String var1, String[] var2);

   public String getDescription() {
      return this.description;
   }

   public String getShortDesc() {
      return this.description;
   }

   public List<String> getAllNames() {
      ArrayList<String> arrayList = new ArrayList<>();
      arrayList.add(this.name);
      arrayList.addAll(this.aliases);
      return arrayList;
   }

   protected void logDirectRaw(Text text) {
      CommandManager.getInstance().sendRaw(text);
   }

   protected void logDirectRaw(MutableText mutableText) {
      CommandManager.getInstance().sendRaw(mutableText);
   }

   public List<String> getLongDesc() {
      return Arrays.asList(this.description, "", "Usage:", "> " + this.name + " - " + this.description);
   }

   public Stream<String> tabComplete(String string, String[] stringArray) {
      return Stream.empty();
   }

   public boolean hiddenFromHelp() {
      return false;
   }

   public List<String> getAliases() {
      return this.aliases;
   }

   protected void logDirect(String string) {
      ChatMessage.brandmessage(string);
   }

   protected void logDirect(MutableText mutableText) {
      ChatMessage.brandmessage(mutableText);
   }

   protected void logDirect(Text text) {
      ChatMessage.brandmessage(text);
   }

   protected void logDirect(String string, Formatting formatting) {
      CommandManager commandManager = CommandManager.getInstance();
      if (commandManager == null) {
         ChatMessage.brandmessage(string);
      } else {
         if (formatting == Formatting.RED) {
            commandManager.sendError(string);
         } else if (formatting == Formatting.GREEN) {
            commandManager.sendSuccess(string);
         } else {
            commandManager.sendMessage(string);
         }
      }
   }

   protected void usage() {
      Sounds.play("command_error");
      CommandManager commandManager = CommandManager.getInstance();
      String string = commandManager != null ? commandManager.getPrefix() : ".";
      String string2 = string + "help " + this.name;
      MutableText mutableText = Text.literal("Команда " + this.name + " использована некорректно. Используйте ")
         .formatted(Formatting.RED)
         .append(Text.literal(string2).formatted(new Formatting[]{Formatting.RED, Formatting.BOLD}))
         .append(Text.literal(" чтобы посмотреть список команд.").formatted(Formatting.RED));
      if (commandManager == null) {
         ChatMessage.brandmessage(mutableText);
      } else {
         commandManager.sendRaw(ChatMessage.brandmessage().copy().append(Text.literal("→ ").formatted(Formatting.DARK_GRAY)).append(mutableText));
      }
   }
}

