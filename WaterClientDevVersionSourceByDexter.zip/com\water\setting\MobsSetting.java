package com.water.setting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

public final class MobsSetting extends Setting<Set<EntityType<?>>> {
   private final List<EntityType<?>> availableMobs = Registries.ENTITY_TYPE
      .stream()
      .filter(MobsSetting::isLivingMob)
      .sorted(Comparator.comparing(this::getDisplayName, String.CASE_INSENSITIVE_ORDER))
      .toList();
   private long version;

   public MobsSetting(String name, EntityType<?>... defaults) {
      super(name, createDefaultSet(defaults));
   }

   private static boolean isLivingMob(EntityType<?> type) {
      SpawnGroup g = type.getSpawnGroup();
      return g == SpawnGroup.MONSTER
         || g == SpawnGroup.CREATURE
         || g == SpawnGroup.AMBIENT
         || g == SpawnGroup.AXOLOTLS
         || g == SpawnGroup.UNDERGROUND_WATER_CREATURE
         || g == SpawnGroup.WATER_CREATURE
         || g == SpawnGroup.WATER_AMBIENT;
   }

   public void setValue(Set<EntityType<?>> value) {
      LinkedHashSet<EntityType<?>> next = new LinkedHashSet<>();
      if (value != null) {
         for (EntityType<?> t : value) {
            if (t != null) {
               next.add(t);
            }
         }
      }

      super.setValue(next);
      this.version++;
   }

   public boolean contains(EntityType<?> type) {
      return type != null && this.getValue().contains(type);
   }

   public void toggle(EntityType<?> type) {
      if (type != null) {
         LinkedHashSet<EntityType<?>> next = new LinkedHashSet<>(this.getValue());
         if (!next.add(type)) {
            next.remove(type);
         }

         this.setValue(next);
      }
   }

   public void clear() {
      if (!this.getValue().isEmpty()) {
         this.setValue(Collections.emptySet());
      }
   }

   public int size() {
      return this.getValue().size();
   }

   public long getVersion() {
      return this.version;
   }

   public Set<EntityType<?>> getSelectedMobs() {
      return Collections.unmodifiableSet(this.getValue());
   }

   public List<EntityType<?>> getAvailableMobs() {
      return this.availableMobs;
   }

   public List<EntityType<?>> filter(String query) {
      String normalized = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
      if (normalized.isEmpty()) {
         return this.availableMobs;
      } else {
         List<EntityType<?>> filtered = new ArrayList<>();

         for (EntityType<?> t : this.availableMobs) {
            String displayName = this.getDisplayName(t).toLowerCase(Locale.ROOT);
            Identifier id = Registries.ENTITY_TYPE.getId(t);
            String idString = id == null ? "" : id.toString().toLowerCase(Locale.ROOT);
            if (displayName.contains(normalized) || idString.contains(normalized)) {
               filtered.add(t);
            }
         }

         return filtered;
      }
   }

   public String getDisplayName(EntityType<?> type) {
      try {
         return type.getName().getString();
      } catch (Exception var4) {
         Identifier id = Registries.ENTITY_TYPE.getId(type);
         return id == null ? "Mob" : id.getPath();
      }
   }

   public String getSummary() {
      if (this.getValue().isEmpty()) {
         return "None";
      } else {
         EntityType<?> first = this.getValue().iterator().next();
         String firstName = this.getDisplayName(first);
         int extra = this.getValue().size() - 1;
         return extra > 0 ? firstName + " +" + extra : firstName;
      }
   }

   private static Set<EntityType<?>> createDefaultSet(EntityType<?>... defaults) {
      LinkedHashSet<EntityType<?>> selected = new LinkedHashSet<>();
      if (defaults != null) {
         Collections.addAll(selected, defaults);
         selected.remove(null);
      }

      return selected;
   }
}

