package com.water.gui;

import com.water.module.Module;
import com.water.module.ModuleManager;
import com.water.module.modules.client.WaterPlus;
import com.water.module.modules.misc.ChatMacro;
import com.water.setting.Setting;
import com.water.utils.KeyNameUtil;
import com.water.utils.renderer.AwtFontRenderer;
import com.water.utils.renderer.RenderUtil;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class ChatMacroScreen extends Screen {
   private static final int intVal = 420;
   private static final int intVal2 = 380;
   private static final int PAD = 12;
   private static final int HEAD_H = 36;
   private static final int FOOT_H = 44;
   private static final int ROW_H = 52;
   private static final int ROW_GAP = 6;
   private static final int KEY_W = 72;
   private static final float floatVal = 14.0F;
   private static final float R_SM = 8.0F;
   private static final float R_XS = 5.0F;
   private static final int C_BD_IN = -15327184;
   private static final int C_TEXT = -2234128;
   private static final int C_TEXT_DIM = -7824982;
   private static final int C_MUTED = -12298906;
   private static final int C_RED = -2539435;
   private static final int C_GREEN = -11751558;
   private static final int C_WHITE_10 = 285212671;
   private static final int C_GRID_BG = -16183270;
   private Screen parent;
   private ChatMacro module;
   private long openNs = 0L;
   private final List<String[]> macros = new ArrayList<>();
   private int editingText = -1;
   private int listeningKey = -1;
   private int scroll = 0;
   private int intVal3;
   private int intVal4;

   public ChatMacroScreen(Screen parent) {
      super(Text.literal(""));
      this.parent = parent;
      this.module = this.find();
      this.load();
   }

   private ChatMacro find() {
      for (Module m : ModuleManager.INSTANCE.getModules()) {
         if (m instanceof ChatMacro cm) {
            return cm;
         }
      }

      return null;
   }

   private void load() {
      this.macros.clear();
      if (this.module == null) {
         this.macros.add(new String[]{"", "0"});
      } else {
         List<Setting<?>> s = this.module.getSettings();

         for (int i = 0; i + 1 < s.size(); i += 2) {
            String text = (String)s.get(i).getValue();
            String key = String.valueOf(s.get(i + 1).getValue());
            this.macros.add(new String[]{text, key});
         }

         if (this.macros.isEmpty()) {
            this.macros.add(new String[]{"", "0"});
         }
      }
   }

   private void save() {
      if (this.module != null) {
         List<Setting<?>> s = this.module.getSettings();

         for (int i = 0; i < this.macros.size() && i * 2 + 1 < s.size(); i++) {
            ((Setting<String>)s.get(i * 2)).setValue(this.macros.get(i)[0]);
            ((Setting<Integer>)s.get(i * 2 + 1)).setValue(this.parseKey(this.macros.get(i)[1]));
         }
      }
   }

   private int parseKey(String s) {
      try {
         return Integer.parseInt(s);
      } catch (Exception var3) {
         return 0;
      }
   }

   private int getInt3() {
      return (this.width - 420) / 2;
   }

   private int getInt4() {
      return (this.height - 380) / 2;
   }

   private int listY() {
      return this.getInt4() + 36 + 12;
   }

   private int listH() {
      return 276;
   }

   private int visRows() {
      return Math.max(1, this.listH() / 58);
   }

   private int maxScroll() {
      return Math.max(0, this.macros.size() - this.visRows());
   }

   protected void init() {
      this.intVal3 = this.getInt3();
      this.intVal4 = this.getInt4();
   }

   public void renderBackground(DrawContext ctx, int mx, int my, float d) {
   }

   public void render(DrawContext ctx, int mx, int my, float delta) {
      if (this.openNs == 0L) {
         this.openNs = System.nanoTime();
      }

      float a = this.easeOut(Math.min(1.0F, (float)(System.nanoTime() - this.openNs) / 1.E8F));
      this.intVal3 = this.getInt3();
      this.intVal4 = this.getInt4();
      int acc = WaterPlus.getAccentARGB();
      int panBg = WaterPlus.getBackgroundARGB();
      float r = WaterPlus.getGuiRoundness();
      float rSm = Math.max(5.0F, r * 0.6F);
      float rXs = Math.max(4.0F, r * 0.4F);
      float gl = WaterPlus.getGlassIntensity();
      RenderUtil.drawRoundedRect(
         ctx,
         (float)(this.intVal3 - 4),
         (float)(this.intVal4 - 4),
         428.0F,
         388.0F,
         r + 3.0F,
         this.intOf2(intOf3(acc & 16777215, (int)(25.0F * a)), 1.0F),
         false
      );
      RenderUtil.drawRoundedRect(ctx, (float)this.intVal3, (float)this.intVal4, 420.0F, 380.0F, r, this.intOf2(panBg, a), false);
      if (gl > 0.01F) {
         RenderUtil.drawRoundedRect(
            ctx, (float)(this.intVal3 + 1), (float)(this.intVal4 + 1), 418.0F, 38.0F, r, this.intOf2(intOf3(16777215, (int)(15.0F * gl)), a), false
         );
         RenderUtil.drawOutline(
            ctx, (float)this.intVal3, (float)this.intVal4, 420.0F, 380.0F, r, 1.0F, this.intOf2(intOf3(16777215, (int)(50.0F * gl)), a), false
         );
      } else {
         RenderUtil.drawOutline(ctx, (float)this.intVal3, (float)this.intVal4, 420.0F, 380.0F, r, 1.0F, this.intOf2(acc & 16777215 | 1426063360, a), false);
      }

      RenderUtil.drawRoundedRect(ctx, (float)this.intVal3, (float)this.intVal4, 420.0F, 36.0F, r, r, 0.0F, 0.0F, false, this.intOf2(intOf3(0, 55), a));
      ctx.fill(this.intVal3, this.intVal4 + 36, this.intVal3 + 420, this.intVal4 + 36 + 1, this.intOf2(-15327184, a));
      RenderUtil.drawRoundedRect(ctx, (float)this.intVal3, (float)(this.intVal4 + 8), 3.0F, 20.0F, 1.5F, this.intOf2(acc, a), false);
      this.run(ctx, "CHAT MACROS", this.intVal3 + 12 + 8, this.intVal4 + 11, this.intOf2(-2234128, a));
      this.run(ctx, this.macros.size() + " macros", this.intVal3 + 12 + 8, this.intVal4 + 23, this.intOf2(-7824982, a));
      int addX = this.intVal3 + 420 - 12 - 60;
      int addY = this.intVal4 + 9;
      boolean addHov = this.hov(mx, my, addX, addY, 60, 18);
      RenderUtil.drawRoundedRect(
         ctx, (float)addX, (float)addY, 60.0F, 18.0F, 9.0F, this.intOf2(addHov ? acc & 16777215 | 855638016 : acc & 16777215 | 402653184, a), false
      );
      RenderUtil.drawOutline(ctx, (float)addX, (float)addY, 60.0F, 18.0F, 9.0F, 1.0F, this.intOf2(acc & 16777215 | 1711276032, a), false);
      this.run(ctx, "+ ADD", addX + (60 - this.intOf("+ ADD")) / 2, addY + 4, this.intOf2(acc, a));
      int lx = this.intVal3 + 12;
      int ly = this.listY();
      int rows = this.visRows();
      this.scroll = Math.max(0, Math.min(this.maxScroll(), this.scroll));

      for (int i = 0; i < rows; i++) {
         int idx = i + this.scroll;
         if (idx >= this.macros.size()) {
            break;
         }

         String[] m = this.macros.get(idx);
         String text = m[0];
         int key = this.parseKey(m[1]);
         int ry = ly + i * 58;
         boolean isEditText = this.editingText == idx;
         boolean isListenKey = this.listeningKey == idx;
         boolean anyActive = isEditText || isListenKey;
         int rowBg = anyActive ? acc & 16777215 | 369098752 : this.intOf2(419430399, a);
         int rowBd = anyActive ? acc & 16777215 | 1426063360 : this.intOf2(587202559, a);
         RenderUtil.drawRoundedRect(ctx, (float)lx, (float)ry, (float)396, 52.0F, rSm, rowBg, false);
         RenderUtil.drawOutline(ctx, (float)lx, (float)ry, (float)396, 52.0F, rSm, 1.0F, rowBd, false);
         this.run(ctx, "#" + (idx + 1), lx + 8, ry + 6, this.intOf2(anyActive ? acc : -12298906, a));
         int tfX = lx + 8;
         boolean cursor = isEditText && System.currentTimeMillis() / 500L % 2L == 0L;
         String disp = text + (cursor ? "|" : "");
         if (disp.isEmpty()) {
            disp = isEditText ? "|" : "";
         }

         int fieldBg = isEditText ? this.intOf2(acc & 16777215 | 570425344, a) : this.intOf2(570425344, a);
         int fieldBd = isEditText ? this.intOf2(acc & 16777215 | -2013265920, a) : this.intOf2(872415231, a);
         RenderUtil.drawRoundedRect(ctx, (float)(tfX - 2), (float)(ry + 22), (float)280, 20.0F, rXs, fieldBg, false);
         RenderUtil.drawOutline(ctx, (float)(tfX - 2), (float)(ry + 22), (float)280, 20.0F, rXs, 1.0F, fieldBd, false);
         int textCol = text.isEmpty() && !isEditText ? this.intOf2(-12298906, a) : this.intOf2(-2234128, a);
         String textDisp = text.isEmpty() && !isEditText ? "Type message or /command..." : disp;
         int maxTW = 272;
         if (this.intOf(textDisp) > 272) {
            while (textDisp.length() > 1 && this.intOf(textDisp) > 272) {
               textDisp = textDisp.substring(1);
            }
         }

         this.run(ctx, textDisp, tfX + 2, ry + 28, textCol);
         int kx = lx + 396 - 72 - 34;
         int ky = ry + 22;
         boolean kHov = this.hov(mx, my, kx, ky, 72, 20);
         String kLabel = isListenKey ? "PRESS..." : (key <= 0 ? "NO KEY" : this.keyName(key));
         int kBg = isListenKey
            ? this.intOf2(acc & 16777215 | 1140850688, a)
            : (key > 0 ? this.intOf2(acc & 16777215 | 671088640, a) : this.intOf2(570425344, a));
         int kBd = isListenKey ? this.intOf2(acc, a) : (key > 0 ? this.intOf2(acc & 16777215 | 1996488704, a) : this.intOf2(872415231, a));
         RenderUtil.drawRoundedRect(ctx, (float)kx, (float)ky, 72.0F, 20.0F, rXs, kBg, false);
         RenderUtil.drawOutline(ctx, (float)kx, (float)ky, 72.0F, 20.0F, rXs, 1.0F, kBd, false);
         this.run(ctx, kLabel, kx + (72 - this.intOf(kLabel)) / 2, ky + 5, this.intOf2(isListenKey ? acc : (key > 0 ? -2234128 : -12298906), a));
         int delX = lx + 396 - 26;
         int delY = ry + 22;
         boolean delHov = this.hov(mx, my, delX, delY, 20, 20);
         RenderUtil.drawRoundedRect(ctx, (float)delX, (float)delY, 20.0F, 20.0F, rXs, this.intOf2(delHov ? 1155088469 : 584663125, a), false);
         RenderUtil.drawOutline(ctx, (float)delX, (float)delY, 20.0F, 20.0F, rXs, 1.0F, this.intOf2(-2539435, a * (delHov ? 0.9F : 0.4F)), false);
         this.run(ctx, "✕", delX + (20 - this.intOf("✕")) / 2, delY + 5, this.intOf2(-2539435, a));
      }

      if (this.macros.isEmpty()) {
         this.run(
            ctx,
            "No macros yet — click + ADD",
            this.intVal3 + 210 - this.intOf("No macros yet — click + ADD") / 2,
            this.intVal4 + 190 - 5,
            this.intOf2(-12298906, a)
         );
      }

      if (this.macros.size() > this.visRows()) {
         int sbX = this.intVal3 + 420 - 8;
         int sbY = this.listY();
         int sbH = this.listH();
         float frac = (float)this.visRows() / this.macros.size();
         float th = Math.max(20.0F, sbH * frac);
         float ty = sbY + (sbH - th) * ((float)this.scroll / Math.max(1, this.maxScroll()));
         RenderUtil.drawRoundedRect(ctx, (float)sbX, (float)sbY, 4.0F, (float)sbH, 2.0F, this.intOf2(-15327184, a), false);
         RenderUtil.drawRoundedRect(ctx, (float)sbX, (float)((int)ty), 4.0F, (float)((int)th), 2.0F, this.intOf2(acc & 16777215 | -1442840576, a), false);
      }

      int fy = this.intVal4 + 380 - 44;
      ctx.fill(this.intVal3, fy, this.intVal3 + 420, fy + 1, this.intOf2(-15327184, a));
      RenderUtil.drawRoundedRect(ctx, (float)this.intVal3, (float)fy, 420.0F, 44.0F, 0.0F, 0.0F, r, r, false, this.intOf2(intOf3(0, 50), a));
      int btnY = fy + 11;
      int canX = this.intVal3 + 12;
      boolean canH = this.hov(mx, my, canX, btnY, 80, 22);
      RenderUtil.drawRoundedRect(ctx, (float)canX, (float)btnY, 80.0F, 22.0F, 11.0F, this.intOf2(canH ? 419430399 : 150994943, a), false);
      RenderUtil.drawOutline(ctx, (float)canX, (float)btnY, 80.0F, 22.0F, 11.0F, 1.0F, this.intOf2(-15327184, a), false);
      this.run(ctx, "CANCEL", canX + (80 - this.intOf("CANCEL")) / 2, btnY + 7, this.intOf2(-7824982, a));
      int savX = this.intVal3 + 420 - 12 - 80;
      boolean savH = this.hov(mx, my, savX, btnY, 80, 22);
      RenderUtil.drawRoundedRect(ctx, (float)savX, (float)btnY, 80.0F, 22.0F, 11.0F, this.intOf2(savH ? acc : acc & 16777215 | 570425344, a), false);
      RenderUtil.drawOutline(ctx, (float)savX, (float)btnY, 80.0F, 22.0F, 11.0F, 1.5F, this.intOf2(acc, a * (savH ? 1.0F : 0.5F)), false);
      this.run(ctx, "SAVE", savX + (80 - this.intOf("SAVE")) / 2, btnY + 7, this.intOf2(savH ? -16777216 : acc, a));
      super.render(ctx, mx, my, delta);
   }

   public boolean mouseClicked(Click click, boolean bl) {
      int mx = (int)click.x();
      int my = (int)click.y();
      int btn = click.button();
      this.intVal3 = this.getInt3();
      this.intVal4 = this.getInt4();
      int acc = WaterPlus.getAccentARGB();
      int fy = this.intVal4 + 380 - 44;
      int btnY = fy + 11;
      if (this.hov(mx, my, this.intVal3 + 12, btnY, 80, 22)) {
         MinecraftClient.getInstance().setScreen(this.parent);
         return true;
      } else if (this.hov(mx, my, this.intVal3 + 420 - 12 - 80, btnY, 80, 22)) {
         this.save();
         MinecraftClient.getInstance().setScreen(this.parent);
         return true;
      } else {
         int addX = this.intVal3 + 420 - 12 - 60;
         int addY = this.intVal4 + 9;
         if (this.hov(mx, my, addX, addY, 60, 18)) {
            this.macros.add(new String[]{"", "0"});
            this.scroll = this.maxScroll();
            this.editingText = this.macros.size() - 1;
            this.listeningKey = -1;
            return true;
         } else {
            this.editingText = -1;
            this.listeningKey = -1;
            int lx = this.intVal3 + 12;
            int ly = this.listY();
            int rows = this.visRows();

            for (int i = 0; i < rows; i++) {
               int idx = i + this.scroll;
               if (idx >= this.macros.size()) {
                  break;
               }

               int ry = ly + i * 58;
               int tfX = lx + 8;
               if (this.hov(mx, my, tfX - 2, ry + 22, 280, 20)) {
                  this.editingText = idx;
                  return true;
               }

               int kx = lx + 396 - 72 - 34;
               int ky = ry + 22;
               if (this.hov(mx, my, kx, ky, 72, 20)) {
                  this.listeningKey = idx;
                  return true;
               }

               int delX = lx + 396 - 26;
               int delY = ry + 22;
               if (this.hov(mx, my, delX, delY, 20, 20)) {
                  this.macros.remove(idx);
                  this.scroll = Math.max(0, Math.min(this.maxScroll(), this.scroll));
                  this.editingText = -1;
                  this.listeningKey = -1;
                  return true;
               }
            }

            return super.mouseClicked(click, bl);
         }
      }
   }

   public boolean mouseScrolled(double mx, double my, double hAmt, double vAmt) {
      this.scroll = Math.max(0, Math.min(this.maxScroll(), this.scroll + (vAmt > 0.0 ? -1 : 1)));
      return true;
   }

   public boolean keyPressed(KeyInput input) {
      int kc = input.getKeycode();
      if (this.listeningKey < 0) {
         if (this.editingText >= 0) {
            if (kc != 256 && kc != 257) {
               if (kc == 259 && !this.macros.get(this.editingText)[0].isEmpty()) {
                  String t = this.macros.get(this.editingText)[0];
                  this.macros.get(this.editingText)[0] = t.substring(0, t.length() - 1);
                  return true;
               } else if (input.isPaste()) {
                  String[] var10000 = this.macros.get(this.editingText);
                  var10000[0] = var10000[0] + MinecraftClient.getInstance().keyboard.getClipboard().trim();
                  return true;
               } else {
                  return true;
               }
            } else {
               this.editingText = -1;
               return true;
            }
         } else if (kc == 256) {
            MinecraftClient.getInstance().setScreen(this.parent);
            return true;
         } else {
            return super.keyPressed(input);
         }
      } else {
         if (kc != 256 && kc != 259) {
            this.macros.get(this.listeningKey)[1] = String.valueOf(kc);
         } else {
            this.macros.get(this.listeningKey)[1] = "0";
         }

         this.listeningKey = -1;
         return true;
      }
   }

   public boolean charTyped(CharInput input) {
      if (this.editingText >= 0) {
         String[] var10000 = this.macros.get(this.editingText);
         var10000[0] = var10000[0] + input.asString();
         return true;
      } else {
         return super.charTyped(input);
      }
   }

   private void run(DrawContext ctx, String s, int x, int y, int c) {
      AwtFontRenderer.INSTANCE.drawString(ctx, s, x, y, c);
   }

   private int intOf(String s) {
      return AwtFontRenderer.INSTANCE.getWidth(s);
   }

   private int intOf2(int c, float a) {
      return Math.max(0, Math.min(255, (int)((c >> 24 & 0xFF) * a))) << 24 | c & 16777215;
   }

   private static int intOf3(int rgb, int alpha) {
      return Math.max(0, Math.min(255, alpha)) << 24 | rgb & 16777215;
   }

   private float easeOut(float t) {
      return 1.0F - (float)Math.pow(1.0F - Math.min(1.0F, t), 3.0);
   }

   private boolean hov(int mx, int my, int x, int y, int w, int h) {
      return mx >= x && mx <= x + w && my >= y && my <= y + h;
   }

   private String keyName(int kc) {
      if (kc <= 0) {
         return "None";
      } else {
         String n = GLFW.glfwGetKeyName(kc, 0);
         return n != null && !n.isBlank() ? n.toUpperCase() : KeyNameUtil.displayName(kc);
      }
   }

   public boolean shouldPause() {
      return false;
   }
}

