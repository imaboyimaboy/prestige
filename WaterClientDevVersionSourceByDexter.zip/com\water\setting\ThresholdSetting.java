package com.water.setting;

import com.water.module.ModuleManager;

public final class ThresholdSetting extends Setting<Integer> {
   private boolean enabled;

   public ThresholdSetting(String name, boolean enabled, int value, int min, int max) {
      super(name, value, min, max);
      this.enabled = enabled;
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public void setEnabled(boolean enabled) {
      if (this.enabled != enabled) {
         this.enabled = enabled;
         ModuleManager.INSTANCE.onSettingChanged();
      }
   }

   public String serialize() {
      return this.enabled + "|" + this.getValue();
   }

   public void deserialize(String serialized) {
      if (serialized != null && !serialized.isBlank()) {
         String[] parts = serialized.split("\\|", 2);

         try {
            if (parts.length == 2) {
               this.enabled = Boolean.parseBoolean(parts[0]);
               this.setValue(Integer.parseInt(parts[1]));
               return;
            }

            this.setValue(Integer.parseInt(serialized));
         } catch (NumberFormatException var4) {
         }
      }
   }
}

