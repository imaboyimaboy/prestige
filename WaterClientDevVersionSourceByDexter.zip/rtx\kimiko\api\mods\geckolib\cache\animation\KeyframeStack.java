package rtx.kimiko.api.mods.geckolib.cache.animation;

import it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet;
import java.util.List;
import java.util.Set;
import rtx.kimiko.api.mods.geckolib.loading.math.value.Variable;

public final class KeyframeStack {
   private Keyframe[] xKeyframes;
   private Keyframe[] yKeyframes;
   private Keyframe[] zKeyframes;
   public static final KeyframeStack EMPTY = new KeyframeStack(new Keyframe[0], new Keyframe[0], new Keyframe[0]);

   public KeyframeStack(List<Keyframe> list, List<Keyframe> list2, List<Keyframe> list3) {
      this(list.toArray(new Keyframe[0]), list2.toArray(new Keyframe[0]), list3.toArray(new Keyframe[0]));
   }

   public KeyframeStack(Keyframe[] xKeyframes, Keyframe[] yKeyframes, Keyframe[] zKeyframes) {
      this.xKeyframes = xKeyframes;
      this.yKeyframes = yKeyframes;
      this.zKeyframes = zKeyframes;
   }

   public double getTotalKeyframeTime() {
      double d = 0.0;
      if (this.xKeyframes.length > 0) {
         Keyframe keyframe = this.xKeyframes[this.xKeyframes.length - 1];
         d = Math.max(d, keyframe.startTime() + keyframe.length());
      }

      if (this.yKeyframes.length > 0) {
         Keyframe keyframe = this.yKeyframes[this.yKeyframes.length - 1];
         d = Math.max(d, keyframe.startTime() + keyframe.length());
      }

      if (this.zKeyframes.length > 0) {
         Keyframe keyframe = this.zKeyframes[this.zKeyframes.length - 1];
         d = Math.max(d, keyframe.startTime() + keyframe.length());
      }

      return d;
   }

   public Set<Variable> getUsedVariables() {
      ReferenceOpenHashSet referenceOpenHashSet = new ReferenceOpenHashSet();

      for (Keyframe keyframe : this.xKeyframes) {
         referenceOpenHashSet.addAll(keyframe.getUsedVariables());
      }

      for (Keyframe keyframe : this.yKeyframes) {
         referenceOpenHashSet.addAll(keyframe.getUsedVariables());
      }

      for (Keyframe keyframe : this.zKeyframes) {
         referenceOpenHashSet.addAll(keyframe.getUsedVariables());
      }

      return referenceOpenHashSet;
   }

   public Keyframe[] xKeyframes() {
      return this.xKeyframes;
   }

   public Keyframe[] yKeyframes() {
      return this.yKeyframes;
   }

   public Keyframe[] zKeyframes() {
      return this.zKeyframes;
   }
}

