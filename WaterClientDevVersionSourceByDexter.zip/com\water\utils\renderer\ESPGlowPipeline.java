package com.water.utils.renderer;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;
import java.awt.Color;
import java.nio.ByteBuffer;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.UniformType;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import org.lwjgl.system.MemoryUtil;

public final class ESPGlowPipeline {
   private static RenderPipeline pipeline;
   private static GpuBuffer uniformBuffer;
   private static final int UNIFORM_SIZE = 128;
   public static float defaultGlowSize = 12.0F;

   private ESPGlowPipeline() {
   }

   public static void init() {
      if (pipeline == null) {
         try {
            pipeline = RenderPipeline.builder(new Snippet[0])
               .withLocation(Identifier.of("water", "esp_glow_box"))
               .withVertexShader(Identifier.of("water", "esp_glow_box_vertex"))
               .withFragmentShader(Identifier.of("water", "esp_glow_box_fragment"))
               .withVertexFormat(VertexFormat.builder().build(), DrawMode.TRIANGLES)
               .withUniform("Uniforms", UniformType.UNIFORM_BUFFER)
               .withBlend(BlendFunction.TRANSLUCENT)
               .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
               .withCull(false)
               .build();
            uniformBuffer = RenderSystem.getDevice().createBuffer(() -> "ESPGlow Uniforms", 136, 128L);
         } catch (Exception var1) {
            System.err.println("[ESPGlowPipeline] Init failed: " + var1.getMessage());
         }
      }
   }

   public static void drawGlowBox(Matrix4f matrix, float x, float y, float w, float h, Color color, float glowSize, float z) {
      if (pipeline == null) {
         init();
      }

      if (pipeline != null && uniformBuffer != null) {
         ByteBuffer buf = MemoryUtil.memAlloc(128);

         try {
            buf.putFloat(matrix.m00()).putFloat(matrix.m01()).putFloat(matrix.m02()).putFloat(matrix.m03());
            buf.putFloat(matrix.m10()).putFloat(matrix.m11()).putFloat(matrix.m12()).putFloat(matrix.m13());
            buf.putFloat(matrix.m20()).putFloat(matrix.m21()).putFloat(matrix.m22()).putFloat(matrix.m23());
            buf.putFloat(matrix.m30()).putFloat(matrix.m31()).putFloat(matrix.m32()).putFloat(matrix.m33());
            buf.putFloat(x).putFloat(y).putFloat(w).putFloat(h);
            buf.putFloat(color.getRed() / 255.0F);
            buf.putFloat(color.getGreen() / 255.0F);
            buf.putFloat(color.getBlue() / 255.0F);
            buf.putFloat(color.getAlpha() / 255.0F);
            buf.putFloat(glowSize);
            buf.putFloat(z);
            buf.putFloat(0.0F).putFloat(0.0F);
            buf.flip();
            CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
            encoder.writeToBuffer(uniformBuffer.slice(), buf);
            Framebuffer fb = MinecraftClient.getInstance().getFramebuffer();
            RenderPass pass = encoder.createRenderPass(
               () -> "ESPGlow", fb.getColorAttachmentView(), OptionalInt.empty(), fb.getDepthAttachmentView(), OptionalDouble.empty()
            );

            try {
               RenderUtil.applyScissor(pass);
               pass.setPipeline(pipeline);
               pass.setUniform("Uniforms", uniformBuffer);
               pass.draw(0, 6);
            } catch (Throwable var19) {
               if (pass != null) {
                  try {
                     pass.close();
                  } catch (Throwable var18) {
                     var19.addSuppressed(var18);
                  }
               }

               throw var19;
            }

            if (pass != null) {
               pass.close();
            }
         } finally {
            MemoryUtil.memFree(buf);
         }
      }
   }

   public static void shutdown() {
      if (uniformBuffer != null) {
         uniformBuffer.close();
         uniformBuffer = null;
      }

      pipeline = null;
   }
}

