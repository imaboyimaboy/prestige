package rtx.kimiko.api.mods.geckolib.loading.json.raw;

import com.google.gson.JsonDeserializer;
import com.google.gson.JsonParseException;
import com.mojang.datafixers.util.Either;
import rtx.kimiko.api.mods.geckolib.util.JsonUtil;

public final class UVUnion {
   private Either<double[], UVFaces> uvData;

   public UVUnion(Either<double[], UVFaces> uvData) {
      this.uvData = uvData;
   }

   public boolean isBoxUV() {
      return this.uvData.left().isPresent();
   }

   public static JsonDeserializer<UVUnion> deserializer() throws JsonParseException {
      return (jsonElement, type, jsonDeserializationContext) -> {
         if (jsonElement.isJsonObject()) {
            return new UVUnion(Either.right((UVFaces)jsonDeserializationContext.deserialize(jsonElement.getAsJsonObject(), UVFaces.class)));
         } else if (jsonElement.isJsonArray()) {
            return new UVUnion(Either.left(JsonUtil.jsonArrayToDoubleArray(jsonElement.getAsJsonArray())));
         } else {
            throw new JsonParseException("Invalid format provided for UVUnion, must be either double array or UVFaces collection");
         }
      };
   }

   public Either<double[], UVFaces> uvData() {
      return this.uvData;
   }
}

