package com.water.module.modules.misc;

import com.water.module.Category;
import com.water.module.Module;
import com.water.module.ModuleManager;
import com.water.setting.Setting;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

public final class GambleRig extends Module {
   private final Setting<Float> myTarget = new Setting<>("My Result", 9.0F, 1.0F, 9.0F);
   private final Setting<Boolean> autoSwapSlot = new Setting<>("Auto Slot Swap", true);
   private static boolean selecting = false;
   private static BlockPos myDropperPos = null;
   private static BlockPos lastInteractedBlock = null;
   private static final Map<Integer, ItemStack> savedSlots = new LinkedHashMap<>();
   private static ItemStack fillerItem = null;
   private static Item myDropperItemType = null;
   private static int fakeEmptySlot = -1;
   private static boolean fakeActive = false;
   private static boolean screenScanned = false;
   private static int activeTarget = -1;
   private static int myRenameTarget = -1;
   private static boolean itemPlacedBack = false;
   private static int currentDrawSlotId = -1;

   public GambleRig() {
      super("Gamble Rig", Category.MISC);
      this.addSetting(this.myTarget);
      this.addSetting(this.autoSwapSlot);
   }

   @Override
   public void onEnable() {
      this.resetAll();
      selecting = true;
      if (mc.player != null) {
         mc.player.sendMessage(Text.literal("§d[GR] §fRight-click your dropper"), true);
      }
   }

   @Override
   public void onDisable() {
      this.resetAll();
   }

   private void resetAll() {
      this.resetFakeState();
      selecting = false;
      myDropperPos = null;
      myDropperItemType = null;
      myRenameTarget = -1;
   }

   private void resetFakeState() {
      fakeActive = false;
      screenScanned = false;
      fakeEmptySlot = -1;
      activeTarget = -1;
      fillerItem = null;
      itemPlacedBack = false;
      savedSlots.clear();
   }

   @Override
   public void onTick() {
      if (mc.player != null && mc.world != null) {
         this.handleScreenState();
         if (myDropperPos != null) {
            myRenameTarget = Math.round(this.myTarget.getValue());
         }
      }
   }

   public static boolean handleBlockClick(BlockPos pos) {
      Module m = ModuleManager.INSTANCE.getModuleByName("Gamble Rig");
      if (m != null && m.isEnabled() && selecting) {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc.world == null) {
            return false;
         } else if (!mc.world.getBlockState(pos).isOf(Blocks.DROPPER) && !mc.world.getBlockState(pos).isOf(Blocks.DISPENSER)) {
            return false;
         } else {
            myDropperPos = pos.toImmutable();
            selecting = false;
            if (mc.player != null) {
               mc.player.sendMessage(Text.literal("§d[GR] §a✔ Dropper set — ready!"), true);
            }

            return true;
         }
      } else {
         return false;
      }
   }

   private void handleScreenState() {
      if (!(mc.currentScreen instanceof HandledScreen)) {
         if (fakeActive || screenScanned) {
            this.resetFakeState();
         }
      } else {
         ScreenHandler h = mc.player.currentScreenHandler;
         if (h != null && h.slots.size() == 45) {
            if (!screenScanned) {
               screenScanned = true;
               this.identifyAndSetup(h);
            }

            if (fakeActive && !itemPlacedBack) {
               boolean anyEmpty = false;

               for (int i = 0; i < 9; i++) {
                  if (i != fakeEmptySlot) {
                     Slot s = (Slot)h.slots.get(i);
                     if (!s.hasStack() || s.getStack().isEmpty()) {
                        anyEmpty = true;
                        break;
                     }
                  }
               }

               if (!anyEmpty) {
                  itemPlacedBack = true;
               }
            }
         }
      }
   }

   public static void tryScanIfNeeded() {
      if (!screenScanned && !fakeActive) {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc.player != null) {
            ScreenHandler h = mc.player.currentScreenHandler;
            if (h != null && h.slots.size() == 45) {
               boolean hasData = false;

               for (int i = 0; i < 9; i++) {
                  Slot s = (Slot)h.slots.get(i);
                  if (s.hasStack() && !s.getStack().isEmpty()) {
                     hasData = true;
                     break;
                  }
               }

               if (hasData) {
                  Module m = ModuleManager.INSTANCE.getModuleByName("Gamble Rig");
                  if (m != null && m.isEnabled()) {
                     screenScanned = true;
                     ((GambleRig)m).identifyAndSetup(h);
                  }
               }
            }
         }
      }
   }

   private void identifyAndSetup(ScreenHandler handler) {
      if (lastInteractedBlock != null && myDropperPos != null) {
         if (lastInteractedBlock.equals(myDropperPos)) {
            int target = Math.round(this.myTarget.getValue());
            int targetIdx = Math.max(0, Math.min(8, target - 1));
            savedSlots.clear();
            fillerItem = null;
            itemPlacedBack = false;

            for (int i = 0; i < 9; i++) {
               Slot slot = (Slot)handler.slots.get(i);
               if (slot.hasStack() && !slot.getStack().isEmpty()) {
                  savedSlots.put(i, slot.getStack().copy());
                  if (fillerItem == null) {
                     fillerItem = slot.getStack().copy();
                  }

                  if (myDropperItemType == null) {
                     myDropperItemType = slot.getStack().getItem();
                  }
               }
            }

            if (fillerItem != null && savedSlots.containsKey(targetIdx)) {
               fakeEmptySlot = targetIdx;
               activeTarget = target;
               fakeActive = true;
            }
         }
      }
   }

   public static void setLastInteractedBlock(BlockPos p) {
      lastInteractedBlock = p != null ? p.toImmutable() : null;
   }

   public static boolean isFakeActive() {
      return fakeActive;
   }

   public static int getFakeEmptySlot() {
      return fakeEmptySlot;
   }

   public static int getActiveTarget() {
      return activeTarget;
   }

   public static ItemStack getFillerItem() {
      return fillerItem;
   }

   public static Item getCurrentDropperItemType() {
      return myDropperItemType;
   }

   public static boolean isItemPlacedBack() {
      return itemPlacedBack;
   }

   public static void setItemPlacedBack(boolean v) {
      itemPlacedBack = v;
   }

   public static void setCurrentDrawSlotId(int id) {
      currentDrawSlotId = id;
   }

   public static boolean shouldAutoSwap() {
      if (fakeActive && !itemPlacedBack) {
         Module m = ModuleManager.INSTANCE.getModuleByName("Gamble Rig");
         return m != null && m.isEnabled() && ((GambleRig)m).autoSwapSlot.getValue();
      } else {
         return false;
      }
   }

   public static int findRealEmptySlot(ScreenHandler h) {
      if (h == null) {
         return -1;
      } else {
         for (int i = 0; i < 9; i++) {
            if (i != fakeEmptySlot) {
               Slot s = (Slot)h.slots.get(i);
               if (!s.hasStack() || s.getStack().isEmpty()) {
                  return i;
               }
            }
         }

         return -1;
      }
   }

   public static boolean shouldRenameItem(ItemStack stack) {
      if (currentDrawSlotId >= 0 && currentDrawSlotId <= 8) {
         return false;
      } else if (myRenameTarget < 1 || myDropperItemType == null) {
         return false;
      } else if (stack != null && !stack.isEmpty()) {
         Module m = ModuleManager.INSTANCE.getModuleByName("Gamble Rig");
         return m != null && m.isEnabled() ? stack.getItem() == myDropperItemType : false;
      } else {
         return false;
      }
   }

   public static Text getRenamedText(ItemStack stack) {
      return Text.literal("-1");
   }

   public static Text getRenamedText() {
      return Text.literal("-1");
   }

   public static boolean shouldFakeDisplay() {
      return fakeActive;
   }

   public static ItemStack getFakeItem(int s) {
      return savedSlots.get(s);
   }

   public static ItemStack getSavedItem(int s) {
      return savedSlots.get(s);
   }

   public static int getRealEmptySlot() {
      return -1;
   }

   public static boolean isRenameActive() {
      return myRenameTarget > 0;
   }

   public static int getRenameTarget() {
      return myRenameTarget;
   }

   public static int parseNumberSafe(ItemStack s) {
      return -1;
   }
}

