package rtx.kimiko.api.drags;

final class DragLerpAnim {
   private long lastTickNs;
   float anim;
   float to;
   float speed;

   DragLerpAnim(float f, float f2, float f3) {
      this.anim = f;
      this.to = f2;
      this.speed = f3;
      this.lastTickNs = System.nanoTime();
   }

   float getAnim() {
      long l = System.nanoTime();
      float f = Math.min((float)(l - this.lastTickNs) / 1.E9F, 0.05F);
      this.lastTickNs = l;
      float f2 = Math.clamp(this.speed * 2.0F, 0.0F, 0.999F);
      float f3 = 1.0F - (float)Math.pow(1.0F - f2, f * 100.0F);
      this.anim = this.anim + (this.to - this.anim) * f3;
      return this.anim;
   }

   void setAnim(float f) {
      this.anim = f;
      this.lastTickNs = System.nanoTime();
   }

   void setTo(float f) {
      this.to = f;
   }

   void setSpeed(float f) {
      this.speed = f;
   }

   void setToAsBoolean(boolean bl) {
      this.to = bl ? 1.0F : 0.0F;
   }

   float getTo() {
      return this.to;
   }
}

