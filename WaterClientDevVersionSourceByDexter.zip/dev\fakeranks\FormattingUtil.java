package dev.fakeranks;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class FormattingUtil {
   private static final Pattern HEX_CODE = Pattern.compile("&#([A-Fa-f0-9]{6})");

   private FormattingUtil() {
   }

   public static String legacyHex(int rgb) {
      String hex = String.format(Locale.ROOT, "%06X", rgb & 16777215);
      StringBuilder builder = new StringBuilder("§x");

      for (int i = 0; i < hex.length(); i++) {
         builder.append('§').append(hex.charAt(i));
      }

      return builder.toString();
   }

   public static String translateHexCodes(String input) {
      Matcher matcher = HEX_CODE.matcher(input);
      StringBuffer output = new StringBuffer();

      while (matcher.find()) {
         int color = Integer.parseInt(matcher.group(1), 16);
         matcher.appendReplacement(output, Matcher.quoteReplacement(legacyHex(color)));
      }

      matcher.appendTail(output);
      return output.toString().replace('&', '§');
   }
}

