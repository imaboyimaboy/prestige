package rtx.kimiko.api.mods.geckolib.animation.state;

import java.util.function.Function;
import net.minecraft.util.math.MathHelper;
import rtx.kimiko.api.mods.geckolib.animation.object.EasingType;
import rtx.kimiko.api.mods.geckolib.animation.object.LoopType;
import rtx.kimiko.api.mods.geckolib.cache.animation.Animation;
import rtx.kimiko.api.mods.geckolib.cache.animation.BoneAnimation;
import rtx.kimiko.api.mods.geckolib.cache.animation.Keyframe;
import rtx.kimiko.api.mods.geckolib.cache.animation.KeyframeStack;
import rtx.kimiko.api.mods.geckolib.cache.model.GeoBone;
import rtx.kimiko.api.mods.geckolib.util.MiscUtil;

public final class AnimationPoint {
   private Animation animation;
   private EasingType easingOverride;
   private LoopType loopType;
   private double animTime;
   private int[][][] keyFramePoints;
   public static final int NO_KEYFRAME = -2;
   public static final int BEFORE_FIRST_KEYFRAME = -1;

   public AnimationPoint(Animation animation, EasingType easingOverride, LoopType loopType, double animTime, int[][][] keyFramePoints) {
      this.animation = animation;
      this.easingOverride = easingOverride;
      this.loopType = loopType;
      this.animTime = animTime;
      this.keyFramePoints = keyFramePoints;
   }

   public boolean hasFinished() {
      return MiscUtil.areFloatsEqual(this.animTime, this.animation.length());
   }

   public int[] scalePoints(int n) {
      return this.keyFramePoints[n][AnimationPoint.Transform.SCALE.index];
   }

   private static void findBonePoints(BoneAnimation boneAnimation, int[][] nArray, double d, boolean bl) {
      findKeyframePoints(boneAnimation.scaleKeyFrames(), nArray[AnimationPoint.Transform.SCALE.index], d, bl);
      findKeyframePoints(boneAnimation.rotationKeyFrames(), nArray[AnimationPoint.Transform.ROTATION.index], d, bl);
      findKeyframePoints(boneAnimation.positionKeyFrames(), nArray[AnimationPoint.Transform.TRANSLATION.index], d, bl);
   }

   public Keyframe getCurrentKeyframe(int n, AnimationPoint.Transform transform, AnimationPoint.Axis axis) {
      return this.getKeyframe(n, transform, axis, 0);
   }

   public Keyframe getNextKeyframe(int n, AnimationPoint.Transform transform, AnimationPoint.Axis axis) {
      return this.getKeyframe(n, transform, axis, 1);
   }

   private static int[][][] constructBoneArray(Animation animation, double d) {
      BoneAnimation[] boneAnimationArray = animation.boneAnimations();
      int[][][] nArray = new int[boneAnimationArray.length][3][3];

      for (int i = 0; i < boneAnimationArray.length; i++) {
         findBonePoints(boneAnimationArray[i], nArray[i], d, false);
      }

      return nArray;
   }

   public Keyframe getPreviousKeyframe(int n, AnimationPoint.Transform transform, AnimationPoint.Axis axis) {
      return this.getKeyframe(n, transform, axis, -1);
   }

   public Keyframe getKeyframe(int n, AnimationPoint.Transform transform, AnimationPoint.Axis axis, int n2) {
      BoneAnimation boneAnimation = this.animation.boneAnimations()[n];
      Keyframe[] keyframeArray = axis.keyframes(transform.keyframeStack(boneAnimation));
      int n3 = this.keyFramePoints[n][transform.index][axis.index];
      return keyframeArray.length != 0 && n3 != -2 ? keyframeArray[MathHelper.clamp(n3 + n2, 0, keyframeArray.length - 1)] : null;
   }

   private static int findKeyframePointForward(Keyframe[] keyframeArray, double d, int n) {
      if (keyframeArray.length == 0) {
         return -2;
      } else if (keyframeArray[0].startTime() > d) {
         return -1;
      } else {
         for (int i = Math.max(0, n); i < keyframeArray.length; i++) {
            if (i + 1 < keyframeArray.length && keyframeArray[i + 1].startTime() >= d) {
               return i;
            }
         }

         return keyframeArray.length - 1;
      }
   }

   public int[] translationPoints(int n) {
      return this.keyFramePoints[n][AnimationPoint.Transform.TRANSLATION.index];
   }

   public int[] rotationPoints(int n) {
      return this.keyFramePoints[n][AnimationPoint.Transform.ROTATION.index];
   }

   private static int findKeyframePointReverse(Keyframe[] keyframeArray, double d, int n) {
      if (keyframeArray.length == 0) {
         return -2;
      } else {
         for (int i = Math.min(n, keyframeArray.length - 1); i >= 0; i--) {
            if (i - 1 >= 0 && keyframeArray[i - 1].startTime() <= d) {
               return i - 1;
            }
         }

         return -1;
      }
   }

   private static void findKeyframePoints(KeyframeStack keyframeStack, int[] nArray, double d, boolean bl) {
      if (bl) {
         nArray[AnimationPoint.Axis.X_2.index] = findKeyframePointReverse(keyframeStack.xKeyframes(), d, nArray[AnimationPoint.Axis.X_2.index]);
         nArray[AnimationPoint.Axis.Y_2.index] = findKeyframePointReverse(keyframeStack.yKeyframes(), d, nArray[AnimationPoint.Axis.Y_2.index]);
         nArray[AnimationPoint.Axis.Z_2.index] = findKeyframePointReverse(keyframeStack.zKeyframes(), d, nArray[AnimationPoint.Axis.Z_2.index]);
      } else {
         nArray[AnimationPoint.Axis.X_2.index] = findKeyframePointForward(keyframeStack.xKeyframes(), d, nArray[AnimationPoint.Axis.X_2.index]);
         nArray[AnimationPoint.Axis.Y_2.index] = findKeyframePointForward(keyframeStack.yKeyframes(), d, nArray[AnimationPoint.Axis.Y_2.index]);
         nArray[AnimationPoint.Axis.Z_2.index] = findKeyframePointForward(keyframeStack.zKeyframes(), d, nArray[AnimationPoint.Axis.Z_2.index]);
      }
   }

   public int findBoneIndex(GeoBone geoBone) {
      BoneAnimation[] boneAnimationArray = this.animation.boneAnimations();

      for (int i = 0; i < boneAnimationArray.length; i++) {
         if (boneAnimationArray[i].boneName().equals(geoBone.name())) {
            return i;
         }
      }

      return -1;
   }

   public AnimationPoint createNext(double d) {
      if (MiscUtil.areFloatsEqual(d, this.animTime)) {
         return this;
      } else {
         d = MathHelper.clamp(d, 0.0, this.animation.length());
         AnimationPoint animationPoint = new AnimationPoint(this.animation, this.easingOverride, this.loopType, d, this.keyFramePoints);
         boolean bl = d < this.animTime;

         for (int i = 0; i < this.keyFramePoints.length; i++) {
            findBonePoints(this.animation.boneAnimations()[i], animationPoint.keyFramePoints[i], d, bl);
         }

         return animationPoint;
      }
   }

   public static AnimationPoint createFor(Animation animation, EasingType easingType, LoopType loopType, double d) {
      d = MathHelper.clamp(d, 0.0, animation.length());
      return new AnimationPoint(animation, easingType, loopType, d, constructBoneArray(animation, d));
   }

   public Animation animation() {
      return this.animation;
   }

   public EasingType easingOverride() {
      return this.easingOverride;
   }

   public LoopType loopType() {
      return this.loopType;
   }

   public double animTime() {
      return this.animTime;
   }

   public int[][][] keyFramePoints() {
      return this.keyFramePoints;
   }

   public enum Axis {
      X_2(0, KeyframeStack::xKeyframes),
      Y_2(1, KeyframeStack::yKeyframes),
      Z_2(2, KeyframeStack::zKeyframes);

      public int index;
      public Function<KeyframeStack, Keyframe[]> framesFunction;

      private Axis(int index, Function<KeyframeStack, Keyframe[]> framesFunction) {
         this.index = index;
         this.framesFunction = framesFunction;
      }

      public Keyframe[] keyframes(KeyframeStack keyframeStack) {
         return this.framesFunction.apply(keyframeStack);
      }

      private static AnimationPoint.Axis[] $values() {
         return new AnimationPoint.Axis[]{X_2, Y_2, Z_2};
      }
   }

   public enum Transform {
      SCALE(0, 1.0F, BoneAnimation::scaleKeyFrames),
      ROTATION(1, 0.0F, BoneAnimation::rotationKeyFrames),
      TRANSLATION(2, 0.0F, BoneAnimation::positionKeyFrames);

      public int index;
      public float defaultValue;
      public Function<BoneAnimation, KeyframeStack> stackFunction;

      private Transform(int index, float defaultValue, Function<BoneAnimation, KeyframeStack> stackFunction) {
         this.index = index;
         this.defaultValue = defaultValue;
         this.stackFunction = stackFunction;
      }

      public KeyframeStack keyframeStack(BoneAnimation boneAnimation) {
         return this.stackFunction.apply(boneAnimation);
      }

      private static AnimationPoint.Transform[] $values() {
         return new AnimationPoint.Transform[]{SCALE, ROTATION, TRANSLATION};
      }
   }
}

