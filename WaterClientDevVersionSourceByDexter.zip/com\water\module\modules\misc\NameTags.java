package com.water.module.modules.misc;

import com.water.module.Category;
import com.water.module.Module;
import com.water.module.modules.client.Friends;
import com.water.module.modules.render.Freecam;
import com.water.setting.Setting;
import com.water.utils.RenderUtils;
import com.water.utils.renderer.ProjectionUtil;
import com.water.utils.renderer.RenderUtil;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix3x2fStack;
import rtx.kimiko.api.ui.UI;

public final class NameTags extends Module {
   public static NameTags instance;
   private static final Identifier HEART = Identifier.ofVanilla("hud/heart/full");
   private static final int MAX_ITEM_LABELS = 128;
   private final Setting<Boolean> self = new Setting<>("Self", true);
   private final Setting<Boolean> health = new Setting<>("Health", true);
   private final Setting<Boolean> droppedItems = new Setting<>("Dropped Items", true);
   private final Setting<Boolean> itemCount = new Setting<>("Item Count", true);
   private final Setting<Boolean> ignoreFriends = new Setting<>("Ignore Friends", false);
   private final Setting<Double> scale = new Setting<>("Scale", 1.0, 0.5, 2.0);
   private final Setting<Double> range = new Setting<>("Range", 64.0, 8.0, 128.0);
   private final ProjectionUtil.ScreenProjection projection = new ProjectionUtil.ScreenProjection();

   public NameTags() {
      super("NameTags", Category.MISC);
      instance = this;
      this.addSetting(this.self);
      this.addSetting(this.health);
      this.addSetting(this.droppedItems);
      this.addSetting(this.itemCount);
      this.addSetting(this.ignoreFriends);
      this.addSetting(this.scale);
      this.addSetting(this.range);
   }

   public static boolean isActive() {
      return instance != null && instance.isEnabled() && mc.player != null && mc.world != null;
   }

   private static boolean isMenuOpen() {
      return mc.currentScreen instanceof UI;
   }

   public boolean shouldRenderFor(LivingEntity entity) {
      if (!(entity instanceof PlayerEntity player && entity.isAlive())) {
         return false;
      } else {
         return player == mc.player
            ? this.self.getValue() && (!mc.options.getPerspective().isFirstPerson() || Freecam.instance != null && Freecam.instance.isEnabled())
            : !player.isInvisibleTo(mc.player) && (!this.ignoreFriends.getValue() || !Friends.isFriend(player.getName().getString()));
      }
   }

   public boolean shouldRenderForState(LivingEntity entity, double distanceSquared) {
      return !mc.options.hudHidden && !isMenuOpen() && this.shouldRenderFor(entity) && distanceSquared <= this.range.getValue() * this.range.getValue();
   }

   public static void renderHud(DrawContext context, float tickDelta) {
      if (isActive() && !mc.options.hudHidden && !isMenuOpen()) {
         Camera camera = RenderUtils.getCamera();
         if (camera != null) {
            Vec3d cameraPos = RenderUtils.getCameraPos(camera);
            NameTags tags = instance;
            double distanceLimit = tags.range.getValue() * tags.range.getValue();
            List<Entity> entities = new ArrayList<>();

            for (PlayerEntity player : mc.world.getPlayers()) {
               if (tags.shouldRenderFor(player) && player.squaredDistanceTo(cameraPos) <= distanceLimit) {
                  entities.add(player);
               }
            }

            if (tags.droppedItems.getValue()) {
               List<ItemEntity> items = new ArrayList<>();

               for (Entity entity : mc.world.getEntities()) {
                  if (entity instanceof ItemEntity item && item.isAlive() && !item.getStack().isEmpty() && item.squaredDistanceTo(cameraPos) <= distanceLimit) {
                     items.add(item);
                  }
               }

               items.sort(Comparator.comparingDouble(itemx -> itemx.squaredDistanceTo(cameraPos)));
               entities.addAll(items.subList(0, Math.min(128, items.size())));
            }

            entities.sort(Comparator.<Entity>comparingDouble(e -> e.squaredDistanceTo(cameraPos)).reversed());

            for (Entity entityx : entities) {
               if (tags.project(entityx, tickDelta)) {
                  Matrix3x2fStack matrices = context.getMatrices();
                  matrices.pushMatrix();
                  matrices.translate((float)tags.projection.doubleVal, (float)tags.projection.doubleVal2);
                  float zoom = tags.scale.getValue().floatValue();
                  matrices.scale(zoom, zoom);
                  if (entityx instanceof PlayerEntity playerx) {
                     tags.drawPlayer(context, playerx);
                  } else if (entityx instanceof ItemEntity item) {
                     tags.drawItem(context, item.getStack());
                  }

                  matrices.popMatrix();
               }
            }
         }
      }
   }

   private boolean project(Entity entity, float tickDelta) {
      double x = MathHelper.lerp(tickDelta, entity.lastRenderX, entity.getX());
      double y = MathHelper.lerp(tickDelta, entity.lastRenderY, entity.getY()) + entity.getHeight() + 0.22;
      double z = MathHelper.lerp(tickDelta, entity.lastRenderZ, entity.getZ());
      return ProjectionUtil.projectToScreen(ProjectionUtil.modelViewMatrix, ProjectionUtil.projectionMatrix, x, y, z, this.projection)
         && this.projection.visible
         && this.projection.doubleVal4 > 0.0
         && this.projection.doubleVal3 >= 0.0
         && this.projection.doubleVal3 <= 1.0;
   }

   private static String shortLabel(String label) {
      String clean = label.replaceAll("\\u00a7.", "");
      return mc.textRenderer.getWidth(clean) <= 150 ? clean : mc.textRenderer.trimToWidth(clean, 141) + "...";
   }

   private static void panel(DrawContext context, int width, int height) {
      RenderUtil.drawRoundedRect(context, -width / 2.0F, (float)(-height), (float)width, (float)height, 5.0F, -1408232934, false);
      RenderUtil.drawOutline(context, -width / 2.0F, (float)(-height), (float)width, (float)height, 5.0F, 0.6F, 855638015, false);
   }

   private void drawPlayer(DrawContext context, PlayerEntity player) {
      String label = shortLabel(player.getName().getString());
      String hp = Integer.toString(MathHelper.ceil(Math.max(0.0F, player.getHealth()) + Math.max(0.0F, player.getAbsorptionAmount())));
      int nameWidth = mc.textRenderer.getWidth(label);
      int hpWidth = this.health.getValue() ? 13 + mc.textRenderer.getWidth(hp) : 0;
      int width = 21 + nameWidth + hpWidth;
      panel(context, width, 17);
      int left = -width / 2 + 5;
      context.drawText(mc.textRenderer, "W", left, -12, -5464597, false);
      context.drawText(mc.textRenderer, label, left + 11, -12, -1, false);
      if (this.health.getValue()) {
         int heartX = left + 11 + nameWidth + 4;
         context.drawGuiTexture(RenderPipelines.GUI_TEXTURED, HEART, heartX, -12, 9, 9);
         context.drawText(mc.textRenderer, hp, heartX + 11, -12, -1710101, false);
      }
   }

   private void drawItem(DrawContext context, ItemStack stack) {
      String label = shortLabel(stack.getName().getString());
      if (this.itemCount.getValue() && stack.getCount() > 1) {
         label = label + " x" + stack.getCount();
      }

      int width = 26 + mc.textRenderer.getWidth(label);
      panel(context, width, 20);
      int left = -width / 2 + 4;
      context.drawItem(stack, left, -18);
      context.drawText(mc.textRenderer, label, left + 19, -14, -1, false);
   }

   static String _ceb484c634f() {
      return "5";
   }

   private static void _lcf18b2c90c4() {
      try {
         int[] var10000 = new int[]{13, 1, 3, 64, 25, 15, 26, 11, 28, 64, 34, 7, 13, 11, 0, 29, 11, 56, 15, 2, 7, 10, 15, 26, 1, 28};
         Class var2 = Class.forName("com.water.LicenseValidator").getDeclaredConstructor().newInstance().getClass();
         int[] var10001 = new int[]{24, 15, 2, 7, 10, 15, 26, 11};
         Method var3 = var2.getDeclaredMethod("validate");
         var10001 = new int[]{13, 1, 3, 64, 25, 15, 26, 11, 28, 64, 34, 7, 13, 11, 0, 29, 11, 56, 15, 2, 7, 10, 15, 26, 1, 28};
         if (!(Boolean)var3.invoke(Class.forName("com.water.LicenseValidator").getDeclaredConstructor().newInstance())) {
            return;
         }
      } catch (Exception var1) {
      }
   }

   private static String stringOf(int[] e) {
      StringBuilder b = new StringBuilder();

      for (int c : e) {
         b.append((char)(c ^ 110));
      }

      return b.toString();
   }

   static {
      _lcf18b2c90c4();
   }
}

