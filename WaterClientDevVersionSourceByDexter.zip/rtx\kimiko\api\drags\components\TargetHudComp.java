package rtx.kimiko.api.drags.components;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextVisitFactory;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector4f;
import rtx.kimiko.api.drags.DragSystem;
import rtx.kimiko.api.drags.Draggable;
import rtx.kimiko.api.drags.Position;
import rtx.kimiko.api.events.EventBus;
import rtx.kimiko.api.events.EventHandler;
import rtx.kimiko.api.events.impl.render.WorldRenderEvent;
import rtx.kimiko.api.modules.ModuleManager;
import rtx.kimiko.api.modules.impl.Interface.InterfaceModule;
import rtx.kimiko.api.modules.impl.Interface.TargetHudModule;
import rtx.kimiko.api.modules.impl.Visuals.NameTags;
import rtx.kimiko.api.ui.theme.ClientAccent;
import rtx.kimiko.utils.animations.Easings;
import rtx.kimiko.utils.animations.SmoothAnimation;
import rtx.kimiko.utils.color.ColorUtil;
import rtx.kimiko.utils.network.Network;
import rtx.kimiko.utils.rank.ReallyWorldRanks;
import rtx.kimiko.utils.render.others.RectUtil;
import rtx.kimiko.utils.render.render2d.ClientPalette;
import rtx.kimiko.utils.render.render2d.Render2D;
import rtx.kimiko.utils.render.render2d.Render2DCoordinateSpace;
import rtx.kimiko.utils.render.render2d.rectangle.rectdefault.BuiltRectangle;

public final class TargetHudComp extends Draggable {
   private static final String NAME_FONT = "montserrat-semibold";
   private static final String INFO_FONT = "montserrat-medium";
   private static final float PAD = 6.0F;
   private static final float HEAD = 22.0F;
   private static final float HAT_SCALE = 1.18F;
   private static final float GAP = 7.0F;
   private static final float BAR_H = 3.0F;
   private static final float NAME_SIZE = 8.0F;
   private static final float INFO_SIZE = 6.0F;
   private static final float RADIUS = 7.0F;
   private static final float MIN_CONTENT_W = 74.0F;
   private static final float HEIGHT = 34.0F;
   private static final long HOLD_MS = 1500L;
   private static final int NAME_COLOR = -1;
   private static final int INFO_COLOR = -3618608;
   private static final int BAR_BG_COLOR = -14935006;
   private static final float NEW_PAD = 3.0F;
   private static final float NEW_GAP = 3.0F;
   private static final float NEW_HEAD = 15.0F;
   private static final float NEW_HEAD_RADIUS = 6.0F;
   private static final String NEW_FONT = "small-pixel";
   private static final float NEW_ICON = 8.0F;
   private static final float NEW_ICON_GAP = 3.0F;
   private static final float NEW_HEAD_ITEMS_GAP = 3.0F;
   private static final float NEW_BAR_H = 8.0F;
   private static final float NEW_BAR_RADIUS = 2.0F;
   private static final float NEW_MIN_CONTENT = 78.0F;
   private static final float NEW_TEXT_EDGE_PAD = 2.0F;
   private static final float NEW_BOTTOM_PAD = 5.0F;
   private static final float NEW_HEIGHT = 45.0F;
   private static final EquipmentSlot[] NEW_SLOTS = new EquipmentSlot[]{
      EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET, EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND
   };
   private static final EquipmentSlot[] ARMOR_SLOTS = new EquipmentSlot[]{
      EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET, EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND
   };
   private static final float ARMOR_SCALE = 0.5F;
   private static final float ARMOR_ICON = 8.0F;
   private static final float ARMOR_GAP = 3.0F;
   private static final float CLASSIC_ARMOR_EXTRA = 11.0F;
   private static final float NEW_ARMOR_COLLAPSE = 10.0F;
   private static final int PARTICLE_COUNT = 12;
   private static final float PARTICLE_MOVE_SPEED = 36.0F;
   private static final float PARTICLE_LIFETIME_JITTER = 0.2F;
   private static final float PARTICLE_FADE_IN = 0.15F;
   private final SmoothAnimation visibility = new SmoothAnimation();
   private final List<TargetHudComp.HeadParticle> headParticles = new ArrayList<>();
   private final Random random = new Random();
   private boolean lastTargetVisible;
   private LivingEntity target;
   private long lastSeenMs;
   private float healthDisplay;
   private float hpGrayDisplay = 1.0F;
   private float armorProgress = 1.0F;
   private final float[] slotAppear = new float[NEW_SLOTS.length];
   private float currentWidth = 120.0F;
   private float lastPinnedWidth = Float.NaN;
   private long lastNs = System.nanoTime();
   private int particleEntityId = Integer.MIN_VALUE;
   private int lastParticleHurtTime = -1;
   private final Vector4f followScratch = new Vector4f();
   private float followScreenX;
   private float followScreenY;
   private float followHalfH;
   private boolean followProjectionValid;
   private float followOffsetX;
   private float followOffsetY;
   private static final int HP_GREEN = 3530826;
   private static final int HP_ORANGE = 16751136;
   private static final int HP_RED = 16722480;

   public TargetHudComp() {
      super("targethud", 5.0F, 150.0F);
      this.visibility.set(0.0);
      EventBus.get().subscribe(this);
   }

   private static Text resolveName(LivingEntity livingEntity) {
      PlayerEntity playerEntity;
      Text text;
      return (Text)(livingEntity instanceof PlayerEntity && (text = NameTags.resolveDisplayName(playerEntity = (PlayerEntity)livingEntity)) != null
         ? ReallyWorldRanks.stripGlyphs(text)
         : Text.literal(livingEntity.getName().getString()));
   }

   private static String normalize(String string, boolean bl) {
      StringBuilder stringBuilder = new StringBuilder();
      string.codePoints().forEach(n -> stringBuilder.append(NameTags.displayGlyphCovered(n, bl)));
      return stringBuilder.toString();
   }

   @Override
   public float width() {
      return this.currentWidth;
   }

   @Override
   public float height() {
      return isNewMode() ? 45.0F - 10.0F * (1.0F - easeInOutCubic(this.armorProgress)) : 34.0F + 11.0F * easeInOutCubic(this.armorProgress);
   }

   private static float clamp01(float f) {
      return Math.max(0.0F, Math.min(1.0F, f));
   }

   private static int darken(int n, float f) {
      float f2 = 1.0F - Math.max(0.0F, Math.min(1.0F, f));
      int n2 = Math.round((n >> 16 & 0xFF) * f2);
      int n3 = Math.round((n >> 8 & 0xFF) * f2);
      int n4 = Math.round((n & 0xFF) * f2);
      return clamp255(n2) << 16 | clamp255(n3) << 8 | clamp255(n4);
   }

   private static boolean isNewMode() {
      TargetHudModule targetHudModule = hudModule();
      return targetHudModule != null && targetHudModule.isNewMode();
   }

   @Override
   public boolean isInteractive() {
      return componentEnabled();
   }

   private void pinCenterOnResize() {
      float f;
      if (!Float.isNaN(this.lastPinnedWidth) && !this.getDrag().isDragging() && Math.abs(f = this.currentWidth - this.lastPinnedWidth) > 1.0E-4F) {
         this.getDrag().setTargetX(this.getDrag().getTargetX() - f * 0.5F);
         this.getDrag().syncToTarget();
      }

      this.lastPinnedWidth = this.currentWidth;
   }

   private static float easeInOutCubic(float f) {
      float var1;
      return (var1 = clamp01(f)) < 0.5F ? 4.0F * var1 * var1 * var1 : 1.0F - (float)Math.pow(-2.0F * var1 + 2.0F, 3.0) / 2.0F;
   }

   private void drawHeadBackground(DrawContext drawContext, LivingEntity livingEntity, float f, float f2, float f3, float f4, float f5, float f6, float f7) {
      if (!(livingEntity instanceof AbstractClientPlayerEntity)) {
         Render2D.rect(f, f2, f3, f3, f5, f4, f4, f4, ColorUtil.multAlpha(-14935006, f6 * 0.5F));
         float f8 = Render2D.msdfWidth("montserrat-semibold", "?", 8.0F);
         Render2D.msdfText("montserrat-semibold", "?", f + (f3 - f8) * 0.5F, f2 + (f3 - 8.0F) * 0.45F - f7, 8.0F, ColorUtil.multAlpha(-1, f6 * 0.7F));
      }
   }

   private static int armorPieceCount(LivingEntity livingEntity) {
      if (!armorEnabled()) {
         return 0;
      } else {
         int n = 0;

         for (EquipmentSlot equipmentSlot : ARMOR_SLOTS) {
            if (!livingEntity.getEquippedStack(equipmentSlot).isEmpty()) {
               n++;
            }
         }

         return n;
      }
   }

   private void updateHitParticles(LivingEntity livingEntity, float f, float f2) {
      if (livingEntity.getId() != this.particleEntityId) {
         this.particleEntityId = livingEntity.getId();
         this.lastParticleHurtTime = livingEntity.hurtTime;
         this.headParticles.clear();
      }

      int n = livingEntity.hurtTime;
      if (livingEntity.hurtTime > this.lastParticleHurtTime && n > 0) {
         this.spawnHeadParticles(f, f2, 38.5F, 12);
      }

      this.lastParticleHurtTime = n;
   }

   private static int healthColor(float f) {
      if ((f = Math.max(0.0F, Math.min(1.0F, f))) >= 0.8F) {
         return 3530826;
      } else if (f >= 0.4F) {
         float f2 = (f - 0.4F) / 0.4F;
         return ColorUtil.lerpColor(16751136, 3530826, f2);
      } else {
         float f3 = f / 0.4F;
         return ColorUtil.lerpColor(16722480, 16751136, f3);
      }
   }

   private static void drawBarFill(float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8) {
      if (!(f3 <= 0.5F)) {
         float f9 = Math.min(f6, f5 * 0.5F);
         float f11 = clamp01(f8);
         int n = Math.round(235.0F * f11) << 24;
         TargetHudModule targetHudModule = hudModule();
         if (targetHudModule != null && targetHudModule.barWhite()) {
            int n2 = Math.round(215.0F * f11) << 24 | 14145495;
            Render2D.rect(new BuiltRectangle(f, f2, f3, f5, f9, n2).withSmoothness(-0.7F));
         } else if (targetHudModule != null && targetHudModule.barClient()) {
            Render2D.rect(new BuiltRectangle(f, f2, f3, f5, f9, -1).withPaletteGradient(3, 1.0F, clamp01(235.0F * f11 / 255.0F)).withSmoothness(-0.7F));
         } else {
            int n3 = healthColor(f7) & 16777215;
            int n4 = n | darken(n3, 0.45F);
            int n5 = n | n3;
            Render2D.rect(new BuiltRectangle(f, f2, f3, f5, f9, f9, f9, f9, n4, n5, n5, n4, -0.7F));
         }
      }
   }

   private static int barFillColorAt(float f, float f2) {
      TargetHudModule targetHudModule = hudModule();
      if (targetHudModule != null && targetHudModule.barWhite()) {
         return -2631721;
      } else if (targetHudModule != null && targetHudModule.barClient()) {
         return 0xFF000000 | ClientPalette.loopColor(clamp01(f) + ClientPalette.scrollPhase()) & 16777215;
      } else {
         int n = healthColor(f2) & 16777215;
         return 0xFF000000 | ColorUtil.lerpColor(darken(n, 0.45F), n, clamp01(f));
      }
   }

   private static float easeOutCubic(float f) {
      float f2 = 1.0F - clamp01(f);
      return 1.0F - f2 * f2 * f2;
   }

   private void drawArmorCentered(DrawContext drawContext, LivingEntity livingEntity, float f, float f2, float f3, float f4) {
      if (armorPieceCount(livingEntity) > 0) {
         float f7 = 8.0F / 16.0F;
         ArrayList<ItemStack> arrayList = new ArrayList<>(ARMOR_SLOTS.length);

         for (EquipmentSlot equipmentSlot : ARMOR_SLOTS) {
            arrayList.add(livingEntity.getEquippedStack(equipmentSlot));
         }

         float f8 = arrayList.size() * 8.0F + (arrayList.size() - 1) * 3.0F;
         float f9 = f - f8 * 0.5F;
         float f10 = Math.max(0.0F, Math.min(1.0F, f3));
         int n = Math.max(1, arrayList.size() - 1);
         Render2D.beginFrame(drawContext);

         for (int i = 0; i < arrayList.size(); i++) {
            float f11 = 0.35F + 0.25F * ((float)i / n);
            float f12 = easeOutCubic((f4 - f11) / 0.3F);
            if (f12 > 0.01F) {
               float f5 = f9 + i * 11.0F;
               int n2 = Math.round(36.0F * f10 * f12) << 24;
               Render2D.rect(f5 - 1.0F, f2 - 1.0F, 10.0F, 10.0F, 2.0F * f12, n2);
            }
         }

         Render2D.flush();
         float f13 = 4.0F;

         for (int ix = 0; ix < arrayList.size(); ix++) {
            ItemStack itemStack = arrayList.get(ix);
            float f5;
            float f14;
            if (!itemStack.isEmpty() && !((f14 = clamp01((f4 - (f5 = 0.45F + 0.25F * ((float)ix / n))) / 0.3F)) <= 0.01F)) {
               float f15 = f7 * f10 * easeOutBack(f14);
               float f16 = f9 + ix * 11.0F;
               drawContext.getMatrices().pushMatrix();
               Render2DCoordinateSpace.applyGuiScaleIndependence(drawContext.getMatrices());
               drawContext.getMatrices().translate(f16 + f13, f2 + f13);
               drawContext.getMatrices().scale(f15, f15);
               drawContext.getMatrices().translate(-8.0F, -8.0F);
               drawContext.drawItem(itemStack, 0, 0);
               drawContext.getMatrices().popMatrix();
            }
         }
      }
   }

   private void spawnHeadParticles(float f, float f2, float f3, int n) {
      long l = System.currentTimeMillis();

      for (int i = 0; i < n; i++) {
         float f4 = (0.3333F + this.random.nextFloat() * 0.6667F) * f3;
         float f5 = (float)Math.toRadians(this.random.nextFloat() * 360.0F);
         float f6 = (float)Math.sin(f5) * f4;
         float f7 = (float)(-Math.cos(f5)) * f4;
         long l2 = Math.max(120L, (long)Math.round(f4 / 36.0F * 1000.0F));
         float f8 = 1.0F + (this.random.nextFloat() * 2.0F - 1.0F) * 0.2F;
         long l3 = Math.max(120L, (long)Math.round((float)l2 * f8));
         float f9 = n <= 1 ? 0.0F : (float)i / (n - 1);
         this.headParticles.add(new HeadParticle(f, f2, f6, f7, l, l3, f9));
      }
   }

   private void drawHitParticles(DrawContext drawContext, float f) {
      if (!this.headParticles.isEmpty()) {
         long l = System.currentTimeMillis();
         Iterator<TargetHudComp.HeadParticle> iterator = this.headParticles.iterator();

         while (iterator.hasNext()) {
            TargetHudComp.HeadParticle headParticle = iterator.next();
            float f2 = headParticle.progress(l);
            if (f2 >= 1.0F) {
               iterator.remove();
            } else {
               float f3 = getParticleAlpha(f2) * f;
               if (!(f3 <= 0.004F)) {
                  float f4 = headParticle.startX + headParticle.offsetX * f2;
                  float f5 = headParticle.startY + headParticle.offsetY * f2;
                  float f6 = 1.0F * (0.85F + (1.0F - f2) * 0.15F);
                  int n = ClientAccent.gradientColor(headParticle.gradient, 255.0F) & 16777215;
                  Render2D.circle(f4, f5, f6, ColorUtil.multAlpha(n, f3));
               }
            }
         }
      }
   }

   private static float getParticleAlpha(float f) {
      float f2 = Math.max(0.0F, Math.min(1.0F, f));
      return f2 <= 0.15F ? f2 / 0.15F : Math.max(0.0F, Math.min(1.0F, 1.0F - (f2 - 0.15F) / 0.85F));
   }

   private static boolean componentEnabled() {
      TargetHudModule targetHudModule = ModuleManager.get().get(TargetHudModule.class);
      return targetHudModule != null && targetHudModule.isEnabled();
   }

   private void updateFollow(float f) {
      boolean bl = followEnabled()
         && this.followProjectionValid
         && this.target != null
         && this.target != MinecraftClient.getInstance().player
         && !DragSystem.get().isDragModeActive();
      float f3 = 0.0F;
      float f4 = 0.0F;
      if (bl) {
         float f2 = this.width();
         float f5 = this.height();
         float f6 = Position.screenWidth();
         float f7 = Position.screenHeight();
         float f8 = this.followScreenX;
         float f9 = this.followScreenY;
         boolean bl2 = f8 > -f6 * 0.1F && f8 < f6 * 1.1F && f9 > -f7 * 0.1F && f9 < f7 * 1.1F;
         if (bl2) {
            float f10 = Math.max(this.followHalfH, 14.0F);
            float f11 = f10 * 0.45F;
            float f14 = f8 / f6;
            float f15 = Math.min(1.0F, Math.abs(f14 - 0.5F) / 0.15F);
            float f16 = f14 < 0.5F ? f8 + f11 + 10.0F : f8 - f11 - 10.0F - f2;
            float f17 = f9 - f5 * 0.5F;
            float f18 = f8 - f2 * 0.5F;
            float f19 = f9 + f10 + 8.0F;
            float f20 = f18 + (f16 - f18) * f15;
            float f21 = f19 + (f17 - f19) * f15;
            f20 = Position.clampX(f20, f2);
            f21 = Position.clampY(f21, f5);
            f3 = f20 - this.getX();
            f4 = f21 - this.getY();
         }
      }

      float f2 = 1.0F - (float)Math.exp(-f * 12.0F);
      this.followOffsetX = this.followOffsetX + (f3 - this.followOffsetX) * f2;
      this.followOffsetY = this.followOffsetY + (f4 - this.followOffsetY) * f2;
      if (!bl && Math.abs(this.followOffsetX) < 0.5F && Math.abs(this.followOffsetY) < 0.5F) {
         this.followOffsetX = 0.0F;
         this.followOffsetY = 0.0F;
      }
   }

   private static void drawColoredName(Text text, float f, float f2, float f3, int n, float f4) {
      boolean bl = NameTags.isStylized(text.getString());
      StringBuilder stringBuilder = new StringBuilder();
      float[] fArray = new float[]{f};
      int[] nArray = new int[]{n};
      text.visit((style2, string) -> {
         TextVisitFactory.visitFormatted(string, style2, (n2, style, n3) -> {
            int n4 = style.getColor() != null ? 0xFF000000 | style.getColor().getRgb() : n;
            if (n4 != nArray[0] && !stringBuilder.isEmpty()) {
               String currentStr = stringBuilder.toString();
               Render2D.msdfText("montserrat-semibold", currentStr, fArray[0], f2, f3, ColorUtil.multAlpha(nArray[0], f4));
               fArray[0] += Render2D.msdfWidth("montserrat-semibold", currentStr, f3);
               stringBuilder.setLength(0);
            }

            nArray[0] = n4;
            stringBuilder.append(NameTags.displayGlyphCovered(n3, bl));
            return true;
         });
         return Optional.empty();
      }, Style.EMPTY);
      if (!stringBuilder.isEmpty()) {
         Render2D.msdfText("montserrat-semibold", stringBuilder.toString(), fArray[0], f2, f3, ColorUtil.multAlpha(nArray[0], f4));
      }
   }

   private static boolean followEnabled() {
      TargetHudModule targetHudModule = hudModule();
      return targetHudModule != null && targetHudModule.followTarget();
   }

   private static int sampleBarPalette(int[] nArray, float f) {
      int n = nArray.length;
      if (n <= 1) {
         return n == 1 ? nArray[0] : 16777215;
      } else {
         float f2 = clamp01(f) * (n - 1);
         int n2 = (int)f2;
         if (n2 > n - 2) {
            n2 = n - 2;
         }

         return ColorUtil.lerpColor(nArray[n2] | 0xFF000000, nArray[n2 + 1] | 0xFF000000, f2 - n2);
      }
   }

   private static String distanceText(LivingEntity livingEntity) {
      ClientPlayerEntity clientPlayerEntity = MinecraftClient.getInstance().player;
      float f = clientPlayerEntity != null ? clientPlayerEntity.distanceTo(livingEntity) : 0.0F;
      return Integer.toString(Math.round(f));
   }

   private void drawHeadForeground(DrawContext drawContext, LivingEntity livingEntity, float f, float f2, float f3, float f4, float f5, float f6) {
      if (livingEntity instanceof AbstractClientPlayerEntity abstractClientPlayerEntity) {
         Identifier identifier = abstractClientPlayerEntity.getSkin().body().texturePath();
         int n = Math.max(0, Math.min(255, Math.round(f6 * 255.0F))) << 24 | 16777215;
         n = tintHurt(n, livingEntity);
         String string = identifier.toString();
         if (Render2D.imageReady(string)) {
            Render2D.imageUvNearest(string, f, f2, f3, f5, f4, f4, f4, 0.5F, 0.125F, 0.125F, 0.25F, 0.25F, n);
            float f8 = (0.125F - 0.105932206F) * 0.5F;
            Render2D.imageUvNearest(string, f, f2, f3, f5, f4, f4, f4, 0.5F, 0.625F + f8, 0.125F + f8, 0.75F - f8, 0.25F - f8, n);
         } else {
            drawContext.drawTexture(RenderPipelines.GUI_TEXTURED, identifier, (int)f, (int)f2, 8.0F, 8.0F, (int)f3, (int)f3, 8, 8, 64, 64, n);
            drawContext.drawTexture(RenderPipelines.GUI_TEXTURED, identifier, (int)f, (int)f2, 40.0F, 8.0F, (int)f3, (int)f3, 8, 8, 64, 64, n);
         }
      }
   }

   private static boolean armorEnabled() {
      TargetHudModule targetHudModule = ModuleManager.get().get(TargetHudModule.class);
      return targetHudModule != null && targetHudModule.showArmor();
   }

   private void renderContent(DrawContext drawContext, float f, float f2) {
      if (isNewMode()) {
         this.renderNew(drawContext, f, f2);
      } else {
         boolean bl = armorEnabled() && armorPieceCount(this.target) > 0;
         float f3 = bl ? 6.0F : 10.0F;
         this.armorProgress = this.armorProgress + ((bl ? 1.0F : 0.0F) - this.armorProgress) * (1.0F - (float)Math.exp(-f * f3));
         this.armorProgress = clamp01(this.armorProgress);
         float f4 = easeInOutCubic(this.armorProgress);
         float f5 = 11.0F * f4;
         float f6 = 34.0F + f5;
         float f7 = this.getY() + 6.0F + f5 * 0.5F;
         float f8 = this.getX() + 6.0F + 11.0F;
         float f9 = f7 + 11.0F;
         this.updateHitParticles(this.target, f8, f9);
         Text text = resolveName(this.target);
         float f10 = Math.max(1.0F, this.target.getMaxHealth());
         float f11 = Network.getResolvedHealth(this.target, true);
         float f12 = Math.max(0.0F, Math.min(1.0F, f11 / f10));
         this.healthDisplay = this.healthDisplay + (f12 - this.healthDisplay) * (1.0F - (float)Math.exp(-f * 12.0F));
         String string = Math.round(f12 * 100.0F) + "% - " + distanceText(this.target) + "m";
         float f13 = coloredWidth(text, 8.0F);
         float f14 = Render2D.msdfWidth("montserrat-medium", string, 6.0F);
         float f15 = Math.max(74.0F, Math.max(f13, f14));
         this.currentWidth = 35.0F + f15 + 6.0F;
         this.pinCenterOnResize();
         float f16 = this.getX();
         float f17 = this.getY();
         float f18 = 0.94F + f2 * 0.06F;
         float f19 = f16 + this.currentWidth * 0.5F;
         float f20 = f17 + f6 * 0.5F;
         drawContext.getMatrices().pushMatrix();
         drawContext.getMatrices().translate(f19, f20);
         drawContext.getMatrices().scale(f18);
         drawContext.getMatrices().translate(-f19, -f20);
         Render2D.beginFrame(drawContext);
         RectUtil.drawClientRect(f16, f17, this.currentWidth, f6, 7.0F, f2);
         Render2D.flush();
         Render2D.beginFrame(drawContext);
         float f21 = f16 + 6.0F + 22.0F + 7.0F;
         float f22 = f21 + f15 * 0.5F;
         float f23 = 8.0F * f4;
         float f24 = (22.0F + f5 - 8.0F - f23 - 3.0F - 6.0F) / (2.0F + f4);
         float f25 = f17 + 6.0F;
         float f26 = f25 + 8.0F + f24 * f4;
         float f27 = f26 + f23 + f24;
         float f28 = f27 + 3.0F + f24;
         drawColoredName(text, f22 - f13 * 0.5F, f25, 8.0F, -1, f2 * 0.85F);
         float f31 = barRadius(3.0F);
         Render2D.rect(f21, f27 + 1.0F, f15, 3.0F, f31, ColorUtil.multAlpha(-14935006, f2 * 0.5F));
         float f32 = f15 * this.healthDisplay;
         drawBarFill(f21, f27 + 1.0F, f32, f15, 3.0F, f31, this.healthDisplay, f2);
         Render2D.msdfText("montserrat-medium", string, f22 - f14 * 0.5F, f28, 6.0F, ColorUtil.multAlpha(-3618608, f2));
         this.drawHeadBackground(drawContext, this.target, f16 + 6.0F + 1.0F, f7, 22.0F, 11.0F, 11.0F, f2, 0.0F);
         Render2D.flush();
         Render2D.beginFrame(drawContext);
         this.drawHitParticles(drawContext, f2);
         Render2D.flush();
         Render2D.beginFrame(drawContext);
         this.drawHeadForeground(drawContext, this.target, f16 + 6.0F + 1.0F, f7, 22.0F, 11.0F, 11.0F, f2);
         Render2D.flush();
         if (this.armorProgress > 0.02F) {
            this.drawArmorCentered(drawContext, this.target, f22, f26 + 1.0F, f2, this.armorProgress);
         }

         drawContext.getMatrices().popMatrix();
      }
   }

   private static float coloredWidth(Text text, float f) {
      boolean bl = NameTags.isStylized(text.getString());
      float[] fArray = new float[]{0.0F};
      text.visit((style, string) -> {
         fArray[0] += Render2D.msdfWidth("montserrat-semibold", normalize(stripCodes(string), bl), f);
         return Optional.empty();
      }, Style.EMPTY);
      return fArray[0];
   }

   @Override
   protected void render(DrawContext drawContext) {
      long l = System.nanoTime();
      float f = Math.min(0.1F, (float)(l - this.lastNs) / 1.E9F);
      this.lastNs = l;
      boolean bl3 = DragSystem.get().isDragModeActive();
      LivingEntity livingEntity = (LivingEntity)(bl3 ? MinecraftClient.getInstance().player : hoveredTarget());
      if (livingEntity != null) {
         this.target = livingEntity;
         this.lastSeenMs = System.currentTimeMillis();
      }

      boolean bl4 = this.target != null && !bl3 && this.target.isInvisible();
      boolean bl5 = this.target != null && !bl4 && (bl3 || System.currentTimeMillis() - this.lastSeenMs <= 1500L);
      boolean bl2 = componentEnabled() && bl5;
      if (bl2 != this.lastTargetVisible) {
         this.visibility.run(bl2 ? 1.0 : 0.0, bl2 ? 0.18 : 0.12, Easings.CUBIC_OUT, false);
         this.lastTargetVisible = bl2;
      }

      this.visibility.update();
      this.updateFollow(f);
      float f2 = this.visibility.get();
      if (f2 <= 0.01F) {
         if (!bl2) {
            this.target = null;
         }
      } else if (this.target != null) {
         boolean bl = Math.abs(this.followOffsetX) > 0.01F || Math.abs(this.followOffsetY) > 0.01F;
         if (bl) {
            drawContext.getMatrices().pushMatrix();
            drawContext.getMatrices().translate(this.followOffsetX, this.followOffsetY);
         }

         try {
            this.renderContent(drawContext, f, f2);
         } finally {
            if (bl) {
               drawContext.getMatrices().popMatrix();
            }
         }
      }
   }

   private void renderNew(DrawContext drawContext, float f, float f2) {
      float f4 = this.getX();
      float f5 = this.getY();
      ArrayList<ItemStack> arrayList = new ArrayList<>(NEW_SLOTS.length);
      boolean bl = false;

      for (EquipmentSlot equipmentSlot : NEW_SLOTS) {
         ItemStack itemStack = this.target.getEquippedStack(equipmentSlot);
         arrayList.add(itemStack);
         bl |= !itemStack.isEmpty();
      }

      boolean bl2 = armorEnabled() && bl;
      float f6 = bl2 ? 6.0F : 10.0F;
      this.armorProgress = this.armorProgress + ((bl2 ? 1.0F : 0.0F) - this.armorProgress) * (1.0F - (float)Math.exp(-f * f6));
      this.armorProgress = clamp01(this.armorProgress);
      float f7 = easeInOutCubic(this.armorProgress);
      float f8 = 45.0F - 10.0F * (1.0F - f7);
      float f9 = f5 + f8 - 5.0F - 8.0F;
      float f10 = f4 + 3.0F;
      float f11 = f5 + 3.0F;
      float f12 = f9 - 3.0F - f11;
      float f3;
      float f14 = f3 = Math.max(4.5F, 6.0F * clamp01(f12 / Math.max(26.0F, 1.0F)));
      InterfaceModule interfaceModule = InterfaceModule.getInstance();
      if (interfaceModule != null && interfaceModule.rectCornerRadius.getFloat() > 6.0F) {
         f14 = Math.min(interfaceModule.rectCornerRadius.getFloat(), f12 * 0.5F);
      }

      this.updateHitParticles(this.target, f10 + f12 * 0.5F, f11 + f12 * 0.5F);
      Text text = resolveName(this.target);
      float f15 = Math.max(1.0F, this.target.getMaxHealth());
      float f16 = Network.getResolvedHealth(this.target, true);
      float f17 = clamp01(f16 / f15);
      this.healthDisplay = this.healthDisplay + (f17 - this.healthDisplay) * (1.0F - (float)Math.exp(-f * 12.0F));
      float f18 = arrayList.size() * 8.0F + (arrayList.size() - 1) * 3.0F;
      float f19 = coloredWidth(text, 8.0F);
      float f20 = f10 + f12 + 3.0F;
      float f21 = easeOutCubic(clamp01(this.armorProgress / 0.6F));
      float f22 = (f18 + 2.0F) * f21;
      float f23 = Math.max(f19, f22);
      this.currentWidth = Math.max(84.0F, f20 - f4 + f23 + 3.0F);
      this.pinCenterOnResize();
      f4 = this.getX();
      f5 = this.getY();
      f9 = f5 + f8 - 5.0F - 8.0F;
      f10 = f4 + 3.0F;
      f11 = f5 + 3.0F;
      f20 = f10 + f12 + 3.0F;
      float f24 = 0.94F + f2 * 0.06F;
      float f25 = f4 + this.currentWidth * 0.5F;
      float f26 = f5 + f8 * 0.5F;
      drawContext.getMatrices().pushMatrix();
      drawContext.getMatrices().translate(f25, f26);
      drawContext.getMatrices().scale(f24);
      drawContext.getMatrices().translate(-f25, -f26);
      Render2D.beginFrame(drawContext);
      RectUtil.drawClientRect(f4, f5, this.currentWidth, f8, 7.0F, f2);
      Render2D.flush();
      Render2D.beginFrame(drawContext);
      float f29 = f11 + f12 - 10.0F;
      float f30 = f29 + 10.0F * 0.5F;
      float f31 = f20 + 1.0F;
      float f32 = f11 + f12 * 0.5F - 4.0F;
      float f33 = (f11 + f29 - 8.0F) * 0.5F;
      float f34 = lerp(f32, f33, f7) - 1.5F * (1.0F - f7);
      drawColoredName(text, f20, f34, 8.0F, -1, f2 * 0.85F);
      float f36 = f4 + 3.0F;
      float f37 = this.currentWidth - 6.0F;
      float f38 = barRadius(8.0F);
      Render2D.rect(f36, f9, f37, 8.0F, f38, ColorUtil.multAlpha(-14935006, f2 * 0.6F));
      float f39 = f37 * this.healthDisplay;
      drawBarFill(f36, f9, f39, f37, 8.0F, f38, this.healthDisplay, f2);
      String string = Math.round(Math.max(0.0F, f16)) + "HP";
      float f40 = Render2D.msdfWidth("small-pixel", string, 6.0F);
      float f41 = f36 + (f37 - f40) * 0.5F + 0.75F;
      float f42 = f36 + f39 - f40 - 2.0F;
      float f43 = Math.max(Math.min(f41, f42), f36 + 2.0F);
      float f44 = f9 + 1.0F - 0.3F;
      float f45 = f40 <= 0.0F ? 0.0F : clamp01((f36 + f39 - f43) / f40);
      float f46 = clamp01((f43 + f40 * 0.5F - f36) / Math.max(f37, 1.0F));
      int n2 = barFillColorAt(f46, this.healthDisplay);
      int n3 = ColorUtil.lerpColor(-14935006, n2, f45);
      float f47 = (0.2126F * (n3 >> 16 & 0xFF) + 0.7152F * (n3 >> 8 & 0xFF) + 0.0722F * (n3 & 0xFF)) / 255.0F;
      float f48 = clamp01(1.0F - f47 * 1.35F);
      this.hpGrayDisplay = this.hpGrayDisplay + (f48 - this.hpGrayDisplay) * (1.0F - (float)Math.exp(-f * 10.0F));
      int n4 = Math.round(clamp01(this.hpGrayDisplay) * 255.0F);
      int n5 = 0xFF000000 | n4 << 16 | n4 << 8 | n4;
      Render2D.msdfText("small-pixel", string, f43, f44, 6.0F, ColorUtil.multAlpha(n5, f2));
      float f49 = f4 + this.currentWidth - 3.0F + 1.0F;
      int n6 = Math.max(1, arrayList.size() - 1);
      float f50 = 1.0F - (float)Math.exp(-f * 14.0F);
      float f51 = 1.0F - (float)Math.exp(-f * 30.0F);
      float f52 = f31;

      for (int i = 0; i < arrayList.size(); i++) {
         float f53 = 0.35F + 0.25F * ((float)i / n6);
         boolean bl3 = f52 - 1.0F + 10.0F <= f49;
         int n = this.armorProgress > f53 && bl3 ? 1 : 0;
         this.slotAppear[i] = clamp01(this.slotAppear[i] + ((n != 0 ? 1.0F : 0.0F) - this.slotAppear[i]) * (n != 0 ? f50 : f51));
         f52 += 11.0F;
      }

      if (this.armorProgress > 0.02F) {
         float f54 = f31;

         for (int i = 0; i < arrayList.size(); i++) {
            float f55 = easeOutCubic(this.slotAppear[i]);
            if (f55 > 0.01F) {
               int n = Math.round(36.0F * clamp01(f2) * f55) << 24;
               Render2D.rect(f54 - 1.0F, f29, 10.0F, 10.0F, 2.0F * f55, n);
            }

            f54 += 11.0F;
         }
      }

      this.drawHeadBackground(drawContext, this.target, f10, f11, f12, f3, f14, f2, 1.0F * (1.0F - f7));
      Render2D.flush();
      Render2D.beginFrame(drawContext);
      this.drawHitParticles(drawContext, f2);
      Render2D.flush();
      Render2D.beginFrame(drawContext);
      this.drawHeadForeground(drawContext, this.target, f10, f11, f12, f3, f14, f2);
      Render2D.flush();
      float f56 = 0.5F * clamp01(f2);
      TextRenderer textRenderer = MinecraftClient.getInstance().textRenderer;
      float f57 = f31;

      for (int n = 0; n < arrayList.size(); n++) {
         ItemStack itemStack = arrayList.get(n);
         float f58;
         if (!itemStack.isEmpty() && this.armorProgress > 0.02F && (f58 = clamp01((this.slotAppear[n] - 0.35F) / 0.65F)) > 0.01F) {
            float f59 = f56 * easeOutBack(f58);
            drawContext.getMatrices().pushMatrix();
            Render2DCoordinateSpace.applyGuiScaleIndependence(drawContext.getMatrices());
            drawContext.getMatrices().translate(f57 + 4.0F, f30);
            drawContext.getMatrices().scale(f59, f59);
            drawContext.getMatrices().translate(-8.0F, -8.0F);
            drawContext.drawItem(itemStack, 0, 0);
            drawContext.drawStackOverlay(textRenderer, itemStack, 0, 0);
            drawContext.getMatrices().popMatrix();
         }

         f57 += 11.0F;
      }

      drawContext.getMatrices().popMatrix();
   }

   private static float barRadius(float f) {
      InterfaceModule interfaceModule = InterfaceModule.getInstance();
      float f2 = interfaceModule == null ? f * 0.5F : interfaceModule.rectCornerRadius.getFloat();
      return Math.max(0.0F, Math.min(f2, f * 0.5F));
   }

   private static int tintHurt(int n, LivingEntity livingEntity) {
      int n2 = livingEntity.hurtTime;
      if (n2 <= 0) {
         return n;
      } else {
         float f = Math.min(1.0F, n2 / 10.0F);
         int n3 = n >>> 24;
         int n4 = n >> 16 & 0xFF;
         int n5 = n >> 8 & 0xFF;
         int n6 = n & 0xFF;
         n4 = Math.round(n4 + (255 - n4) * f * 0.35F);
         n5 = Math.round(n5 * (1.0F - f * 0.65F));
         n6 = Math.round(n6 * (1.0F - f * 0.65F));
         return n3 << 24 | clamp255(n4) << 16 | clamp255(n5) << 8 | clamp255(n6);
      }
   }

   private static TargetHudModule hudModule() {
      return ModuleManager.get().get(TargetHudModule.class);
   }

   private static String stripCodes(String string) {
      String string2 = Formatting.strip(string);
      return string2 == null ? "" : string2;
   }

   private static int clamp255(int n) {
      return n < 0 ? 0 : Math.min(n, 255);
   }

   private static float lerp(float f, float f2, float f3) {
      return f + (f2 - f) * clamp01(f3);
   }

   private static LivingEntity hoveredTarget() {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      if (minecraftClient.crosshairTarget instanceof EntityHitResult entityHitResult) {
         if (!(entityHitResult.getEntity() instanceof LivingEntity livingEntity && livingEntity != minecraftClient.player)) {
            return null;
         } else if (!livingEntity.isAlive() || livingEntity.isRemoved() || livingEntity.getHealth() <= 0.0F) {
            return null;
         } else {
            return livingEntity.isInvisible() ? null : livingEntity;
         }
      } else {
         return null;
      }
   }

   @EventHandler
   private void onWorldRender(WorldRenderEvent worldRenderEvent) {
      this.followProjectionValid = false;
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      if (followEnabled() && this.target != null && minecraftClient.player != null && this.target != minecraftClient.player) {
         float f2 = worldRenderEvent.getPartialTicks();
         Vec3d vec3d = worldRenderEvent.getCamera() == null
            ? minecraftClient.gameRenderer.getCamera().getCameraPos()
            : worldRenderEvent.getCamera().getCameraPos();
         Vec3d vec3d2 = this.target.getLerpedPos(f2);
         this.followScratch
            .set((float)(vec3d2.x - vec3d.x), (float)(vec3d2.y + (this.target.getHeight() + 0.4F) * 0.5F - vec3d.y), (float)(vec3d2.z - vec3d.z), 1.0F);
         worldRenderEvent.getPositionMatrix().transform(this.followScratch);
         worldRenderEvent.getProjectionMatrix().transform(this.followScratch);
         if (!(this.followScratch.w <= 1.0E-4F)) {
            float f3 = (this.followScratch.x / this.followScratch.w * 0.5F + 0.5F) * Position.screenWidth();
            float f4 = (1.0F - (this.followScratch.y / this.followScratch.w * 0.5F + 0.5F)) * Position.screenHeight();
            if (!Float.isNaN(f3) && !Float.isNaN(f4)) {
               float f5 = 40.0F;
               this.followScratch
                  .set((float)(vec3d2.x - vec3d.x), (float)(vec3d2.y + this.target.getHeight() + 0.4F - vec3d.y), (float)(vec3d2.z - vec3d.z), 1.0F);
               worldRenderEvent.getPositionMatrix().transform(this.followScratch);
               worldRenderEvent.getProjectionMatrix().transform(this.followScratch);
               float f;
               if (this.followScratch.w > 1.0E-4F
                  && !Float.isNaN(f = (1.0F - (this.followScratch.y / this.followScratch.w * 0.5F + 0.5F)) * Position.screenHeight())) {
                  f5 = Math.abs(f4 - f);
               }

               this.followScreenX = f3;
               this.followScreenY = f4;
               this.followHalfH = f5;
               this.followProjectionValid = true;
            }
         }
      }
   }

   private static float easeOutBack(float f) {
      f = clamp01(f);
      float f3 = 1.70158F + 1.0F;
      float f4 = f - 1.0F;
      return 1.0F + f3 * f4 * f4 * f4 + 1.70158F * f4 * f4;
   }

   class HeadParticle {
      final float startX;
      final float startY;
      final float offsetX;
      final float offsetY;
      final long startTime;
      final long lifetime;
      final float gradient;

      HeadParticle(float startX, float startY, float offsetX, float offsetY, long startTime, long lifetime, float gradient) {
         this.startX = startX;
         this.startY = startY;
         this.offsetX = offsetX;
         this.offsetY = offsetY;
         this.startTime = startTime;
         this.lifetime = lifetime;
         this.gradient = gradient;
      }

      float progress(long currentTime) {
         return Math.max(0.0F, Math.min(1.0F, (float)(currentTime - this.startTime) / (float)this.lifetime));
      }
   }
}

