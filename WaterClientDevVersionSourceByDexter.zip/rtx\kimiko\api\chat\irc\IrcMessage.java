package rtx.kimiko.api.chat.irc;

public final class IrcMessage {
   private long id;
   private long timestamp;
   private String user;
   private String prefix;
   private String text;
   private String to;

   public IrcMessage(long id, long timestamp, String user, String prefix, String text, String to) {
      this.id = id;
      this.timestamp = timestamp;
      this.user = user;
      this.prefix = prefix;
      this.text = text;
      this.to = to;
   }

   public boolean isPrivate() {
      return this.to != null && !this.to.isBlank();
   }

   public long id() {
      return this.id;
   }

   public long timestamp() {
      return this.timestamp;
   }

   public String user() {
      return this.user;
   }

   public String prefix() {
      return this.prefix;
   }

   public String text() {
      return this.text;
   }

   public String to() {
      return this.to;
   }
}

