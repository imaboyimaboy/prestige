package rtx.kimiko.api.drags.components;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.ItemCooldownManager;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.s2c.play.CooldownUpdateS2CPacket;
import net.minecraft.util.Identifier;
import rtx.kimiko.api.drags.DragSystem;
import rtx.kimiko.api.events.EventBus;
import rtx.kimiko.api.events.EventHandler;
import rtx.kimiko.api.events.impl.network.PacketEvent;
import rtx.kimiko.api.modules.impl.Interface.CooldownsModule;
import rtx.kimiko.utils.render.render2d.Render2DCoordinateSpace;

public final class CooldownsComp extends ListHudComp {
   private static final Item[] PREVIEW_ITEMS = new Item[]{Items.ENDER_PEARL, Items.CHORUS_FRUIT, Items.MACE};
   private final Map<Identifier, CooldownsComp.Cooldown> cooldowns = new ConcurrentHashMap<>();
   private long previewSwitchMs;
   private int previewIndex;
   private static final float ITEM_SCALE = 0.5F;

   public CooldownsComp() {
      super("cooldowns", "Cooldowns", CooldownsModule.class, 118.0F, 82.0F);
      EventBus.get().subscribe(this);
   }

   @Override
   protected String headerIconGlyph() {
      return "i";
   }

   @Override
   protected List<ListHudComp.Row> collectRows() {
      long l = System.currentTimeMillis();
      if (MinecraftClient.getInstance().world == null) {
         this.cooldowns.clear();
      }

      ArrayList<ListHudComp.Row> arrayList = new ArrayList<>();
      Iterator<CooldownsComp.Cooldown> iterator = this.cooldowns.values().iterator();

      while (iterator.hasNext()) {
         CooldownsComp.Cooldown cooldown = iterator.next();
         long l2 = cooldown.endMs - l;
         if (l2 <= 0L) {
            iterator.remove();
         } else {
            ItemStack itemStack = resolveCooldownStack(cooldown.group);
            if (!itemStack.isEmpty()) {
               String string = cleanName(itemStack.getName().getString());
               ListHudComp.IconDrawer iconDrawer = (drawContext, f, f2, f3, f4) -> drawItemIcon(drawContext, itemStack, f, f2, f3, f4);
               arrayList.add(new Row(cooldown.group, string, formatRemaining(l2), iconDrawer));
            }
         }
      }

      if (arrayList.isEmpty() && DragSystem.get().isDragModeActive()) {
         arrayList.add(this.previewRow(l));
      }

      return arrayList;
   }

   private static String formatRemaining(long l) {
      float f = (float)l / 1000.0F;
      if (f >= 60.0F) {
         int n = Math.round(f);
         return n / 60 + ":" + String.format(Locale.ROOT, "%02d", n % 60);
      } else {
         return String.format(Locale.ROOT, "%.1fs", f);
      }
   }

   private static ItemStack resolveCooldownStack(Identifier identifier) {
      ClientPlayerEntity clientPlayerEntity = MinecraftClient.getInstance().player;
      if (clientPlayerEntity == null) {
         return ItemStack.EMPTY;
      } else {
         ItemCooldownManager itemCooldownManager = clientPlayerEntity.getItemCooldownManager();
         PlayerInventory playerInventory = clientPlayerEntity.getInventory();
         int n = playerInventory.size();

         for (int i = 0; i < n; i++) {
            ItemStack itemStack = playerInventory.getStack(i);
            if (!itemStack.isEmpty() && identifier.equals(itemCooldownManager.getGroup(itemStack))) {
               return itemStack;
            }
         }

         return ItemStack.EMPTY;
      }
   }

   private static void drawItemIcon(DrawContext drawContext, ItemStack itemStack, float f, float f2, float f3, float f4) {
      float f5 = Math.max(0.0F, Math.min(1.0F, f4));
      if (itemStack != null && !itemStack.isEmpty() && !(f5 <= 0.01F)) {
         float f6 = 0.5F * f5;
         float f7 = f + f3 * 0.5F;
         float f8 = f2 + f3 * 0.5F - 0.5F;
         drawContext.getMatrices().pushMatrix();
         Render2DCoordinateSpace.applyGuiScaleIndependence(drawContext.getMatrices());
         drawContext.getMatrices().translate(f7, f8);
         drawContext.getMatrices().scale(f6, f6);
         drawContext.getMatrices().translate(-8.0F, -8.0F);
         drawContext.drawItem(itemStack, 0, 0);
         drawContext.getMatrices().popMatrix();
      }
   }

   @EventHandler
   private void onPacket(PacketEvent packetEvent) {
      if (packetEvent.isReceive() && packetEvent.getPacket() instanceof CooldownUpdateS2CPacket cooldownUpdateS2CPacket) {
         Identifier identifier = cooldownUpdateS2CPacket.cooldownGroup();
         if (identifier != null) {
            if (cooldownUpdateS2CPacket.cooldown() <= 0) {
               this.cooldowns.remove(identifier);
            } else {
               long l = System.currentTimeMillis() + cooldownUpdateS2CPacket.cooldown() * 50L;
               this.cooldowns.put(identifier, new Cooldown(identifier, l));
            }
         }
      }
   }

   private static String cleanName(String string) {
      return string == null
         ? ""
         : string.replaceAll("\\[[^\\[\\]]*\\]", " ").replaceAll("<[^<>]*>", " ").replaceAll("\\{[^{}]*\\}", " ").replaceAll("\\s+", " ").trim();
   }

   private ListHudComp.Row previewRow(long l) {
      if (l - this.previewSwitchMs >= 1000L) {
         this.previewIndex = (this.previewIndex + 1) % PREVIEW_ITEMS.length;
         this.previewSwitchMs = l;
      }

      ItemStack itemStack = PREVIEW_ITEMS[this.previewIndex].getDefaultStack();
      return new Row(
         "preview", "Example cooldown", "**:**", (drawContext, f, f2, f3, f4) -> drawItemIcon(drawContext, itemStack, f, f2, f3, f4), null
      );
   }

   final class Cooldown {
      private Identifier group;
      private long endMs;

      private Cooldown(Identifier group, long endMs) {
         this.group = group;
         this.endMs = endMs;
      }

      public Identifier group() {
         return this.group;
      }

      public long endMs() {
         return this.endMs;
      }
   }
}

