package rtx.kimiko.api.mods.geckolib.loading.math.function.generic;

import rtx.kimiko.api.mods.geckolib.animation.state.ControllerState;
import rtx.kimiko.api.mods.geckolib.loading.math.MathValue;
import rtx.kimiko.api.mods.geckolib.loading.math.function.MathFunction;

public final class ATan2Function extends MathFunction {
   private MathValue mathValue;
   private MathValue mathValue2;

   public ATan2Function(MathValue... mathValueArray) {
      super(mathValueArray);
      this.mathValue = mathValueArray[0];
      this.mathValue2 = mathValueArray[1];
   }

   @Override
   public String getName() {
      return "math.atan2";
   }

   @Override
   public double compute(ControllerState controllerState) {
      return Math.atan2(this.mathValue.get(controllerState), this.mathValue2.get(controllerState)) * 180.0F / (float)Math.PI;
   }

   @Override
   public MathValue[] getArgs() {
      return new MathValue[]{this.mathValue, this.mathValue2};
   }

   @Override
   public int getMinArgs() {
      return 2;
   }
}

