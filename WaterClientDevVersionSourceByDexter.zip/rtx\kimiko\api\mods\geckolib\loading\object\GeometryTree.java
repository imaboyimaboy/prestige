package rtx.kimiko.api.mods.geckolib.loading.object;

import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import java.util.Map;
import rtx.kimiko.api.mods.geckolib.loading.definition.geometry.GeometryDescription;
import rtx.kimiko.api.mods.geckolib.loading.json.raw.Bone;
import rtx.kimiko.api.mods.geckolib.loading.json.raw.MinecraftGeometry;
import rtx.kimiko.api.mods.geckolib.loading.json.raw.Model;

public final class GeometryTree {
   private Map<String, BoneStructure> topLevelBones;
   private GeometryDescription properties;

   public GeometryTree(Map<String, BoneStructure> topLevelBones, GeometryDescription properties) {
      this.topLevelBones = topLevelBones;
      this.properties = properties;
   }

   public static GeometryTree fromModel(Model model) {
      Object2ObjectOpenHashMap object2ObjectOpenHashMap = new Object2ObjectOpenHashMap();
      MinecraftGeometry minecraftGeometry = model.minecraftGeometry()[0];
      Bone[] boneArray = minecraftGeometry.bones();
      Object2ObjectOpenHashMap object2ObjectOpenHashMap2 = new Object2ObjectOpenHashMap(boneArray.length);

      for (Bone bone : boneArray) {
         Object object = new BoneStructure(bone);
         object2ObjectOpenHashMap2.put(bone.name(), object);
         if (bone.parent() == null) {
            object2ObjectOpenHashMap.put(bone.name(), object);
         }
      }

      for (Bone bonex : boneArray) {
         Object object = bonex.parent();
         if (object != null) {
            String string = bonex.name();
            if (((String)object).equals(string)) {
               throw new IllegalArgumentException("Invalid model definition. Bone has defined itself as its own parent: null");
            }

            BoneStructure boneStructure = (BoneStructure)object2ObjectOpenHashMap2.get(object);
            if (boneStructure == null) {
               throw new IllegalArgumentException(
                  "Invalid model definition. Found bone with undefined parent (child -> parent): " + string + " -> " + (String)object
               );
            }

            boneStructure.children().put(string, (BoneStructure)object2ObjectOpenHashMap2.get(string));
         }
      }

      return new GeometryTree(object2ObjectOpenHashMap, minecraftGeometry.geometryDescription());
   }

   public Map<String, BoneStructure> topLevelBones() {
      return this.topLevelBones;
   }

   public GeometryDescription properties() {
      return this.properties;
   }
}

