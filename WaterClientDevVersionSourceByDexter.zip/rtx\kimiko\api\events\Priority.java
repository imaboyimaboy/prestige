package rtx.kimiko.api.events;

public enum Priority {
   HIGHEST,
   HIGH,
   NORMAL,
   LOW,
   LOWEST,
   MONITOR;

   private static Priority[] $values() {
      return new Priority[]{HIGHEST, HIGH, NORMAL, LOW, LOWEST, MONITOR};
   }
}

