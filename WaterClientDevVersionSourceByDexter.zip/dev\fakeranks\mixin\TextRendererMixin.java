package dev.fakeranks.mixin;

import dev.fakeranks.UniversalNameReplacer;
import net.minecraft.text.OrderedText;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(
   targets = {"net/minecraft/client/font/TextRenderer"},
   remap = false
)
public abstract class TextRendererMixin {
   @ModifyVariable(
      method = {"draw", "prepare", "getWidth", "trimToWidth", "trimToWidth", "mirror"},
      at = @At("HEAD"),
      argsOnly = true,
      ordinal = 0,
      require = 0
   )
   private String fakeranks$replaceRenderedString(String value) {
      return UniversalNameReplacer.replace(value);
   }

   @ModifyVariable(
      method = {"draw", "drawWithOutline", "prepare", "getWidth"},
      at = @At("HEAD"),
      argsOnly = true,
      ordinal = 0,
      require = 0
   )
   private OrderedText fakeranks$replaceRenderedOrderedText(OrderedText value) {
      return UniversalNameReplacer.replace(value);
   }
}

