package rtx.kimiko.api.mods.acountswiher.ru.vidtu.ias.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Objects;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rtx.kimiko.api.mods.acountswiher.ru.vidtu.ias.account.Account;
import rtx.kimiko.api.mods.acountswiher.ru.vidtu.ias.config.migrator.Migrator;
import rtx.kimiko.api.mods.acountswiher.ru.vidtu.ias.utils.GSONUtils;

public final class IASConfig {
   private static final Gson GSON = new GsonBuilder().excludeFieldsWithModifiers(new int[]{128, 16}).create();
   public static final Logger LOGGER = LoggerFactory.getLogger("IAS/IASConfig");
   public static boolean titleText = true;
   public static String titleTextX = null;
   public static String titleTextY = null;
   public static TextAlign titleTextAlign = TextAlign.LEFT;
   public static boolean titleButton = true;
   public static String titleButtonX = null;
   public static String titleButtonY = null;
   public static boolean serversText = true;
   public static String serversTextX = null;
   public static String serversTextY = null;
   public static TextAlign serversTextAlign = TextAlign.LEFT;
   public static boolean serversButton = true;
   public static String serversButtonX = null;
   public static String serversButtonY = null;
   public static boolean allowNoCrypt = false;
   public static boolean nickWarns = true;
   public static boolean unexpectedPigs = true;
   public static boolean barNick = false;
   public static ServerMode server = ServerMode.AVAILABLE;
   public static boolean passwordEchoing = true;
   public static boolean restoreLastAccount = true;
   public static String lastAccountName = null;
   public static String lastAccountUuid = null;
   public static boolean lastAccountOnline = true;

   private IASConfig() {
   }

   public static void load(Path path) {
      try {
         LOGGER.debug("IAS: Loading config for {}...", path);
         Path path2 = path.resolve("ias.json");
         if (!Files.isRegularFile(path2)) {
            LOGGER.debug("IAS: Config not found. Saving...");
            save(path);
            return;
         }

         String string = Files.readString(path2);
         JsonObject jsonObject = (JsonObject)GSON.fromJson(string, JsonObject.class);
         int n = jsonObject.has("version") ? GSONUtils.getIntOrThrow(jsonObject, "version") : 1;
         LOGGER.trace("IAS: Loaded config version is {}.", n);
         Migrator migrator = Migrator.fromVersion(n);
         if (migrator == null) {
            GSON.fromJson(jsonObject, IASConfig.class);
            LOGGER.debug("IAS: Config loaded.");
            return;
         }

         LOGGER.info("IAS: Migrating old config version {} via {}.", n, migrator);
         migrator.load(jsonObject);
         LOGGER.info("IAS: Migrated old config.");
         save(path);
      } catch (Throwable var9) {
         throw new RuntimeException("Unable to load IAS config.", var9);
      } finally {
         titleTextAlign = Objects.requireNonNullElse(titleTextAlign, TextAlign.LEFT);
         serversTextAlign = Objects.requireNonNullElse(serversTextAlign, TextAlign.LEFT);
         server = Objects.requireNonNullElse(server, ServerMode.AVAILABLE);
      }
   }

   public static void save(Path path) {
      try {
         LOGGER.debug("IAS: Saving config into {}...", path);
         titleTextAlign = Objects.requireNonNullElse(titleTextAlign, TextAlign.LEFT);
         serversTextAlign = Objects.requireNonNullElse(serversTextAlign, TextAlign.LEFT);
         server = Objects.requireNonNullElse(server, ServerMode.AVAILABLE);
         Path path2 = path.resolve("ias.json");
         JsonObject jsonObject = (JsonObject)GSON.toJsonTree(new IASConfig());
         jsonObject.addProperty("version", 4);
         String string = GSON.toJson(jsonObject);
         Files.createDirectories(path2.getParent());
         Files.writeString(
            path2,
            string,
            StandardOpenOption.CREATE,
            StandardOpenOption.TRUNCATE_EXISTING,
            StandardOpenOption.WRITE,
            StandardOpenOption.SYNC,
            StandardOpenOption.DSYNC
         );
         LOGGER.debug("IAS: Config saved to {}.", path2);
      } catch (Throwable var4) {
         throw new RuntimeException("Unable to save IAS config.", var4);
      }
   }

   public static void rememberLastAccount(Account account, boolean bl) {
      lastAccountName = account.name();
      lastAccountUuid = account.uuid().toString();
      lastAccountOnline = bl;
   }

   public static void clearLastAccount() {
      lastAccountName = null;
      lastAccountUuid = null;
      lastAccountOnline = true;
   }

   public static boolean matchesLastAccount(Account account) {
      return account != null && lastAccountName != null && lastAccountUuid != null
         ? lastAccountName.equalsIgnoreCase(account.name()) && lastAccountUuid.equalsIgnoreCase(account.uuid().toString())
         : false;
   }

   public static boolean useServerAuth() {
      if (server == null) {
         return true;
      } else {
         return switch (server) {
            case ALWAYS -> true;
            case NEVER -> false;
            case AVAILABLE -> true;
         };
      }
   }
}

