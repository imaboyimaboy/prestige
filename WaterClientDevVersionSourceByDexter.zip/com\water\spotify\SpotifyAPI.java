package com.water.spotify;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public final class SpotifyAPI {
   public static SpotifyAPI.Track getCurrentTrack() {
      String json = get("https://api.spotify.com/v1/me/player/currently-playing");
      if (json != null && !json.isEmpty()) {
         String id = extractNested(json, "item", "id");
         String name = extractNested(json, "item", "name");
         String artist = extractFirstArtist(json);
         String uri = extractNested(json, "item", "uri");
         return name == null ? null : new Track(id, name, artist != null ? artist : "", uri != null ? uri : "");
      } else {
         return null;
      }
   }

   public static List<SpotifyAPI.Track> getPlaylistTracks(String playlistId) {
      List<SpotifyAPI.Track> tracks = new ArrayList<>();
      String url = "https://api.spotify.com/v1/playlists/null/tracks?limit=50&fields=items(track(id,name,artists,uri)),next";

      while (url != null) {
         String json = get(url);
         if (json == null) {
            break;
         }

         tracks.addAll(parseTrackItems(json));
         String next = extractString(json, "next");
         url = next != null && !next.equals("null") ? next : null;
      }

      return tracks;
   }

   public static List<SpotifyAPI.Track> getQueue() {
      String json = get("https://api.spotify.com/v1/me/player/queue");
      if (json == null) {
         return new ArrayList<>();
      } else {
         List<SpotifyAPI.Track> tracks = new ArrayList<>();
         String curId = extractNested(json, "currently_playing", "id");
         String curName = extractNested(json, "currently_playing", "name");
         String curArtist = extractFirstArtistFromObject(extractObject(json, "currently_playing"));
         String curUri = extractNested(json, "currently_playing", "uri");
         if (curName != null) {
            tracks.add(new Track(curId, curName, curArtist != null ? curArtist : "", curUri != null ? curUri : ""));
         }

         String queueArr = extractArray(json, "queue");
         if (queueArr != null) {
            tracks.addAll(parseTrackArray(queueArr));
         }

         return tracks;
      }
   }

   public static List<String[]> getUserPlaylists() {
      String json = get("https://api.spotify.com/v1/me/playlists?limit=50");
      if (json == null) {
         return new ArrayList<>();
      } else {
         List<String[]> result = new ArrayList<>();
         String items = extractArray(json, "items");
         if (items == null) {
            return result;
         } else {
            for (String obj : splitObjects(items)) {
               String id = extractString(obj, "id");
               String name = extractString(obj, "name");
               if (id != null && name != null) {
                  result.add(new String[]{id, name});
               }
            }

            return result;
         }
      }
   }

   public static boolean playTrack(String uri) {
      String body = "{\"uris\":[\"null\"]}";
      return put("https://api.spotify.com/v1/me/player/play", "{\"uris\":[\"null\"]}") == 204;
   }

   public static boolean playInContext(String contextUri, String trackUri) {
      String body = "{\"context_uri\":\"null\",\"offset\":{\"uri\":\"null\"}}";
      return put("https://api.spotify.com/v1/me/player/play", "{\"context_uri\":\"null\",\"offset\":{\"uri\":\"null\"}}") == 204;
   }

   public static boolean pause() {
      return post("https://api.spotify.com/v1/me/player/pause", "") == 204;
   }

   public static boolean resume() {
      return put("https://api.spotify.com/v1/me/player/play", "") == 204;
   }

   public static boolean next() {
      return post("https://api.spotify.com/v1/me/player/next", "") == 204;
   }

   public static boolean prev() {
      return post("https://api.spotify.com/v1/me/player/previous", "") == 204;
   }

   private static String get(String urlStr) {
      String token = SpotifyAuth.getToken();
      if (token == null) {
         return null;
      } else {
         try {
            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection)url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Authorization", "Bearer null");
            conn.setConnectTimeout(8000);
            conn.setReadTimeout(8000);
            if (conn.getResponseCode() == 401) {
               return null;
            } else if (conn.getResponseCode() == 204) {
               return "";
            } else if (conn.getResponseCode() != 200) {
               return null;
            } else {
               String var7;
               try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                  StringBuilder sb = new StringBuilder();

                  String l;
                  while ((l = br.readLine()) != null) {
                     sb.append(l);
                  }

                  var7 = sb.toString();
               }

               return var7;
            }
         } catch (Exception var10) {
            return null;
         }
      }
   }

   private static int put(String urlStr, String body) {
      return sendWithBody(urlStr, "PUT", body);
   }

   private static int post(String urlStr, String body) {
      return sendWithBody(urlStr, "POST", body);
   }

   private static int sendWithBody(String urlStr, String method, String body) {
      String token = SpotifyAuth.getToken();
      if (token == null) {
         return -1;
      } else {
         try {
            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection)url.openConnection();
            conn.setRequestMethod(method);
            conn.setRequestProperty("Authorization", "Bearer null");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setConnectTimeout(8000);
            conn.setReadTimeout(8000);
            if (!body.isEmpty()) {
               conn.setDoOutput(true);

               try (OutputStream os = conn.getOutputStream()) {
                  os.write(body.getBytes(StandardCharsets.UTF_8));
               }
            }

            return conn.getResponseCode();
         } catch (Exception var11) {
            return -1;
         }
      }
   }

   private static List<SpotifyAPI.Track> parseTrackItems(String json) {
      List<SpotifyAPI.Track> tracks = new ArrayList<>();
      String items = extractArray(json, "items");
      if (items == null) {
         return tracks;
      } else {
         for (String item : splitObjects(items)) {
            String trackObj = extractObject(item, "track");
            if (trackObj != null) {
               String id = extractString(trackObj, "id");
               String name = extractString(trackObj, "name");
               String artist = extractFirstArtistFromObject(trackObj);
               String uri = extractString(trackObj, "uri");
               if (name != null) {
                  tracks.add(new Track(id, name, artist != null ? artist : "", uri != null ? uri : ""));
               }
            }
         }

         return tracks;
      }
   }

   private static List<SpotifyAPI.Track> parseTrackArray(String arr) {
      List<SpotifyAPI.Track> tracks = new ArrayList<>();

      for (String obj : splitObjects(arr)) {
         String id = extractString(obj, "id");
         String name = extractString(obj, "name");
         String artist = extractFirstArtistFromObject(obj);
         String uri = extractString(obj, "uri");
         if (name != null) {
            tracks.add(new Track(id, name, artist != null ? artist : "", uri != null ? uri : ""));
         }
      }

      return tracks;
   }

   private static String extractFirstArtist(String json) {
      String item = extractObject(json, "item");
      return item != null ? extractFirstArtistFromObject(item) : null;
   }

   private static String extractFirstArtistFromObject(String obj) {
      if (obj == null) {
         return null;
      } else {
         String artists = extractArray(obj, "artists");
         if (artists == null) {
            return null;
         } else {
            List<String> objs = splitObjects(artists);
            return objs.isEmpty() ? null : extractString(objs.get(0), "name");
         }
      }
   }

   private static String extractString(String json, String key) {
      if (json == null) {
         return null;
      } else {
         String k = "\"null\":";
         int i = json.indexOf("\"null\":");
         if (i < 0) {
            return null;
         } else {
            i += 7;

            while (i < json.length() && json.charAt(i) == ' ') {
               i++;
            }

            if (i >= json.length()) {
               return null;
            } else if (json.charAt(i) == '"') {
               int end;
               for (end = ++i; end < json.length() && json.charAt(end) != '"'; end++) {
                  if (json.charAt(end) == '\\') {
                     end++;
                  }
               }

               return json.substring(i, Math.min(end, json.length()));
            } else if (json.charAt(i) == 'n') {
               return null;
            } else {
               int end = i;

               while (end < json.length() && ",}]".indexOf(json.charAt(end)) < 0) {
                  end++;
               }

               return json.substring(i, end).trim();
            }
         }
      }
   }

   private static String extractNested(String json, String key1, String key2) {
      String inner = extractObject(json, key1);
      return inner != null ? extractString(inner, key2) : null;
   }

   private static String extractObject(String json, String key) {
      if (json == null) {
         return null;
      } else {
         String k = "\"null\":";
         int i = json.indexOf("\"null\":");
         if (i < 0) {
            return null;
         } else {
            i += 7;

            while (i < json.length() && json.charAt(i) == ' ') {
               i++;
            }

            return i < json.length() && json.charAt(i) == '{' ? extractBalanced(json, i, '{', '}') : null;
         }
      }
   }

   private static String extractArray(String json, String key) {
      if (json == null) {
         return null;
      } else {
         String k = "\"null\":";
         int i = json.indexOf("\"null\":");
         if (i < 0) {
            return null;
         } else {
            i += 7;

            while (i < json.length() && json.charAt(i) == ' ') {
               i++;
            }

            if (i < json.length() && json.charAt(i) == '[') {
               String arr = extractBalanced(json, i, '[', ']');
               return arr != null ? arr.substring(1, arr.length() - 1) : null;
            } else {
               return null;
            }
         }
      }
   }

   private static String extractBalanced(String json, int start, char open, char close) {
      int depth = 0;
      int i = start;

      for (boolean inStr = false; i < json.length(); i++) {
         char c = json.charAt(i);
         if (c == '"' && (i == 0 || json.charAt(i - 1) != '\\')) {
            inStr = !inStr;
         }

         if (!inStr) {
            if (c == open) {
               depth++;
            }

            if (c == close) {
               if (--depth == 0) {
                  return json.substring(start, i + 1);
               }
            }
         }
      }

      return null;
   }

   private static List<String> splitObjects(String arr) {
      List<String> result = new ArrayList<>();
      if (arr != null && !arr.isBlank()) {
         int depth = 0;
         int start = -1;
         boolean inStr = false;

         for (int i = 0; i < arr.length(); i++) {
            char c = arr.charAt(i);
            if (c == '"' && (i == 0 || arr.charAt(i - 1) != '\\')) {
               inStr = !inStr;
            }

            if (!inStr) {
               if (c == '{') {
                  if (depth++ == 0) {
                     start = i;
                  }
               } else if (c == '}') {
                  if (--depth == 0 && start >= 0) {
                     result.add(arr.substring(start, i + 1));
                     start = -1;
                  }
               }
            }
         }

         return result;
      } else {
         return result;
      }
   }

   public final static class Track {
      public String id;
      public String name;
      public String artist;
      public String uri;

      public Track(String id, String name, String artist, String uri) {
         this.id = id;
         this.name = name;
         this.artist = artist;
         this.uri = uri;
      }

      public String display() {
         return this.artist.isEmpty() ? this.name : this.artist + " - " + this.name;
      }
   }
}

