package rtx.kimiko.api.chat.commands.helpers;

import java.util.List;
import java.util.function.Function;
import net.minecraft.text.Text;
import rtx.kimiko.utils.chat.ChatMessage;

public class Paginator<T> {
   private List<T> items;
   private int page = 1;
   private final int itemsPerPage = 8;

   public Paginator(List<T> items) {
      this.items = items;
   }

   public void setPage(int page) {
      this.page = Math.max(1, page);
   }

   public void display(Runnable headerPrinter, Function<T, Text> rowMapper, String cmdPrefix) {
      if (headerPrinter != null) {
         headerPrinter.run();
      }

      if (this.items != null && !this.items.isEmpty()) {
         int maxPages = (this.items.size() + 8 - 1) / 8;
         int curPage = Math.min(this.page, maxPages);
         int start = (curPage - 1) * 8;
         int end = Math.min(start + 8, this.items.size());

         for (int i = start; i < end; i++) {
            ChatMessage.brandmessage(rowMapper.apply(this.items.get(i)));
         }
      }
   }
}

