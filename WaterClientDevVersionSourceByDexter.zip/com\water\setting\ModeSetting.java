package com.water.setting;

import java.util.List;

public final class ModeSetting extends Setting<String> {
   private List<String> modes;
   private List<String> legacyNames;

   public ModeSetting(String name, String defaultValue, String... modes) {
      this(name, defaultValue, new String[0], modes);
   }

   public ModeSetting(String name, String defaultValue, String[] legacyNames, String... modes) {
      super(name, defaultValue);
      if (modes != null && modes.length != 0) {
         this.modes = List.of(modes);
         this.legacyNames = legacyNames == null ? List.of() : List.of(legacyNames);
         this.setValue(defaultValue);
      } else {
         throw new IllegalArgumentException("ModeSetting requires at least one mode");
      }
   }

   public List<String> getModes() {
      return this.modes;
   }

   public void cycleNext() {
      this.setValue(this.getModeRelativeToCurrent(1));
   }

   public void cyclePrevious() {
      this.setValue(this.getModeRelativeToCurrent(-1));
   }

   public boolean check(String mode) {
      return this.normalize(mode).equalsIgnoreCase(this.getValue());
   }

   public void setValue(String value) {
      super.setValue(this.resolveMode(value));
   }

   @Override
   public boolean matchesName(String settingName) {
      if (super.matchesName(settingName)) {
         return true;
      } else {
         String normalized = this.normalize(settingName);

         for (String legacyName : this.legacyNames) {
            if (legacyName.equalsIgnoreCase(normalized)) {
               return true;
            }
         }

         return false;
      }
   }

   private String getModeRelativeToCurrent(int direction) {
      int size = this.modes.size();
      if (size == 0) {
         return "";
      } else {
         String current = this.getValue();

         for (int i = 0; i < size; i++) {
            if (this.modes.get(i).equalsIgnoreCase(current)) {
               int nextIndex = Math.floorMod(i + direction, size);
               return this.modes.get(nextIndex);
            }
         }

         return this.modes.getFirst();
      }
   }

   private String resolveMode(String value) {
      String normalized = this.normalize(value);

      for (String mode : this.modes) {
         if (mode.equalsIgnoreCase(normalized)) {
            return mode;
         }
      }

      return this.modes.getFirst();
   }

   private String normalize(String value) {
      return value == null ? "" : value.trim();
   }
}

