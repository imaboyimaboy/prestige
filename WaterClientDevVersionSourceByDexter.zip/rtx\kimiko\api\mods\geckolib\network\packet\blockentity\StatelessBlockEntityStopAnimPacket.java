package rtx.kimiko.api.mods.geckolib.network.packet.blockentity;

import java.util.function.Consumer;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.network.packet.CustomPayload.Id;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import rtx.kimiko.api.mods.geckolib.GeckoLibConstants;
import rtx.kimiko.api.mods.geckolib.animatable.GeoBlockEntity;
import rtx.kimiko.api.mods.geckolib.animatable.stateless.StatelessGeoBlockEntity;
import rtx.kimiko.api.mods.geckolib.network.packet.MultiloaderPacket;
import rtx.kimiko.api.mods.geckolib.util.ClientUtil;

public final class StatelessBlockEntityStopAnimPacket implements MultiloaderPacket {
   private BlockPos blockPos;
   private String animation;
   public static final Id<StatelessBlockEntityStopAnimPacket> TYPE = new Id(GeckoLibConstants.id("stateless_block_entity_stop_anim"));
   public static final PacketCodec<PacketByteBuf, StatelessBlockEntityStopAnimPacket> CODEC = PacketCodec.tuple(
      BlockPos.PACKET_CODEC,
      StatelessBlockEntityStopAnimPacket::blockPos,
      PacketCodecs.STRING,
      StatelessBlockEntityStopAnimPacket::animation,
      StatelessBlockEntityStopAnimPacket::new
   );

   public StatelessBlockEntityStopAnimPacket(BlockPos blockPos, String animation) {
      this.blockPos = blockPos;
      this.animation = animation;
   }

   public Id<? extends CustomPayload> getId() {
      return TYPE;
   }

   @Override
   public void receiveMessage(PlayerEntity playerEntity, Consumer<Runnable> consumer) {
      consumer.accept(
         () -> {
            World world = ClientUtil.getLevel();
            GeoBlockEntity geoBlockEntity;
            BlockEntity blockEntity;
            if (world != null
               && (blockEntity = world.getBlockEntity(this.blockPos)) instanceof GeoBlockEntity
               && (geoBlockEntity = (GeoBlockEntity)blockEntity) instanceof StatelessGeoBlockEntity) {
               StatelessGeoBlockEntity statelessGeoBlockEntity = (StatelessGeoBlockEntity)geoBlockEntity;
               statelessGeoBlockEntity.handleClientAnimationStop(geoBlockEntity, 0L, this.animation);
            }
         }
      );
   }

   public BlockPos blockPos() {
      return this.blockPos;
   }

   public String animation() {
      return this.animation;
   }
}

