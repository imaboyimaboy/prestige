package com.water.spotify.lyrics;

import com.water.utils.RenderUtils;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.font.TextRenderer.TextLayerType;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public class LyricParticle3D {
   private String text;
   private Vec3d basePosition;
   private long spawnTimeMs;
   private long durationMs;
   private float floatHeight;
   private float tiltSign;
   private boolean forceExpire = false;

   public LyricParticle3D(String text, Vec3d basePosition, long spawnTimeMs, long durationMs, float floatHeight) {
      this.text = text;
      this.basePosition = basePosition;
      this.spawnTimeMs = spawnTimeMs;
      this.durationMs = durationMs;
      this.floatHeight = floatHeight;
      this.tiltSign = Math.random() > 0.5 ? 1.0F : -1.0F;
   }

   public Vec3d getBasePosition() {
      return this.basePosition;
   }

   public void dismiss() {
      this.forceExpire = true;
   }

   public boolean isDead(long nowMs) {
      return this.forceExpire || nowMs - this.spawnTimeMs >= this.durationMs;
   }

   public String getText() {
      return this.text;
   }

   public void render(MatrixStack matrices, Camera camera, TextRenderer font, String animMode, int colorRgb, long nowMs) {
      long elapsed = nowMs - this.spawnTimeMs;
      if (elapsed >= 0L && elapsed <= this.durationMs && !this.forceExpire) {
         double offsetY;
         float animScale;
         float rotationTilt;
         String displayText;
         float alpha;
         label72: {
            float progress = MathHelper.clamp((float)elapsed / (float)this.durationMs, 0.0F, 1.0F);
            alpha = 1.0F;
            offsetY = 0.0;
            animScale = 1.0F;
            rotationTilt = 0.0F;
            displayText = this.text;
            byte renderX = -1;
            switch (animMode.hashCode()) {
               case 2181788:
                  if (animMode.equals("Fade")) {
                     if (progress < 0.15F) {
                        alpha = progress / 0.15F;
                     } else if (progress < 0.8F) {
                        alpha = 1.0F;
                     } else {
                        alpha = 1.0F - (progress - 0.8F) / 0.2F;
                     }
                     break label72;
                  }
                  break;
               case 705729945:
                  if (animMode.equals("PopScale")) {
                     if (progress < 0.18F) {
                        float t = progress / 0.18F;
                        alpha = easeOutCubic(t);
                        animScale = 0.35F + 0.65F * easeOutBack(t);
                        offsetY = -0.04 * (1.0F - easeOutCubic(t));
                     } else if (progress < 0.8F) {
                        alpha = 1.0F;
                        animScale = 1.0F;
                        offsetY = 0.0;
                     } else {
                        float t = (progress - 0.8F) / 0.2F;
                        alpha = 1.0F - easeInCubic(t);
                        animScale = 1.0F - 0.05F * t;
                        offsetY = 0.03 * easeInCubic(t);
                     }
                     break label72;
                  }
                  break;
               case 999415928:
                  if (animMode.equals("KineticSlide")) {
                     if (progress < 0.2F) {
                        float t = progress / 0.2F;
                        alpha = easeOutCubic(t);
                        offsetY = -0.15 * (1.0F - easeOutCubic(t));
                        animScale = 0.92F + 0.08F * t;
                        rotationTilt = (1.0F - t) * 4.0F * this.tiltSign;
                     } else if (progress < 0.8F) {
                        alpha = 1.0F;
                        offsetY = 0.0;
                        animScale = 1.0F;
                        rotationTilt = 0.0F;
                     } else {
                        float t = (progress - 0.8F) / 0.2F;
                        alpha = 1.0F - easeInCubic(t);
                        offsetY = 0.05 * easeInCubic(t);
                        animScale = 1.0F - 0.04F * t;
                     }
                     break label72;
                  }
                  break;
               case 1599290445:
                  if (animMode.equals("Typewriter")) {
                     if (progress < 0.3F) {
                        float typeProgress = progress / 0.3F;
                        int visibleChars = Math.min(this.text.length(), (int)Math.ceil(this.text.length() * typeProgress));
                        displayText = this.text.substring(0, Math.max(1, visibleChars));
                        alpha = Math.min(1.0F, progress / 0.08F);
                        offsetY = progress * (this.floatHeight * 0.2);
                     } else if (progress < 0.75F) {
                        displayText = this.text;
                        alpha = 1.0F;
                        offsetY = progress * (this.floatHeight * 0.2);
                     } else {
                        float eraseProgress = (progress - 0.75F) / 0.25F;
                        int remainingChars = Math.max(0, this.text.length() - (int)Math.floor(this.text.length() * eraseProgress));
                        displayText = this.text.substring(0, remainingChars);
                        alpha = 1.0F - eraseProgress * 0.7F;
                        offsetY = progress * (this.floatHeight * 0.2);
                     }
                     break label72;
                  }
            }

            if (progress < 0.15F) {
               float t = progress / 0.15F;
               alpha = easeOutCubic(t);
               offsetY = -0.06 * (1.0F - easeOutCubic(t));
               animScale = 0.93F + 0.07F * easeOutBack(t);
            } else if (progress < 0.8F) {
               alpha = 1.0F;
               offsetY = 0.0;
               animScale = 1.0F;
            } else {
               float t = (progress - 0.8F) / 0.2F;
               alpha = 1.0F - easeInCubic(t);
               offsetY = 0.04 * easeInCubic(t);
               animScale = 1.0F - 0.03F * t;
            }
         }

         alpha = MathHelper.clamp(alpha, 0.0F, 1.0F);
         if (!(alpha <= 0.001F) && displayText != null && !displayText.isBlank()) {
            Vec3d camPos = RenderUtils.getCameraPos(camera);
            double renderX = this.basePosition.x - camPos.x;
            double renderY = this.basePosition.y + offsetY - camPos.y;
            double renderZ = this.basePosition.z - camPos.z;
            matrices.push();
            matrices.translate(renderX, renderY, renderZ);
            matrices.multiply(camera.getRotation());
            if (rotationTilt != 0.0F) {
               matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(rotationTilt));
            }

            float staticScale = 0.04F * animScale;
            matrices.scale(staticScale, -staticScale, staticScale);
            float textWidth = font.getWidth(displayText);
            float xOffset = -textWidth / 2.0F;
            float yOffset = -9.0F * 0.35F;
            int alphaInt = (int)(alpha * 255.0F);
            int finalColor = alphaInt << 24 | colorRgb & 16777215;
            Matrix4f modelMatrix = matrices.peek().getPositionMatrix();
            Immediate consumers = MinecraftClient.getInstance().getBufferBuilders().getEntityVertexConsumers();
            font.draw(Text.literal(displayText), xOffset, yOffset, finalColor, false, modelMatrix, consumers, TextLayerType.NORMAL, 0, 15728880);
            consumers.draw();
            matrices.pop();
         }
      }
   }

   private static float easeOutCubic(float t) {
      return 1.0F - (float)Math.pow(1.0F - t, 3.0);
   }

   private static float easeInCubic(float t) {
      return (float)Math.pow(t, 3.0);
   }

   private static float easeOutBack(float t) {
      float c3 = 1.70158F + 1.0F;
      return 1.0F + c3 * (float)Math.pow(t - 1.0F, 3.0) + 1.70158F * (float)Math.pow(t - 1.0F, 2.0);
   }
}

