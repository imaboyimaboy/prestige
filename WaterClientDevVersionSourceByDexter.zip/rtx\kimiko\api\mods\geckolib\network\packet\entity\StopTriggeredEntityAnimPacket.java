package rtx.kimiko.api.mods.geckolib.network.packet.entity;

import java.util.Optional;
import java.util.function.Consumer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.network.packet.CustomPayload.Id;
import net.minecraft.world.World;
import rtx.kimiko.api.mods.geckolib.GeckoLibConstants;
import rtx.kimiko.api.mods.geckolib.animatable.GeoEntity;
import rtx.kimiko.api.mods.geckolib.animatable.GeoReplacedEntity;
import rtx.kimiko.api.mods.geckolib.network.packet.MultiloaderPacket;
import rtx.kimiko.api.mods.geckolib.util.ClientUtil;
import rtx.kimiko.api.mods.geckolib.util.RenderUtil;

public final class StopTriggeredEntityAnimPacket implements MultiloaderPacket {
   private int entityId;
   private boolean replacedEntity;
   private Optional<String> controllerName;
   private Optional<String> animName;
   public static final Id<StopTriggeredEntityAnimPacket> TYPE = new Id(GeckoLibConstants.id("stop_triggered_entity_anim"));
   public static final PacketCodec<PacketByteBuf, StopTriggeredEntityAnimPacket> CODEC = PacketCodec.tuple(
      PacketCodecs.VAR_INT,
      StopTriggeredEntityAnimPacket::entityId,
      PacketCodecs.BOOLEAN,
      StopTriggeredEntityAnimPacket::isReplacedEntity,
      PacketCodecs.STRING.collect(PacketCodecs::optional),
      StopTriggeredEntityAnimPacket::controllerName,
      PacketCodecs.STRING.collect(PacketCodecs::optional),
      StopTriggeredEntityAnimPacket::animName,
      StopTriggeredEntityAnimPacket::new
   );

   public StopTriggeredEntityAnimPacket(int entityId, boolean isReplacedEntity, Optional<String> controllerName, Optional<String> animName) {
      this.entityId = entityId;
      this.replacedEntity = isReplacedEntity;
      this.controllerName = controllerName;
      this.animName = animName;
   }

   public Id<? extends CustomPayload> getId() {
      return TYPE;
   }

   @Override
   public void receiveMessage(PlayerEntity playerEntity, Consumer<Runnable> consumer) {
      consumer.accept(() -> {
         World world = ClientUtil.getLevel();
         Entity entity;
         if (world != null && (entity = world.getEntityById(this.entityId)) != null) {
            if (!this.replacedEntity) {
               if (entity instanceof GeoEntity geoEntity) {
                  geoEntity.stopTriggeredAnim(this.controllerName.orElse(null), this.animName.orElse(null));
               }
            } else {
               if (RenderUtil.getReplacedAnimatable(entity.getType()) instanceof GeoReplacedEntity geoReplacedEntity) {
                  geoReplacedEntity.stopTriggeredAnim(entity, this.controllerName.orElse(null), this.animName.orElse(null));
               }
            }
         }
      });
   }

   public int entityId() {
      return this.entityId;
   }

   public boolean isReplacedEntity() {
      return this.replacedEntity;
   }

   public Optional<String> controllerName() {
      return this.controllerName;
   }

   public Optional<String> animName() {
      return this.animName;
   }
}

