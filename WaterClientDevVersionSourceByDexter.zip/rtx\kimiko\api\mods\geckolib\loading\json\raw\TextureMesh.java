package rtx.kimiko.api.mods.geckolib.loading.json.raw;

import com.google.gson.JsonDeserializer;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import net.minecraft.util.JsonHelper;
import rtx.kimiko.api.mods.geckolib.util.JsonUtil;

public final class TextureMesh {
   private double[] localPivot;
   private double[] position;
   private double[] rotation;
   private double[] scale;
   private String texture;

   public TextureMesh(double[] localPivot, double[] position, double[] rotation, double[] scale, String texture) {
      this.localPivot = localPivot;
      this.position = position;
      this.rotation = rotation;
      this.scale = scale;
      this.texture = texture;
   }

   public static JsonDeserializer<TextureMesh> deserializer() throws JsonParseException {
      return (jsonElement, type, jsonDeserializationContext) -> {
         JsonObject jsonObject = jsonElement.getAsJsonObject();
         double[] dArray = JsonUtil.jsonArrayToDoubleArray(JsonHelper.getArray(jsonObject, "local_pivot", null));
         double[] dArray2 = JsonUtil.jsonArrayToDoubleArray(JsonHelper.getArray(jsonObject, "position", null));
         double[] dArray3 = JsonUtil.jsonArrayToDoubleArray(JsonHelper.getArray(jsonObject, "rotation", null));
         double[] dArray4 = JsonUtil.jsonArrayToDoubleArray(JsonHelper.getArray(jsonObject, "scale", null));
         String string = JsonHelper.getString(jsonObject, "texture", null);
         return new TextureMesh(dArray, dArray2, dArray3, dArray4, string);
      };
   }

   public double[] localPivot() {
      return this.localPivot;
   }

   public double[] position() {
      return this.position;
   }

   public double[] rotation() {
      return this.rotation;
   }

   public double[] scale() {
      return this.scale;
   }

   public String texture() {
      return this.texture;
   }
}

