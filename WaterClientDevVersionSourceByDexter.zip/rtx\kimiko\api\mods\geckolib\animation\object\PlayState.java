package rtx.kimiko.api.mods.geckolib.animation.object;

public enum PlayState {
   CONTINUE,
   PAUSE,
   STOP;

   private static PlayState[] $values() {
      return new PlayState[]{CONTINUE, PAUSE, STOP};
   }
}

