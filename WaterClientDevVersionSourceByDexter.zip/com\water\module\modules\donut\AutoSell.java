package com.water.module.modules.donut;

import com.water.module.Category;
import com.water.module.Module;
import com.water.setting.Setting;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.input.MouseInput;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.text.Text;
import ru.waterclient.mixin.HandledScreenAccessor;

public final class AutoSell extends Module {
   private final Setting<Integer> loopDelay = new Setting<>("Loop Delay (ticks)", 10, 1, 100);
   private AutoSell.Phase phase;
   private int ticks;
   private int deadline;
   private int nextAction;
   private int syncId;
   private int expectedTransfer;
   private int stagedBefore;
   private int transferred;
   private boolean reusingMenu;

   public AutoSell() {
      super("Auto Sell", Category.DONUT);
      this.addSetting(this.loopDelay);
   }

   @Override
   public ItemStack getModuleIcon() {
      return new ItemStack(Items.FURNACE);
   }

   @Override
   public void onEnable() {
      this.phase = AutoSell.Phase.OPEN;
      this.ticks = this.nextAction = this.transferred = 0;
      this.deadline = 200;
      this.syncId = -1;
      this.reusingMenu = false;
   }

   @Override
   public void onTick() {
      if (mc.player != null && mc.world != null && mc.getNetworkHandler() != null) {
         this.ticks++;
         if (this.phase == AutoSell.Phase.OPEN) {
            if (this.ticks >= this.nextAction) {
               if (mc.currentScreen instanceof HandledScreen<?> open
                  && open.getScreenHandler() instanceof GenericContainerScreenHandler container
                  && container.getRows() == 6
                  && open.getTitle().getString().strip().equalsIgnoreCase("Sell")) {
                  this.phase = AutoSell.Phase.WAIT_MENU;
                  this.deadline = this.ticks + 200;
               } else if (mc.currentScreen == null) {
                  boolean found = false;

                  for (int i = 0; i < 36; i++) {
                     if (mc.player.getInventory().getStack(i).isOf(Items.FURNACE)) {
                        found = true;
                     }
                  }

                  if (found) {
                     mc.getNetworkHandler().sendChatCommand("sell");
                     this.phase = AutoSell.Phase.WAIT_MENU;
                     this.deadline = this.ticks + 200;
                  }
               }
            }
         } else if (mc.currentScreen instanceof HandledScreen<?> screen
            && screen.getScreenHandler() instanceof GenericContainerScreenHandler handler
            && handler.getRows() == 6
            && screen.getTitle().getString().strip().equalsIgnoreCase("Sell")) {
            if (this.phase == AutoSell.Phase.WAIT_SALE) {
               if (!handler.getCursorStack().isEmpty()) {
                  this.retry();
               } else if (this.ticks >= this.nextAction) {
                  boolean empty = true;

                  for (int ix = 0; ix < 53; ix++) {
                     if (!handler.getSlot(ix).getStack().isEmpty()) {
                        empty = false;
                        break;
                     }
                  }

                  if (empty) {
                     this.restartLoop();
                     this.phase = AutoSell.Phase.WAIT_MENU;
                     this.reusingMenu = true;
                     this.deadline = this.ticks + 200;
                  } else if (this.ticks > this.deadline) {
                     this.retry();
                  }
               }
            } else {
               if (this.phase == AutoSell.Phase.WAIT_MENU) {
                  if (this.ticks < this.nextAction) {
                     return;
                  }

                  if (!isSellButton(handler.getSlot(53).getStack())) {
                     if (this.ticks > this.deadline) {
                        this.retry();
                     }

                     return;
                  }

                  this.syncId = handler.syncId;
                  this.phase = AutoSell.Phase.TRANSFER;
                  this.nextAction = this.ticks + 1;
               }

               if (handler.syncId != this.syncId || !handler.getCursorStack().isEmpty()) {
                  this.retry();
               } else if (isSellButton(handler.getSlot(53).getStack())) {
                  int staged = 0;

                  for (int ixx = 0; ixx < 53; ixx++) {
                     ItemStack stack = handler.getSlot(ixx).getStack();
                     if (!stack.isEmpty() && !stack.isOf(Items.FURNACE)) {
                        this.retry();
                        return;
                     }

                     staged += stack.getCount();
                  }

                  if (this.ticks >= this.nextAction) {
                     if (this.phase == AutoSell.Phase.WAIT_TRANSFER) {
                        if (staged < this.stagedBefore + this.expectedTransfer) {
                           if (this.ticks > this.deadline) {
                              this.retry();
                           }

                           return;
                        }

                        this.transferred = this.transferred + this.expectedTransfer;
                        this.phase = AutoSell.Phase.TRANSFER;
                     }

                     List<Slot> batch = new ArrayList<>();
                     this.expectedTransfer = 0;

                     for (Slot slot : handler.slots) {
                        if (slot.inventory == mc.player.getInventory() && slot.getStack().isOf(Items.FURNACE)) {
                           batch.add(slot);
                           this.expectedTransfer = this.expectedTransfer + slot.getStack().getCount();
                        }
                     }

                     if (!batch.isEmpty()) {
                        this.stagedBefore = staged;
                        this.phase = AutoSell.Phase.WAIT_TRANSFER;
                        this.deadline = this.ticks + 100;
                        this.nextAction = this.ticks + 1;

                        for (Slot slotx : batch) {
                           if (mc.currentScreen != screen || handler.syncId != this.syncId || !handler.getCursorStack().isEmpty()) {
                              this.retry();
                              return;
                           }

                           if (slotx.getStack().isOf(Items.FURNACE)) {
                              this.click(screen, slotx, true);
                           }
                        }
                     } else if (staged == 0) {
                        this.transferred = 0;
                        this.nextAction = this.ticks + 1;
                     } else {
                        this.phase = AutoSell.Phase.WAIT_SALE;
                        this.deadline = this.ticks + 200;
                        this.nextAction = this.ticks + 1;
                        this.click(screen, handler.getSlot(53), false);
                     }
                  }
               } else if (this.phase != AutoSell.Phase.WAIT_SALE || this.ticks >= this.deadline) {
                  this.retry();
               }
            }
         } else if (this.reusingMenu && mc.currentScreen == null) {
            this.restartLoop();
         } else if (this.phase != AutoSell.Phase.WAIT_MENU || this.ticks >= this.deadline) {
            if (this.phase == AutoSell.Phase.WAIT_SALE && mc.currentScreen == null) {
               this.restartLoop();
            } else {
               this.retry();
            }
         }
      } else {
         this.restartLoop();
      }
   }

   private void restartLoop() {
      this.phase = AutoSell.Phase.OPEN;
      this.reusingMenu = false;
      this.syncId = -1;
      this.transferred = this.expectedTransfer = this.stagedBefore = 0;
      this.nextAction = this.ticks + this.loopDelay.getValue();
   }

   private static boolean isSellButton(ItemStack stack) {
      if (!stack.isEmpty() && !stack.isOf(Items.FURNACE)) {
         String label = stack.getName().getString();
         LoreComponent lore = (LoreComponent)stack.get(DataComponentTypes.LORE);
         if (lore != null) {
            for (Text line : lore.lines()) {
               label = label + " " + line.getString();
            }
         }

         return label.toLowerCase(Locale.ROOT).contains("click to sell items");
      } else {
         return false;
      }
   }

   private void click(HandledScreen<?> screen, Slot slot, boolean shift) {
      HandledScreenAccessor position = (HandledScreenAccessor)screen;
      Click click = new Click(position.water$getX() + slot.x + 8, position.water$getY() + slot.y + 8, new MouseInput(0, shift ? 1 : 0));
      screen.mouseClicked(click, false);
      if (mc.currentScreen == screen) {
         screen.mouseReleased(click);
      }
   }

   private void retry() {
      this.restartLoop();
      if (mc.currentScreen instanceof HandledScreen<?> screen
         && screen.getScreenHandler() instanceof GenericContainerScreenHandler handler
         && handler.getRows() == 6
         && screen.getTitle().getString().strip().equalsIgnoreCase("Sell")) {
         this.phase = AutoSell.Phase.WAIT_MENU;
         this.reusingMenu = true;
      }

      this.nextAction = this.ticks + Math.max(20, this.loopDelay.getValue());
      this.deadline = this.nextAction + 200;
   }

   enum Phase {
      OPEN,
      WAIT_MENU,
      TRANSFER,
      WAIT_TRANSFER,
      WAIT_SALE;

      private static AutoSell.Phase[] $values() {
         return new AutoSell.Phase[]{OPEN, WAIT_MENU, TRANSFER, WAIT_TRANSFER, WAIT_SALE};
      }
   }
}

