package com.water.module.modules.donut;

import com.water.module.Category;
import com.water.module.Module;
import com.water.setting.Setting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.Entity.RemovalReason;

public final class AntiTrap extends Module {
   private final Setting<Boolean> armorStands = new Setting<>("Armor Stands", true);
   private final Setting<Boolean> minecarts = new Setting<>("Minecarts", true);
   private final Setting<Boolean> chestMinecarts = new Setting<>("Chest Minecarts", true);
   private final Setting<Boolean> hopperMinecarts = new Setting<>("Hopper Minecarts", true);

   public AntiTrap() {
      super("AntiTrap", Category.DONUT);
      this.addSetting(this.armorStands);
      this.addSetting(this.minecarts);
      this.addSetting(this.chestMinecarts);
      this.addSetting(this.hopperMinecarts);
   }

   @Override
   public void onEnable() {
      this.removeTrapEntities();
   }

   @Override
   public void onTick() {
      this.removeTrapEntities();
   }

   private void removeTrapEntities() {
      if (mc.world != null) {
         List<Entity> trapEntities = new ArrayList<>();
         mc.world.getEntities().forEach(entity -> {
            if (entity != null && this.isTrapEntity(entity.getType())) {
               trapEntities.add(entity);
            }
         });
         trapEntities.forEach(e -> {
            if (!e.isRemoved()) {
               e.remove(RemovalReason.DISCARDED);
            }
         });
      }
   }

   private boolean isTrapEntity(EntityType<?> type) {
      if (type == null) {
         return false;
      } else if (this.armorStands.getValue() && type.equals(EntityType.ARMOR_STAND)) {
         return true;
      } else if (this.minecarts.getValue() && type.equals(EntityType.MINECART)) {
         return true;
      } else {
         return this.chestMinecarts.getValue() && type.equals(EntityType.CHEST_MINECART)
            ? true
            : this.hopperMinecarts.getValue() && type.equals(EntityType.HOPPER_MINECART);
      }
   }
}

