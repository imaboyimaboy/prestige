package rtx.kimiko.api.liteapi;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import rtx.kimiko.api.modules.Module;
import rtx.kimiko.api.modules.ModuleManager;

public final class FeatureBlocklist {
   private static volatile Set<String> blocked = Collections.emptySet();

   private FeatureBlocklist() {
   }

   public static void clear() {
      blocked = Collections.emptySet();
   }

   public static boolean hasAny() {
      return !blocked.isEmpty();
   }

   public static boolean isModuleBlocked(Module module) {
      if (module == null) {
         return false;
      } else {
         Set<String> set = blocked;
         if (set.isEmpty()) {
            return false;
         } else {
            Feature feature = module.getClass().getAnnotation(Feature.class);
            if (feature == null) {
               return false;
            } else {
               for (String string : feature.value()) {
                  if (string != null && set.contains(string.toLowerCase().trim())) {
                     return true;
                  }
               }

               return false;
            }
         }
      }
   }

   public static void applyBlocklist(Collection<String> collection) {
      if (collection != null && !collection.isEmpty()) {
         HashSet<String> hashSet = new HashSet<>();

         for (String string : collection) {
            if (string != null && !string.isBlank()) {
               hashSet.add(string.toLowerCase().trim());
            }
         }

         blocked = hashSet;
      } else {
         blocked = Collections.emptySet();
      }
   }

   public static Set<String> knownFeatures() {
      LinkedHashSet<String> linkedHashSet = new LinkedHashSet<>();

      for (Module module : ModuleManager.get().getAll()) {
         Feature feature = module.getClass().getAnnotation(Feature.class);
         if (feature != null) {
            Collections.addAll(linkedHashSet, feature.value());
         }
      }

      return linkedHashSet;
   }
}

