package rtx.kimiko.api.drags;

import net.minecraft.client.gui.DrawContext;
import rtx.kimiko.api.modules.impl.Interface.InterfaceModule;
import rtx.kimiko.utils.math.MathUtils;

public final class DragController {
   private float xPos;
   private float yPos;
   private float desiredX;
   private float desiredY;
   private float startX;
   private float startY;
   private float preDragX;
   private float preDragY;
   private boolean dragging;
   private boolean cancelled;
   private float snapLineX = Float.NaN;
   private float snapLineY = Float.NaN;
   private float tiltAngle;
   private float tiltVelocity;
   private float filteredMouseVelocity;
   private float lastTiltMouseX;
   private long lastTiltUpdateNs;
   private boolean renderPositionLocked;
   private float lockedRenderX;
   private float lockedRenderY;
   private boolean directDrag;
   private final DragLerpAnim dragAnimPc = new DragLerpAnim(0.0F, 0.0F, 0.125F);
   private DragLerpAnim animX;
   private DragLerpAnim animY;
   private DragLerpAnim animX2;
   private DragLerpAnim animY2;
   public static final long PULSE_PERIOD_MS = 500L;

   public DragController(float f, float f2) {
      this.xPos = f;
      this.yPos = f2;
      this.desiredX = f;
      this.desiredY = f2;
   }

   public float getOriginX() {
      return this.preDragX;
   }

   public float getOriginY() {
      return this.preDragY;
   }

   public void cancel() {
      if (this.dragging) {
         this.cancelled = true;
         this.dragging = false;
         this.xPos = this.preDragX;
         this.yPos = this.preDragY;
         this.desiredX = this.preDragX;
         this.desiredY = this.preDragY;
         this.ensureAnims();
         this.animX.setTo(this.xPos);
         this.animY.setTo(this.yPos);
         this.animX2.setTo(this.xPos);
         this.animY2.setTo(this.yPos);
      }
   }

   public void release() {
      if (this.dragging) {
         this.cancelled = false;
         this.dragging = false;
         if (this.animX != null) {
            this.animX.setTo(this.xPos);
         }

         if (this.animY != null) {
            this.animY.setTo(this.yPos);
         }
      }
   }

   public float getTiltAngle() {
      return this.tiltAngle;
   }

   void beginRender() {
      if (!this.renderPositionLocked) {
         this.lockedRenderX = this.computeRenderX();
         this.lockedRenderY = this.computeRenderY();
         this.renderPositionLocked = true;
      }
   }

   public void syncToTarget() {
      this.ensureAnims();
      this.animX.setAnim(this.xPos);
      this.animX.setTo(this.xPos);
      this.animY.setAnim(this.yPos);
      this.animY.setTo(this.yPos);
      this.animX2.setAnim(this.xPos);
      this.animX2.setTo(this.xPos);
      this.animY2.setAnim(this.yPos);
      this.animY2.setTo(this.yPos);
   }

   public void applyScreenClamp(float f, float f2) {
      this.xPos = Position.clampX(this.desiredX, f);
      this.yPos = Position.clampY(this.desiredY, f2);
   }

   public void renderOverlay(DrawContext drawContext, float f, float f2, float f3, float f4) {
      float f5 = this.overlayAlpha();
      if (!(f5 <= 0.1F)) {
         DragOverlayRenderer.render(drawContext, this, f, f2, f3, f4, f5);
      }
   }

   public void swapGrabOffset() {
      if (this.dragging) {
         float f = this.startX;
         this.startX = this.startY;
         this.startY = f;
      }
   }

   private void ensureAnims() {
      if (this.animX == null) {
         this.animX = new DragLerpAnim(this.xPos, this.xPos, 0.08F);
      }

      if (this.animY == null) {
         this.animY = new DragLerpAnim(this.yPos, this.yPos, 0.08F);
      }

      if (this.animX2 == null) {
         this.animX2 = new DragLerpAnim(this.xPos, this.xPos, 0.1F);
      }

      if (this.animY2 == null) {
         this.animY2 = new DragLerpAnim(this.yPos, this.yPos, 0.1F);
      }
   }

   private static float jitterStrength() {
      InterfaceModule interfaceModule = InterfaceModule.getInstance();
      if (interfaceModule == null || !interfaceModule.dragStyle.check("Обычный") && interfaceModule.dragJitter.getValue()) {
         float f = pulsePhase();
         float f2 = f > 0.5F ? 1.0F - f : f;
         float var4;
         float f3 = f2 < 0.5F ? 4.0F * f2 * f2 * f2 : (float)(1.0 - Math.pow(-2.0 * (var4 = f2 * 2.0F) + 2.0, 3.0) / 2.0);
         return f3 * f3;
      } else {
         return 0.0F;
      }
   }

   float getSnapLineX() {
      return this.snapLineX;
   }

   public float overlayAlpha() {
      this.dragAnimPc.setToAsBoolean(this.dragging);
      return this.dragAnimPc.getAnim();
   }

   public void snapOverlayToTarget() {
      this.ensureAnims();
      this.animX2.setAnim(this.xPos);
      this.animX2.setTo(this.xPos);
      this.animY2.setAnim(this.yPos);
      this.animY2.setTo(this.yPos);
   }

   void setSnapLineX(float f) {
      this.snapLineX = f;
   }

   void setSnapLineY(float f) {
      this.snapLineY = f;
   }

   private float computeRenderY() {
      this.ensureAnims();
      float f = this.animY.getAnim();
      if (this.dragging) {
         float f2 = jitterStrength();
         f += MathUtils.getRandom(-2.0F * f2, 2.0F * f2);
      } else {
         this.animY.setTo(this.yPos);
      }

      return f;
   }

   float getSnapLineY() {
      return this.snapLineY;
   }

   private float computeRenderX() {
      this.ensureAnims();
      float f = this.animX.getAnim();
      if (this.dragging) {
         float f2 = jitterStrength();
         f += MathUtils.getRandom(-2.0F * f2, 2.0F * f2);
      } else {
         this.animX.setTo(this.xPos);
      }

      return f;
   }

   public static float pulsePhase() {
      return (float)(System.currentTimeMillis() % 500L) / 500.0F;
   }

   public void updateTilt(float f, boolean bl) {
      long l = System.nanoTime();
      if (!bl) {
         this.tiltAngle = 0.0F;
         this.tiltVelocity = 0.0F;
         this.filteredMouseVelocity = 0.0F;
         this.lastTiltMouseX = f;
         this.lastTiltUpdateNs = l;
      } else if (this.lastTiltUpdateNs == 0L) {
         this.lastTiltMouseX = f;
         this.lastTiltUpdateNs = l;
      } else {
         float f2 = Math.clamp((float)(l - this.lastTiltUpdateNs) / 1.E9F, 0.001F, 0.05F);
         float f3 = this.dragging ? (f - this.lastTiltMouseX) / f2 : 0.0F;
         this.lastTiltMouseX = f;
         this.lastTiltUpdateNs = l;
         float f4 = 1.0F - (float)Math.exp(-14.0F * f2);
         this.filteredMouseVelocity = this.filteredMouseVelocity + (f3 - this.filteredMouseVelocity) * f4;
         float f5 = this.dragging ? Math.clamp(this.filteredMouseVelocity * 0.012F, -6.5F, 6.5F) : 0.0F;
         float f6 = (f5 - this.tiltAngle) * 105.0F - this.tiltVelocity * 16.0F;
         this.tiltVelocity += f6 * f2;
         this.tiltAngle = Math.clamp(this.tiltAngle + this.tiltVelocity * f2, -7.0F, 7.0F);
         if (!this.dragging && Math.abs(this.tiltAngle) < 0.01F && Math.abs(this.tiltVelocity) < 0.05F) {
            this.tiltAngle = 0.0F;
            this.tiltVelocity = 0.0F;
            this.filteredMouseVelocity = 0.0F;
         }
      }
   }

   public void setTargetX(float f) {
      this.xPos = f;
      this.desiredX = f;
   }

   public boolean isDragging() {
      return this.dragging;
   }

   public float getTargetY() {
      return this.yPos;
   }

   void endRender() {
      this.renderPositionLocked = false;
   }

   public boolean tryGrab(float f, float f2, float f3, float f4) {
      if (!this.isHovered(f, f2, f3, f4)) {
         return false;
      } else {
         this.cancelled = false;
         this.dragging = true;
         this.preDragX = this.xPos;
         this.preDragY = this.yPos;
         this.startX = f - this.xPos;
         this.startY = f2 - this.yPos;
         this.lastTiltMouseX = f;
         this.lastTiltUpdateNs = System.nanoTime();
         this.filteredMouseVelocity = 0.0F;
         return true;
      }
   }

   public float getRenderX() {
      return this.renderPositionLocked ? this.lockedRenderX : this.computeRenderX();
   }

   public float getRenderY() {
      return this.renderPositionLocked ? this.lockedRenderY : this.computeRenderY();
   }

   public float getTargetX() {
      return this.xPos;
   }

   public void setTargetY(float f) {
      this.yPos = f;
      this.desiredY = f;
   }

   public boolean isHovered(float f, float f2, float f3, float f4) {
      return f > this.xPos && f < this.xPos + f3 && f2 > this.yPos && f2 < this.yPos + f4;
   }

   public void adjustY(float f) {
      this.yPos += f;
      this.desiredY += f;
   }

   DragLerpAnim getAnimY() {
      return this.animY;
   }

   DragLerpAnim getAnimX() {
      return this.animX;
   }

   DragLerpAnim getAnimX2() {
      return this.animX2;
   }

   DragLerpAnim getAnimY2() {
      return this.animY2;
   }

   public boolean wasCancelled() {
      return this.cancelled;
   }

   public void tick(float f, float f2, float f3, float f4, boolean bl) {
      this.directDrag = bl;
      this.dragAnimPc.setToAsBoolean(this.dragging);
      this.dragAnimPc.getAnim();
      this.dragAnimPc.setSpeed(0.04F);
      this.ensureAnims();
      this.snapLineX = Float.NaN;
      this.snapLineY = Float.NaN;
      if (this.dragging) {
         this.xPos = f - this.startX;
         this.yPos = f2 - this.startY;
         DragOverlayRenderer.clampToScreen(this, f3, f4);
         DragOverlayRenderer.applyGridSnap(this, f3, f4);
         this.desiredX = this.xPos;
         this.desiredY = this.yPos;
         this.animX2.setTo(this.xPos);
         this.animY2.setTo(this.yPos);
         if (bl) {
            this.animX.setTo(this.xPos);
            this.animY.setTo(this.yPos);
         }
      } else {
         this.animX.setTo(this.xPos);
         this.animY.setTo(this.yPos);
      }
   }
}

