package com.water.spotify.lyrics;

public final class LyricLine implements Comparable<LyricLine> {
   private long timestampMs;
   private String text;

   public LyricLine(long timestampMs, String text) {
      this.timestampMs = timestampMs;
      this.text = text;
   }

   public int compareTo(LyricLine o) {
      return Long.compare(this.timestampMs, o.timestampMs);
   }

   public long timestampMs() {
      return this.timestampMs;
   }

   public String text() {
      return this.text;
   }
}

