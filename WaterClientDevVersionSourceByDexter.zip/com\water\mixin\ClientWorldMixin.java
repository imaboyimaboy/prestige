package com.water.mixin;

import com.water.module.modules.render.DevSpawnerVisuals;
import com.water.module.modules.render.NoRender;
import net.minecraft.block.BlockState;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({ClientWorld.class})
public class ClientWorldMixin {
   @ModifyVariable(
      method = {"setBlockState(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/BlockState;II)Z"},
      at = @At("HEAD"),
      argsOnly = true,
      ordinal = 0
   )
   private BlockState water$devSpawnerInstantState(BlockState state, BlockPos pos) {
      return DevSpawnerVisuals.visualStateForPlacement(pos, state);
   }

   @Inject(
      method = {"getLightningTicksLeft"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void water$hideLightningFlash(CallbackInfoReturnable<Integer> cir) {
      if (NoRender.hideThunder()) {
         cir.setReturnValue(0);
      }
   }
}

