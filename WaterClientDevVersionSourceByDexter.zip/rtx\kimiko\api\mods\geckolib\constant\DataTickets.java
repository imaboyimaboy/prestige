package rtx.kimiko.api.mods.geckolib.constant;

import com.google.common.reflect.TypeToken;
import java.util.EnumMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import rtx.kimiko.api.mods.geckolib.animation.state.ControllerState;
import rtx.kimiko.api.mods.geckolib.animation.state.KeyFrameEvent;
import rtx.kimiko.api.mods.geckolib.cache.animation.keyframeevent.CustomInstructionKeyframeData;
import rtx.kimiko.api.mods.geckolib.cache.animation.keyframeevent.ParticleKeyframeData;
import rtx.kimiko.api.mods.geckolib.cache.animation.keyframeevent.SoundKeyframeData;
import rtx.kimiko.api.mods.geckolib.constant.dataticket.DataTicket;
import rtx.kimiko.api.mods.geckolib.constant.dataticket.SerializableDataTicket;
import rtx.kimiko.api.mods.geckolib.renderer.GeoArmorRenderer;
import rtx.kimiko.api.mods.geckolib.renderer.GeoItemRenderer;

public final class DataTickets {
   private static final Map<Identifier, SerializableDataTicket<?>> SERIALIZABLE_TICKETS = new ConcurrentHashMap<>();
   public static final DataTicket<Void> RESET_RENDER_PASS = DataTicket.dataTicketOf2("reset_render_pass", Void.class);
   public static final DataTicket<Entity> ENTITY = DataTicket.dataTicketOf2("entity", Entity.class);
   public static final DataTicket<BlockEntity> BLOCK_ENTITY = DataTicket.dataTicketOf2("block_entity", BlockEntity.class);
   public static final DataTicket<ItemStack> ITEMSTACK = DataTicket.dataTicketOf2("itemstack", ItemStack.class);
   public static final DataTicket<EquipmentSlot> EQUIPMENT_SLOT = DataTicket.dataTicketOf2("equipment_slot", EquipmentSlot.class);
   public static final DataTicket<GeoArmorRenderer.StackForRender> STACK_FOR_RENDER = DataTicket.dataTicketOf2(
      "stack_for_render", GeoArmorRenderer.StackForRender.class
   );
   public static final DataTicket<GeoItemRenderer.StackForRender> ITEM_RENDER_DATA = DataTicket.dataTicketOf2(
      "item_render_data", GeoItemRenderer.StackForRender.class
   );
   public static final DataTicket<ControllerState[]> ANIMATION_CONTROLLER_STATES = DataTicket.dataTicketOf2(
      "animation_controller_states", ControllerState[].class
   );
   public static final DataTicket<Double> TICK = DataTicket.dataTicketOf2("tick", Double.class);
   public static final DataTicket<KeyFrameEvent<?, CustomInstructionKeyframeData>> CUSTOM_INSTRUCTION_KEYFRAME_EVENT = DataTicket.dataTicketOf(
      "custom_instruction_keyframe_event", new TypeToken<KeyFrameEvent<?, CustomInstructionKeyframeData>>() {}
   );
   public static final DataTicket<KeyFrameEvent<?, ParticleKeyframeData>> PARTICLE_KEYFRAME_EVENT = DataTicket.dataTicketOf(
      "particle_keyframe_event", new TypeToken<KeyFrameEvent<?, ParticleKeyframeData>>() {}
   );
   public static final DataTicket<KeyFrameEvent<?, SoundKeyframeData>> SOUND_KEYFRAME_EVENT = DataTicket.dataTicketOf(
      "sound_keyframe_event", new TypeToken<KeyFrameEvent<?, SoundKeyframeData>>() {}
   );
   public static final DataTicket<Direction> DIRECTION = DataTicket.dataTicketOf2("direction", Direction.class);
   public static final DataTicket<Integer> RENDER_COLOR = DataTicket.dataTicketOf2("render_color", Integer.class);
   public static final DataTicket<Integer> PACKED_LIGHT = DataTicket.dataTicketOf2("packed_light", Integer.class);
   public static final DataTicket<Integer> PACKED_OVERLAY = DataTicket.dataTicketOf2("packed_overlay", Integer.class);
   public static final DataTicket<Long> ANIMATABLE_INSTANCE_ID = DataTicket.dataTicketOf2("animatable_instance_id", Long.class);
   public static final DataTicket<Object> ANIMATABLE_MANAGER = DataTicket.dataTicketOf2("animatable_manager", Object.class);
   public static final DataTicket<Float> PARTIAL_TICK = DataTicket.dataTicketOf2("partial_tick", Float.class);
   public static final DataTicket<Boolean> IS_MOVING = DataTicket.dataTicketOf2("is_moving", Boolean.class);
   public static final DataTicket<Class> ANIMATABLE_CLASS = DataTicket.dataTicketOf2("animatable_class", Class.class);
   public static final DataTicket<EnumMap> PER_SLOT_RENDER_DATA = DataTicket.dataTicketOf2("per_slot_render_data", EnumMap.class);
   public static final DataTicket<Vec3d> POSITION = DataTicket.dataTicketOf2("position", Vec3d.class);
   public static final DataTicket<Boolean> IS_GECKOLIB_WEARER = DataTicket.dataTicketOf2("is_geckolib_wearer", Boolean.class);
   public static final DataTicket<Boolean> HAS_GLINT = DataTicket.dataTicketOf2("has_glint", Boolean.class);
   public static final DataTicket<BipedEntityModel> HUMANOID_MODEL = DataTicket.dataTicketOf2("humanoid_model", BipedEntityModel.class);
   public static final DataTicket<Float> ENTITY_PITCH = DataTicket.dataTicketOf2("entity_pitch", Float.class);
   public static final DataTicket<Float> ENTITY_YAW = DataTicket.dataTicketOf2("entity_yaw", Float.class);
   public static final DataTicket<Boolean> IS_ENCHANTED = DataTicket.dataTicketOf2("is_enchanted", Boolean.class);
   public static final DataTicket<Boolean> IS_STACKABLE = DataTicket.dataTicketOf2("is_stackable", Boolean.class);
   public static final DataTicket<Integer> MAX_USE_DURATION = DataTicket.dataTicketOf2("max_use_duration", Integer.class);
   public static final DataTicket<Integer> MAX_DURABILITY = DataTicket.dataTicketOf2("max_durability", Integer.class);
   public static final DataTicket<Integer> REMAINING_DURABILITY = DataTicket.dataTicketOf2("remaining_durability", Integer.class);
   public static final DataTicket<Boolean> INVISIBLE_TO_PLAYER = DataTicket.dataTicketOf2("invisible_to_player", Boolean.class);
   public static final DataTicket<EntityPose> ENTITY_POSE = DataTicket.dataTicketOf2("entity_pose", EntityPose.class);
   public static final DataTicket<Float> ENTITY_BODY_YAW = DataTicket.dataTicketOf2("entity_body_yaw", Float.class);
   public static final DataTicket<Boolean> IS_SHAKING = DataTicket.dataTicketOf2("is_shaking", Boolean.class);
   public static final DataTicket<Vec3d> VELOCITY = DataTicket.dataTicketOf2("velocity", Vec3d.class);
   public static final DataTicket<BlockPos> BLOCKPOS = DataTicket.dataTicketOf2("blockpos", BlockPos.class);
   public static final DataTicket<Boolean> SPRINTING = DataTicket.dataTicketOf2("sprinting", Boolean.class);
   public static final DataTicket<Boolean> IS_CROUCHING = DataTicket.dataTicketOf2("is_crouching", Boolean.class);
   public static final DataTicket<Boolean> SWINGING_ARM = DataTicket.dataTicketOf2("swinging_arm", Boolean.class);
   public static final DataTicket<Boolean> IS_DEAD_OR_DYING = DataTicket.dataTicketOf2("is_dead_or_dying", Boolean.class);

   private DataTickets() {
   }

   public static <D> SerializableDataTicket<D> registerSerializable(SerializableDataTicket<D> ticket) {
      SERIALIZABLE_TICKETS.put(ticket.getRegisteredId(), ticket);
      return ticket;
   }

   public static SerializableDataTicket<?> byName(Identifier id) {
      return SERIALIZABLE_TICKETS.get(id);
   }
}

