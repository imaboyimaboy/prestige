package rtx.kimiko.api.drags.components;

import java.util.List;
import java.util.Locale;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import rtx.kimiko.api.drags.Draggable;
import rtx.kimiko.api.modules.ModuleManager;
import rtx.kimiko.api.modules.impl.Interface.InterfaceModule;
import rtx.kimiko.api.modules.impl.Interface.KeyStrokesModule;
import rtx.kimiko.api.ui.settings.Setting;
import rtx.kimiko.api.ui.settings.impl.BoolSetting;
import rtx.kimiko.utils.animations.Easings;
import rtx.kimiko.utils.animations.SmoothAnimation;
import rtx.kimiko.utils.color.ColorUtil;
import rtx.kimiko.utils.render.others.RectUtil;
import rtx.kimiko.utils.render.render2d.ClientPalette;
import rtx.kimiko.utils.render.render2d.Render2D;

public final class KeyStrokesComp extends Draggable {
   private static final float KEY = 22.0F;
   private static final float GAP = 2.5F;
   private static final float MOUSE_H = 16.0F;
   private static final float SPACE_H = 14.5F;
   private static final float FALLBACK_RADIUS = 5.0F;
   private static final float WIDTH = 71.0F;
   private static final String FONT = "montserrat-medium";
   private static final float KEY_FONT = 8.5F;
   private static final float MOUSE_FONT = 7.0F;
   private static final float SINK = 1.1F;
   private static final int LABEL_IDLE = -4604215;
   private static final int TOP_IDLE = -233038042;
   private static final int BOT_IDLE = -233498851;
   private static final int KEY_W = 0;
   private static final int KEY_A = 1;
   private static final int KEY_S = 2;
   private static final int KEY_D = 3;
   private static final int KEY_LMB = 4;
   private static final int KEY_RMB = 5;
   private static final int KEY_SPACE = 6;
   private final SmoothAnimation visibility = new SmoothAnimation();
   private final SmoothAnimation[] press = new SmoothAnimation[7];

   public KeyStrokesComp() {
      super("keystrokes", 5.0F, 225.0F);
      this.visibility.set(0.0);

      for (int i = 0; i < this.press.length; i++) {
         this.press[i] = new SmoothAnimation();
         this.press[i].set(0.0);
      }
   }

   private static KeyStrokesModule module() {
      return ModuleManager.get().get(KeyStrokesModule.class);
   }

   @Override
   public String displayName() {
      return "KeyStrokes";
   }

   @Override
   public float width() {
      return 71.0F;
   }

   @Override
   public float height() {
      KeyStrokesModule keyStrokesModule = module();
      float f = 46.5F;
      if (keyStrokesModule == null || keyStrokesModule.showMouse.getValue()) {
         f += 18.5F;
      }

      if (keyStrokesModule == null || keyStrokesModule.showSpace.getValue()) {
         f += 17.0F;
      }

      return f;
   }

   @Override
   public boolean isInteractive() {
      KeyStrokesModule keyStrokesModule = module();
      return keyStrokesModule != null && keyStrokesModule.isEnabled();
   }

   @Override
   protected List<Setting> buildHudSettings() {
      List<Setting> list = super.buildHudSettings();
      KeyStrokesModule keyStrokesModule = module();
      if (keyStrokesModule != null) {
         list.add(new BoolSetting(keyStrokesModule.showMouse));
         list.add(new BoolSetting(keyStrokesModule.showCps));
         list.add(new BoolSetting(keyStrokesModule.showSpace));
      }

      return list;
   }

   private static float panelRadius() {
      InterfaceModule interfaceModule = InterfaceModule.getInstance();
      return interfaceModule != null ? interfaceModule.rectCornerRadius.getFloat() : 5.0F;
   }

   @Override
   protected void render(DrawContext drawContext) {
      KeyStrokesModule keyStrokesModule = module();
      boolean bl = keyStrokesModule != null && keyStrokesModule.isEnabled();
      this.visibility.run(bl ? 1.0 : 0.0, bl ? 0.18 : 0.12, Easings.CUBIC_OUT, true);
      this.visibility.update();
      float f = this.visibility.get();
      if (!(f <= 0.01F)) {
         MinecraftClient minecraftClient = MinecraftClient.getInstance();
         boolean bl2 = keyStrokesModule == null || keyStrokesModule.showMouse.getValue();
         boolean bl3 = keyStrokesModule != null && keyStrokesModule.showCps.getValue();
         boolean bl4 = keyStrokesModule == null || keyStrokesModule.showSpace.getValue();
         float f2 = this.getX();
         float f3 = this.getY();
         float f4 = this.width();
         float f5 = this.height();
         float f6 = 0.92F + f * 0.08F;
         float f7 = f2 + f4 * 0.5F;
         float f8 = f3 + f5 * 0.5F;
         drawContext.getMatrices().pushMatrix();
         drawContext.getMatrices().translate(f7, f8);
         drawContext.getMatrices().scale(f6);
         drawContext.getMatrices().translate(-f7, -f8);
         Render2D.beginFrame(drawContext);
         this.drawKey(
            0, f2 + 22.0F + 2.5F, f3, 22.0F, 22.0F, keyLabel(minecraftClient.options.forwardKey), 8.5F, minecraftClient.options.forwardKey.isPressed(), f
         );
         float f9;
         this.drawKey(1, f2, f9 = f3 + 24.5F, 22.0F, 22.0F, keyLabel(minecraftClient.options.leftKey), 8.5F, minecraftClient.options.leftKey.isPressed(), f);
         this.drawKey(2, f2 + 22.0F + 2.5F, f9, 22.0F, 22.0F, keyLabel(minecraftClient.options.backKey), 8.5F, minecraftClient.options.backKey.isPressed(), f);
         this.drawKey(3, f2 + 49.0F, f9, 22.0F, 22.0F, keyLabel(minecraftClient.options.rightKey), 8.5F, minecraftClient.options.rightKey.isPressed(), f);
         f9 += 24.5F;
         if (bl2) {
            float f10 = (f4 - 2.5F) * 0.5F;
            this.drawKey(4, f2, f9, f10, 16.0F, mouseLabel(keyStrokesModule, true, bl3), 7.0F, minecraftClient.options.attackKey.isPressed(), f);
            this.drawKey(5, f2 + f10 + 2.5F, f9, f10, 16.0F, mouseLabel(keyStrokesModule, false, bl3), 7.0F, minecraftClient.options.useKey.isPressed(), f);
            f9 += 18.5F;
         }

         if (bl4) {
            this.drawKey(6, f2, f9, f4, 14.5F, null, 0.0F, minecraftClient.options.jumpKey.isPressed(), f);
         }

         Render2D.flush();
         drawContext.getMatrices().popMatrix();
      }
   }

   private static String mouseLabel(KeyStrokesModule keyStrokesModule, boolean bl, boolean bl2) {
      if (bl2 && keyStrokesModule != null) {
         int n = bl ? keyStrokesModule.leftCps() : keyStrokesModule.rightCps();
         if (n > 0) {
            return n + " CPS";
         }
      }

      return bl ? "LMB" : "RMB";
   }

   private static String keyLabel(KeyBinding keyBinding) {
      Object object = keyBinding.getBoundKeyTranslationKey();
      if (object != null && !((String)object).isBlank()) {
         if (((String)object).startsWith("key.keyboard.")) {
            object = ((String)object).substring(13);
         } else if (((String)object).startsWith("key.mouse.")) {
            object = "M " + ((String)object).substring(10);
         }

         return ((String)object).replace('.', ' ').toUpperCase(Locale.ROOT);
      } else {
         return "?";
      }
   }

   private void drawKey(int n, float f, float f2, float f3, float f4, String string, float f5, boolean bl, float f6) {
      SmoothAnimation smoothAnimation = this.press[n];
      smoothAnimation.run(bl ? 1.0 : 0.0, bl ? 0.55 : 0.28, Easings.CUBIC_OUT, true);
      smoothAnimation.update();
      float f7 = smoothAnimation.get();
      float f8 = 1.1F * f7;
      float f9 = f + f8;
      float f10 = f2 + f8;
      float f11 = f3 - f8 * 2.0F;
      float f12 = f4 - f8 * 2.0F;
      float f13 = Math.min(panelRadius(), Math.min(f11, f12) * 0.5F);
      float f14 = f6 * (1.0F - f7);
      if (f14 > 0.003921569F) {
         int n2 = ColorUtil.multAlpha(-233038042, f14);
         int n3 = ColorUtil.multAlpha(-233498851, f14);
         Render2D.rect(f9, f10, f11, f12, f13, n2, n2, n3, n3);
      }

      if (f7 > 0.003921569F) {
         RectUtil.drawClientRect(f9, f10, f11, f12, f13, f6 * f7);
      }

      int n2 = ColorUtil.rgba(255, 255, 255, Math.round(26.0F * f6));
      int[] nArray = ClientPalette.cornerColors(0.5882353F * f6);
      Render2D.outline(
         f9,
         f10,
         f11,
         f12,
         f13,
         0.5F,
         ColorUtil.lerpColor(n2, nArray[0], f7),
         ColorUtil.lerpColor(n2, nArray[1], f7),
         ColorUtil.lerpColor(n2, nArray[2], f7),
         ColorUtil.lerpColor(n2, nArray[3], f7)
      );
      int n4 = ColorUtil.multAlpha(ColorUtil.lerpColor(-4604215, -1, f7), f6);
      if (string == null) {
         float f15 = f11 * 0.42F;
         float f16 = 2.5F;
         Render2D.rect(f9 + (f11 - f15) * 0.5F, f10 + (f12 - f16) * 0.5F, f15, f16, f16 * 0.5F, n4, n4, n4, n4);
      } else {
         float f17 = f5;
         float f18 = Render2D.msdfWidth("montserrat-medium", string, f5);

         while (f18 > f11 - 6.0F && f17 > 5.5F) {
            f18 = Render2D.msdfWidth("montserrat-medium", string, f17 -= 0.5F);
         }

         Render2D.msdfText("montserrat-medium", string, f9 + (f11 - f18) * 0.5F, f10 + (f12 - f17) * 0.5F - f17 * 0.12F, f17, n4);
      }
   }
}

