package rtx.kimiko.api.events.impl.inventory;

import net.minecraft.screen.slot.SlotActionType;
import rtx.kimiko.api.events.CancellableEvent;

public final class ClickSlotEvent extends CancellableEvent {
   private int windowId;
   private int slotId;
   private int button;
   private SlotActionType actionType;

   public ClickSlotEvent(int windowId, int slotId, int button, SlotActionType actionType) {
      this.windowId = windowId;
      this.slotId = slotId;
      this.button = button;
      this.actionType = actionType;
   }

   public int getWindowId() {
      return this.windowId;
   }

   public int getSlotId() {
      return this.slotId;
   }

   public int getButton() {
      return this.button;
   }

   public SlotActionType getActionType() {
      return this.actionType;
   }
}

