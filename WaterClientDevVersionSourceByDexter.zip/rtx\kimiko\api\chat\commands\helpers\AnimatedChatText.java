package rtx.kimiko.api.chat.commands.helpers;

import net.minecraft.text.OrderedText;
import net.minecraft.text.Style;
import net.minecraft.text.TextColor;
import rtx.kimiko.api.ui.theme.ThemeManager;
import rtx.kimiko.utils.color.ColorAssist;

public final class AnimatedChatText {
   public static final int SENTINEL_TITLE = 12648430;
   public static final int SENTINEL_DECOR = 12648429;
   public static final int SENTINEL_LINE = 12648428;
   private static final float SCROLL_MS = 1400.0F;
   private static final float BAND_GLYPHS = 6.0F;

   private AnimatedChatText() {
   }

   private static int sweepColor(int n, int n2, float f) {
      int n3 = ThemeManager.accentFill(255.0F) & 16777215;
      int n4 = ThemeManager.accentBright(255.0F) & 16777215;
      float f2 = n2 <= 1 ? 0.0F : (float)n / (n2 - 1);
      float f4 = Math.abs(f2 - f);
      f4 = Math.min(f4, 1.0F - f4);
      float f5 = 6.0F / Math.max(1, n2);
      float f6 = Math.max(0.0F, 1.0F - f4 / Math.max(1.0E-4F, f5));
      f6 = f6 * f6 * (3.0F - 2.0F * f6);
      return ColorAssist.interpolateColor(n3, n4, f6) & 16777215;
   }

   public static Style lineStyle() {
      return Style.EMPTY.withColor(TextColor.fromRgb(12648428));
   }

   public static Style decorStyle() {
      return Style.EMPTY.withColor(TextColor.fromRgb(12648429));
   }

   public static Style titleStyle() {
      return Style.EMPTY.withColor(TextColor.fromRgb(12648430));
   }

   public static OrderedText animate(OrderedText orderedText) {
      int[] nArray = new int[]{0};
      orderedText.accept((n, style, n2) -> {
         if (sentinelKind(style) == 0) {
            nArray[0]++;
         }

         return true;
      });
      int n3 = nArray[0];
      float f = (float)(System.currentTimeMillis() % 1400L) / 1400.0F;
      int n4 = ThemeManager.accentBright(255.0F) & 16777215;
      int n5 = ThemeManager.accentFill(255.0F) & 16777215;
      return characterVisitor -> {
         int[] animCounter = new int[]{0};
         return orderedText.accept((charIdx, style, codePoint) -> {
            Style style2 = style;
            int n6 = sentinelKind(style);
            if (n6 == 0) {
               style2 = style.withColor(TextColor.fromRgb(sweepColor(animCounter[0], n3, f)));
               animCounter[0]++;
            } else if (n6 == 1) {
               style2 = style.withColor(TextColor.fromRgb(n4));
            } else if (n6 == 2) {
               style2 = style.withColor(TextColor.fromRgb(n5));
            }

            return characterVisitor.accept(charIdx, style2, codePoint);
         });
      };
   }

   public static boolean hasSentinel(OrderedText orderedText) {
      boolean[] blArray = new boolean[]{false};
      orderedText.accept((n, style, n2) -> {
         if (sentinelKind(style) >= 0) {
            blArray[0] = true;
            return false;
         } else {
            return true;
         }
      });
      return blArray[0];
   }

   private static int sentinelKind(Style style) {
      TextColor textColor = style == null ? null : style.getColor();
      if (textColor == null) {
         return -1;
      } else {
         int n = textColor.getRgb() & 16777215;
         if (n == 12648430) {
            return 0;
         } else if (n == 12648429) {
            return 1;
         } else {
            return n == 12648428 ? 2 : -1;
         }
      }
   }
}

