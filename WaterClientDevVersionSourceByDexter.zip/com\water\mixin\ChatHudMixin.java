package com.water.mixin;

import com.water.module.Module;
import com.water.module.ModuleManager;
import com.water.module.modules.donut.FakeRoles;
import com.water.module.modules.misc.NameProtect;
import java.lang.reflect.Method;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ChatHud.class})
public class ChatHudMixin {
   @Shadow
   private List<?> messages;

   @Inject(
      method = {"addMessage*", "addMessage*", "addMessage*"},
      at = {@At("RETURN")}
   )
   private void afterAddMessage(CallbackInfo ci) {
      Module rtpModule = ModuleManager.INSTANCE.getModuleByName("RTP Home Reset");
      if (rtpModule != null && rtpModule.isEnabled()) {
         if (this.messages != null && !this.messages.isEmpty()) {
            this.messages
               .removeIf(
                  line -> {
                     if (line == null) {
                        return false;
                     } else {
                        try {
                           for (Method m : line.getClass().getDeclaredMethods()) {
                              if (m.getParameterCount() == 0) {
                                 m.setAccessible(true);
                                 if (m.invoke(line) instanceof Text t) {
                                    String text = t.getString().toLowerCase();
                                    return text.contains("home deleted")
                                       || text.contains("home set")
                                       || text.contains("teleported to a random location")
                                       || text.contains("teleported to your home");
                                 }
                              }
                           }
                        } catch (Throwable var8) {
                        }

                        return false;
                     }
                  }
               );
         }
      }
   }

   @ModifyVariable(
      method = {"addMessage"},
      at = @At("HEAD"),
      ordinal = 0,
      argsOnly = true
   )
   private Text modifyChatMessage(Text message) {
      if (message != null && NameProtect.instance != null && NameProtect.instance.isEnabled() && MinecraftClient.getInstance().getSession() != null) {
         String name = MinecraftClient.getInstance().getSession().getUsername();
         if (name != null) {
            String str = message.getString();
            if (str.contains(name)) {
               message = Text.literal(str.replace(name, NameProtect.instance.getFakeName()));
            }
         }
      }

      return FakeRoles.modifyChatText(message);
   }
}

