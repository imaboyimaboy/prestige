package rtx.kimiko.api.mods.geckolib.animatable.client;

import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import rtx.kimiko.api.mods.geckolib.renderer.GeoArmorRenderer;
import rtx.kimiko.api.mods.geckolib.renderer.GeoItemRenderer;

public interface GeoRenderProvider {
   GeoRenderProvider DEFAULT = new GeoRenderProvider() {};

   default GeoItemRenderer<?> getGeoItemRenderer() {
      return null;
   }

   default GeoArmorRenderer<?, ?> getGeoArmorRenderer(ItemStack itemStack, EquipmentSlot equipmentSlot) {
      return null;
   }

   static GeoRenderProvider geoRenderProviderOf(ItemStack itemStack) {
      return DEFAULT;
   }
}

