package com.water.setting;

import net.minecraft.item.ItemStack;

public final class OptionEntry {
   private String value;
   private String label;
   private ItemStack previewStack;

   public OptionEntry(String value, String label, ItemStack previewStack) {
      this.value = value;
      this.label = label;
      this.previewStack = previewStack;
   }

   public ItemStack getPreviewStack() {
      return this.previewStack == null ? ItemStack.EMPTY : this.previewStack.copy();
   }

   public String value() {
      return this.value;
   }

   public String label() {
      return this.label;
   }

   public ItemStack previewStack() {
      return this.previewStack;
   }
}

