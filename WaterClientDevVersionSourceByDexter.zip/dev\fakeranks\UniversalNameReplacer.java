package dev.fakeranks;

import java.util.ArrayList;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Style;

public final class UniversalNameReplacer {
   private UniversalNameReplacer() {
   }

   public static String replace(String value) {
      if (value == null) {
         return null;
      } else {
         try {
            UniversalNameReplacer.NamePair names = activeNames();
            return names == null ? value : value.replace(names.real(), names.custom());
         } catch (Throwable var2) {
            return value;
         }
      }
   }

   public static OrderedText replace(OrderedText value) {
      if (value == null) {
         return null;
      } else {
         try {
            UniversalNameReplacer.NamePair names = activeNames();
            if (names == null) {
               return value;
            } else {
               StringBuilder plain = new StringBuilder();
               ArrayList<Style> styles = new ArrayList<>();
               value.accept((index, style, codePoint) -> {
                  plain.appendCodePoint(codePoint);
                  styles.add(style);
                  return true;
               });
               String source = plain.toString();
               if (!source.contains(names.real())) {
                  return value;
               } else {
                  int realCodePoints = names.real().codePointCount(0, names.real().length());
                  return visitor -> {
                     int sourceChar = 0;
                     int sourceCodePoint = 0;
                     int outputIndex = 0;

                     while (sourceChar < source.length()) {
                        if (source.startsWith(names.real(), sourceChar)) {
                           Style style = styles.get(sourceCodePoint);

                           for (int customChar = 0;
                              customChar < names.custom().length();
                              customChar += Character.charCount(names.custom().codePointAt(customChar))
                           ) {
                              int codePoint = names.custom().codePointAt(customChar);
                              if (!visitor.accept(outputIndex++, style, codePoint)) {
                                 return false;
                              }
                           }

                           sourceChar += names.real().length();
                           sourceCodePoint += realCodePoints;
                        } else {
                           int codePoint = source.codePointAt(sourceChar);
                           if (!visitor.accept(outputIndex++, styles.get(sourceCodePoint), codePoint)) {
                              return false;
                           }

                           sourceChar += Character.charCount(codePoint);
                           sourceCodePoint++;
                        }
                     }

                     return true;
                  };
               }
            }
         } catch (Throwable var6) {
            return value;
         }
      }
   }

   private static UniversalNameReplacer.NamePair activeNames() {
      FakeRanksState state = FakeRanksClient.STATE;
      if (state != null && state.enabled()) {
         String real = state.realPlayerName();
         String custom = state.customName();
         return real != null && !real.isEmpty() && custom != null && !custom.isEmpty() && !real.equals(custom) ? new NamePair(real, custom) : null;
      } else {
         return null;
      }
   }

   final static class NamePair {
      private String real;
      private String custom;

      private NamePair(String real, String custom) {
         this.real = real;
         this.custom = custom;
      }

      public String real() {
         return this.real;
      }

      public String custom() {
         return this.custom;
      }
   }
}

