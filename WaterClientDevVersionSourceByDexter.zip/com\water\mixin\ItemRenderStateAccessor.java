package com.water.mixin;

import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.render.item.ItemRenderState.LayerRenderState;
import net.minecraft.item.ItemDisplayContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({ItemRenderState.class})
public interface ItemRenderStateAccessor {
   @Accessor("layerCount")
   int water$getLayerCount();

   @Accessor("layers")
   LayerRenderState[] water$getLayers();

   @Accessor("displayContext")
   ItemDisplayContext water$getDisplayContext();
}

