package com.water.setting;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.item.ItemStack;

public final class OptionSelectSetting extends Setting<String> {
   private String defaultValue_2;
   private List<OptionEntry> options;

   public OptionSelectSetting(String name, String defaultValue, OptionEntry... options) {
      super(name, defaultValue);
      this.defaultValue_2 = defaultValue;
      this.options = List.of(options);
   }

   public List<OptionEntry> getOptions() {
      return this.options;
   }

   public List<OptionEntry> filter(String query) {
      String normalized = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
      if (normalized.isEmpty()) {
         return this.options;
      } else {
         List<OptionEntry> filtered = new ArrayList<>();

         for (OptionEntry option : this.options) {
            String value = option.value() == null ? "" : option.value().toLowerCase(Locale.ROOT);
            String label = option.label() == null ? "" : option.label().toLowerCase(Locale.ROOT);
            if (value.contains(normalized) || label.contains(normalized)) {
               filtered.add(option);
            }
         }

         return filtered;
      }
   }

   public void select(String value) {
      if (value == null) {
         this.reset();
      } else {
         for (OptionEntry option : this.options) {
            if (option.value().equalsIgnoreCase(value)) {
               this.setValue(option.value());
               return;
            }
         }
      }
   }

   public void reset() {
      this.setValue(this.defaultValue_2);
   }

   public boolean isSelected(OptionEntry option) {
      return option != null && this.getValue() != null && option.value().equalsIgnoreCase(this.getValue());
   }

   public OptionEntry getSelectedOption() {
      for (OptionEntry option : this.options) {
         if (this.isSelected(option)) {
            return option;
         }
      }

      return this.options.isEmpty() ? null : this.options.getFirst();
   }

   public String getSummary() {
      OptionEntry selected = this.getSelectedOption();
      return selected == null ? "Choose" : selected.label();
   }

   public ItemStack getPreviewStack() {
      OptionEntry selected = this.getSelectedOption();
      return selected == null ? ItemStack.EMPTY : selected.getPreviewStack();
   }
}

