package com.water.mixin;

import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.item.ItemRenderState.LayerRenderState;
import net.minecraft.client.render.model.json.Transformation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({LayerRenderState.class})
public interface LayerRenderStateAccessor {
   @Accessor("renderLayer")
   RenderLayer water$getRenderLayer();

   @Accessor("transform")
   Transformation water$getTransform();

   @Accessor("tints")
   int[] water$getTints();
}

