package rtx.kimiko.api.drags;

import net.minecraft.client.MinecraftClient;
import rtx.kimiko.utils.render.render2d.Render2DCoordinateSpace;

public final class Position {
   public static final float SCREEN_MARGIN = 5.0F;
   private float float_;
   private float float2;

   public Position(float f, float f2) {
      this.float_ = f;
      this.float2 = f2;
   }

   public float getFloat() {
      return this.float_;
   }

   public void set(float f, float f2, float f3, float f4) {
      this.float_ = clampX(f, f3);
      this.float2 = clampY(f2, f4);
   }

   public float getFloat2() {
      return this.float2;
   }

   public static float clampX(float f, float f2) {
      float f3 = Math.max(5.0F, screenWidth() - f2 - 5.0F);
      return Math.max(5.0F, Math.min(f3, f));
   }

   public static float clampY(float f, float f2) {
      float f3 = Math.max(5.0F, screenHeight() - f2 - 5.0F);
      return Math.max(5.0F, Math.min(f3, f));
   }

   public void setRaw(float f, float f2) {
      this.float_ = f;
      this.float2 = f2;
   }

   public static float mouseX() {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      if (minecraftClient == null) {
         return 0.0F;
      } else {
         double d = minecraftClient.mouse.getScaledX(minecraftClient.getWindow());
         return (float)(d / Render2DCoordinateSpace.guiIndependentScale());
      }
   }

   public static float mouseY() {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      if (minecraftClient == null) {
         return 0.0F;
      } else {
         double d = minecraftClient.mouse.getScaledY(minecraftClient.getWindow());
         return (float)(d / Render2DCoordinateSpace.guiIndependentScale());
      }
   }

   public static float screenWidth() {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      return minecraftClient != null && minecraftClient.getWindow() != null
         ? minecraftClient.getWindow().getFramebufferWidth() / Render2DCoordinateSpace.designGuiScale()
         : 960.0F;
   }

   public static float screenHeight() {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      return minecraftClient != null && minecraftClient.getWindow() != null
         ? minecraftClient.getWindow().getFramebufferHeight() / Render2DCoordinateSpace.designGuiScale()
         : 540.0F;
   }
}

