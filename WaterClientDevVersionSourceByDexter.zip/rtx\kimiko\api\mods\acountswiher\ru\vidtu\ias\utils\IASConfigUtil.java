package rtx.kimiko.api.mods.acountswiher.ru.vidtu.ias.utils;

public final class IASConfigUtil {
   public static boolean isNullOrBlank(String str) {
      return str == null || str.isBlank();
   }

   public static boolean canUseSunServer() {
      return true;
   }
}

