package com.water.module.modules.donut;

import com.water.module.Category;
import com.water.module.Module;
import com.water.setting.ModeSetting;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;

public final class FakeRoles extends Module {
   public static FakeRoles instance;
   private static final String MODE_NONE = "None";
   private static final String MODE_SRMOD = "SRMOD";
   private static final String MODE_MEDIA = "MEDIA";
   private static final String MODE_SRADMIN = "SRADMIN";
   private static final int TAG_BRACKET = 8355711;
   private static final int TAG_SRMOD = 5635925;
   private static final int TAG_MEDIA = 16733695;
   private static final int TAG_SRADMIN = 16733525;
   private static final int TAG_WHITE = 16777215;
   private final ModeSetting role = new ModeSetting("Role", "None", "None", "SRMOD", "MEDIA", "SRADMIN");

   public FakeRoles() {
      super("FakeRoles", Category.DONUT);
      instance = this;
      this.addSetting(this.role);
   }

   public static boolean isActive() {
      return instance != null && instance.isEnabled() && !instance.role.check("None") && mc != null && mc.player != null;
   }

   public static String getActiveRole() {
      return !isActive() ? null : instance.role.getValue();
   }

   public static String getPlayerName() {
      return mc != null && mc.getSession() != null ? mc.getSession().getUsername() : null;
   }

   public static Text modifyChatText(Text original) {
      if (isActive() && original != null) {
         String playerName = getPlayerName();
         if (playerName != null && !playerName.isBlank()) {
            String plain = original.getString();
            if (!plain.contains(playerName)) {
               return original;
            } else {
               Text prefixed = buildPrefixedName(playerName);
               int idx = plain.indexOf(playerName);
               MutableText result = Text.empty();
               if (idx > 0) {
                  result.append(Text.literal(plain.substring(0, idx)));
               }

               result.append(prefixed);
               int afterIdx = idx + playerName.length();
               if (afterIdx < plain.length()) {
                  result.append(Text.literal(plain.substring(afterIdx)));
               }

               return result;
            }
         } else {
            return original;
         }
      } else {
         return original;
      }
   }

   public static Text buildPrefixedDisplayName(String playerName) {
      return isActive() && playerName != null ? buildPrefixedName(playerName) : null;
   }

   public static String getPrefixedNameString() {
      if (!isActive()) {
         return null;
      } else {
         String playerName = getPlayerName();
         if (playerName == null) {
            return null;
         } else {
            Text prefixed = buildPrefixedName(playerName);
            return prefixed.getString();
         }
      }
   }

   public static Style getRolePrefixStyle() {
      if (!isActive()) {
         return Style.EMPTY;
      } else {
         String activeRole = instance.role.getValue();
         switch (activeRole.hashCode()) {
            case -1236884432:
               if (activeRole.equals("SRADMIN")) {
                  return roleStyle(16733525);
               }
               break;
            case 73234372:
               if (activeRole.equals("MEDIA")) {
                  return roleStyle(16733695);
               }
               break;
            case 79171619:
               if (activeRole.equals("SRMOD")) {
                  return roleStyle(5635925);
               }
         }

         return Style.EMPTY;
      }
   }

   public static Style getRoleBracketStyle() {
      return isActive() ? Style.EMPTY.withColor(TextColor.fromRgb(8355711)).withBold(false) : Style.EMPTY;
   }

   public static Style getRolePrefixStyleForChar(int codePoint) {
      return codePoint != 91 && codePoint != 93 && !Character.isWhitespace(codePoint) ? getRolePrefixStyle() : getRoleBracketStyle();
   }

   public static Style getRoleNameStyle() {
      if (!isActive()) {
         return Style.EMPTY;
      } else {
         String activeRole = instance.role.getValue();
         switch (activeRole.hashCode()) {
            case -1236884432:
               if (activeRole.equals("SRADMIN")) {
                  return roleStyle(16733525);
               }
               break;
            case 73234372:
               if (activeRole.equals("MEDIA")) {
                  return Style.EMPTY.withColor(TextColor.fromRgb(16777215)).withBold(false);
               }
               break;
            case 79171619:
               if (activeRole.equals("SRMOD")) {
                  return roleStyle(5635925);
               }
         }

         return Style.EMPTY;
      }
   }

   public static String getRolePrefixString() {
      if (!isActive()) {
         return null;
      } else {
         String activeRole = instance.role.getValue();
         switch (activeRole.hashCode()) {
            case -1236884432:
               if (activeRole.equals("SRADMIN")) {
                  return "[SR.ADMIN] ";
               }
               break;
            case 73234372:
               if (activeRole.equals("MEDIA")) {
                  return "[MEDIA] ";
               }
               break;
            case 79171619:
               if (activeRole.equals("SRMOD")) {
                  return "[SR.MOD] ";
               }
         }

         return null;
      }
   }

   private static Text buildPrefixedName(String playerName) {
      String activeRole = instance.role.getValue();
      switch (activeRole.hashCode()) {
         case -1236884432:
            if (activeRole.equals("SRADMIN")) {
               return buildSradminName(playerName);
            }
            break;
         case 73234372:
            if (activeRole.equals("MEDIA")) {
               return buildMediaName(playerName);
            }
            break;
         case 79171619:
            if (activeRole.equals("SRMOD")) {
               return buildSrmodName(playerName);
            }
      }

      return Text.literal(playerName);
   }

   private static Text buildSrmodName(String playerName) {
      MutableText result = Text.empty();
      appendTag(result, "SR.MOD", roleStyle(5635925));
      result.append(Text.literal(playerName).setStyle(getRoleNameStyle()));
      return result;
   }

   private static Text buildMediaName(String playerName) {
      MutableText result = Text.empty();
      appendTag(result, "MEDIA", roleStyle(16733695));
      result.append(Text.literal(playerName).setStyle(getRoleNameStyle()));
      return result;
   }

   private static Text buildSradminName(String playerName) {
      MutableText result = Text.empty();
      appendTag(result, "SR.ADMIN", roleStyle(16733525));
      result.append(Text.literal(playerName).setStyle(getRoleNameStyle()));
      return result;
   }

   private static void appendTag(MutableText result, String roleText, Style roleStyle) {
      Style bracketStyle = Style.EMPTY.withColor(TextColor.fromRgb(8355711)).withBold(false);
      result.append(Text.literal("[").setStyle(bracketStyle));
      result.append(Text.literal(roleText).setStyle(roleStyle));
      result.append(Text.literal("] ").setStyle(bracketStyle));
   }

   private static Style roleStyle(int rgb) {
      return Style.EMPTY.withColor(TextColor.fromRgb(rgb)).withBold(true);
   }
}

