package com.water.utils;

import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.WeakHashMap;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

public final class NametagRenderState {
   private static final Set<EntityRenderState> OVERRIDDEN_LABELS = Collections.newSetFromMap(new WeakHashMap<>());

   private NametagRenderState() {
   }

   public static void clear(EntityRenderState state) {
      OVERRIDDEN_LABELS.remove(state);
   }

   public static void mark(EntityRenderState state) {
      OVERRIDDEN_LABELS.add(state);
   }

   public static boolean hasEntry(EntityRenderState state) {
      return OVERRIDDEN_LABELS.contains(state);
   }

   public static boolean isOutlinedLabel(Text text) {
      return false;
   }

   public final static class Entry {
      private Object entity;
      private Vec3d labelPos;
      private Text nameLabel;
      private Text healthLabel;
      private List<NametagRenderState.ItemEntry> items;

      public Entry(Object entity, Vec3d labelPos, Text nameLabel, Text healthLabel, List<NametagRenderState.ItemEntry> items) {
         this.entity = entity;
         this.labelPos = labelPos;
         this.nameLabel = nameLabel;
         this.healthLabel = healthLabel;
         this.items = items;
      }

      public Object entity() {
         return this.entity;
      }

      public Vec3d labelPos() {
         return this.labelPos;
      }

      public Text nameLabel() {
         return this.nameLabel;
      }

      public Text healthLabel() {
         return this.healthLabel;
      }

      public List<NametagRenderState.ItemEntry> items() {
         return this.items;
      }
   }

   public final class ItemEntry {
      private ItemStack stack;

      public ItemEntry(ItemStack stack) {
         this.stack = stack;
      }

      public ItemStack stack() {
         return this.stack;
      }
   }
}

