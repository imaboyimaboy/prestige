package rtx.kimiko.api.mods.geckolib.renderer.base;

import java.util.Optional;
import java.util.function.Consumer;
import rtx.kimiko.api.mods.geckolib.animation.state.BoneSnapshot;
import rtx.kimiko.api.mods.geckolib.cache.model.GeoBone;

public interface BoneSnapshots {
   Optional<BoneSnapshot> get(String var1);

   default BoneSnapshot get(GeoBone geoBone) {
      return geoBone.frameSnapshot != null ? geoBone.frameSnapshot : this.get(geoBone.name()).get();
   }

   default void ifPresent(String string, Consumer<BoneSnapshot> consumer) {
      this.get(string).ifPresent(consumer);
   }
}

