package rtx.kimiko.api.mods.geckolib.event.entity;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.entity.Entity;
import rtx.kimiko.api.mods.geckolib.animatable.GeoAnimatable;
import rtx.kimiko.api.mods.geckolib.event.GeoRenderEvent;
import rtx.kimiko.api.mods.geckolib.renderer.GeoEntityRenderer;
import rtx.kimiko.api.mods.geckolib.renderer.base.GeoRenderState;

public class CompileEntityRenderLayersEvent<T extends Entity & GeoAnimatable, R extends EntityRenderState & GeoRenderState>
   implements GeoRenderEvent<T, Void, R> {
   public static final Event<CompileEntityRenderLayersEvent.Listener> EVENT = EventFactory.createArrayBacked(
      CompileEntityRenderLayersEvent.Listener.class,
      (CompileEntityRenderLayersEvent.Listener)compileEntityRenderLayersEvent -> {},
      listenerArray -> compileEntityRenderLayersEvent -> {
         for (CompileEntityRenderLayersEvent.Listener listener : listenerArray) {
            listener.handle(compileEntityRenderLayersEvent);
         }
      }
   );
   private GeoEntityRenderer<T, R> renderer;

   public CompileEntityRenderLayersEvent(GeoEntityRenderer<T, R> geoEntityRenderer) {
      this.renderer = geoEntityRenderer;
   }

   public GeoEntityRenderer<T, R> getRenderer() {
      return this.renderer;
   }

   public interface Listener {
      void handle(CompileEntityRenderLayersEvent<?, ?> var1);
   }
}

