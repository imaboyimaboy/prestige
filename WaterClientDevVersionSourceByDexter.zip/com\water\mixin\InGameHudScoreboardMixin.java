package com.water.mixin;

import com.water.module.modules.donut.OldDonutScoreboard;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({InGameHud.class})
public class InGameHudScoreboardMixin {
   @Inject(
      method = {"renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/render/RenderTickCounter;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void water$oldDonutScoreboardHideSidebar(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
      if (OldDonutScoreboard.shouldHideVanillaSidebar()) {
         ci.cancel();
      }
   }
}

