package com.water.module.modules.client;

import com.water.module.Category;
import com.water.module.Module;
import com.water.setting.ActionSetting;
import com.water.setting.ModeSetting;
import com.water.setting.Setting;
import com.water.spotify.SpotifyAuth;
import com.water.utils.renderer.AwtFontRenderer;
import java.awt.Color;
import org.lwjgl.glfw.GLFW;
import ru.waterclient.WaterClient;
import ru.waterclient.module.impl.client.MenuSettingsModule;
import ru.waterclient.module.impl.visuals.AspectRation;

public final class WaterPlus extends Module {
   private static WaterPlus INSTANCE;
   private final Setting<Color> accentColor = new Setting<>("Color", new Color(151, 71, 255, 255));
   private final Setting<Color> bgColor = new Setting<>("Background", new Color(12, 12, 12, 255));
   private final Setting<Boolean> animations = new Setting<>("Animations", true);
   private final Setting<Double> tracerWidth = new Setting<>("Tracer Width", 2.0, 1.0, 6.0);
   private final Setting<Double> guiRoundness = new Setting<>("GUI Roundness", 10.0, 0.0, 20.0);
   private final Setting<Integer> glassIntensity = new Setting<>("Glass Intensity", 60, 0, 100);
   private final Setting<Boolean> menuBlur = new Setting<>("Menu Blur", true);
   private final Setting<Integer> accentGlow = new Setting<>("Accent Glow", 0, 0, 100);
   private final ModeSetting rowStyle = new ModeSetting("Row Style", "Minimal", "Filled", "Minimal", "Outlined");
   private final ModeSetting headerStyle = new ModeSetting("Header Style", "Transparent", "Solid", "Gradient", "Transparent");
   private final ModeSetting panelShape = new ModeSetting("Panel Shape", "Rounded", "Rounded", "Sharp", "Pill");
   private final ModeSetting animSpeed = new ModeSetting("Anim Speed", "Normal", "Slow", "Normal", "Fast", "Off");
   private final Setting<Boolean> notifications = new Setting<>("Notifications", true);
   private final Setting<Boolean> notifyIcons = new Setting<>("Notify Icons", true);
   private final Setting<Boolean> moduleIcons = new Setting<>("Module Icons", true);
   private final Setting<Boolean> uiSounds = new Setting<>("UI Sounds", true);
   private final Setting<String> guiKeyName = new Setting<>("GUI Key", "RShift");
   private final ActionSetting stretchAction = new ActionSetting("Stretch", "Stretch", WaterPlus::enableStretch);
   private final ModeSetting menuSize = new ModeSetting("Menu Size", "3", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10");
   private final Setting<String> spotifyClientId = new Setting<>("Spotify Client ID", "");
   private static volatile int resolvedGuiKey = 344;
   public static volatile boolean listeningGuiKey = false;

   public WaterPlus() {
      super("Water +", Category.CLIENT);
      this.addSetting(this.accentColor);
      this.addSetting(this.bgColor);
      this.addSetting(this.glassIntensity);
      this.addSetting(this.menuBlur);
      this.addSetting(this.accentGlow);
      this.addSetting(this.rowStyle);
      this.addSetting(this.headerStyle);
      this.addSetting(this.panelShape);
      this.addSetting(this.animSpeed);
      this.addSetting(this.animations);
      this.addSetting(this.uiSounds);
      this.addSetting(this.notifications);
      this.addSetting(this.notifyIcons);
      this.addSetting(this.guiRoundness);
      this.addSetting(this.guiKeyName);
      this.addSetting(this.stretchAction);
      this.addSetting(this.spotifyClientId);
      INSTANCE = this;
   }

   private static void enableStretch() {
      if (WaterClient.get != null && WaterClient.get.manager != null) {
         AspectRation aspectModule = WaterClient.get.manager.get(AspectRation.class);
         if (aspectModule != null) {
            AspectRation.aspect.currentMode = "4:3";
            AspectRation.aspect.index = AspectRation.aspect.modes.indexOf("4:3");
            if (!aspectModule.enable) {
               aspectModule.toggle();
            }
         }
      }
   }

   @Override
   public void onTick() {
      if (INSTANCE != null) {
         AwtFontRenderer.FontChoice selectedFont = getSelectedFontChoice();
         if (AwtFontRenderer.getFont() != selectedFont) {
            AwtFontRenderer.setFont(selectedFont);
         }

         String cid = this.spotifyClientId.getValue();
         if (cid != null && !cid.isBlank() && !cid.equals(SpotifyAuth.getClientId())) {
            SpotifyAuth.setClientId(cid);
         }

         resolvedGuiKey = nameToGlfw(this.guiKeyName.getValue());
      }
   }

   public static void applyGuiKey(int glfwKeyCode, String keyName) {
      if (INSTANCE != null) {
         INSTANCE.guiKeyName.setValue(keyName);
         resolvedGuiKey = glfwKeyCode;
         listeningGuiKey = false;
      }
   }

   public static String getGuiKeyDisplayName() {
      if (INSTANCE == null) {
         return "RShift";
      } else {
         String v = INSTANCE.guiKeyName.getValue();
         return v != null && !v.isBlank() ? v : "RShift";
      }
   }

   public static float getAccentGlow() {
      return INSTANCE == null ? 0.5F : Math.max(0, Math.min(100, INSTANCE.accentGlow.getValue())) / 100.0F;
   }

   public static String getRowStyle() {
      return INSTANCE == null ? "Filled" : INSTANCE.rowStyle.getValue();
   }

   public static String getHeaderStyle() {
      return INSTANCE == null ? "Solid" : INSTANCE.headerStyle.getValue();
   }

   public static float getEffectiveRoundness() {
      if (INSTANCE == null) {
         return 8.0F;
      } else {
         String shape = INSTANCE.panelShape.getValue();
         switch (shape.hashCode()) {
            case 2487641:
               if (shape.equals("Pill")) {
                  return 20.0F;
               }
               break;
            case 79847370:
               if (shape.equals("Sharp")) {
                  return 0.0F;
               }
         }

         return getGuiRoundness();
      }
   }

   public static float getAnimSpeedMult() {
      if (INSTANCE == null) {
         return 1.0F;
      } else {
         String s = INSTANCE.animSpeed.getValue();
         switch (s.hashCode()) {
            case 79183:
               if (s.equals("Off")) {
                  return 999.0F;
               }
               break;
            case 2182268:
               if (s.equals("Fast")) {
                  return 2.5F;
               }
               break;
            case 2580001:
               if (s.equals("Slow")) {
                  return 0.4F;
               }
         }

         return 1.0F;
      }
   }

   public static boolean animationsEffectivelyEnabled() {
      return !animationsEnabled() ? false : !"Off".equals(INSTANCE == null ? "Normal" : INSTANCE.animSpeed.getValue());
   }

   public static AwtFontRenderer.FontChoice getSelectedFontChoice() {
      return MenuSettingsModule.getSelectedFontChoice();
   }

   public static int getGuiKey() {
      return resolvedGuiKey > 0 ? resolvedGuiKey : 344;
   }

   public static boolean notificationsEnabled() {
      return INSTANCE == null ? true : INSTANCE.notifications.getValue();
   }

   public static boolean uiSoundsEnabled() {
      return INSTANCE == null ? true : INSTANCE.uiSounds.getValue();
   }

   public static boolean notificationIconsEnabled() {
      return INSTANCE == null ? true : INSTANCE.notifyIcons.getValue();
   }

   public static boolean moduleIconsEnabled() {
      return INSTANCE == null ? true : INSTANCE.moduleIcons.getValue();
   }

   public static boolean menuBlurEnabled() {
      return INSTANCE == null ? true : INSTANCE.menuBlur.getValue();
   }

   public static float getGuiRoundness() {
      if (INSTANCE == null) {
         return 8.0F;
      } else {
         double v = INSTANCE.guiRoundness.getValue();
         if (Double.isNaN(v) || Double.isInfinite(v)) {
            v = 8.0;
         }

         return (float)Math.max(0.0, Math.min(20.0, v));
      }
   }

   public static float getGlassIntensity() {
      if (INSTANCE == null) {
         return 0.6F;
      } else {
         int v = INSTANCE.glassIntensity.getValue();
         return Math.max(0, Math.min(100, v)) / 100.0F;
      }
   }

   public static int getAccentARGB() {
      Color c = getAccentColor();
      return c.getAlpha() << 24 | c.getRed() << 16 | c.getGreen() << 8 | c.getBlue();
   }

   public static Color getAccentColor() {
      return INSTANCE == null ? new Color(151, 71, 255, 255) : INSTANCE.accentColor.getValue();
   }

   public static void setAccentColor(Color color) {
      if (INSTANCE != null && color != null) {
         INSTANCE.accentColor.setValue(new Color(color.getRed(), color.getGreen(), color.getBlue(), 255));
      }
   }

   public static int getBackgroundARGB() {
      Color c = getBackgroundColor();
      float glass = getGlassIntensity();
      int baseAlpha = c.getAlpha();
      int glassAlpha = (int)(baseAlpha * (1.0F - glass * 0.82F));
      glassAlpha = Math.max(15, Math.min(255, glassAlpha));
      return glassAlpha << 24 | c.getRed() << 16 | c.getGreen() << 8 | c.getBlue();
   }

   public static Color getBackgroundColor() {
      if (INSTANCE == null) {
         return new Color(12, 12, 12, 255);
      } else {
         Color c = INSTANCE.bgColor.getValue();
         if (c == null) {
            return new Color(12, 12, 12, 255);
         } else {
            return c.getAlpha() < 200 ? new Color(c.getRed(), c.getGreen(), c.getBlue(), 255) : c;
         }
      }
   }

   public static boolean animationsEnabled() {
      return INSTANCE == null ? true : INSTANCE.animations.getValue();
   }

   public static int menuSizePercent() {
      if (INSTANCE == null) {
         return 5;
      } else {
         try {
            return Integer.parseInt(INSTANCE.menuSize.getValue());
         } catch (Exception var1) {
            return 5;
         }
      }
   }

   public static String getSpotifyClientId() {
      if (INSTANCE == null) {
         return "";
      } else {
         String v = INSTANCE.spotifyClientId.getValue();
         return v != null ? v : "";
      }
   }

   public static float tracerLineWidth() {
      if (INSTANCE == null) {
         return 2.0F;
      } else {
         double v = 2.0;

         try {
            v = INSTANCE.tracerWidth.getValue();
         } catch (Exception var3) {
         }

         if (Double.isNaN(v) || Double.isInfinite(v)) {
            v = 1.0;
         }

         v = Math.max(1.0, Math.min(6.0, v));
         return (float)v;
      }
   }

   public static int nameToGlfw(String name) {
      if (name == null) {
         return 344;
      } else {
         switch (name.hashCode()) {
            case -2099925287:
               if (name.equals("Insert")) {
                  return 260;
               }
               break;
            case -2039297130:
               if (name.equals("LShift")) {
                  return 340;
               }
               break;
            case -1911885927:
               if (name.equals("PageDn")) {
                  return 267;
               }
               break;
            case -1911885398:
               if (name.equals("PageUp")) {
                  return 266;
               }
               break;
            case -1867522224:
               if (name.equals("RShift")) {
                  return 344;
               }
               break;
            case 69819:
               if (name.equals("End")) {
                  return 269;
               }
               break;
            case 83829:
               if (name.equals("Tab")) {
                  return 258;
               }
               break;
            case 2255103:
               if (name.equals("Home")) {
                  return 268;
               }
               break;
            case 2330045:
               if (name.equals("LAlt")) {
                  return 342;
               }
               break;
            case 2508791:
               if (name.equals("RAlt")) {
                  return 346;
               }
               break;
            case 67114680:
               if (name.equals("Enter")) {
                  return 257;
               }
               break;
            case 72298711:
               if (name.equals("LCtrl")) {
                  return 341;
               }
               break;
            case 77839837:
               if (name.equals("RCtrl")) {
                  return 345;
               }
               break;
            case 2043376075:
               if (name.equals("Delete")) {
                  return 261;
               }
         }

         char var10000;
         if (name.length() == 1) {
            char var19 = GLFW.glfwGetKeyScancode(name.charAt(0)) > 0 ? name.toUpperCase().charAt(0) : 344;
            var10000 = var19;
         } else {
            label82:
            if (name.startsWith("F") && name.length() <= 3) {
               int var22;
               try {
                  int num = Integer.parseInt(name.substring(1));
                  var22 = 290 + (num - 1);
               } catch (Exception var6) {
                  break label82;
               }

               return var22;
            }

            label75:
            if (name.startsWith("KP")) {
               int var21;
               try {
                  int num = Integer.parseInt(name.substring(2));
                  var21 = 320 + num;
               } catch (Exception var5) {
                  break label75;
               }

               return var21;
            }

            short var20 = 344;
            var10000 = (char)var20;
         }

         return var10000;
      }
   }

   static String _c0f4a84b9a3() {
      return "I";
   }
}

