package com.water.mixin;

import com.water.module.modules.misc.Freelook;
import com.water.module.modules.render.DevSpawnerVisuals;
import com.water.module.modules.render.TotemGlow;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({HeldItemRenderer.class})
public class HeldItemRendererMixin {
   @Inject(
      method = {"renderFirstPersonItem"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onRenderFirstPersonItem(CallbackInfo ci) {
      if (Freelook.instance != null && Freelook.instance.isCameraActive()) {
         ci.cancel();
      }
   }

   @ModifyVariable(
      method = {"renderItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemDisplayContext;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;I)V"},
      at = @At("HEAD"),
      argsOnly = true,
      ordinal = 0
   )
   private ItemStack water$devSpawnerHeldIcon(ItemStack stack) {
      return DevSpawnerVisuals.spoofedStack(stack);
   }

   @Inject(
      method = {"renderItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemDisplayContext;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;I)V"},
      at = {@At("HEAD")}
   )
   private void water$totemGlow(
      LivingEntity entity, ItemStack stack, ItemDisplayContext renderMode, MatrixStack matrices, OrderedRenderCommandQueue queue, int light, CallbackInfo ci
   ) {
      if (renderMode == ItemDisplayContext.FIRST_PERSON_RIGHT_HAND || renderMode == ItemDisplayContext.FIRST_PERSON_LEFT_HAND) {
         TotemGlow.render(entity, stack, renderMode, matrices, queue, light);
      }
   }
}

