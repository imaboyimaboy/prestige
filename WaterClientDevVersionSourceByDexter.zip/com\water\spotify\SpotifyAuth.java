package com.water.spotify;

import java.awt.Desktop;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URI;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class SpotifyAuth {
   private static String CLIENT_ID = "";
   private static final String REDIRECT_URI = "http://localhost:8888/callback";
   private static final String SCOPES = "user-read-playback-state user-modify-playback-state user-read-currently-playing playlist-read-private playlist-read-collaborative";
   private static final Path TOKEN_FILE = Paths.get(System.getProperty("user.home"), ".water_spotify_token");
   private static volatile String accessToken = null;
   private static volatile String refreshToken = null;
   private static volatile long expiresAt = 0L;
   private static volatile boolean authInProgress = false;
   private static final ExecutorService exec = Executors.newSingleThreadExecutor(r -> {
      Thread t = new Thread(r, "spotify-auth");
      t.setDaemon(true);
      return t;
   });

   public static void setClientId(String id) {
      if (id != null && !id.isBlank() && !id.equals(CLIENT_ID)) {
         CLIENT_ID = id.trim();

         try {
            Files.deleteIfExists(TOKEN_FILE);
         } catch (Exception var2) {
         }

         accessToken = null;
         refreshToken = null;
         expiresAt = 0L;
      }
   }

   public static String getClientId() {
      return CLIENT_ID;
   }

   public static boolean isConfigured() {
      return !CLIENT_ID.isBlank();
   }

   public static boolean isAuthed() {
      if (accessToken != null && System.currentTimeMillis() < expiresAt - 30000L) {
         return true;
      } else {
         loadTokenFromDisk();
         return accessToken != null && System.currentTimeMillis() < expiresAt - 30000L;
      }
   }

   public static String getToken() {
      if (!isAuthed()) {
         return null;
      } else {
         if (System.currentTimeMillis() > expiresAt - 60000L) {
            exec.submit(SpotifyAuth::doRefresh);
         }

         return accessToken;
      }
   }

   public static void startAuth(Runnable onSuccess, Runnable onFail) {
      if (isConfigured() && !authInProgress) {
         authInProgress = true;
         exec.submit(
            () -> {
               try {
                  byte[] verifierBytes = new byte[64];
                  new SecureRandom().nextBytes(verifierBytes);
                  String codeVerifier = Base64.getUrlEncoder().withoutPadding().encodeToString(verifierBytes);
                  MessageDigest digest = MessageDigest.getInstance("SHA-256");
                  byte[] hash = digest.digest(codeVerifier.getBytes(StandardCharsets.US_ASCII));
                  String codeChallenge = Base64.getUrlEncoder().withoutPadding().encodeToString(hash);
                  byte[] stateBytes = new byte[16];
                  new SecureRandom().nextBytes(stateBytes);
                  String state = Base64.getUrlEncoder().withoutPadding().encodeToString(stateBytes);
                  String authUrl = "https://accounts.spotify.com/authorize?client_id="
                     + URLEncoder.encode(CLIENT_ID, StandardCharsets.UTF_8)
                     + "&response_type=code&redirect_uri="
                     + URLEncoder.encode("http://localhost:8888/callback", StandardCharsets.UTF_8)
                     + "&scope="
                     + URLEncoder.encode(
                        "user-read-playback-state user-modify-playback-state user-read-currently-playing playlist-read-private playlist-read-collaborative",
                        StandardCharsets.UTF_8
                     )
                     + "&state="
                     + state
                     + "&code_challenge_method=S256&code_challenge="
                     + codeChallenge;
                  Desktop.getDesktop().browse(new URI(authUrl));
                  String code = waitForCallback(state);
                  if (code == null) {
                     if (onFail != null) {
                        onFail.run();
                     }

                     return;
                  }

                  String tokenJson = exchangeCode(code, codeVerifier);
                  if (tokenJson != null) {
                     parseAndSaveToken(tokenJson);
                     if (onSuccess != null) {
                        onSuccess.run();
                     }

                     return;
                  }

                  if (onFail != null) {
                     onFail.run();
                  }
               } catch (Exception var15) {
                  if (onFail != null) {
                     onFail.run();
                  }

                  return;
               } finally {
                  authInProgress = false;
               }
            }
         );
      }
   }

   private static String waitForCallback(String expectedState) throws Exception {
      String var21;
      try (ServerSocket server = new ServerSocket(8888)) {
         server.setSoTimeout(120000);

         try (Socket client = server.accept()) {
            BufferedReader br = new BufferedReader(new InputStreamReader(client.getInputStream(), StandardCharsets.UTF_8));
            String line = br.readLine();
            if (line == null) {
               return null;
            }

            String path = line.split(" ")[1];
            String query = path.contains("?") ? path.split("\\?", 2)[1] : "";
            String code = null;
            String state = null;

            for (String param : query.split("&")) {
               String[] kv = param.split("=", 2);
               if (kv.length == 2) {
                  if (kv[0].equals("code")) {
                     code = URLDecoder.decode(kv[1], StandardCharsets.UTF_8);
                  }

                  if (kv[0].equals("state")) {
                     state = URLDecoder.decode(kv[1], StandardCharsets.UTF_8);
                  }
               }
            }

            String response = "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n<html><body style='background:#0a0e18;color:#5be6d0;font-family:sans-serif;text-align:center;padding:50px'><h2>✓ Water Client connected to Spotify</h2><p>You can close this tab and return to Minecraft.</p></body></html>";
            client.getOutputStream().write(response.getBytes(StandardCharsets.UTF_8));
            if (!expectedState.equals(state)) {
               return null;
            }

            var21 = code;
         }
      }

      return var21;
   }

   private static String exchangeCode(String code, String codeVerifier) throws Exception {
      String body = "grant_type=authorization_code&code="
         + URLEncoder.encode(code, StandardCharsets.UTF_8)
         + "&redirect_uri="
         + URLEncoder.encode("http://localhost:8888/callback", StandardCharsets.UTF_8)
         + "&client_id="
         + URLEncoder.encode(CLIENT_ID, StandardCharsets.UTF_8)
         + "&code_verifier="
         + URLEncoder.encode(codeVerifier, StandardCharsets.UTF_8);
      URL url = new URL("https://accounts.spotify.com/api/token");
      HttpURLConnection conn = (HttpURLConnection)url.openConnection();
      conn.setRequestMethod("POST");
      conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
      conn.setDoOutput(true);
      conn.setConnectTimeout(10000);
      conn.setReadTimeout(10000);

      try (OutputStream os = conn.getOutputStream()) {
         os.write(body.getBytes(StandardCharsets.UTF_8));
      }

      if (conn.getResponseCode() != 200) {
         return null;
      } else {
         String var8;
         try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();

            String line;
            while ((line = br.readLine()) != null) {
               sb.append(line);
            }

            var8 = sb.toString();
         }

         return var8;
      }
   }

   private static void doRefresh() {
      if (refreshToken != null) {
         try {
            String body = "grant_type=refresh_token&refresh_token="
               + URLEncoder.encode(refreshToken, StandardCharsets.UTF_8)
               + "&client_id="
               + URLEncoder.encode(CLIENT_ID, StandardCharsets.UTF_8);
            URL url = new URL("https://accounts.spotify.com/api/token");
            HttpURLConnection conn = (HttpURLConnection)url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setDoOutput(true);
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(10000);

            try (OutputStream os = conn.getOutputStream()) {
               os.write(body.getBytes(StandardCharsets.UTF_8));
            }

            if (conn.getResponseCode() != 200) {
               return;
            }

            try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
               StringBuilder sb = new StringBuilder();

               String line;
               while ((line = br.readLine()) != null) {
                  sb.append(line);
               }

               parseAndSaveToken(sb.toString());
            }
         } catch (Exception var10) {
         }
      }
   }

   private static void parseAndSaveToken(String json) {
      accessToken = extractJson(json, "access_token");
      String newRefresh = extractJson(json, "refresh_token");
      if (newRefresh != null) {
         refreshToken = newRefresh;
      }

      String expiresIn = extractJson(json, "expires_in");
      long exp = expiresIn != null ? Long.parseLong(expiresIn) : 3600L;
      expiresAt = System.currentTimeMillis() + exp * 1000L;
      saveTokenToDisk();
   }

   private static void saveTokenToDisk() {
      try {
         String data = "null\nnull\n0";
         Files.writeString(TOKEN_FILE, data, StandardCharsets.UTF_8);
      } catch (Exception var1) {
      }
   }

   private static void loadTokenFromDisk() {
      try {
         if (!Files.exists(TOKEN_FILE)) {
            return;
         }

         String[] lines = Files.readString(TOKEN_FILE, StandardCharsets.UTF_8).split("\n");
         if (lines.length >= 3) {
            accessToken = lines[0].trim();
            refreshToken = lines[1].trim();
            expiresAt = Long.parseLong(lines[2].trim());
            if (System.currentTimeMillis() > expiresAt - 30000L && refreshToken != null) {
               doRefresh();
            }
         }
      } catch (Exception var1) {
      }
   }

   private static String extractJson(String json, String key) {
      String search = "\"null\":";
      int i = json.indexOf("\"null\":");
      if (i < 0) {
         return null;
      } else {
         i += 7;

         while (i < json.length() && (json.charAt(i) == ' ' || json.charAt(i) == '"')) {
            i++;
         }

         int end = i;

         while (end < json.length() && json.charAt(end) != '"' && json.charAt(end) != ',' && json.charAt(end) != '}') {
            end++;
         }

         return json.substring(i, end).trim();
      }
   }

   public static boolean isAuthInProgress() {
      return authInProgress;
   }
}

