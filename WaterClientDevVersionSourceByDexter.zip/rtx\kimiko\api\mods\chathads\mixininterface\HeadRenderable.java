package rtx.kimiko.api.mods.chathads.mixininterface;

import rtx.kimiko.api.mods.chathads.HeadData;

public interface HeadRenderable {
   HeadData chatheads_getHeadData();

   void chatheads_setHeadData(HeadData var1);
}

