package rtx.kimiko.api.mods.geckolib.loading.json.raw;

import com.google.gson.JsonDeserializer;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import net.minecraft.util.JsonHelper;
import rtx.kimiko.api.mods.geckolib.loading.definition.geometry.GeometryDescription;
import rtx.kimiko.api.mods.geckolib.util.JsonUtil;

public final class MinecraftGeometry {
   private Bone[] bones;
   private String cape;
   private GeometryDescription geometryDescription;

   public MinecraftGeometry(Bone[] bones, String cape, GeometryDescription geometryDescription) {
      this.bones = bones;
      this.cape = cape;
      this.geometryDescription = geometryDescription;
   }

   public static JsonDeserializer<MinecraftGeometry> deserializer() throws JsonParseException {
      return (jsonElement, type, jsonDeserializationContext) -> {
         JsonObject jsonObject = jsonElement.getAsJsonObject();
         Bone[] boneArray = JsonUtil.jsonArrayToObjectArray(JsonHelper.getArray(jsonObject, "bones", null), jsonDeserializationContext, Bone.class);
         String string = JsonHelper.getString(jsonObject, "cape", null);
         GeometryDescription geometryDescription = (GeometryDescription)JsonHelper.deserialize(
            jsonObject, "description", null, jsonDeserializationContext, GeometryDescription.class
         );
         if (boneArray == null) {
            boneArray = new Bone[0];
         }

         return new MinecraftGeometry(boneArray, string, geometryDescription);
      };
   }

   public Bone[] bones() {
      return this.bones;
   }

   public String cape() {
      return this.cape;
   }

   public GeometryDescription geometryDescription() {
      return this.geometryDescription;
   }
}

