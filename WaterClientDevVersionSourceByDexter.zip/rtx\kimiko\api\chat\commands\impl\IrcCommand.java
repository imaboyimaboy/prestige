package rtx.kimiko.api.chat.commands.impl;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.text.ClickEvent.RunCommand;
import net.minecraft.text.HoverEvent.ShowText;
import net.minecraft.util.Formatting;
import rtx.kimiko.api.chat.commands.Command;
import rtx.kimiko.api.chat.commands.CommandManager;
import rtx.kimiko.api.chat.commands.helpers.CommandDividers;
import rtx.kimiko.api.chat.irc.IrcClient;
import rtx.kimiko.api.chat.irc.IrcPrefix;
import rtx.kimiko.api.modules.impl.Utils.Irc;

public final class IrcCommand extends Command {
   public IrcCommand() {
      super("irc", "IRC chat: send messages and pick your prefix");
   }

   @Override
   public void execute(String string, String[] stringArray) {
      if (stringArray.length == 0) {
         this.usage();
      } else {
         String string2 = stringArray[0].toLowerCase();
         if (string2.equals("prefix")) {
            this.handlePrefix(stringArray);
         } else if (string2.equals("block")) {
            this.handleBlock(stringArray);
         } else if (string2.equals("unblock")) {
            this.handleUnblock(stringArray);
         } else if (string2.equals("blocklist")) {
            this.handleBlocklist();
         } else {
            Irc irc = Irc.getInstance();
            if (irc == null || !irc.isEnabled()) {
               this.logDirect("Enable the IRC module first.", Formatting.RED);
            } else if (string2.equals("online")) {
               this.logDirect("Online: " + IrcClient.INSTANCE.online() + (IrcClient.INSTANCE.isConnected() ? "" : " (bridge offline)"));
            } else if (string2.equals("pm")) {
               this.handlePm(stringArray);
            } else {
               String string3 = String.join(" ", stringArray).trim();
               if (string3.isEmpty()) {
                  this.logDirect("Nothing to send.", Formatting.RED);
               } else {
                  IrcClient.INSTANCE.send(string3);
               }
            }
         }
      }
   }

   @Override
   public List<String> getLongDesc() {
      return Arrays.asList(
         "IRC chat over the local bridge.",
         "Usage:",
         "> irc <message>",
         "> irc pm <name> <message>",
         "> irc block <name>",
         "> irc unblock <name>",
         "> irc blocklist",
         "> irc prefix",
         "> irc prefix list",
         "> irc prefix <id>",
         "> irc online"
      );
   }

   @Override
   public Stream<String> tabComplete(String string2, String[] stringArray) {
      if (stringArray.length == 1) {
         return Stream.of("pm", "block", "unblock", "blocklist", "prefix", "online").filter(string -> string.startsWith(stringArray[0].toLowerCase()));
      } else if (stringArray.length == 2 && stringArray[0].equalsIgnoreCase("prefix")) {
         Stream<String> stream = Stream.concat(Stream.of("list"), Arrays.stream(IrcPrefix.ids()));
         return stream.filter(string -> string.startsWith(stringArray[1].toLowerCase()));
      } else {
         return stringArray.length == 2 && stringArray[0].equalsIgnoreCase("unblock")
            ? IrcClient.INSTANCE.blockedNames().stream().filter(string -> string.startsWith(stringArray[1].toLowerCase()))
            : Stream.empty();
      }
   }

   private void handlePrefix(String[] stringArray) {
      if (stringArray.length == 1) {
         IrcPrefix ircPrefix = IrcClient.INSTANCE.prefix();
         MutableText mutableText = IrcClient.brand().append(Text.literal("Your prefix: ").formatted(Formatting.GRAY));
         mutableText.append((Text)(ircPrefix.isNone() ? Text.literal("none").formatted(Formatting.DARK_GRAY) : ircPrefix.component()));
         this.logDirectRaw(mutableText);
         this.logDirect("Use \"irc prefix list\" to see all, \"irc prefix <id>\" to set one.");
      } else if (stringArray[1].equalsIgnoreCase("list")) {
         this.renderPrefixList();
      } else {
         IrcPrefix ircPrefix = IrcPrefix.fromId(stringArray[1]);
         if (ircPrefix.isNone() && !stringArray[1].equalsIgnoreCase("none")) {
            this.logDirect("Unknown prefix '" + stringArray[1] + "'. Use irc prefix list.", Formatting.RED);
         } else {
            IrcClient.INSTANCE.setPrefix(ircPrefix);
            MutableText mutableText = IrcClient.brand().append(Text.literal("Успешно установлен префикс ").formatted(Formatting.WHITE));
            mutableText.append((Text)(ircPrefix.isNone() ? Text.literal("none").formatted(Formatting.DARK_GRAY) : ircPrefix.component()));
            this.logDirectRaw(mutableText);
         }
      }
   }

   private void handleBlock(String[] stringArray) {
      if (stringArray.length < 2) {
         this.logDirect("Usage: irc block <name>", Formatting.RED);
      } else {
         String string = stringArray[1].trim();
         if (string.isEmpty()) {
            this.logDirect("Specify who to block.", Formatting.RED);
         } else if (string.equalsIgnoreCase(IrcClient.INSTANCE.effectiveName())) {
            this.logDirect("You can't block yourself.", Formatting.RED);
         } else {
            if (IrcClient.INSTANCE.block(string)) {
               this.logDirect("Blocked null. You won't see their messages.");
            } else {
               this.logDirect("null is already blocked.", Formatting.YELLOW);
            }
         }
      }
   }

   private void handleBlocklist() {
      List<String> list = IrcClient.INSTANCE.blockedNames();
      if (list.isEmpty()) {
         this.logDirect("Your blocklist is empty.");
      } else {
         int n = CommandDividers.calcLineCountForContent("IRC BLOCKLIST", list);
         this.logDirectRaw(CommandDividers.header("IRC BLOCKLIST", n));
         String string2 = CommandManager.get().getPrefix();

         for (String string3 : list) {
            MutableText mutableText = Text.literal(string3)
               .styled(
                  style -> style.withColor(Formatting.WHITE)
                     .withHoverEvent(new ShowText(Text.literal("Нажми, чтобы разблокировать null").formatted(Formatting.GRAY)))
                     .withClickEvent(new RunCommand("nullirc unblock null"))
               );
            this.logDirectRaw(mutableText);
         }

         this.logDirectRaw(CommandDividers.footer("IRC BLOCKLIST", n));
         MutableText mutableText = Text.literal("Нажми на ник, чтобы разблокировать").styled(style -> style.withColor(Formatting.GRAY).withItalic(true));
         this.logDirectRaw(mutableText);
      }
   }

   private void handleUnblock(String[] stringArray) {
      if (stringArray.length < 2) {
         this.logDirect("Usage: irc unblock <name>", Formatting.RED);
      } else {
         String string = stringArray[1].trim();
         if (string.isEmpty()) {
            this.logDirect("Specify who to unblock.", Formatting.RED);
         } else {
            if (IrcClient.INSTANCE.unblock(string)) {
               this.logDirect("Unblocked null.");
            } else {
               this.logDirect("null isn't blocked.", Formatting.YELLOW);
            }
         }
      }
   }

   private void renderPrefixList() {
      String string = CommandManager.get().getPrefix();
      List<String> list = Arrays.stream(IrcPrefix.values()).filter(ircPrefix -> !ircPrefix.isNone()).map(IrcPrefix::display).toList();
      int n = CommandDividers.calcLineCountForContent("IRC PREFIXES", list);
      this.logDirectRaw(CommandDividers.header("IRC PREFIXES", n));

      for (IrcPrefix ircPrefix2 : IrcPrefix.values()) {
         if (!ircPrefix2.isNone()) {
            String string3 = ircPrefix2.display().trim();
            MutableText mutableText = Text.empty()
               .styled(
                  style -> style.withHoverEvent(new ShowText(Text.literal("Нажми, чтобы выбрать: null").formatted(Formatting.GRAY)))
                     .withClickEvent(new RunCommand(string + "irc prefix " + ircPrefix2.id()))
               );
            mutableText.append(ircPrefix2.component());
            this.logDirectRaw(mutableText);
         }
      }

      this.logDirectRaw(CommandDividers.footer("IRC PREFIXES", n));
      MutableText mutableText = Text.literal("Нажми на префикс, чтобы выбрать его").styled(style -> style.withColor(Formatting.GRAY).withItalic(true));
      this.logDirectRaw(mutableText);
   }

   private void handlePm(String[] stringArray) {
      if (stringArray.length < 3) {
         this.logDirect("Usage: irc pm <name> <message>", Formatting.RED);
      } else {
         String string = stringArray[1].trim();
         if (string.isEmpty()) {
            this.logDirect("Specify who to message.", Formatting.RED);
         } else if (string.equalsIgnoreCase(IrcClient.INSTANCE.effectiveName())) {
            this.logDirect("You can't private-message yourself.", Formatting.RED);
         } else {
            String string2 = String.join(" ", Arrays.copyOfRange(stringArray, 2, stringArray.length)).trim();
            if (string2.isEmpty()) {
               this.logDirect("Nothing to send.", Formatting.RED);
            } else {
               IrcClient.INSTANCE.send(string2, string);
            }
         }
      }
   }
}

