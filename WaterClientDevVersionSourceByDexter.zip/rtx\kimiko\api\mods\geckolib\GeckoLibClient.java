package rtx.kimiko.api.mods.geckolib;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.resource.v1.ResourceLoader;
import net.minecraft.network.packet.CustomPayload.Id;
import net.minecraft.resource.ResourceType;
import rtx.kimiko.api.mods.geckolib.cache.GeckoLibResources;
import rtx.kimiko.api.mods.geckolib.network.packet.MultiloaderPacket;

public class GeckoLibClient implements ClientModInitializer {
   public static <P extends MultiloaderPacket> void registerPacket(Id<P> id) {
      ClientPlayNetworking.registerGlobalReceiver(
         id, (multiloaderPacket, context) -> multiloaderPacket.receiveMessage(context.player(), arg_0 -> context.client().execute(arg_0))
      );
   }

   public void onInitializeClient() {
      ResourceLoader.get(ResourceType.CLIENT_RESOURCES).registerReloader(GeckoLibResources.RELOAD_LISTENER_ID, GeckoLibResources::reload);
   }
}

