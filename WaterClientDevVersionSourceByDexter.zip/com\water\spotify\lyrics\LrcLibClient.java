package com.water.spotify.lyrics;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpClient.Redirect;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

public final class LrcLibClient {
   private static final String API_GET = "https://lrclib.net/api/get";
   private static final String API_SEARCH = "https://lrclib.net/api/search";
   private static final Map<String, List<LyricLine>> LYRICS_CACHE = new ConcurrentHashMap<>();
   private static final HttpClient HTTP_CLIENT = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(12L)).followRedirects(Redirect.NORMAL).build();

   private LrcLibClient() {
   }

   public static CompletableFuture<List<LyricLine>> fetchLyricsAsync(String trackName, String artistName, boolean debugMode) {
      if (trackName != null && !trackName.isBlank()) {
         String cacheKey = (trackName.trim() + " - " + (artistName != null ? artistName.trim() : "")).toLowerCase(Locale.ROOT);
         if (LYRICS_CACHE.containsKey(cacheKey)) {
            if (debugMode) {
               System.out.printf("[Spotify Lyric] Взято из кэша: %s (%d строк)\n", cacheKey, LYRICS_CACHE.get(cacheKey).size());
            }

            return CompletableFuture.completedFuture(LYRICS_CACHE.get(cacheKey));
         } else {
            return CompletableFuture.supplyAsync(() -> {
               List<LyricLine> lines = tryFetchGet(trackName, artistName, debugMode);
               if (!lines.isEmpty()) {
                  LYRICS_CACHE.put(cacheKey, lines);
                  return lines;
               } else {
                  lines = tryFetchSearch(trackName, artistName, debugMode);
                  if (!lines.isEmpty()) {
                     LYRICS_CACHE.put(cacheKey, lines);
                     return lines;
                  } else {
                     return Collections.emptyList();
                  }
               }
            });
         }
      } else {
         return CompletableFuture.completedFuture(Collections.emptyList());
      }
   }

   private static List<LyricLine> tryFetchGet(String trackName, String artistName, boolean debugMode) {
      String cleanTrack = cleanTrackName(trackName);
      String cleanArtist = artistName != null ? artistName.trim() : "";
      String query = String.format(
         "?track_name=%s&artist_name=%s", URLEncoder.encode(cleanTrack, StandardCharsets.UTF_8), URLEncoder.encode(cleanArtist, StandardCharsets.UTF_8)
      );
      return executeRequest("https://lrclib.net/api/getnull", debugMode);
   }

   private static List<LyricLine> tryFetchSearch(String trackName, String artistName, boolean debugMode) {
      String cleanTrack = cleanTrackName(trackName);
      String cleanArtist = artistName != null ? artistName.trim() : "";
      String searchQuery = "null null";
      String query = "?q=" + URLEncoder.encode(searchQuery, StandardCharsets.UTF_8);

      try {
         HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create("https://lrclib.net/api/searchnull"))
            .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
            .timeout(Duration.ofSeconds(14L))
            .GET()
            .build();
         HttpResponse<String> response = HTTP_CLIENT.send(request, BodyHandlers.ofString());
         if (response.statusCode() == 200) {
            for (JsonElement elem : JsonParser.parseString(response.body()).getAsJsonArray()) {
               if (elem.isJsonObject()) {
                  JsonObject obj = elem.getAsJsonObject();
                  if (obj.has("trackName")
                     && obj.has("artistName")
                     && cleanTrackName(obj.get("trackName").getAsString()).equalsIgnoreCase(cleanTrack)
                     && obj.get("artistName").getAsString().equalsIgnoreCase(cleanArtist)
                     && obj.has("syncedLyrics")
                     && !obj.get("syncedLyrics").isJsonNull()) {
                     String syncedLrc = obj.get("syncedLyrics").getAsString();
                     List<LyricLine> parsed = LrcParser.parse(syncedLrc);
                     if (!parsed.isEmpty()) {
                        if (debugMode) {
                           System.out.println("[Spotify Lyric] Найден текст через Search Fallback!");
                        }

                        return parsed;
                     }
                  }
               }
            }
         }
      } catch (Exception var15) {
         if (debugMode) {
            System.err.println("[Spotify Lyric/Debug] Search Fallback Exception: " + var15.getMessage());
         }
      }

      return Collections.emptyList();
   }

   private static List<LyricLine> executeRequest(String url, boolean debugMode) {
      for (int attempt = 1; attempt <= 2; attempt++) {
         try {
            HttpRequest request = HttpRequest.newBuilder()
               .uri(URI.create(url))
               .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
               .timeout(Duration.ofSeconds(14L))
               .GET()
               .build();
            HttpResponse<String> response = HTTP_CLIENT.send(request, BodyHandlers.ofString());
            if (response.statusCode() == 200) {
               JsonObject json = JsonParser.parseString(response.body()).getAsJsonObject();
               if (json.has("syncedLyrics") && !json.get("syncedLyrics").isJsonNull()) {
                  String syncedLrc = json.get("syncedLyrics").getAsString();
                  return LrcParser.parse(syncedLrc);
               }
            }
         } catch (Exception var8) {
            if (debugMode) {
               System.err.printf("[Spotify Lyric/Debug] Попытка %d не удалась: %s\n", attempt, var8.getMessage());
            }

            if (attempt < 2) {
               try {
                  Thread.sleep(400L);
               } catch (InterruptedException var7) {
               }
            }
         }
      }

      return Collections.emptyList();
   }

   private static String cleanTrackName(String trackName) {
      return trackName == null ? "" : trackName.replaceAll("\\(.*?\\)", "").replaceAll("\\[.*?\\]", "").trim();
   }
}

