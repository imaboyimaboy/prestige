package com.water.module.modules.misc;

import com.water.module.ActivatableModule;
import com.water.module.Category;
import com.water.module.modules.client.Friends;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Collection;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.network.ServerInfo.ServerType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardEntry;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.Team;
import net.minecraft.text.Text;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult.Type;

public final class AutoLog extends ActivatableModule {
   private static final long COMBAT_COOLDOWN_MS = 20000L;
   private static final int COMBAT_COOLDOWN_TICKS = 400;
   private static final double COMBAT_GRACE_RANGE = 8.0;
   private static final long SERVER_COMBAT_GRACE_MS = 1500L;
   private static final int MAX_TEXT_SCAN_DEPTH = 4;
   private long lastHitTime;
   private long lastAttackTime;
   private long lastServerCombatTagTime;
   private float lastCombinedHealth = -1.0F;
   private int lastObservedAttackedTick = -1;
   private int lastObservedAttackTick = -1;
   private String savedHost;
   private int savedPort;
   private String savedName;
   private boolean reconnectPending = false;
   private long reconnectTime = 0L;
   private static final long RECONNECT_DELAY_MS = 3000L;

   public AutoLog() {
      super("AutoLog", Category.MISC);
   }

   @Override
   public void onActivationKeyPressed() {
      if (mc.player != null && mc.world != null) {
         this.saveServerInfo();
         this.disconnect();
         this.reconnectPending = true;
         this.reconnectTime = System.currentTimeMillis() + 3000L;
      }
   }

   @Override
   public void onEnable() {
      this.lastHitTime = 0L;
      this.lastAttackTime = 0L;
      this.lastServerCombatTagTime = 0L;
      this.lastCombinedHealth = this.getCurrentCombinedHealth();
      this.lastObservedAttackedTick = this.getCurrentAttackedTick();
      this.lastObservedAttackTick = this.getCurrentAttackTick();
      if (mc.player != null && mc.world != null && (this.isCombatContextPresent() || this.isRecentPlayerCombat() || this.isServerCombatTagged())) {
         this.startCombatCooldown(System.currentTimeMillis());
      }
   }

   @Override
   public void onTick() {
      if (this.reconnectPending && mc.player == null && mc.world == null) {
         if (System.currentTimeMillis() >= this.reconnectTime && this.savedHost != null) {
            this.reconnectPending = false;
            this.doReconnect();
         }
      } else if (mc.player != null && mc.world != null) {
         long now = System.currentTimeMillis();
         float currentCombinedHealth = this.getCurrentCombinedHealth();
         boolean tookDamage = this.lastCombinedHealth >= 0.0F && currentCombinedHealth + 0.001F < this.lastCombinedHealth;
         this.lastCombinedHealth = currentCombinedHealth;
         if (mc.player.hurtTime > 0 || tookDamage || this.hasNewPlayerHit()) {
            this.lastHitTime = now;
         }

         boolean serverCombatTagged = this.isServerCombatTagged();
         if (serverCombatTagged) {
            this.lastServerCombatTagTime = now;
         }

         if (mc.options.attackKey.isPressed()
            && mc.crosshairTarget != null
            && mc.crosshairTarget.getType() == Type.ENTITY
            && mc.crosshairTarget instanceof EntityHitResult ehr
            && ehr.getEntity() instanceof PlayerEntity target
            && target != mc.player) {
            this.lastAttackTime = now;
         }

         if (this.hasNewPlayerAttack()) {
            this.lastAttackTime = now;
         }

         if (!this.isCombatCooldownActive(now, serverCombatTagged)) {
            for (PlayerEntity player : mc.world.getPlayers()) {
               if (player != mc.player && !player.isSpectator() && (!Friends.isAutoLog() || !Friends.isFriend(player.getName().getString()))) {
                  if (mc.getNetworkHandler() != null && mc.getNetworkHandler().getConnection() != null) {
                     this.saveServerInfo();
                     mc.getNetworkHandler().getConnection().disconnect(Text.literal("[AutoLog] Player detected: " + player.getName().getString()));
                     this.toggle();
                  }

                  return;
               }
            }
         }
      }
   }

   private void saveServerInfo() {
      if (mc.getCurrentServerEntry() != null) {
         ServerInfo info = mc.getCurrentServerEntry();
         ServerAddress addr = ServerAddress.parse(info.address);
         this.savedHost = addr.getAddress();
         this.savedPort = addr.getPort();
         this.savedName = info.name;
      }
   }

   private void disconnect() {
      if (mc.getNetworkHandler() != null && mc.getNetworkHandler().getConnection() != null) {
         mc.getNetworkHandler().getConnection().disconnect(Text.literal("[AutoLog] Manual leave"));
      }
   }

   private void doReconnect() {
      if (this.savedHost != null) {
         ServerInfo info = new ServerInfo(this.savedName != null ? this.savedName : this.savedHost, this.savedHost + ":" + this.savedPort, ServerType.OTHER);
         ConnectScreen.connect(new MultiplayerScreen(new TitleScreen()), mc, ServerAddress.parse(info.address), info, false, null);
      }
   }

   private boolean isCombatCooldownActive(long now, boolean serverCombatTagged) {
      if (serverCombatTagged || this.isRecentPlayerCombat() || now - this.lastServerCombatTagTime < 1500L) {
         return true;
      } else if (this.lastHitTime <= 0L && this.lastAttackTime <= 0L) {
         return false;
      } else {
         long lastCombatTime = Math.max(this.lastHitTime, this.lastAttackTime);
         return now - lastCombatTime < 20000L;
      }
   }

   private boolean isCombatContextPresent() {
      if (mc.player != null && mc.world != null) {
         if (mc.player.hurtTime <= 0 && !this.isRecentPlayerCombat()) {
            if (mc.crosshairTarget != null
               && mc.crosshairTarget.getType() == Type.ENTITY
               && mc.crosshairTarget instanceof EntityHitResult ehr
               && ehr.getEntity() instanceof PlayerEntity target
               && target != mc.player
               && !target.isSpectator()) {
               return true;
            } else {
               double maxDistSq = 64.0;

               for (PlayerEntity p : mc.world.getPlayers()) {
                  if (p != mc.player && !p.isSpectator() && mc.player.squaredDistanceTo(p) <= maxDistSq) {
                     return true;
                  }
               }

               return false;
            }
         } else {
            return true;
         }
      } else {
         return false;
      }
   }

   private void startCombatCooldown(long now) {
      this.lastHitTime = now;
      this.lastAttackTime = now;
      this.lastServerCombatTagTime = now;
   }

   private boolean isRecentPlayerCombat() {
      return this.isRecentPlayerHit() || this.isRecentPlayerAttack();
   }

   private boolean hasNewPlayerHit() {
      int t = this.getCurrentAttackedTick();
      if (t > 0 && t != this.lastObservedAttackedTick) {
         this.lastObservedAttackedTick = t;
         return this.isRecentPlayerHit();
      } else {
         return false;
      }
   }

   private boolean hasNewPlayerAttack() {
      int t = this.getCurrentAttackTick();
      if (t > 0 && t != this.lastObservedAttackTick) {
         this.lastObservedAttackTick = t;
         return this.isRecentPlayerAttack();
      } else {
         return false;
      }
   }

   private boolean isRecentPlayerHit() {
      if (mc.player == null) {
         return false;
      } else {
         return mc.player.getLastAttacker() instanceof PlayerEntity a && a != mc.player && !a.isSpectator()
            ? this.isRecentCombatTick(mc.player.getLastAttackedTime())
            : false;
      }
   }

   private boolean isRecentPlayerAttack() {
      if (mc.player == null) {
         return false;
      } else {
         return mc.player.getAttacking() instanceof PlayerEntity t && t != mc.player && !t.isSpectator()
            ? this.isRecentCombatTick(mc.player.getLastAttackTime())
            : false;
      }
   }

   private boolean isRecentCombatTick(int tickTimestamp) {
      if (mc.player != null && tickTimestamp > 0) {
         int elapsed = mc.player.age - tickTimestamp;
         return elapsed >= 0 && elapsed < 400;
      } else {
         return false;
      }
   }

   private int getCurrentAttackedTick() {
      return mc.player != null ? mc.player.getLastAttackedTime() : -1;
   }

   private int getCurrentAttackTick() {
      return mc.player != null ? mc.player.getLastAttackTime() : -1;
   }

   private boolean isServerCombatTagged() {
      if (mc.world != null && this.containsCombatScoreboardText(mc.world.getScoreboard())) {
         return true;
      } else {
         Set<Object> visited = Collections.newSetFromMap(new IdentityHashMap<>());
         return mc.inGameHud != null && this.containsCombatText(mc.inGameHud, 0, visited);
      }
   }

   private boolean containsCombatScoreboardText(Scoreboard sb) {
      if (sb == null) {
         return false;
      } else {
         for (ScoreboardObjective obj : sb.getObjectives()) {
            if (this.containsCombatKeyword(obj.getName()) || this.containsCombatText(obj.getDisplayName())) {
               return true;
            }
         }

         for (ScoreboardDisplaySlot slot : ScoreboardDisplaySlot.values()) {
            ScoreboardObjective objx = sb.getObjectiveForSlot(slot);
            if (objx != null) {
               if (this.containsCombatKeyword(objx.getName()) || this.containsCombatText(objx.getDisplayName())) {
                  return true;
               }

               for (ScoreboardEntry entry : sb.getScoreboardEntries(objx)) {
                  if (this.containsCombatKeyword(entry.owner()) || this.containsCombatText(entry.name()) || this.containsCombatText(entry.display())) {
                     return true;
                  }

                  Team team = sb.getScoreHolderTeam(entry.owner());
                  if (this.containsCombatTeamText(team)) {
                     return true;
                  }
               }
            }
         }

         for (Team team : sb.getTeams()) {
            if (this.containsCombatTeamText(team)) {
               return true;
            }
         }

         return false;
      }
   }

   private boolean containsCombatTeamText(Team team) {
      return team != null
         && (
            this.containsCombatKeyword(team.getName())
               || this.containsCombatText(team.getDisplayName())
               || this.containsCombatText(team.getPrefix())
               || this.containsCombatText(team.getSuffix())
         );
   }

   private boolean containsCombatText(Object value, int depth, Set<Object> visited) {
      if (value == null || depth > 4) {
         return false;
      } else if (value instanceof Text t) {
         return this.containsCombatKeyword(t.getString());
      } else if (value instanceof String s) {
         return this.containsCombatKeyword(s);
      } else if (!visited.add(value)) {
         return false;
      } else if (value instanceof Map<?, ?> map) {
         for (Entry<?, ?> e : map.entrySet()) {
            if (this.containsCombatText(e.getKey(), depth + 1, visited) || this.containsCombatText(e.getValue(), depth + 1, visited)) {
               return true;
            }
         }

         return false;
      } else if (value instanceof Collection) {
         for (Object el : (Collection)value) {
            if (this.containsCombatText(el, depth + 1, visited)) {
               return true;
            }
         }

         return false;
      } else {
         Class<?> clazz = value.getClass();
         if (!this.isInspectableClass(clazz)) {
            return false;
         } else {
            for (Class<?> cur = clazz; cur != null && cur != Object.class; cur = cur.getSuperclass()) {
               for (Field f : cur.getDeclaredFields()) {
                  if (!Modifier.isStatic(f.getModifiers()) && !f.getType().isPrimitive() && !f.getDeclaringClass().getName().startsWith("java.lang")) {
                     try {
                        f.setAccessible(true);
                        if (this.containsCombatText(f.get(value), depth + 1, visited)) {
                           return true;
                        }
                     } catch (Exception var11) {
                     }
                  }
               }
            }

            return false;
         }
      }
   }

   private boolean isInspectableClass(Class<?> c) {
      String n = c.getName();
      return n.startsWith("net.minecraft.scoreboard.")
         || n.startsWith("net.minecraft.text.")
         || n.startsWith("net.minecraft.client.gui.hud.")
         || n.startsWith("net.minecraft.client.network.")
         || n.startsWith("java.util.");
   }

   private boolean containsCombatKeyword(String v) {
      return v != null && v.toLowerCase().contains("combat");
   }

   private boolean containsCombatText(Text t) {
      return t != null && this.containsCombatKeyword(t.getString());
   }

   private float getCurrentCombinedHealth() {
      return mc.player != null ? mc.player.getHealth() + mc.player.getAbsorptionAmount() : -1.0F;
   }
}

