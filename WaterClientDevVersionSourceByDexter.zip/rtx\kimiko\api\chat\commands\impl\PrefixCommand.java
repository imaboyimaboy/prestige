package rtx.kimiko.api.chat.commands.impl;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;
import net.minecraft.util.Formatting;
import rtx.kimiko.api.chat.commands.Command;
import rtx.kimiko.api.chat.commands.CommandManager;

public final class PrefixCommand extends Command {
   public PrefixCommand() {
      super("prefix", "Changes command prefix");
   }

   @Override
   public void execute(String string, String[] stringArray) {
      CommandManager commandManager = CommandManager.getInstance();
      if (stringArray.length == 0) {
         this.logDirect("Current prefix: " + commandManager.getPrefix());
         this.usage();
      } else if (stringArray[0].equalsIgnoreCase("set") && stringArray.length >= 2) {
         String string2 = stringArray[1];
         if (string2.length() <= 3 && !string2.contains(" ")) {
            commandManager.setPrefix(string2);
            this.logDirect("Prefix changed to: null", Formatting.GREEN);
         } else {
            this.logDirect("Prefix must be 1-3 chars without spaces.", Formatting.RED);
         }
      } else {
         this.usage();
      }
   }

   @Override
   public List<String> getLongDesc() {
      return Arrays.asList("Changes command prefix.", "Usage:", "> prefix", "> prefix set <symbol>");
   }

   @Override
   public Stream<String> tabComplete(String string2, String[] stringArray) {
      if (stringArray.length == 1) {
         return Stream.of("set").filter(string -> string.startsWith(stringArray[0].toLowerCase()));
      } else {
         return stringArray.length == 2 && stringArray[0].equalsIgnoreCase("set")
            ? Stream.of(".", "!", "$", "#", "-", "/").filter(string -> string.startsWith(stringArray[1]))
            : Stream.empty();
      }
   }
}

