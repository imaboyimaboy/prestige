package rtx.kimiko.api.mods.geckolib.network.packet.blockentity;

import java.util.Optional;
import java.util.function.Consumer;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.network.packet.CustomPayload.Id;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import rtx.kimiko.api.mods.geckolib.GeckoLibConstants;
import rtx.kimiko.api.mods.geckolib.animatable.GeoBlockEntity;
import rtx.kimiko.api.mods.geckolib.network.packet.MultiloaderPacket;
import rtx.kimiko.api.mods.geckolib.util.ClientUtil;

public final class StopTriggeredBlockEntityAnimPacket implements MultiloaderPacket {
   private BlockPos pos;
   private Optional<String> controllerName;
   private Optional<String> animName;
   public static final Id<StopTriggeredBlockEntityAnimPacket> TYPE = new Id(GeckoLibConstants.id("stop_triggered_blockentity_anim"));
   public static final PacketCodec<PacketByteBuf, StopTriggeredBlockEntityAnimPacket> CODEC = PacketCodec.tuple(
      BlockPos.PACKET_CODEC,
      StopTriggeredBlockEntityAnimPacket::pos,
      PacketCodecs.STRING.collect(PacketCodecs::optional),
      StopTriggeredBlockEntityAnimPacket::controllerName,
      PacketCodecs.STRING.collect(PacketCodecs::optional),
      StopTriggeredBlockEntityAnimPacket::animName,
      StopTriggeredBlockEntityAnimPacket::new
   );

   public StopTriggeredBlockEntityAnimPacket(BlockPos pos, Optional<String> controllerName, Optional<String> animName) {
      this.pos = pos;
      this.controllerName = controllerName;
      this.animName = animName;
   }

   public Id<? extends CustomPayload> getId() {
      return TYPE;
   }

   @Override
   public void receiveMessage(PlayerEntity playerEntity, Consumer<Runnable> consumer) {
      consumer.accept(() -> {
         World world = ClientUtil.getLevel();
         BlockEntity blockEntity;
         if (world != null && (blockEntity = world.getBlockEntity(this.pos)) instanceof GeoBlockEntity) {
            GeoBlockEntity geoBlockEntity = (GeoBlockEntity)blockEntity;
            geoBlockEntity.stopTriggeredAnim(this.controllerName.orElse(null), this.animName.orElse(null));
         }
      });
   }

   public BlockPos pos() {
      return this.pos;
   }

   public Optional<String> controllerName() {
      return this.controllerName;
   }

   public Optional<String> animName() {
      return this.animName;
   }
}

