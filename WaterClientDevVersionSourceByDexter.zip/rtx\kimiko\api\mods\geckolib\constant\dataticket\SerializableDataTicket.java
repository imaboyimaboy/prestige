package rtx.kimiko.api.mods.geckolib.constant.dataticket;

import com.google.common.reflect.TypeToken;
import it.unimi.dsi.fastutil.Pair;
import java.lang.reflect.Type;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import rtx.kimiko.api.mods.geckolib.constant.DataTickets;

public final class SerializableDataTicket<D> extends DataTicket<D> {
   public static final PacketCodec<RegistryByteBuf, SerializableDataTicket<?>> STREAM_CODEC = PacketCodec.tuple(
      Identifier.PACKET_CODEC, SerializableDataTicket::getRegisteredId, SerializableDataTicket::enforceValidTicket
   );
   private final PacketCodec<? super RegistryByteBuf, D> packetCodec;
   private Identifier registeredId;

   private SerializableDataTicket(Identifier identifier, Class<? extends D> clazz, Type type, PacketCodec<? super RegistryByteBuf, D> packetCodec) {
      super(identifier.toString(), clazz, type);
      this.registeredId = identifier;
      this.packetCodec = packetCodec;
   }

   public static <D> SerializableDataTicket<D> serializableDataTicketOf(
      Identifier identifier, Class<? extends D> clazz, Type type, PacketCodec<? super RegistryByteBuf, D> packetCodec
   ) {
      return (SerializableDataTicket<D>)IDENTITY_CACHE.computeIfAbsent(
         Pair.of(type, identifier.toString()), pair -> DataTickets.registerSerializable(new SerializableDataTicket<>(identifier, clazz, type, packetCodec))
      );
   }

   public static <D> SerializableDataTicket<D> create(
      Identifier identifier, Class<? extends D> clazz, TypeToken<D> typeToken, PacketCodec<? super RegistryByteBuf, D> packetCodec
   ) {
      return serializableDataTicketOf(identifier, clazz, typeToken.getType(), packetCodec);
   }

   public static <D> SerializableDataTicket<D> create(Identifier identifier, Class<? extends D> clazz, PacketCodec<? super RegistryByteBuf, D> packetCodec) {
      return serializableDataTicketOf(identifier, clazz, clazz, packetCodec);
   }

   public static SerializableDataTicket<String> ofString(Identifier identifier) {
      return create(identifier, String.class, PacketCodecs.STRING);
   }

   public static SerializableDataTicket<Boolean> ofBoolean(Identifier identifier) {
      return create(identifier, Boolean.class, PacketCodecs.BOOLEAN);
   }

   public static SerializableDataTicket<Integer> ofInt(Identifier identifier) {
      return create(identifier, Integer.class, PacketCodecs.INTEGER);
   }

   public static SerializableDataTicket<?> enforceValidTicket(Identifier identifier) throws IllegalStateException {
      SerializableDataTicket<?> serializableDataTicket = DataTickets.byName(identifier);
      if (serializableDataTicket == null) {
         throw new IllegalStateException(
            "Attempted to retrieve a SerializableDataTicket that does not exist! Likely didn't register the ticket properly: " + identifier
         );
      } else {
         return serializableDataTicket;
      }
   }

   public Identifier getRegisteredId() {
      return this.registeredId;
   }

   public PacketCodec<? super RegistryByteBuf, D> streamCodec() {
      return this.packetCodec;
   }

   public static SerializableDataTicket<Vec3d> ofVec3(Identifier identifier) {
      return create(identifier, Vec3d.class, PacketCodecs.VECTOR_3F.xmap(Vec3d::new, Vec3d::toVector3f));
   }

   public static <E extends Enum<E>> SerializableDataTicket<E> ofEnum(Identifier identifier, Class<E> clazz) {
      PacketCodec<RegistryByteBuf, E> codec = new PacketCodec<RegistryByteBuf, E>() {
         public E decode(RegistryByteBuf buf) {
            return Enum.valueOf(clazz, buf.readString());
         }

         public void encode(RegistryByteBuf buf, E value) {
            buf.writeString(value.name());
         }
      };
      return create(identifier, clazz, codec);
   }

   public static SerializableDataTicket<BlockPos> ofBlockPos(Identifier identifier) {
      return create(identifier, BlockPos.class, BlockPos.PACKET_CODEC);
   }
}

