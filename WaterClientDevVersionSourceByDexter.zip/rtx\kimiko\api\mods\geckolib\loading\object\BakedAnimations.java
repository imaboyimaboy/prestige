package rtx.kimiko.api.mods.geckolib.loading.object;

import java.util.Map;
import rtx.kimiko.api.mods.geckolib.cache.animation.Animation;

public final class BakedAnimations {
   private Map<String, Animation> animations;

   public BakedAnimations(Map<String, Animation> animations) {
      this.animations = animations;
   }

   public Animation getAnimation(String string) {
      return this.animations.get(string);
   }

   public Map<String, Animation> animations() {
      return this.animations;
   }
}

