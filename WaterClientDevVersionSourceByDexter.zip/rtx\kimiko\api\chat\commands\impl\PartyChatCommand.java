package rtx.kimiko.api.chat.commands.impl;

import java.util.Arrays;
import java.util.List;
import net.minecraft.util.Formatting;
import rtx.kimiko.api.chat.commands.Command;
import rtx.kimiko.api.modules.ModuleManager;
import rtx.kimiko.api.modules.impl.Utils.Party;
import rtx.kimiko.api.party.PartyClient;

public final class PartyChatCommand extends Command {
   public PartyChatCommand() {
      super("pc", "Party-чат: написать сообщение участникам Party.", "pchat");
   }

   @Override
   public void execute(String string, String[] stringArray) {
      if (stringArray.length == 0) {
         this.logDirect("Использование: pc <сообщение>", Formatting.RED);
      } else {
         String string2 = String.join(" ", Arrays.copyOfRange(stringArray, 0, stringArray.length)).trim();
         if (string2.isEmpty()) {
            this.logDirect("Введите сообщение.", Formatting.RED);
         } else if (this.ensureLink()) {
            PartyClient.INSTANCE.sendChat(string2);
         }
      }
   }

   @Override
   public List<String> getLongDesc() {
      return Arrays.asList("Party-чат — сообщение видят только участники вашей Party.", "> pc <сообщение>", "Аналог: party chat <сообщение>");
   }

   private boolean ensureLink() {
      if (PartyClient.INSTANCE.isConnected()) {
         return true;
      } else {
         Party party = ModuleManager.get().get(Party.class);
         if (party != null && !party.isEnabled()) {
            party.enable();
            this.logDirect("Модуль Party включён — подключаюсь к серверу. Повторите команду через пару секунд.", Formatting.YELLOW);
         } else {
            this.logDirect("Нет связи с Party-сервером. Попробуйте позже.", Formatting.RED);
         }

         return false;
      }
   }
}

