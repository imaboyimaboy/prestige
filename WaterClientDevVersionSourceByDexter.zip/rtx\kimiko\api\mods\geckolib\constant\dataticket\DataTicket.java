package rtx.kimiko.api.mods.geckolib.constant.dataticket;

import com.google.common.reflect.TypeToken;
import it.unimi.dsi.fastutil.Pair;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import java.lang.reflect.Type;
import java.util.Map;
import java.util.Objects;
import rtx.kimiko.api.mods.geckolib.renderer.base.GeoRenderState;

public class DataTicket<D> {
   static final Map<Pair<Type, String>, DataTicket<?>> IDENTITY_CACHE = new Object2ObjectOpenHashMap();
   private String string;
   private final Class<? extends D> clazz;
   private Type type;

   DataTicket(String string, Class<? extends D> clazz, Type type) {
      this.string = string;
      this.clazz = clazz;
      this.type = type;
   }

   @Override
   public boolean equals(Object object) {
      if (this == object) {
         return true;
      } else {
         return !(object instanceof DataTicket<?> dataTicket) ? false : this.clazz == dataTicket.clazz && this.string.equals(dataTicket.string);
      }
   }

   @Override
   public String toString() {
      return "DataTicket{" + this.string + ": " + this.clazz.getName() + "}";
   }

   @Override
   public int hashCode() {
      return Objects.hash(this.string, this.clazz);
   }

   public String id() {
      return this.string;
   }

   public static <D> DataTicket<D> create(String string, Class<? super D> clazz, TypeToken<D> typeToken) {
      return (DataTicket<D>)IDENTITY_CACHE.computeIfAbsent(
         Pair.of(typeToken.getType(), string), pair -> new DataTicket<>(string, (Class<? extends D>)clazz, typeToken.getType())
      );
   }

   public static <D> DataTicket<D> create(String string, Class<? extends D> clazz) {
      return (DataTicket<D>)IDENTITY_CACHE.computeIfAbsent(Pair.of(clazz, string), pair -> new DataTicket<>(string, clazz, clazz));
   }

   public static <D> DataTicket<D> dataTicketOf(String string, TypeToken<D> typeToken) {
      return create(string, typeToken.getRawType(), typeToken);
   }

   public static <D> DataTicket<D> dataTicketOf2(String string, Class<? extends D> clazz) {
      return create(string, clazz);
   }

   public Class<? extends D> objectType() {
      return this.clazz;
   }

   public Type dataType() {
      return this.type;
   }

   public boolean canExtractFrom(Object object) {
      return object instanceof GeoRenderState renderState ? renderState.hasGeckolibData(this) : false;
   }
}

