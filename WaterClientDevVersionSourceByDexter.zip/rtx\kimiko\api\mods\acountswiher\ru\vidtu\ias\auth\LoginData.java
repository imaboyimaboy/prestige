package rtx.kimiko.api.mods.acountswiher.ru.vidtu.ias.auth;

import java.util.UUID;

public final class LoginData {
   private String name;
   private UUID uuid;
   private String token;
   private boolean online;

   public LoginData(String name, UUID uuid, String token, boolean online) {
      this.name = name;
      this.uuid = uuid;
      this.token = token;
      this.online = online;
   }

   public String name() {
      return this.name;
   }

   public UUID uuid() {
      return this.uuid;
   }

   public String token() {
      return this.token;
   }

   public boolean online() {
      return this.online;
   }
}

