package com.water.module;

import net.minecraft.item.ItemStack;

public enum Category {
   COMBAT("COMBAT"),
   RENDER("RENDER"),
   MISC("MISC"),
   DONUT("DONUT"),
   CLIENT("CLIENT");

   private String name;

   private Category(String name) {
      this.name = name;
   }

   public String getName() {
      return this.name;
   }

   public ItemStack getIcon() {
      return ItemStack.EMPTY;
   }

   private static Category[] $values() {
      return new Category[]{COMBAT, RENDER, MISC, DONUT, CLIENT};
   }
}

