package com.water.module.modules.client;

import com.water.module.Category;
import com.water.module.Module;
import com.water.setting.Setting;
import com.water.spotify.lyrics.LrcLibClient;
import com.water.spotify.lyrics.LyricLine;
import com.water.spotify.lyrics.LyricLineSplitter;
import com.water.spotify.lyrics.LyricParticle3D;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

public final class SpotifyLyric extends Module {
   private static SpotifyLyric instance;
   private final Setting<SpotifyLyric.Animation> animation = new Setting<>("Animation", SpotifyLyric.Animation.LyricFlow);
   private final Setting<Color> color = new Setting<>("Color", new Color(80, 220, 255));
   private final Setting<Boolean> split = new Setting<>("Smart Split", true);
   private final Setting<Float> maxLines = new Setting<>("Max Lines", 3.0F, 1.0F, 6.0F);
   private final Setting<Float> displayTime = new Setting<>("Display Time (s)", 6.0F, 2.0F, 15.0F);
   private final Setting<Float> minDistance = new Setting<>("Min Distance", 2.0F, 1.2F, 4.0F);
   private final Setting<Float> maxDistance = new Setting<>("Max Distance", 4.5F, 2.0F, 7.0F);
   private final Setting<Float> spread = new Setting<>("Arc Spread", 70.0F, 20.0F, 85.0F);
   private final Setting<Float> height = new Setting<>("Float Height", 0.5F, 0.1F, 2.0F);
   private final Setting<Float> offset = new Setting<>("Offset (ms)", 0.0F, -5000.0F, 5000.0F);
   private final List<LyricParticle3D> particles = new ArrayList<>();
   private List<LyricLine> raw = List.of();
   private List<LyricLine> lines = List.of();
   private String key = "";
   private int generation;
   private int index;
   private long lastAudio = -1L;
   private long audioTime;
   private boolean lastSplit;
   private boolean playing;
   private Object world;

   public SpotifyLyric() {
      super("Spotify Lyric", Category.CLIENT);
      instance = this;

      for (Setting<?> s : List.of(
         this.animation, this.color, this.split, this.maxLines, this.displayTime, this.minDistance, this.maxDistance, this.spread, this.height, this.offset
      )) {
         this.addSetting(s);
      }
   }

   public static boolean active() {
      return instance != null && instance.isEnabled();
   }

   @Override
   public void onEnable() {
      this.reset();
   }

   @Override
   public void onDisable() {
      this.reset();
      SpotifyHud.releaseLyrics();
   }

   private void reset() {
      this.generation++;
      this.key = "";
      this.raw = List.of();
      this.lines = List.of();
      this.particles.clear();
      this.index = 0;
      this.lastAudio = -1L;
      this.world = null;
   }

   @Override
   public void onTick() {
      SpotifyHud.LyricPlayback media = SpotifyHud.lyricPlayback();
      if (mc.world != this.world) {
         this.particles.clear();
         this.lastAudio = -1L;
         this.world = mc.world;
      }

      String next = (media.title() + "\n" + media.artist()).toLowerCase(Locale.ROOT);
      if (!next.equals(this.key)) {
         this.key = next;
         int request = ++this.generation;
         this.raw = List.of();
         this.lines = List.of();
         this.particles.clear();
         this.index = 0;
         this.lastAudio = -1L;
         if (!media.title().isBlank()) {
            LrcLibClient.fetchLyricsAsync(media.title(), media.artist(), false).thenAccept(result -> mc.execute(() -> {
               if (this.isEnabled() && request == this.generation) {
                  this.raw = List.copyOf(result);
                  this.rebuild();
                  if (this.raw.isEmpty() && mc.player != null) {
                     mc.player.sendMessage(Text.literal("[Spotify Lyric] Keine synchronisierten Lyrics gefunden."), true);
                  }
               }
            }));
         }
      }

      if (this.lastSplit != this.split.getValue()) {
         this.rebuild();
      }

      this.playing = media.playing();
      this.audioTime = Math.max(0L, media.position() + Math.round(this.offset.getValue()));
      if (mc.player != null && mc.world != null && !this.lines.isEmpty()) {
         if (this.lastAudio < 0L || this.audioTime < this.lastAudio || this.audioTime - this.lastAudio > 1500L) {
            this.particles.clear();
            this.index = 0;
         }

         for (; this.index < this.lines.size() && this.lines.get(this.index).timestampMs() <= this.audioTime; this.index++) {
            LyricLine line = this.lines.get(this.index);
            long duration = Math.round(this.displayTime.getValue() * 1000.0F);
            if (duration > 0L && this.audioTime < line.timestampMs() + duration) {
               this.spawn(line, duration);
            }
         }

         this.particles.removeIf(p -> p.isDead(this.audioTime));
         this.lastAudio = this.audioTime;
      }
   }

   private void rebuild() {
      this.lastSplit = this.split.getValue();
      this.lines = this.lastSplit ? LyricLineSplitter.splitLongLines(this.raw) : this.raw;
      this.particles.clear();
      this.index = 0;
      this.lastAudio = -1L;
   }

   private void spawn(LyricLine line, long duration) {
      ThreadLocalRandom random = ThreadLocalRandom.current();
      Vec3d eye = mc.player.getEyePos();
      Vec3d best = null;
      double score = -1.0;
      double low = this.minDistance.getValue().floatValue();
      double high = Math.max(low + 0.1, (double)this.maxDistance.getValue().floatValue());

      for (int i = 0; i < 16; i++) {
         double yaw = Math.toRadians(mc.gameRenderer.getCamera().getYaw() + random.nextDouble(-this.spread.getValue(), this.spread.getValue().floatValue()));
         double d = random.nextDouble(low, high);
         Vec3d point = eye.add(-Math.sin(yaw) * d, random.nextDouble(-0.25, 0.55), Math.cos(yaw) * d);
         double separation = this.particles.stream().mapToDouble(p -> p.getBasePosition().distanceTo(point)).min().orElse(100.0);
         if (separation > score) {
            best = point;
            score = separation;
         }
      }

      while (this.particles.size() >= Math.round(this.maxLines.getValue())) {
         this.particles.removeFirst();
      }

      this.particles.add(new LyricParticle3D(line.text(), best, line.timestampMs(), duration, this.height.getValue()));
   }

   @Override
   public void onRender(MatrixStack matrices, float tickDelta) {
      if (mc.player != null && mc.world != null) {
         for (LyricParticle3D particle : this.particles) {
            particle.render(
               matrices, mc.gameRenderer.getCamera(), mc.textRenderer, this.animation.getValue().name(), this.color.getValue().getRGB(), this.audioTime
            );
         }
      }
   }

   public enum Animation {
      LyricFlow,
      Typewriter,
      PopScale,
      KineticSlide,
      Fade;

      private static SpotifyLyric.Animation[] $values() {
         return new SpotifyLyric.Animation[]{LyricFlow, Typewriter, PopScale, KineticSlide, Fade};
      }
   }
}

