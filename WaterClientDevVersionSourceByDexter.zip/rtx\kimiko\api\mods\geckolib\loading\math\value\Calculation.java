package rtx.kimiko.api.mods.geckolib.loading.math.value;

import java.util.Set;
import rtx.kimiko.api.mods.geckolib.animation.state.ControllerState;
import rtx.kimiko.api.mods.geckolib.loading.math.MathValue;
import rtx.kimiko.api.mods.geckolib.loading.math.Operator;

public final class Calculation implements MathValue {
   private Operator operator;
   private MathValue mathValue;
   private MathValue mathValue2;

   public Calculation(Operator operator, MathValue a, MathValue b) {
      this.operator = operator;
      this.mathValue = a;
      this.mathValue2 = b;
   }

   @Override
   public double get(ControllerState state) {
      return this.operator.apply(this.mathValue.get(state), this.mathValue2.get(state));
   }

   @Override
   public Set<Variable> getUsedVariables() {
      return MathValue.collectUsedVariables(this.mathValue, this.mathValue2);
   }

   public Operator operator() {
      return this.operator;
   }

   public MathValue getMathValue() {
      return this.mathValue;
   }

   public MathValue getMathValue2() {
      return this.mathValue2;
   }
}

