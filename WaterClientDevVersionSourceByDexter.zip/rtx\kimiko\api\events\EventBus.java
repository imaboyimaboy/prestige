package rtx.kimiko.api.events;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import rtx.kimiko.Kimiko;

public final class EventBus {
   private static final EventBus INSTANCE = new EventBus();
   private static final Set<String> REPORTED_FAILURES = ConcurrentHashMap.newKeySet();
   private final Map<Class<?>, CopyOnWriteArrayList<EventBus.Binding>> bindings = new ConcurrentHashMap<>();
   private final AtomicInteger insertionCounter = new AtomicInteger();

   private EventBus() {
   }

   public static EventBus get() {
      return INSTANCE;
   }

   public <E extends Event> E post(E e) {
      List<EventBus.Binding> list = this.bindings.get(e.getClass());
      if (list != null && !list.isEmpty()) {
         boolean bl = e instanceof CancellableEvent;

         for (EventBus.Binding binding : list) {
            CancellableEvent cancellableEvent;
            if (!bl || (cancellableEvent = (CancellableEvent)e).isCancelled() && binding.priority() == Priority.MONITOR || !cancellableEvent.isCancelled()) {
               binding.invoke(e);
            }
         }

         return e;
      } else {
         return e;
      }
   }

   private void resort(Class<?> clazz) {
      CopyOnWriteArrayList<EventBus.Binding> copyOnWriteArrayList = this.bindings.get(clazz);
      if (copyOnWriteArrayList != null) {
         ArrayList<EventBus.Binding> arrayList = new ArrayList<>(copyOnWriteArrayList);
         arrayList.sort(Comparator.<EventBus.Binding>comparingInt(binding -> binding.priority().ordinal()).thenComparingInt(EventBus.Binding::order));
         copyOnWriteArrayList.clear();
         copyOnWriteArrayList.addAll(arrayList);
      }
   }

   private MethodHandle createHandle(Object object, Method method) throws Exception {
      method.setAccessible(true);
      Lookup lookup = MethodHandles.lookup();
      return lookup.unreflect(method).bindTo(object);
   }

   public void subscribe(Object object) {
      for (Class<?> clazz2 = object.getClass(); clazz2 != null && clazz2 != Object.class; clazz2 = clazz2.getSuperclass()) {
         for (Method method : clazz2.getDeclaredMethods()) {
            EventHandler eventHandler = method.getAnnotation(EventHandler.class);
            Class<?> clazz3;
            if (eventHandler != null && method.getParameterCount() == 1 && Event.class.isAssignableFrom(clazz3 = method.getParameterTypes()[0])) {
               try {
                  MethodHandle methodHandle = this.createHandle(object, method);
                  EventBus.Binding binding = new Binding(object, methodHandle, eventHandler.value(), this.insertionCounter.getAndIncrement());
                  this.bindings.computeIfAbsent(clazz3, clazz -> new CopyOnWriteArrayList<>()).add(binding);
                  this.resort(clazz3);
               } catch (Exception var11) {
                  Kimiko.LOGGER.error("[EventBus] Failed to register handler {}.{}", new Object[]{clazz2.getSimpleName(), method.getName(), var11});
               }
            }
         }
      }
   }

   public void unsubscribe(Object object) {
      for (CopyOnWriteArrayList<EventBus.Binding> copyOnWriteArrayList : this.bindings.values()) {
         copyOnWriteArrayList.removeIf(binding -> binding.owner() == object);
      }
   }

   public boolean hasListeners(Class<? extends Event> clazz) {
      List list = this.bindings.get(clazz);
      return list != null && !list.isEmpty();
   }

   public final class Binding {
      private Object owner;
      private MethodHandle handle;
      private Priority priority;
      private int order;

      public Binding(Object owner, MethodHandle handle, Priority priority, int order) {
         this.owner = owner;
         this.handle = handle;
         this.priority = priority;
         this.order = order;
      }

      public void invoke(Event event) {
         try {
            this.handle.invoke((Event)event);
         } catch (Throwable var4) {
            String string = this.owner.getClass().getName() + "|" + event.getClass().getName() + "|" + var4.getClass().getName();
            if (EventBus.REPORTED_FAILURES.add(string)) {
               Kimiko.LOGGER
                  .error(
                     "[EventBus] Exception in event handler {} for {} (further identical errors suppressed)",
                     new Object[]{this.owner.getClass().getSimpleName(), event.getClass().getSimpleName(), var4}
                  );
            }
         }
      }

      public Object owner() {
         return this.owner;
      }

      public MethodHandle handle() {
         return this.handle;
      }

      public Priority priority() {
         return this.priority;
      }

      public int order() {
         return this.order;
      }
   }
}

