package com.water.module.modules.render;

import com.water.module.Category;
import com.water.module.Module;
import com.water.setting.ModeSetting;
import com.water.setting.Setting;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.util.math.BlockPos;

public final class BreakAnimations extends Module {
   public static BreakAnimations INSTANCE;
   private final ModeSetting mode = new ModeSetting("Mode", "Smooth", "Smooth", "Pulse", "Instant");
   private final Setting<Float> speed = new Setting<>("Speed", 1.4F, 0.2F, 4.0F);
   private final Setting<Boolean> cleanup = new Setting<>("Auto Cleanup", true);
   private final Map<Long, BreakAnimations.Entry> entries = new ConcurrentHashMap<>();

   public BreakAnimations() {
      super("Break Animations", Category.RENDER);
      this.addSetting(this.mode);
      this.addSetting(this.speed);
      this.addSetting(this.cleanup);
      INSTANCE = this;
   }

   @Override
   public void onDisable() {
      this.entries.clear();
   }

   @Override
   public void onTick() {
      if (this.cleanup.getValue()) {
         long now = System.currentTimeMillis();
         Iterator<Map.Entry<Long, BreakAnimations.Entry>> it = this.entries.entrySet().iterator();

         while (it.hasNext()) {
            BreakAnimations.Entry e = it.next().getValue();
            if (now - e.lastSeenMs > 2500L || e.target < 0) {
               it.remove();
            }
         }
      }
   }

   public static int transform(BlockPos pos, int progress) {
      BreakAnimations self = INSTANCE;
      if (self == null || !self.isEnabled() || pos == null) {
         return progress;
      } else if (self.mode.check("Instant")) {
         return progress;
      } else if (progress < 0) {
         self.entries.remove(pos.asLong());
         return progress;
      } else {
         long now = System.currentTimeMillis();
         BreakAnimations.Entry e = self.entries.computeIfAbsent(pos.asLong(), ignored -> new Entry(progress, now));
         e.target = progress;
         e.lastSeenMs = now;
         float dt = Math.max(0.0F, Math.min(0.25F, (float)(now - e.lastUpdateMs) / 1000.0F));
         e.lastUpdateMs = now;
         if (self.mode.check("Pulse")) {
            float wave = (float)((Math.sin(now / 85.0) + 1.0) * 0.5);
            int pulsed = Math.round(progress + wave * 2.0F - 1.0F);
            return clampStage(pulsed);
         } else {
            float follow = 1.0F - (float)Math.exp(-9.0F * self.speed.getValue() * dt);
            e.visual = e.visual + (progress - e.visual) * follow;
            if (progress > e.visual && progress - e.visual < 0.15F) {
               e.visual = progress;
            }

            return clampStage(Math.round(e.visual));
         }
      }
   }

   private static int clampStage(int stage) {
      return Math.max(0, Math.min(10, stage));
   }

   final static class Entry {
      float visual;
      int target;
      long lastSeenMs;
      long lastUpdateMs;

      Entry(int progress, long now) {
         this.visual = progress;
         this.target = progress;
         this.lastSeenMs = now;
         this.lastUpdateMs = now;
      }
   }
}

