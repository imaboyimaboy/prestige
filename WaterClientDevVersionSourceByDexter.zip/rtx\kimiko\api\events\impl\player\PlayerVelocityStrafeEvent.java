package rtx.kimiko.api.events.impl.player;

import net.minecraft.util.math.Vec3d;
import rtx.kimiko.api.events.Event;

public final class PlayerVelocityStrafeEvent extends Event {
   private Vec3d velocity;
   private Vec3d movementInput;
   private float speed;

   public PlayerVelocityStrafeEvent(Vec3d vec3d, Vec3d vec3d2, float f) {
      this.velocity = vec3d;
      this.movementInput = vec3d2;
      this.speed = f;
   }

   public float getSpeed() {
      return this.speed;
   }

   public Vec3d getMovementInput() {
      return this.movementInput;
   }

   public void setVelocity(Vec3d vec3d) {
      PlayerVelocityStrafeEvent playerVelocityStrafeEvent = null;
      Vec3d vec3d2 = null;
      long l6 = 283125341;
      long l5 = 103006652;
      l6 = -1689432029;
      l5 = -1192383878;
      this.velocity = vec3d;
      long var10000 = 0;
   }

   public Vec3d getVelocity() {
      return this.velocity;
   }
}

