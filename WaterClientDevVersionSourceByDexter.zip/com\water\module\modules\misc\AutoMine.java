package com.water.module.modules.misc;

import com.water.module.Category;
import com.water.module.Module;
import com.water.setting.Setting;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FluidBlock;
import net.minecraft.entity.Entity;
import net.minecraft.entity.FallingBlockEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ChunkDeltaUpdateS2CPacket;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.math.Direction.Axis;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

public final class AutoMine extends Module {
   private final Setting<Float> range = new Setting<>("Range", 4.5F, 2.0F, 6.0F);
   private final Setting<Float> delay = new Setting<>("Delay", 1.0F, 0.0F, 10.0F);
   private final Setting<Boolean> topDown = new Setting<>("Top Down", true);
   private final Setting<Boolean> drillMode = new Setting<>("3x3 Drill", true);
   private final Setting<Boolean> autoWalk = new Setting<>("Auto Walk", true);
   private final Setting<Boolean> pearlReturn = new Setting<>("Pearl Return", true);
   private final Setting<Boolean> stabilizeGravel = new Setting<>("Stabilize Gravel", true);
   private final AutoMineRecovery recovery = new AutoMineRecovery();
   private int settleTicks;
   private int clearTicks;
   private double lastSupportedY = Double.NaN;
   private final Setting<Boolean> debug = new Setting<>("Debug", true);
   private int minX;
   private int minY;
   private int minZ;
   private int maxX;
   private int maxY;
   private int maxZ;
   private boolean hasBounds;
   private Object miningWorld;
   private int cacheY;
   private final List<AutoMine.Region> regions = new ArrayList<>();
   private final Set<BlockPos> counted = new HashSet<>();
   private final Set<BlockPos> pendingMined = new HashSet<>();
   private final ConcurrentLinkedQueue<AutoMine.ServerUpdate> serverUpdates = new ConcurrentLinkedQueue<>();
   private int confirmationTicks;
   private final TreeMap<Integer, List<BlockPos>> layerCache = new TreeMap<>();
   private boolean cached;
   private AutoMineRoute route;
   private BlockPos turnTarget;
   private BlockPos boundaryTarget;
   private BlockPos singleTarget;
   private BlockPos descentTarget;
   private BlockPos thinTarget;
   private int thinLayerY = Integer.MIN_VALUE;
   private int thinCentreY;
   private BlockPos approachCut;
   private boolean approachAxisX;
   private final AutoMineRotation rotation = new AutoMineRotation();
   private BlockPos jumpWaypoint;
   private int jumpCooldown;
   private int descentFloor = Integer.MIN_VALUE;
   private BlockPos descentEntry;
   private final Map<Integer, List<BlockPos>> routeBands = new HashMap<>();
   private int cooldown;
   private BlockPos currentTarget;
   private int mineAttemptTicks;
   private int totalMined;
   private double lastX;
   private double lastY;
   private double lastZ;
   private int stuckTicks;

   @Override
   public void onPacketReceive(Packet<?> packet) {
      if (packet instanceof BlockUpdateS2CPacket update) {
         this.serverUpdates.add(new ServerUpdate(update.getPos().toImmutable(), update.getState()));
      } else if (packet instanceof ChunkDeltaUpdateS2CPacket update) {
         update.visitUpdates((pos, state) -> this.serverUpdates.add(new ServerUpdate(pos.toImmutable(), state)));
      }
   }

   public boolean allowsMining(BlockHitResult hit) {
      BlockPos pos = hit.getBlockPos();
      return this.isEnabled()
         && this.currentTarget != null
         && this.currentTarget.equals(pos)
         && (this.isInBounds(pos) || pos.equals(this.thinTarget))
         && mc.player != null
         && mc.player.getEyePos().squaredDistanceTo(Vec3d.ofCenter(pos))
            <= Math.pow(Math.min((double)this.range.getValue().floatValue(), mc.player.getBlockInteractionRange()), 2.0)
         && (
            !this.smallObstacle(pos) && !pos.equals(this.singleTarget)
               ? (
                  this.drillMode.getValue()
                     ? this.isMiningTool(mc.player.getMainHandStack()) && this.safeDrillHit(hit)
                     : !this.isDrill(mc.player.getMainHandStack())
               )
               : this.singlePickaxe(mc.player.getMainHandStack())
         );
   }

   private boolean smallObstacle(BlockPos pos) {
      BlockState state = mc.world.getBlockState(pos);
      return !state.isAir()
         && !state.hasBlockEntity()
         && state.getFluidState().isEmpty()
         && state.getHardness(mc.world, pos) >= 0.0F
         && !state.isFullCube(mc.world, pos)
         && !state.getOutlineShape(mc.world, pos).isEmpty();
   }

   private boolean isDrill(ItemStack stack) {
      return Registries.ITEM.getId(stack.getItem()).getPath().contains("drill") || stack.getName().getString().toLowerCase(Locale.ROOT).contains("drill");
   }

   private boolean singlePickaxe(ItemStack stack) {
      return !stack.isEmpty() && Registries.ITEM.getId(stack.getItem()).getPath().endsWith("_pickaxe") && !this.isDrill(stack);
   }

   private boolean isMiningTool(ItemStack stack) {
      return this.isDrill(stack) || Registries.ITEM.getId(stack.getItem()).getPath().contains("pickaxe");
   }

   private boolean drillAxisX(BlockPos target) {
      return target.equals(this.turnTarget) ? !this.route.xAxis() : this.route.xAxis();
   }

   private boolean drillFootprint(BlockPos target, Direction face) {
      if (this.drillMode.getValue() && this.route != null) {
         if (target.equals(this.thinTarget)) {
            boolean axisX = this.drillAxisX(target);
            if (face.getAxis() != (axisX ? Axis.X : Axis.Z)) {
               return false;
            } else {
               for (int cross = -1; cross <= 1; cross++) {
                  for (int y = -1; y <= 1; y++) {
                     BlockPos p = target.add(axisX ? 0 : cross, y, axisX ? cross : 0);
                     if (!this.isInBounds(p) && !p.equals(target) && !mc.world.getBlockState(p).isAir()) {
                        return false;
                     }
                  }
               }

               return true;
            }
         } else if (target.equals(this.descentTarget)) {
            if (this.descentEntry != null && face == Direction.UP && target.getX() == this.descentEntry.getX() && target.getZ() == this.descentEntry.getZ()) {
               for (int x = -1; x <= 1; x++) {
                  for (int z = -1; z <= 1; z++) {
                     if (!this.isInBounds(target.add(x, 0, z))) {
                        return false;
                     }
                  }
               }

               return true;
            } else {
               return false;
            }
         } else {
            boolean turning = target.equals(this.turnTarget);
            boolean centre = target.equals(this.boundaryTarget)
               || (
                  turning
                     ? this.route.turnCentre(target.getX(), target.getY(), target.getZ())
                     : this.route.drillCentre(target.getX(), target.getY(), target.getZ())
               );
            boolean axisX = this.drillAxisX(target);
            if (centre && face.getAxis() == (axisX ? Axis.X : Axis.Z)) {
               for (int cross = -1; cross <= 1; cross++) {
                  for (int vertical = -1; vertical <= 1; vertical++) {
                     if (!this.isInBounds(target.add(axisX ? 0 : cross, vertical, axisX ? cross : 0))) {
                        return false;
                     }
                  }
               }

               return true;
            } else {
               return false;
            }
         }
      } else {
         return false;
      }
   }

   private BlockPos boundaryCentre(BlockPos residual, BlockPos ideal) {
      BlockPos best = null;
      double score = Double.MAX_VALUE;

      for (int c = -1; c <= 1; c++) {
         for (int y = -1; y <= 1; y++) {
            BlockPos centre = residual.add(this.route.xAxis() ? 0 : c, y, this.route.xAxis() ? c : 0);
            boolean fits = true;

            for (int cross = -1; cross <= 1; cross++) {
               for (int vertical = -1; vertical <= 1; vertical++) {
                  BlockPos p = centre.add(this.route.xAxis() ? 0 : cross, vertical, this.route.xAxis() ? cross : 0);
                  if (!this.isInBounds(p)
                     || !this.route.sameSlice(residual.getX(), residual.getY(), residual.getZ(), p.getX(), p.getY(), p.getZ())
                        && !mc.world.getBlockState(p).isAir()) {
                     fits = false;
                  }
               }
            }

            double distance = centre.getSquaredDistance(ideal);
            if (fits && distance < score) {
               best = centre;
               score = distance;
            }
         }
      }

      return best;
   }

   private Vec3d aimPoint(BlockPos target, Vec3d eye) {
      Vec3d centre = Vec3d.ofCenter(target);
      if (target.equals(this.descentTarget)) {
         return centre.add(0.0, 0.499, 0.0);
      } else if (this.smallObstacle(target) || target.equals(this.singleTarget)) {
         return mc.world.getBlockState(target).getOutlineShape(mc.world, target).getBoundingBox().getCenter().add(target.getX(), target.getY(), target.getZ());
      } else if (this.drillMode.getValue() && this.route != null) {
         boolean axisX = this.drillAxisX(target);
         double side = axisX ? eye.x - centre.x : eye.z - centre.z;
         return centre.add(axisX ? Math.copySign(0.499, side) : 0.0, 0.0, axisX ? 0.0 : Math.copySign(0.499, side));
      } else {
         return centre;
      }
   }

   private boolean centredForMining(BlockPos target) {
      if (target.equals(this.thinTarget) && Math.abs(mc.player.getY() - (this.thinCentreY - 1)) > 0.12) {
         return false;
      } else {
         double x = mc.player.getX();
         double z = mc.player.getZ();
         if (!(Math.abs(x - (Math.floor(x) + 0.5)) > 0.12) && !(Math.abs(z - (Math.floor(z) + 0.5)) > 0.12)) {
            return this.drillMode.getValue()
                  && !target.equals(this.singleTarget)
                  && Math.abs(this.drillAxisX(target) ? z - target.getZ() - 0.5 : x - target.getX() - 0.5) > 0.12
               ? false
               : mc.player.isOnGround() && mc.player.getVelocity().horizontalLengthSquared() < 4.0E-4;
         } else {
            return false;
         }
      }
   }

   private boolean safeDrillHit(BlockHitResult hit) {
      if (this.drillFootprint(hit.getBlockPos(), hit.getSide()) && this.centredForMining(hit.getBlockPos())) {
         Vec3d delta = this.aimPoint(hit.getBlockPos(), mc.player.getEyePos()).subtract(mc.player.getEyePos());
         float yaw = (float)(Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0);
         float pitch = (float)(-Math.toDegrees(Math.atan2(delta.y, Math.hypot(delta.x, delta.z))));
         return Math.abs(MathHelper.wrapDegrees(yaw - mc.player.getYaw())) < 0.5F && Math.abs(pitch - mc.player.getPitch()) < 0.5F;
      } else {
         return false;
      }
   }

   private boolean visible(BlockPos pos) {
      BlockHitResult hit = mc.world
         .raycast(new RaycastContext(mc.player.getEyePos(), this.aimPoint(pos, mc.player.getEyePos()), ShapeType.OUTLINE, FluidHandling.NONE, mc.player));
      return hit.getType() == Type.BLOCK && hit.getBlockPos().equals(pos);
   }

   public AutoMine() {
      super("Auto Mine", Category.MISC);
      this.addSetting(this.range);
      this.addSetting(this.delay);
      this.addSetting(this.topDown);
      this.addSetting(this.drillMode);
      this.addSetting(this.autoWalk);
      this.addSetting(this.debug);
      this.addSetting(this.pearlReturn);
      this.addSetting(this.stabilizeGravel);
   }

   @Override
   public void onEnable() {
      this.turnTarget = null;
      this.jumpWaypoint = null;
      this.jumpCooldown = 0;
      this.descentFloor = Integer.MIN_VALUE;
      this.descentEntry = null;
      this.descentTarget = null;
      this.thinTarget = null;
      this.approachCut = null;
      this.thinLayerY = Integer.MIN_VALUE;
      this.rotation.reset();
      this.recovery.reset();
      this.settleTicks = this.clearTicks = 0;
      this.lastSupportedY = Double.NaN;
      this.hasBounds = false;
      this.cached = false;
      this.layerCache.clear();
      this.cooldown = 0;
      this.currentTarget = null;
      this.mineAttemptTicks = 0;
      this.totalMined = 0;
      this.stuckTicks = 0;
      this.regions.clear();
      this.miningWorld = mc.world;
      this.counted.clear();
      this.pendingMined.clear();
      this.serverUpdates.clear();
      this.confirmationTicks = 0;
      if (mc.player != null && mc.world != null) {
         this.scanSchematicBounds();
      }
   }

   @Override
   public void onDisable() {
      this.recovery.reset();
      this.stopAll();
      this.layerCache.clear();
      this.cached = false;
      this.hasBounds = false;
      this.currentTarget = null;
      this.regions.clear();
      this.counted.clear();
      this.pendingMined.clear();
      this.serverUpdates.clear();
      this.confirmationTicks = 0;
      this.msg("§Mined " + this.totalMined + " blocks total");
   }

   private void msg(String s) {
      if (mc.player != null) {
         mc.player.sendMessage(Text.literal("§6[AM]§f null"), false);
      }
   }

   private void dbg(String s) {
      if (this.debug.getValue() && mc.player != null) {
         mc.player.sendMessage(Text.literal("§7[AM] null"), true);
      }
   }

   @Override
   public void onTick() {
      if (this.isEnabled()) {
         if (this.jumpCooldown > 0) {
            this.jumpCooldown--;
         }

         if (mc.player != null && mc.world != null && mc.interactionManager != null && mc.currentScreen == null) {
            if (this.miningWorld != mc.world) {
               this.recovery.reset();
               this.lastSupportedY = Double.NaN;
               this.descentFloor = Integer.MIN_VALUE;
               this.stopAll();
               this.miningWorld = mc.world;
               this.hasBounds = false;
               this.cached = false;
               this.regions.clear();
               this.layerCache.clear();
            }

            if (!this.hasBounds) {
               this.stopAll();
               this.scanSchematicBounds();
            } else if (!this.cached) {
               this.cacheNextLayer();
            } else {
               AutoMine.ServerUpdate update;
               while ((update = this.serverUpdates.poll()) != null) {
                  this.recovery.serverUpdate(update.pos(), update.state());
                  if (this.pendingMined.contains(update.pos()) && (update.state().isAir() || update.state().getBlock() instanceof FluidBlock)) {
                     if (this.counted.add(update.pos())) {
                        this.totalMined++;
                     }

                     this.pendingMined.remove(update.pos());
                     if (update.pos().equals(this.currentTarget)) {
                        this.currentTarget = null;
                        this.confirmationTicks = 0;
                        this.cooldown = Math.max(1, Math.round(this.delay.getValue()));
                     }
                  }
               }

               if (this.currentTarget != null && mc.world.getBlockState(this.currentTarget).isAir()) {
                  mc.options.attackKey.setPressed(false);
                  this.stopWalk();
                  if (++this.confirmationTicks > 100) {
                     this.msg("Server did not confirm mining. Auto Mine stopped.");
                     this.setEnabled(false);
                  }
               } else if (this.cooldown > 0) {
                  this.stopAll();
                  this.cooldown--;
               } else if (this.recovery.hasFailed()) {
                  this.dbg(this.recovery.failure());
                  this.recovery.reset();
                  this.stopAll();
                  this.cooldown = 20;
               } else if (this.recovery.tick()) {
                  this.stopAll();
               } else {
                  List<Entity> falling = mc.world
                     .getOtherEntities(
                        mc.player,
                        mc.player.getBoundingBox().expand(8.0),
                        entityx -> entityx instanceof FallingBlockEntity
                           && this.isInBounds(entityx.getBlockPos())
                           && this.currentTarget != null
                           && entityx.squaredDistanceTo(Vec3d.ofCenter(this.currentTarget)) < 9.0
                     );
                  if (!falling.isEmpty()) {
                     this.stopAll();
                     this.settleTicks = 10;
                     if (this.stabilizeGravel.getValue()) {
                        for (Entity entity : falling) {
                           BlockPos support = entity.getBlockPos().down();
                           if (this.isInBounds(support) && this.recovery.placeSupport(support)) {
                              break;
                           }
                        }
                     }
                  } else if (this.settleTicks > 0) {
                     this.stopAll();
                     this.settleTicks--;
                  } else if (this.approachCut == null || !this.clearApproach()) {
                     double px = mc.player.getX();
                     double py = mc.player.getY();
                     double pz = mc.player.getZ();
                     if (Math.abs(px - this.lastX) + Math.abs(py - this.lastY) + Math.abs(pz - this.lastZ) < 0.05) {
                        this.stuckTicks++;
                     } else {
                        this.stuckTicks = 0;
                     }

                     this.lastX = px;
                     this.lastY = py;
                     this.lastZ = pz;
                     Vec3d eye = mc.player.getEyePos();
                     float maxR = (float)Math.min((double)this.range.getValue().floatValue(), mc.player.getBlockInteractionRange());
                     double maxRSq = maxR * maxR;
                     if (!this.handleFluids(false)) {
                        int mineY = this.findNextMineY();
                        if (mineY == Integer.MAX_VALUE) {
                           this.stopAll();
                           if (this.layerCache.values().stream().flatMap(Collection::stream).anyMatch(p -> !mc.world.isChunkLoaded(p))) {
                              this.clearTicks = 0;
                              this.dbg("Waiting for remaining chunks to load");
                           } else if (this.handleFluids(true)) {
                              this.clearTicks = 0;
                           } else {
                              this.pendingMined.removeIf(p -> !mc.world.getBlockState(p).isAir() && !this.mineable(p));
                              if (++this.clearTicks >= 40 && this.pendingMined.isEmpty()) {
                                 this.msg("§a✓ Done! Mined " + this.totalMined + " blocks.");
                                 this.setEnabled(false);
                              }
                           }
                        } else {
                           this.clearTicks = 0;
                           List<BlockPos> layer = this.routeBands.get(this.route.band(mineY));
                           if (layer == null) {
                              this.dbg("No layer Y=" + mineY);
                           } else {
                              boolean singleLayer = this.singleRemainingLayer(layer);
                              if (singleLayer) {
                                 this.descentFloor = Integer.MIN_VALUE;
                                 this.descentEntry = null;
                                 this.descentTarget = null;
                                 if (mc.player.isOnGround()) {
                                    this.lastSupportedY = mc.player.getY();
                                 }
                              } else if (this.handleDescent(mineY)) {
                                 return;
                              }

                              if (Double.isNaN(this.lastSupportedY)) {
                                 this.lastSupportedY = mc.player.getY();
                              }

                              boolean fell = this.lastSupportedY - mc.player.getY() > 2.0;
                              if (!singleLayer && this.topDown.getValue() && fell && mc.player.getY() < mineY - 1.0) {
                                 this.stopAll();
                                 if (!this.pearlReturn.getValue()) {
                                    this.dbg("Return to the top layer to continue");
                                 } else {
                                    if (mc.player.isOnGround()) {
                                       List<BlockPos> landings = layer.stream()
                                          .filter(
                                             p -> !mc.world.getBlockState(p).isAir()
                                                && mc.world.getBlockState(p.up()).isAir()
                                                && mc.world.getBlockState(p.up(2)).isAir()
                                          )
                                          .sorted(Comparator.comparingDouble(p -> mc.player.squaredDistanceTo(Vec3d.ofCenter(p))))
                                          .limit(12L)
                                          .toList();
                                       if (!this.recovery.pearlTo(landings)) {
                                          this.msg(this.recovery.failure());
                                          this.setEnabled(false);
                                       }
                                    }
                                 }
                              } else {
                                 if (mc.player.isOnGround()) {
                                    this.lastSupportedY = mc.player.getY();
                                 }

                                 BlockPos first = layer.stream()
                                    .filter(p -> this.mineable(p) && (!p.equals(this.thinTarget) || p.getY() == this.thinLayerY))
                                    .findFirst()
                                    .orElse(null);
                                 if (first != null) {
                                    List<BlockPos> work = layer.stream()
                                       .filter(p -> this.route.sameSlice(first.getX(), first.getY(), first.getZ(), p.getX(), p.getY(), p.getZ()))
                                       .toList();
                                    BlockPos obstruction = work.stream()
                                       .filter(this::smallObstacle)
                                       .filter(p -> eye.squaredDistanceTo(Vec3d.ofCenter(p)) <= maxRSq && this.visible(p))
                                       .findFirst()
                                       .orElse(null);
                                    if (obstruction != null && mc.player.isOnGround()) {
                                       if (!obstruction.equals(this.currentTarget)) {
                                          this.mineAttemptTicks = 0;
                                          mc.interactionManager.cancelBlockBreaking();
                                       }

                                       this.currentTarget = obstruction;
                                       this.stopWalk();
                                       this.mineBlock(obstruction);
                                    } else {
                                       this.turnTarget = null;
                                       this.boundaryTarget = null;
                                       this.singleTarget = null;
                                       BlockPos drillCenter = null;
                                       if (this.drillMode.getValue() && !singleLayer) {
                                          drillCenter = new BlockPos(
                                             this.route.walkX(first.getX(), first.getZ()),
                                             this.route.centreY(first.getY()),
                                             this.route.walkZ(first.getX(), first.getZ())
                                          );
                                          if (this.route.lane(first.getX(), first.getZ()) > 0 && this.route.step(first.getX(), first.getZ()) < 3) {
                                             int nextLane = this.route.lane(first.getX(), first.getZ());
                                             BlockPos entrance = layer.stream()
                                                .filter(
                                                   p -> this.route.lane(p.getX(), p.getZ()) == nextLane
                                                      && this.route.step(p.getX(), p.getZ()) < 3
                                                      && this.mineable(p)
                                                )
                                                .min(Comparator.comparingInt(p -> this.route.turnOrder(p.getX(), p.getZ())))
                                                .orElse(first);
                                             this.turnTarget = new BlockPos(
                                                this.route.turnX(entrance.getX(), entrance.getZ()),
                                                this.route.centreY(entrance.getY()),
                                                this.route.turnZ(entrance.getX(), entrance.getZ())
                                             );
                                             drillCenter = this.turnTarget;
                                          }

                                          Direction face = this.drillAxisX(drillCenter) ? Direction.EAST : Direction.SOUTH;
                                          if (!this.drillFootprint(drillCenter, face)) {
                                             this.turnTarget = null;
                                             this.boundaryTarget = this.boundaryCentre(first, drillCenter);
                                             if (this.boundaryTarget != null) {
                                                drillCenter = this.boundaryTarget;
                                             } else {
                                                this.singleTarget = first;
                                                drillCenter = first;
                                             }
                                          }

                                          work = List.of(drillCenter);
                                          if (mc.world.getBlockState(drillCenter).isAir() && eye.squaredDistanceTo(Vec3d.ofCenter(drillCenter)) <= maxRSq) {
                                             this.stopAll();
                                             this.currentTarget = null;
                                             this.confirmationTicks = 0;
                                             if (this.recovery.placeSupport(drillCenter)) {
                                                return;
                                             }

                                             this.dbg("Cannot place centre from here; approaching the front of the 3x3");
                                          }
                                       }

                                       if (singleLayer && this.drillMode.getValue()) {
                                          if (this.thinLayerY != mineY) {
                                             this.thinLayerY = mineY;
                                             this.thinCentreY = AutoMineRoute.remainingCentreY(mineY);
                                          }

                                          this.thinTarget = new BlockPos(
                                             this.route.walkX(first.getX(), first.getZ()), this.thinCentreY, this.route.walkZ(first.getX(), first.getZ())
                                          );
                                          if (this.route.lane(first.getX(), first.getZ()) > 0 && this.route.step(first.getX(), first.getZ()) < 3) {
                                             int nextLane = this.route.lane(first.getX(), first.getZ());
                                             BlockPos entrance = layer.stream()
                                                .filter(
                                                   p -> p.getY() == this.thinLayerY
                                                      && this.route.lane(p.getX(), p.getZ()) == nextLane
                                                      && this.route.step(p.getX(), p.getZ()) < 3
                                                      && this.mineable(p)
                                                )
                                                .min(Comparator.comparingInt(p -> this.route.turnOrder(p.getX(), p.getZ())))
                                                .orElse(first);
                                             this.thinTarget = new BlockPos(
                                                this.route.turnX(entrance.getX(), entrance.getZ()),
                                                this.thinCentreY,
                                                this.route.turnZ(entrance.getX(), entrance.getZ())
                                             );
                                             this.turnTarget = this.thinTarget;
                                          }

                                          drillCenter = this.thinTarget;
                                          if (!this.drillFootprint(this.thinTarget, this.drillAxisX(this.thinTarget) ? Direction.EAST : Direction.SOUTH)) {
                                             this.stopAll();
                                             this.dbg("Cannot fit the raised 3x3 without touching blocks outside the area");
                                             return;
                                          }

                                          work = List.of(this.thinTarget);
                                          if (this.recovery.replaceableSupport(this.thinTarget)) {
                                             this.stopAll();
                                             this.currentTarget = null;
                                             if (this.recovery.placeSupport(this.thinTarget)) {
                                                return;
                                             }
                                          }
                                       }

                                       BlockPos target = null;

                                       for (BlockPos pos : work) {
                                          if (this.mineable(pos)
                                             && eye.squaredDistanceTo(Vec3d.ofCenter(pos)) <= maxRSq
                                             && this.visible(pos)
                                             && this.toolSlot(pos) >= 0) {
                                             target = pos;
                                             break;
                                          }
                                       }

                                       if (target != null && this.centredForMining(target)) {
                                          if (!target.equals(this.currentTarget)) {
                                             this.mineAttemptTicks = 0;
                                             mc.interactionManager.cancelBlockBreaking();
                                          }

                                          this.currentTarget = target;
                                          this.stopWalk();
                                          this.mineBlock(target);
                                       } else {
                                          this.currentTarget = null;
                                          mc.options.attackKey.setPressed(false);
                                          mc.interactionManager.cancelBlockBreaking();
                                          if (!this.autoWalk.getValue()) {
                                             this.stopWalk();
                                          } else {
                                             BlockPos walkTo = drillCenter;
                                             double bestDist = drillCenter == null ? Double.MAX_VALUE : eye.squaredDistanceTo(Vec3d.ofCenter(drillCenter));

                                             for (BlockPos posx : work) {
                                                BlockState state = mc.world.getBlockState(posx);
                                                if (!state.isAir() && !(state.getHardness(mc.world, posx) < 0.0F) && state.getFluidState().isEmpty()) {
                                                   double d = eye.squaredDistanceTo(Vec3d.ofCenter(posx));
                                                   if (d < bestDist) {
                                                      bestDist = d;
                                                      walkTo = posx;
                                                   }
                                                }
                                             }

                                             if (walkTo == null) {
                                                this.settleTicks = 10;
                                                this.dbg("§aLayer Y=" + mineY + " cleared!");
                                             } else {
                                                BlockPos laneTarget = new BlockPos(
                                                   this.drillMode.getValue()
                                                      ? this.route.approachX(walkTo.getX(), walkTo.getZ())
                                                      : this.route.walkX(walkTo.getX(), walkTo.getZ()),
                                                   mc.player.getBlockPos().getY(),
                                                   this.drillMode.getValue()
                                                      ? this.route.approachZ(walkTo.getX(), walkTo.getZ())
                                                      : this.route.walkZ(walkTo.getX(), walkTo.getZ())
                                                );
                                                if (walkTo.equals(this.turnTarget)) {
                                                   laneTarget = new BlockPos(
                                                      this.route.turnApproachX(walkTo.getX(), walkTo.getZ()),
                                                      mc.player.getBlockPos().getY(),
                                                      this.route.turnApproachZ(walkTo.getX(), walkTo.getZ())
                                                   );
                                                }

                                                if (walkTo.equals(this.thinTarget)) {
                                                   laneTarget = new BlockPos(laneTarget.getX(), this.thinCentreY - 1, laneTarget.getZ());
                                                }

                                                BlockPos waypoint = this.findMiningApproach(walkTo, laneTarget);
                                                if (waypoint != null) {
                                                   Box standingBox = mc.player
                                                      .getBoundingBox()
                                                      .offset(
                                                         waypoint.getX() + 0.5 - mc.player.getX(),
                                                         waypoint.getY() - mc.player.getY(),
                                                         waypoint.getZ() + 0.5 - mc.player.getZ()
                                                      );
                                                   if (mc.world.isSpaceEmpty(mc.player, standingBox.offset(0.0, -0.15, 0.0))) {
                                                      this.bridgeTo(waypoint);
                                                   } else {
                                                      this.walkToward(waypoint, walkTo);
                                                   }
                                                } else if (!singleLayer || !this.drillMode.getValue() || !this.startApproachCut(laneTarget)) {
                                                   this.stopWalk();
                                                   this.dbg("No clear standing position for the 3x3 centre");
                                                }
                                             }
                                          }
                                       }
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         } else {
            this.stopAll();
            this.recovery.pause();
         }
      }
   }

   private boolean singleRemainingLayer(List<BlockPos> positions) {
      Integer height = null;

      for (BlockPos pos : positions) {
         if (this.mineable(pos) && (!pos.equals(this.thinTarget) || pos.getY() == this.thinLayerY)) {
            if (height == null) {
               height = pos.getY();
            } else if (height != pos.getY()) {
               return false;
            }
         }
      }

      return height != null;
   }

   private boolean handleFluids(boolean finalCheck) {
      List<BlockPos> fluids = new ArrayList<>();
      if (finalCheck) {
         for (List<BlockPos> layer : this.layerCache.values()) {
            for (BlockPos pos : layer) {
               if (mc.world.getBlockState(pos).getBlock() instanceof FluidBlock) {
                  fluids.add(pos);
               }
            }
         }
      } else {
         BlockPos player = mc.player.getBlockPos();

         for (BlockPos posx : BlockPos.iterate(player.add(-4, -2, -4), player.add(4, 3, 4))) {
            if (this.isInBounds(posx) && mc.world.getBlockState(posx).getBlock() instanceof FluidBlock) {
               fluids.add(posx.toImmutable());
            }
         }
      }

      if (fluids.isEmpty()) {
         return false;
      } else {
         fluids.sort(Comparator.comparingDouble(p -> mc.player.getEyePos().squaredDistanceTo(Vec3d.ofCenter(p))));
         if (this.recovery.hasSupportBlocks()) {
            for (BlockPos posxx : fluids) {
               if (mc.player.getEyePos().squaredDistanceTo(Vec3d.ofCenter(posxx)) > 25.0) {
                  break;
               }

               if (this.recovery.placeSupport(posxx)) {
                  this.stopAll();
                  this.currentTarget = null;
                  return true;
               }
            }
         }

         if (!finalCheck) {
            return false;
         } else {
            this.dbg("Fluids remain in the area; clearing is not finished");
            if (this.recovery.hasSupportBlocks() && this.autoWalk.getValue()) {
               BlockPos posxx = fluids.getFirst();
               BlockPos waypoint = this.findMiningApproach(posxx, mc.player.getBlockPos());
               if (waypoint != null) {
                  this.walkToward(waypoint, posxx);
               }
            }

            return true;
         }
      }
   }

   private boolean handleDescent(int highestRemainingY) {
      if (!this.topDown.getValue()) {
         return false;
      } else {
         if (this.descentFloor == Integer.MIN_VALUE) {
            if (mc.player.getY() < highestRemainingY + 0.75) {
               return false;
            }

            this.descentFloor = this.route.bandBottom(highestRemainingY);
            this.descentEntry = new BlockPos(this.route.entryX(), highestRemainingY + 1, this.route.entryZ());
         }

         this.stopWalk();
         if (!(Math.abs(mc.player.getX() - this.descentEntry.getX() - 0.5) > 0.12) && !(Math.abs(mc.player.getZ() - this.descentEntry.getZ() - 0.5) > 0.12)) {
            if (mc.player.getY() <= this.descentFloor + 0.1 && mc.player.isOnGround()) {
               this.descentFloor = Integer.MIN_VALUE;
               this.descentEntry = null;
               this.descentTarget = null;
               this.lastSupportedY = mc.player.getY();
               this.currentTarget = null;
               this.singleTarget = null;
               return false;
            } else if (!mc.player.isOnGround()) {
               mc.options.attackKey.setPressed(false);
               return true;
            } else {
               BlockPos floor = mc.player.getBlockPos().down();
               BlockPos landing = new BlockPos(floor.getX(), this.descentFloor - 1, floor.getZ());
               BlockState support = mc.world.getBlockState(landing);
               if (support.isAir() || !support.getFluidState().isEmpty() || !support.isFullCube(mc.world, landing)) {
                  this.stopAll();
                  if (support.isAir() && this.recovery.hasSupportBlocks() && this.recovery.placeSupport(landing)) {
                     return true;
                  } else {
                     this.dbg("Need a supported landing for the next layer");
                     return true;
                  }
               } else if (floor.getY() < this.descentFloor) {
                  this.stopAll();
                  return true;
               } else {
                  this.descentTarget = new BlockPos(this.descentEntry.getX(), floor.getY(), this.descentEntry.getZ());
                  this.singleTarget = null;
                  this.turnTarget = null;
                  this.boundaryTarget = null;
                  if (!this.drillFootprint(this.descentTarget, Direction.UP)) {
                     this.stopAll();
                     this.dbg("The corner entry needs a complete 3x3 inside the area");
                     return true;
                  } else if (!this.mineable(this.descentTarget)) {
                     this.stopAll();
                     this.dbg("Waiting for the centre of the corner entry");
                     return true;
                  } else {
                     if (!this.descentTarget.equals(this.currentTarget)) {
                        this.mineAttemptTicks = 0;
                        mc.interactionManager.cancelBlockBreaking();
                     }

                     this.currentTarget = this.descentTarget;
                     this.mineBlock(this.descentTarget);
                     return true;
                  }
               }
            }
         } else {
            this.currentTarget = null;
            this.singleTarget = null;
            mc.options.attackKey.setPressed(false);
            if (mc.interactionManager.isBreakingBlock()) {
               mc.interactionManager.cancelBlockBreaking();
            }

            if (!this.autoWalk.getValue()) {
               this.dbg("Move to the layer entry corner");
               return true;
            } else {
               BlockPos waypoint = this.findMiningApproach(this.descentEntry, this.descentEntry, true);
               if (waypoint == null) {
                  this.dbg("Finding a route to the entry corner");
                  return true;
               } else {
                  Box box = mc.player
                     .getBoundingBox()
                     .offset(waypoint.getX() + 0.5 - mc.player.getX(), waypoint.getY() - mc.player.getY(), waypoint.getZ() + 0.5 - mc.player.getZ());
                  if (mc.world.isSpaceEmpty(mc.player, box.offset(0.0, -0.15, 0.0))) {
                     this.bridgeTo(waypoint);
                  } else {
                     this.walkToward(waypoint, this.descentEntry);
                  }

                  return true;
               }
            }
         }
      }
   }

   private void mineBlock(BlockPos target) {
      this.mineAttemptTicks++;
      Vec3d eye = mc.player.getEyePos();
      Vec3d aim = this.aimPoint(target, eye);
      if (this.equipDrill(target)) {
         double dx = aim.x - eye.x;
         double dy = aim.y - eye.y;
         double dz = aim.z - eye.z;
         double h = Math.sqrt(dx * dx + dz * dz);
         float targetYaw = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
         float targetPitch = (float)(-Math.toDegrees(Math.atan2(dy, h)));
         float yd = MathHelper.wrapDegrees(targetYaw - mc.player.getYaw());
         float pd = MathHelper.wrapDegrees(targetPitch - mc.player.getPitch());
         this.rotateToward(targetYaw, targetPitch);
         boolean aimed = Math.abs(yd) < 0.5F && Math.abs(pd) < 0.5F;
         if (aimed) {
            HitResult hit = mc.player.raycast(Math.min((double)this.range.getValue().floatValue(), mc.player.getBlockInteractionRange()), 1.0F, false);
            boolean onTarget = hit instanceof BlockHitResult blockHit && hit.getType() == Type.BLOCK && this.allowsMining(blockHit);
            if (onTarget) {
               if (this.drillMode.getValue() && !this.smallObstacle(target) && !target.equals(this.singleTarget)) {
                  for (int cross = -1; cross <= 1; cross++) {
                     for (int vertical = -1; vertical <= 1; vertical++) {
                        BlockPos pos = target.equals(this.descentTarget)
                           ? target.add(cross, 0, vertical)
                           : target.add(this.drillAxisX(target) ? 0 : cross, vertical, this.drillAxisX(target) ? cross : 0);
                        if (!mc.world.getBlockState(pos).isAir()) {
                           this.pendingMined.add(pos);
                        }
                     }
                  }
               } else {
                  this.pendingMined.add(target);
               }
            }

            mc.options.attackKey.setPressed(onTarget);
         } else {
            mc.options.attackKey.setPressed(false);
         }

         if (this.mineAttemptTicks > (!target.equals(this.singleTarget) && !this.smallObstacle(target) ? 100 : 600)) {
            this.mineAttemptTicks = 0;
            this.currentTarget = null;
            this.stopAll();
            this.dbg("§cRetry " + target.toShortString());
         }
      }
   }

   private boolean equipDrill(BlockPos target) {
      int slot = this.toolSlot(target);
      if (slot < 0) {
         this.stopAll();
         this.dbg(this.drillMode.getValue() ? "Need drill and a reachable 3x3 centre" : "Need a normal pickaxe");
         return false;
      } else {
         mc.player.getInventory().setSelectedSlot(slot);
         return true;
      }
   }

   private int toolSlot(BlockPos target) {
      if (!this.smallObstacle(target) && !target.equals(this.singleTarget)) {
         BlockHitResult surface = mc.world
            .raycast(new RaycastContext(mc.player.getEyePos(), this.aimPoint(target, mc.player.getEyePos()), ShapeType.OUTLINE, FluidHandling.NONE, mc.player));
         boolean allowDrill = surface.getType() == Type.BLOCK && surface.getBlockPos().equals(target) && this.drillFootprint(target, surface.getSide());
         int best = -1;
         float speed = -1.0F;

         for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (!stack.isEmpty()) {
               String id = Registries.ITEM.getId(stack.getItem()).getPath();
               boolean drill = this.isDrill(stack);
               if (drill && allowDrill) {
                  return i;
               }

               if (!this.drillMode.getValue() && !drill && id.contains("pickaxe")) {
                  float value = stack.getMiningSpeedMultiplier(mc.world.getBlockState(target));
                  if (value > speed) {
                     speed = value;
                     best = i;
                  }
               }
            }
         }

         if (this.drillMode.getValue() && allowDrill) {
            int held = mc.player.getInventory().getSelectedSlot();
            if (this.isMiningTool(mc.player.getInventory().getStack(held))) {
               return held;
            }

            for (int ix = 0; ix < 9; ix++) {
               if (this.isMiningTool(mc.player.getInventory().getStack(ix))) {
                  return ix;
               }
            }
         }

         return best;
      } else {
         int best = -1;
         float fastest = -1.0F;

         for (int ixx = 0; ixx < 9; ixx++) {
            ItemStack stack = mc.player.getInventory().getStack(ixx);
            if (this.singlePickaxe(stack)) {
               float speed = stack.getMiningSpeedMultiplier(mc.world.getBlockState(target));
               if (speed > fastest) {
                  best = ixx;
                  fastest = speed;
               }
            }
         }

         return best;
      }
   }

   private Direction getClosestFace(BlockPos p) {
      Vec3d d = mc.player.getEyePos().subtract(Vec3d.ofCenter(p));
      return Direction.getFacing(d.x, d.y, d.z);
   }

   private BlockPos findMiningApproach(BlockPos target, BlockPos preferred) {
      return this.findMiningApproach(target, preferred, false);
   }

   private BlockPos findMiningApproach(BlockPos target, BlockPos preferred, boolean travelOnly) {
      boolean thin = target.equals(this.thinTarget) && !travelOnly;
      if (!thin && this.jumpWaypoint != null && !mc.player.isOnGround() && this.jumpCooldown > 0) {
         return this.jumpWaypoint;
      } else {
         this.jumpWaypoint = null;
         BlockPos start = mc.player.getBlockPos();
         ArrayDeque<BlockPos> queue = new ArrayDeque<>();
         Map<BlockPos, BlockPos> previous = new HashMap<>();
         queue.add(start);
         previous.put(start, start);
         double eyeHeight = mc.player.getEyePos().y - mc.player.getY();
         double reach = Math.min((double)this.range.getValue().floatValue(), mc.player.getBlockInteractionRange());
         BlockPos frontier = start;
         double initialDistance = start.getSquaredDistance(preferred);
         double bestDistance = initialDistance;
         boolean missingCentre = this.recovery.replaceableSupport(target);

         while (!queue.isEmpty()) {
            BlockPos cell = queue.removeFirst();
            double distance = cell.getSquaredDistance(preferred);
            if (distance < bestDistance) {
               bestDistance = distance;
               frontier = cell;
            }

            Vec3d feet = new Vec3d(cell.getX() + 0.5, cell.getY(), cell.getZ() + 0.5);
            Vec3d eye = feet.add(0.0, eyeHeight, 0.0);
            boolean suitable = false;
            if (eye.squaredDistanceTo(Vec3d.ofCenter(target)) <= reach * reach) {
               if (missingCentre) {
                  suitable = this.recovery.canPlaceSupportFrom(target, eye);
               } else {
                  BlockHitResult hit = mc.world.raycast(new RaycastContext(eye, this.aimPoint(target, eye), ShapeType.OUTLINE, FluidHandling.NONE, mc.player));
                  suitable = hit.getType() == Type.BLOCK
                     && hit.getBlockPos().equals(target)
                     && (!this.drillMode.getValue() || target.equals(this.singleTarget) || this.drillFootprint(target, hit.getSide()));
               }
            }

            if (suitable && !travelOnly && this.drillMode.getValue() && !missingCentre && !target.equals(this.singleTarget)) {
               suitable = this.drillAxisX(target) ? cell.getZ() == target.getZ() : cell.getX() == target.getX();
            }

            if (thin) {
               suitable &= cell.getY() == this.thinCentreY - 1;
            }

            if (travelOnly) {
               suitable = cell.equals(preferred);
            }

            if (suitable) {
               BlockPos next = cell;

               while (!previous.get(next).equals(start) && !next.equals(start)) {
                  next = previous.get(next);
               }

               return next;
            }

            for (Direction direction : new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST}) {
               for (int rise : thin ? new int[]{0, -1, -2} : new int[]{0, 1, -1}) {
                  BlockPos next = cell.offset(direction).up(rise);
                  if ((!thin || AutoMineRoute.remainingStep(cell.getY(), next.getY(), this.thinCentreY))
                     && !previous.containsKey(next)
                     && Math.abs(next.getX() - start.getX()) <= 24
                     && Math.abs(next.getZ() - start.getZ()) <= 24
                     && Math.abs(next.getY() - start.getY()) <= 3) {
                     Vec3d offset = new Vec3d(next.getX() + 0.5 - mc.player.getX(), next.getY() - mc.player.getY(), next.getZ() + 0.5 - mc.player.getZ());
                     Box box = mc.player.getBoundingBox().offset(offset);
                     if (mc.world.isSpaceEmpty(mc.player, box) && (rise != -2 || mc.world.isSpaceEmpty(mc.player, box.offset(0.0, 1.0, 0.0)))) {
                        boolean supported = !mc.world.isSpaceEmpty(mc.player, box.offset(0.0, -0.15, 0.0));
                        if (supported || rise == 0 && this.bridgeFloor(next.down()) && this.recovery.hasSupportBlocks()) {
                           Vec3d headOffset = new Vec3d(
                              cell.getX() + 0.5 - mc.player.getX(), Math.max(cell.getY(), next.getY()) - mc.player.getY(), cell.getZ() + 0.5 - mc.player.getZ()
                           );
                           if (mc.world.isSpaceEmpty(mc.player, mc.player.getBoundingBox().offset(headOffset))) {
                              previous.put(next, cell);
                              queue.addLast(next);
                              break;
                           }
                        }
                     }
                  }
               }
            }
         }

         if (bestDistance < initialDistance && !frontier.equals(start)) {
            BlockPos next = frontier;

            while (!previous.get(next).equals(start)) {
               next = previous.get(next);
            }

            return next;
         } else {
            return null;
         }
      }
   }

   private boolean startApproachCut(BlockPos preferred) {
      BlockPos feet = mc.player.getBlockPos();
      if (feet.getY() != this.thinCentreY - 1) {
         return false;
      } else {
         int dx = Integer.compare(preferred.getX(), feet.getX());
         int dz = Integer.compare(preferred.getZ(), feet.getZ());
         boolean xFirst = Math.abs(preferred.getX() - feet.getX()) >= Math.abs(preferred.getZ() - feet.getZ());
         BlockPos oldThin = this.thinTarget;
         BlockPos oldTurn = this.turnTarget;

         for (boolean axisX : new boolean[]{xFirst, !xFirst}) {
            int step = axisX ? dx : dz;
            if (step != 0) {
               BlockPos candidate = feet.add(axisX ? step : 0, 1, axisX ? 0 : step);
               this.thinTarget = candidate;
               this.turnTarget = axisX != this.route.xAxis() ? candidate : null;
               if (this.isInBounds(candidate.down())
                  && this.mineable(candidate.down())
                  && this.drillFootprint(candidate, axisX ? Direction.EAST : Direction.SOUTH)) {
                  this.approachCut = candidate;
                  this.approachAxisX = axisX;
                  return this.clearApproach();
               }
            }
         }

         this.thinTarget = oldThin;
         this.turnTarget = oldTurn;
         return false;
      }
   }

   private boolean clearApproach() {
      this.thinTarget = this.approachCut;
      this.turnTarget = this.approachAxisX != this.route.xAxis() ? this.approachCut : null;
      if (!this.mineable(this.approachCut) && !this.mineable(this.approachCut.down())) {
         this.approachCut = null;
         return false;
      } else {
         this.stopWalk();
         if (!this.drillFootprint(this.approachCut, this.approachAxisX ? Direction.EAST : Direction.SOUTH)) {
            this.approachCut = null;
            return false;
         } else if (this.recovery.replaceableSupport(this.approachCut)) {
            this.stopAll();
            this.currentTarget = null;
            if (!this.recovery.placeSupport(this.approachCut)) {
               this.dbg("Need a reachable support face and blocks for the next 3x3 passage");
            }

            return true;
         } else if (!this.centredForMining(this.approachCut)) {
            this.stopAll();
            this.walkToward(mc.player.getBlockPos(), this.approachCut);
            return true;
         } else {
            if (!this.approachCut.equals(this.currentTarget)) {
               this.mineAttemptTicks = 0;
               mc.interactionManager.cancelBlockBreaking();
            }

            this.currentTarget = this.approachCut;
            this.mineBlock(this.approachCut);
            return true;
         }
      }
   }

   private boolean bridgeFloor(BlockPos floor) {
      return this.recovery.replaceableSupport(floor)
         && this.regions
            .stream()
            .anyMatch(
               r -> floor.getX() >= r.min().getX()
                  && floor.getX() <= r.max().getX()
                  && floor.getZ() >= r.min().getZ()
                  && floor.getZ() <= r.max().getZ()
                  && floor.getY() >= r.min().getY() - 1
                  && floor.getY() <= r.max().getY()
            );
   }

   private void bridgeTo(BlockPos waypoint) {
      this.stopAll();
      BlockPos floor = waypoint.down();
      if (!this.bridgeFloor(floor) || !this.recovery.hasSupportBlocks()) {
         this.dbg("Need solid blocks to bridge the gap");
      } else if (!this.recovery.placeSupport(floor)) {
         if (mc.player.isOnGround()) {
            double dx = waypoint.getX() + 0.5 - mc.player.getX();
            double dz = waypoint.getZ() + 0.5 - mc.player.getZ();
            double distance = Math.hypot(dx, dz);
            if (!(distance < 0.1)) {
               Vec3d look = Vec3d.ofCenter(floor).subtract(mc.player.getEyePos());
               this.rotateToward(
                  (float)(Math.toDegrees(Math.atan2(look.z, look.x)) - 90.0), (float)(-Math.toDegrees(Math.atan2(look.y, Math.hypot(look.x, look.z))))
               );
               this.moveKeys(dx, dz, distance);
               mc.options.sneakKey.setPressed(true);
            }
         }
      }
   }

   private void walkToward(BlockPos pos, BlockPos focus) {
      this.stopWalk();
      double dx = pos.getX() + 0.5 - mc.player.getX();
      double dz = pos.getZ() + 0.5 - mc.player.getZ();
      double dist = Math.hypot(dx, dz);
      Vec3d look = this.aimPoint(focus, mc.player.getEyePos()).subtract(mc.player.getEyePos());
      float yaw = (float)(Math.toDegrees(Math.atan2(look.z, look.x)) - 90.0);
      float pitch = (float)(-Math.toDegrees(Math.atan2(look.y, Math.hypot(look.x, look.z))));
      this.rotateToward(yaw, pitch);
      if (!(dist < 0.08)) {
         if (pos.getY() > mc.player.getY() + 0.4 && mc.player.isOnGround()) {
            if (this.jumpCooldown <= 0 && mc.world.isSpaceEmpty(mc.player, mc.player.getBoundingBox().offset(0.0, 1.0, 0.0))) {
               this.jumpWaypoint = pos;
               this.jumpCooldown = 15;
               mc.options.jumpKey.setPressed(true);
               this.moveKeys(dx, dz, dist);
            }
         } else if (this.jumpWaypoint != null && !mc.player.isOnGround() && this.jumpCooldown > 0) {
            this.moveKeys(dx, dz, dist);
         } else {
            Vec3d offset = new Vec3d(dx / dist * 0.25, 0.0, dz / dist * 0.25);
            Box nextBox = mc.player.getBoundingBox().offset(offset);
            if (mc.world.isSpaceEmpty(mc.player, nextBox)) {
               double floorProbe = pos.getY() < mc.player.getY() - 0.4 ? Math.min(2.15, mc.player.getY() - pos.getY() + 0.15) : 0.15;
               if (!mc.world.isSpaceEmpty(mc.player, nextBox.offset(0.0, -floorProbe, 0.0))) {
                  this.moveKeys(dx, dz, dist);
               }
            }
         }
      }
   }

   private void moveKeys(double dx, double dz, double distance) {
      double yaw = Math.toRadians(mc.player.getYaw());
      double forward = (-Math.sin(yaw) * dx + Math.cos(yaw) * dz) / distance;
      double left = (Math.cos(yaw) * dx + Math.sin(yaw) * dz) / distance;
      mc.options.forwardKey.setPressed(forward > 0.35);
      mc.options.backKey.setPressed(forward < -0.35);
      mc.options.leftKey.setPressed(left > 0.35);
      mc.options.rightKey.setPressed(left < -0.35);
   }

   private void rotateToward(float yaw, float pitch) {
      float[] next = this.rotation.step(mc.player.getYaw(), mc.player.getPitch(), yaw, pitch);
      mc.player.setYaw(next[0]);
      mc.player.setPitch(next[1]);
   }

   private void stopWalk() {
      mc.options.backKey.setPressed(false);
      mc.options.leftKey.setPressed(false);
      mc.options.rightKey.setPressed(false);
      mc.options.sneakKey.setPressed(false);
      mc.options.forwardKey.setPressed(false);
      mc.options.sprintKey.setPressed(false);
      mc.options.jumpKey.setPressed(false);
   }

   private void stopAll() {
      mc.options.attackKey.setPressed(false);
      this.stopWalk();
      if (mc.interactionManager != null && mc.interactionManager.isBreakingBlock()) {
         mc.interactionManager.cancelBlockBreaking();
      }
   }

   private int findNextMineY() {
      if (this.topDown.getValue()) {
         for (int y = this.maxY; y >= this.minY; y--) {
            List<BlockPos> layer = this.layerCache.get(y);
            if (layer != null) {
               for (BlockPos p : layer) {
                  BlockState state = mc.world.getBlockState(p);
                  if (this.mineable(p) && (!p.equals(this.thinTarget) || p.getY() == this.thinLayerY)) {
                     return y;
                  }
               }
            }
         }
      } else {
         for (int yx = this.minY; yx <= this.maxY; yx++) {
            List<BlockPos> layer = this.layerCache.get(yx);
            if (layer != null) {
               for (BlockPos px : layer) {
                  BlockState state = mc.world.getBlockState(px);
                  if (this.mineable(px) && (!px.equals(this.thinTarget) || px.getY() == this.thinLayerY)) {
                     return yx;
                  }
               }
            }
         }
      }

      return Integer.MAX_VALUE;
   }

   private void buildMineCache() {
      this.layerCache.clear();
      this.routeBands.clear();
      this.cacheY = this.minY;
      this.cached = false;
      Direction facing = mc.player.getHorizontalFacing();
      boolean xAxis = facing.getAxis() == Axis.X;
      boolean forward = facing == Direction.EAST || facing == Direction.SOUTH;
      boolean reverseCross = xAxis ? mc.player.getZ() > (this.minZ + this.maxZ + 1.0) / 2.0 : mc.player.getX() > (this.minX + this.maxX + 1.0) / 2.0;
      this.route = new AutoMineRoute(
         this.minX,
         this.minY,
         this.minZ,
         this.maxX,
         this.maxY,
         this.maxZ,
         xAxis,
         forward,
         reverseCross,
         this.topDown.getValue(),
         this.drillMode.getValue() ? 3 : 1
      );
   }

   private void cacheNextLayer() {
      if (this.cacheY > this.maxY) {
         for (List<BlockPos> positions : this.layerCache.values()) {
            for (BlockPos pos : positions) {
               this.routeBands.computeIfAbsent(this.route.band(pos.getY()), ignored -> new ArrayList<>()).add(pos);
            }
         }

         Comparator<BlockPos> order = Comparator.<BlockPos>comparingInt(p -> this.route.lane(p.getX(), p.getZ()))
            .thenComparingInt(p -> this.route.step(p.getX(), p.getZ()))
            .thenComparingInt(p -> this.route.centrePriority(p.getX(), p.getY(), p.getZ()))
            .thenComparingInt(Vec3i::getY)
            .thenComparingInt(Vec3i::getX)
            .thenComparingInt(Vec3i::getZ);
         this.routeBands.values().forEach(positionsx -> positionsx.sort(order));
         this.cached = true;
         this.msg("Area ready to mine");
      } else {
         List<BlockPos> positions = new ArrayList<>();

         for (int x = this.minX; x <= this.maxX; x++) {
            for (int z = this.minZ; z <= this.maxZ; z++) {
               if (this.isInBounds(new BlockPos(x, this.cacheY, z))) {
                  positions.add(new BlockPos(x, this.cacheY, z));
               }
            }
         }

         this.layerCache.put(this.cacheY++, positions);
      }
   }

   private int countMineable() {
      int count = 0;

      for (List<BlockPos> layer : this.layerCache.values()) {
         for (BlockPos p : layer) {
            BlockState state = mc.world.getBlockState(p);
            if (!state.isAir() && state.getBlock() != Blocks.BEDROCK) {
               count++;
            }
         }
      }

      return count;
   }

   private boolean mineable(BlockPos pos) {
      BlockState state = mc.world.getBlockState(pos);
      return !state.isAir() && state.getHardness(mc.world, pos) >= 0.0F && !(state.getBlock() instanceof FluidBlock);
   }

   private boolean isInBounds(BlockPos p) {
      return this.regions.stream().anyMatch(region -> region.contains(p));
   }

   private void scanSchematicBounds() {
      this.regions.clear();
      this.hasBounds = false;

      try {
         Class<?> data = Class.forName("fi.dy.masa.litematica.data.DataManager");
         Object manager = data.getMethod("getSchematicPlacementManager").invoke(null);
         Object placement = manager.getClass().getMethod("getSelectedSchematicPlacement").invoke(manager);
         if (placement == null) {
            List<?> all = (List<?>)manager.getClass().getMethod("getAllSchematicsPlacements").invoke(manager);
            List<Object> enabled = new ArrayList<>();

            for (Object candidate : all) {
               if (Boolean.TRUE.equals(candidate.getClass().getMethod("isEnabled").invoke(candidate))) {
                  enabled.add(candidate);
               }
            }

            if (enabled.size() != 1) {
               this.msg(enabled.isEmpty() ? "No enabled Litematica placement found." : "Select one placement in Litematica first.");
               this.setEnabled(false);
               return;
            }

            placement = enabled.getFirst();
         }

         if (!Boolean.TRUE.equals(placement.getClass().getMethod("isEnabled").invoke(placement))) {
            this.msg("Enable the selected Litematica placement first.");
            this.setEnabled(false);
            return;
         }

         Class<? extends Enum> required = (Class<? extends Enum>)Class.forName("fi.dy.masa.litematica.schematic.placement.SubRegionPlacement$RequiredEnabled");
         Object mode = Enum.valueOf(required, "PLACEMENT_ENABLED");
         Map<?, ?> boxes = (Map<?, ?>)placement.getClass().getMethod("getSubRegionBoxes", required).invoke(placement, mode);
         this.minX = this.minY = this.minZ = Integer.MAX_VALUE;
         this.maxX = this.maxY = this.maxZ = Integer.MIN_VALUE;

         for (Object box : boxes.values()) {
            Object first = box.getClass().getMethod("getPos1").invoke(box);
            Object second = box.getClass().getMethod("getPos2").invoke(box);
            if (first instanceof BlockPos a && second instanceof BlockPos b) {
               BlockPos min = new BlockPos(Math.min(a.getX(), b.getX()), Math.min(a.getY(), b.getY()), Math.min(a.getZ(), b.getZ()));
               BlockPos max = new BlockPos(Math.max(a.getX(), b.getX()), Math.max(a.getY(), b.getY()), Math.max(a.getZ(), b.getZ()));
               this.regions.add(new Region(min, max));
               this.minX = Math.min(this.minX, min.getX());
               this.minY = Math.min(this.minY, min.getY());
               this.minZ = Math.min(this.minZ, min.getZ());
               this.maxX = Math.max(this.maxX, max.getX());
               this.maxY = Math.max(this.maxY, max.getY());
               this.maxZ = Math.max(this.maxZ, max.getZ());
            }
         }

         if (this.regions.isEmpty()) {
            this.msg("The placement has no enabled subregions.");
            this.setEnabled(false);
            return;
         }

         this.hasBounds = true;
         this.buildMineCache();
         this.msg("Found " + placement.getClass().getMethod("getName").invoke(placement) + " (" + this.regions.size() + " regions)");
      } catch (ClassNotFoundException var15) {
         this.msg("Litematica is not installed.");
         this.setEnabled(false);
      } catch (RuntimeException | ReflectiveOperationException var16) {
         System.err.println("[AutoMine] Litematica placement lookup failed: " + var16);
         this.msg("Cannot read Litematica placement; see latest.log.");
         this.setEnabled(false);
      }
   }

   final static class Region {
      private BlockPos min;
      private BlockPos max;

      private Region(BlockPos min, BlockPos max) {
         this.min = min;
         this.max = max;
      }

      boolean contains(BlockPos p) {
         return p.getX() >= this.min.getX()
            && p.getX() <= this.max.getX()
            && p.getY() >= this.min.getY()
            && p.getY() <= this.max.getY()
            && p.getZ() >= this.min.getZ()
            && p.getZ() <= this.max.getZ();
      }

      public BlockPos min() {
         return this.min;
      }

      public BlockPos max() {
         return this.max;
      }
   }

   final class ServerUpdate {
      private BlockPos pos;
      private BlockState state;

      private ServerUpdate(BlockPos pos, BlockState state) {
         this.pos = pos;
         this.state = state;
      }

      public BlockPos pos() {
         return this.pos;
      }

      public BlockState state() {
         return this.state;
      }
   }
}

