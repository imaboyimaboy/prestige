package rtx.kimiko.api.events.impl.network;

import net.minecraft.network.packet.Packet;
import rtx.kimiko.api.events.CancellableEvent;

public final class PacketEvent extends CancellableEvent {
   private Packet<?> packet;
   private PacketEvent.Direction direction;

   public PacketEvent(Packet<?> packet, PacketEvent.Direction direction) {
      this.packet = packet;
      this.direction = direction;
   }

   public boolean check(Class<? extends Packet<?>> clazz) {
      return clazz.isInstance(this.packet);
   }

   public Packet<?> getPacket() {
      return this.packet;
   }

   public boolean isReceive() {
      return this.direction == PacketEvent.Direction.RECEIVE;
   }

   public boolean isSend() {
      return this.direction == PacketEvent.Direction.SEND;
   }

   public void setPacket(Packet<?> packet) {
      this.packet = packet;
   }

   public PacketEvent.Direction direction() {
      return this.direction;
   }

   public enum Direction {
      SEND,
      RECEIVE;

      private static PacketEvent.Direction[] $values() {
         return new PacketEvent.Direction[]{SEND, RECEIVE};
      }
   }
}

