package com.water.mixin;

import com.water.WaterClient;
import com.water.module.modules.client.WaterPlus;
import net.minecraft.client.Keyboard;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.input.KeyInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(
   value = {Keyboard.class},
   priority = 2000
)
public class WaterMenuKeyboardMixin {
   @Inject(
      method = {"onKey"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void water$openClickGuiFromAnyScreen(long window, int action, KeyInput input, CallbackInfo ci) {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client.getWindow() != null && window == client.getWindow().getHandle() && input.key() == WaterPlus.getGuiKey()) {
         if (action == 1) {
            WaterClient.toggleClickGui();
         }

         ci.cancel();
      }
   }
}

