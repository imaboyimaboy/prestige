package rtx.kimiko.api.mods.geckolib.loading.math.function.limit;

import net.minecraft.util.math.MathHelper;
import rtx.kimiko.api.mods.geckolib.animation.state.ControllerState;
import rtx.kimiko.api.mods.geckolib.loading.math.MathValue;
import rtx.kimiko.api.mods.geckolib.loading.math.function.MathFunction;

public final class ClampFunction extends MathFunction {
   private MathValue value;
   private MathValue min;
   private MathValue max;

   public ClampFunction(MathValue... mathValueArray) {
      super(mathValueArray);
      this.value = mathValueArray[0];
      this.min = mathValueArray[1];
      this.max = mathValueArray[2];
   }

   @Override
   public String getName() {
      return "math.clamp";
   }

   @Override
   public double compute(ControllerState controllerState) {
      return MathHelper.clamp(this.value.get(controllerState), this.min.get(controllerState), this.max.get(controllerState));
   }

   @Override
   public MathValue[] getArgs() {
      return new MathValue[]{this.value, this.min, this.max};
   }

   @Override
   public int getMinArgs() {
      return 3;
   }
}

