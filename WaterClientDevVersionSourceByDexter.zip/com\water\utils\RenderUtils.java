package com.water.utils;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;
import com.water.utils.renderer.ProjectionUtil;
import com.water.utils.renderer.glass.ChunkGlassRenderer;
import java.awt.Color;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.VertexRendering;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.util.Identifier;
import net.minecraft.util.Pair;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShapes;
import org.joml.FrustumIntersection;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.lwjgl.opengl.GL11;

public class RenderUtils {
   private static final Matrix4f POSITION_PROJECTION_MATRIX = new Matrix4f();
   private static final FrustumIntersection FRUSTUM = new FrustumIntersection();
   private static boolean frustumReady;
   private static double frustumX;
   private static double frustumY;
   private static double frustumZ;
   private static final RenderLayer TRACER_LINES = RenderLayer.of(
      "water/tracers",
      RenderSetup.builder(
            RenderPipelines.register(
               RenderPipeline.builder(new Snippet[]{RenderPipelines.RENDERTYPE_LINES_SNIPPET})
                  .withLocation(Identifier.of("water", "pipeline/tracers"))
                  .withVertexShader(Identifier.of("water", "storage_tracer"))
                  .withFragmentShader(Identifier.of("water", "storage_tracer"))
                  .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                  .withDepthWrite(false)
                  .build()
            )
         )
         .expectedBufferSize(1048576)
         .build()
   );
   private static final RenderLayer STORAGE_FILL = RenderLayer.of(
      "water/storage_fill",
      RenderSetup.builder(
            RenderPipelines.register(
               RenderPipeline.builder(new Snippet[]{RenderPipelines.POSITION_COLOR_SNIPPET})
                  .withLocation(Identifier.of("water", "pipeline/storage_fill"))
                  .withVertexFormat(VertexFormats.POSITION_COLOR, DrawMode.QUADS)
                  .withBlend(BlendFunction.TRANSLUCENT)
                  .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                  .withDepthWrite(false)
                  .withCull(false)
                  .build()
            )
         )
         .expectedBufferSize(1048576)
         .build()
   );
   private static final RenderLayer STORAGE_OUTLINE = RenderLayer.of(
      "water/storage_outline",
      RenderSetup.builder(
            RenderPipelines.register(
               RenderPipeline.builder(new Snippet[]{RenderPipelines.RENDERTYPE_LINES_SNIPPET})
                  .withLocation(Identifier.of("water", "pipeline/storage_outline"))
                  .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                  .withDepthWrite(false)
                  .build()
            )
         )
         .expectedBufferSize(1048576)
         .build()
   );
   private static Method cameraPosMethod;

   public static void restoreWorldDepthState() {
      GL11.glEnable(2929);
      GL11.glDepthFunc(515);
      GL11.glDepthMask(true);
   }

   public static RenderUtils.PersistentBatch createPersistentBatch() {
      return new PersistentBatch(RenderLayers.lines());
   }

   public static RenderUtils.PersistentBatch createStorageBoxBatch() {
      return new PersistentBatch(STORAGE_OUTLINE, STORAGE_FILL);
   }

   public static RenderUtils.PersistentBatch createTracerBatch() {
      return new PersistentBatch(TRACER_LINES);
   }

   public static RenderUtils.WorldBatch beginWorldBatch(MatrixStack matrices) {
      return new WorldBatch(matrices);
   }

   public static void updateFrustum(Matrix4f positionMatrix, Matrix4f projectionMatrix, Vec3d cameraPos) {
      if (positionMatrix != null && projectionMatrix != null && cameraPos != null) {
         projectionMatrix.mul(positionMatrix, POSITION_PROJECTION_MATRIX);
         FRUSTUM.set(POSITION_PROJECTION_MATRIX);
         frustumX = cameraPos.x;
         frustumY = cameraPos.y;
         frustumZ = cameraPos.z;
         frustumReady = true;
      } else {
         frustumReady = false;
      }
   }

   public static boolean isWorldBoxVisible(double minX, double minY, double minZ, double maxX, double maxY, double maxZ) {
      if (!frustumReady) {
         return true;
      } else {
         int r = FRUSTUM.intersectAab(
            (float)(minX - frustumX),
            (float)(minY - frustumY),
            (float)(minZ - frustumZ),
            (float)(maxX - frustumX),
            (float)(maxY - frustumY),
            (float)(maxZ - frustumZ)
         );
         return r == -1 || r == -2;
      }
   }

   public static Camera getCamera() {
      return MinecraftClient.getInstance().gameRenderer.getCamera();
   }

   public static Vec3d getCameraPos(Camera camera) {
      if (cameraPosMethod == null) {
         for (Method m : Camera.class.getMethods()) {
            if (m.getReturnType() == Vec3d.class && m.getParameterCount() == 0) {
               cameraPosMethod = m;
               break;
            }
         }
      }

      try {
         return (Vec3d)cameraPosMethod.invoke(camera);
      } catch (Exception var5) {
         return MinecraftClient.getInstance().player.getCameraPosVec(1.0F);
      }
   }

   public static void renderFilledBox(MatrixStack m, double x1, double y1, double z1, double x2, double y2, double z2, Color color) {
      RenderUtils.WorldBatch b = beginWorldBatch(m);
      b.renderFilledBox(x1, y1, z1, x2, y2, z2, color);
      b.flush();
   }

   public static void renderOutlineBox(MatrixStack m, double x1, double y1, double z1, double x2, double y2, double z2, Color color) {
      RenderUtils.WorldBatch b = beginWorldBatch(m);
      b.renderOutlineBox(x1, y1, z1, x2, y2, z2, color);
      b.flush();
   }

   public static void renderLine(MatrixStack m, Color color, Vec3d start, Vec3d end) {
      renderLine(m, color, start, end, 1.0F);
   }

   public static void renderLine(MatrixStack m, Color color, Vec3d start, Vec3d end, float lw) {
      RenderUtils.WorldBatch b = beginWorldBatch(m);
      b.renderLine(color, start, end, lw);
      b.flush();
   }

   public static Vec3d getCameraForward(Camera camera) {
      return new Vec3d(0.0, 0.0, 1.0).rotateX(-((float)Math.toRadians(camera.getPitch()))).rotateY(-((float)Math.toRadians(camera.getYaw()))).normalize();
   }

   public static Vec3d getCameraRight(Camera camera) {
      return new Vec3d(1.0, 0.0, 0.0).rotateY(-((float)Math.toRadians(camera.getYaw()))).normalize();
   }

   public static Vec3d getCameraUp(Vec3d forward, Vec3d right) {
      return forward.crossProduct(right).normalize();
   }

   public static Vec3d getSpreadTracerEnd(double tx, double ty, double tz, Vec3d fwd, Vec3d right, Vec3d up, double endDist, double behindSpread) {
      double r = tx * right.x + ty * right.y + tz * right.z;
      double u = tx * up.x + ty * up.y + tz * up.z;
      double f = tx * fwd.x + ty * fwd.y + tz * fwd.z;
      double sf = Math.max(Math.abs(f), 0.25);
      double pr = r / sf;
      double pu = u / sf;
      if (f <= 0.0) {
         double pl = Math.hypot(pr, pu);
         if (pl < behindSpread) {
            if (pl < 1.0E-4) {
               pr = behindSpread;
               pu = 0.0;
            } else {
               double s = behindSpread / pl;
               pr *= s;
               pu *= s;
            }
         }
      }

      return fwd.add(right.multiply(pr)).add(up.multiply(pu)).normalize().multiply(endDist);
   }

   public static Vec3d getSpreadTracerEnd(Vec3d t, Vec3d fwd, Vec3d right, Vec3d up, double endDist, double behindSpread) {
      return getSpreadTracerEnd(t.x, t.y, t.z, fwd, right, up, endDist, behindSpread);
   }

   public static Vec3d getClampedTracerEnd(Vec3d camRelTarget, Vec3d worldTarget, Vec3d fwd, Vec3d right, Vec3d up, double projDist) {
      MinecraftClient mc = MinecraftClient.getInstance();
      int sw = mc.getWindow().getScaledWidth();
      int sh = mc.getWindow().getScaledHeight();
      Pair<Vec3d, Boolean> proj = ProjectionUtil.project(ProjectionUtil.modelViewMatrix, ProjectionUtil.projectionMatrix, worldTarget);
      if (proj != null && (Boolean)proj.getRight()) {
         Vec3d sp = (Vec3d)proj.getLeft();
         if (sp.x >= 0.0 && sp.x <= sw && sp.y >= 0.0 && sp.y <= sh) {
            return camRelTarget;
         }
      }

      Vector3f ep = ProjectionUtil.projectWithClamp(ProjectionUtil.modelViewMatrix, ProjectionUtil.projectionMatrix, worldTarget);
      return ep == null ? camRelTarget : getRayToScreenPoint(ep.x, ep.y, sw, sh, fwd, right, up).multiply(projDist);
   }

   private static Vec3d getRayToScreenPoint(float sx, float sy, int sw, int sh, Vec3d fwd, Vec3d right, Vec3d up) {
      double ndcX = sx / sw * 2.0F - 1.0F;
      double ndcY = 1.0F - sy / sh * 2.0F;
      double aspect = ProjectionUtil.projectionMatrix.m11() / ProjectionUtil.projectionMatrix.m00();
      double thf = 1.0 / ProjectionUtil.projectionMatrix.m11();
      return fwd.add(right.multiply(ndcX * aspect * thf)).add(up.multiply(ndcY * thf)).normalize();
   }

   static String _ce49636d62c() {
      return "D";
   }

   public final static class PersistentBatch implements AutoCloseable {
      private RenderLayer lineLayer;
      private RenderLayer fillLayer;
      private final BufferAllocator fillAlloc = new BufferAllocator(16777216);
      private final BufferAllocator lineAlloc = new BufferAllocator(8388608);
      private Immediate fillImm;
      private Immediate lineImm;
      private MatrixStack matrices;
      private boolean hasFill;
      private boolean hasLines;
      private boolean closed;
      private final List<ChunkGlassRenderer.Pane> glassPanes = new ArrayList<>();

      private PersistentBatch(RenderLayer lineLayer) {
         this(lineLayer, RenderLayers.debugFilledBox());
      }

      private PersistentBatch(RenderLayer lineLayer, RenderLayer fillLayer) {
         this.lineLayer = lineLayer;
         this.fillLayer = fillLayer;
         this.rebuildImm();
      }

      private void rebuildImm() {
         this.fillImm = VertexConsumerProvider.immediate(this.fillAlloc);
         this.lineImm = VertexConsumerProvider.immediate(this.lineAlloc);
      }

      public void begin(MatrixStack m) {
         this.matrices = m;
         this.hasFill = false;
         this.hasLines = false;
      }

      public void addFilledBox(double x1, double y1, double z1, double x2, double y2, double z2, Color color) {
         if (!this.closed) {
            int argb = toArgb(color);
            Entry e = this.matrices.peek();
            float ax = (float)x1;
            float ay = (float)y1;
            float az = (float)z1;
            float bx = (float)x2;
            float by = (float)y2;
            float bz = (float)z2;
            VertexConsumer vc = this.fillImm.getBuffer(this.fillLayer);
            vc.vertex(e, ax, ay, bz).color(argb);
            vc.vertex(e, bx, ay, bz).color(argb);
            vc.vertex(e, bx, ay, az).color(argb);
            vc.vertex(e, ax, ay, az).color(argb);
            vc.vertex(e, ax, by, az).color(argb);
            vc.vertex(e, bx, by, az).color(argb);
            vc.vertex(e, bx, by, bz).color(argb);
            vc.vertex(e, ax, by, bz).color(argb);
            vc.vertex(e, bx, ay, az).color(argb);
            vc.vertex(e, bx, by, az).color(argb);
            vc.vertex(e, ax, by, az).color(argb);
            vc.vertex(e, ax, ay, az).color(argb);
            vc.vertex(e, ax, ay, bz).color(argb);
            vc.vertex(e, ax, by, bz).color(argb);
            vc.vertex(e, bx, by, bz).color(argb);
            vc.vertex(e, bx, ay, bz).color(argb);
            vc.vertex(e, ax, ay, az).color(argb);
            vc.vertex(e, ax, by, az).color(argb);
            vc.vertex(e, ax, by, bz).color(argb);
            vc.vertex(e, ax, ay, bz).color(argb);
            vc.vertex(e, bx, ay, bz).color(argb);
            vc.vertex(e, bx, by, bz).color(argb);
            vc.vertex(e, bx, by, az).color(argb);
            vc.vertex(e, bx, ay, az).color(argb);
            this.hasFill = true;
         }
      }

      public void addOutlineBox(double x1, double y1, double z1, double x2, double y2, double z2, Color color) {
         if (!this.closed) {
            VertexConsumer lc = this.lineImm.getBuffer(this.lineLayer);
            VertexRendering.drawOutline(this.matrices, lc, VoxelShapes.cuboid(x1, y1, z1, x2, y2, z2), 0.0, 0.0, 0.0, toArgb(color), 1.0F);
            this.hasLines = true;
         }
      }

      public void addLine(Vec3d start, Vec3d end, Color color, float width) {
         if (!this.closed) {
            VertexConsumer lc = this.lineImm.getBuffer(this.lineLayer);
            int argb = toArgb(color);
            Entry e = this.matrices.peek();
            Vector3f n = new Vector3f((float)(end.x - start.x), (float)(end.y - start.y), (float)(end.z - start.z)).normalize();
            float w = Math.max(width, 0.1F);
            lc.vertex(e, (float)start.x, (float)start.y, (float)start.z).color(argb).normal(e, n).lineWidth(w);
            lc.vertex(e, (float)end.x, (float)end.y, (float)end.z).color(argb).normal(e, n).lineWidth(w);
            this.hasLines = true;
         }
      }

      public void flush() {
         this.flushInternal(519);
      }

      public void flushWithDepth() {
         this.flushInternal(515);
      }

      private void flushInternal(int depthFunc) {
         this.flushInternalMask(depthFunc, false);
      }

      private void flushInternalMask(int depthFunc, boolean writeDepth) {
         if (!this.closed && (this.hasFill || this.hasLines)) {
            int prevDepthFunc = GL11.glGetInteger(2932);
            boolean prevDepthMask = GL11.glGetBoolean(2930);

            try {
               GL11.glDepthFunc(depthFunc);
               GL11.glDepthMask(writeDepth);
               if (this.hasFill) {
                  this.fillImm.draw();
               }

               if (this.hasLines) {
                  this.lineImm.draw();
               }
            } finally {
               GL11.glDepthFunc(prevDepthFunc);
               GL11.glDepthMask(prevDepthMask);
               this.rebuildImm();
               this.hasFill = this.hasLines = false;
            }
         }
      }

      public void flushFill() {
         this.flushInternal(519);
      }

      @Override
      public void close() {
         if (!this.closed) {
            this.closed = true;

            try {
               this.fillImm.draw();
            } catch (Exception var3) {
            }

            try {
               this.lineImm.draw();
            } catch (Exception var2) {
            }

            this.fillAlloc.close();
            this.lineAlloc.close();
         }
      }

      private static int toArgb(Color c) {
         return c.getAlpha() << 24 | c.getRed() << 16 | c.getGreen() << 8 | c.getBlue();
      }
   }

   public final static class WorldBatch {
      private MatrixStack matrices;
      private BufferAllocator fillAllocator;
      private Immediate fillImmediate;
      private BufferAllocator lineAllocator;
      private Immediate lineImmediate;
      private boolean hasFill;
      private boolean hasLines;
      private boolean closed;
      private final List<ChunkGlassRenderer.Pane> glassPanes = new ArrayList<>();

      private WorldBatch(MatrixStack matrices) {
         this.matrices = matrices;
         this.fillAllocator = new BufferAllocator(1048576);
         this.fillImmediate = VertexConsumerProvider.immediate(this.fillAllocator);
         this.lineAllocator = new BufferAllocator(524288);
         this.lineImmediate = VertexConsumerProvider.immediate(this.lineAllocator);
      }

      public void renderFilledBox(double x1, double y1, double z1, double x2, double y2, double z2, Color color) {
         int argb = toArgb(color);
         Entry e = this.matrices.peek();
         float ax = (float)x1;
         float ay = (float)y1;
         float az = (float)z1;
         float bx = (float)x2;
         float by = (float)y2;
         float bz = (float)z2;
         VertexConsumer vc = this.fillImmediate.getBuffer(RenderLayers.debugFilledBox());
         vc.vertex(e, ax, ay, az).color(argb);
         vc.vertex(e, bx, ay, az).color(argb);
         vc.vertex(e, bx, ay, bz).color(argb);
         vc.vertex(e, ax, ay, bz).color(argb);
         vc.vertex(e, ax, by, az).color(argb);
         vc.vertex(e, ax, by, bz).color(argb);
         vc.vertex(e, bx, by, bz).color(argb);
         vc.vertex(e, bx, by, az).color(argb);
         vc.vertex(e, ax, ay, az).color(argb);
         vc.vertex(e, ax, by, az).color(argb);
         vc.vertex(e, bx, by, az).color(argb);
         vc.vertex(e, bx, ay, az).color(argb);
         vc.vertex(e, bx, ay, bz).color(argb);
         vc.vertex(e, bx, by, bz).color(argb);
         vc.vertex(e, ax, by, bz).color(argb);
         vc.vertex(e, ax, ay, bz).color(argb);
         vc.vertex(e, ax, ay, bz).color(argb);
         vc.vertex(e, ax, by, bz).color(argb);
         vc.vertex(e, ax, by, az).color(argb);
         vc.vertex(e, ax, ay, az).color(argb);
         vc.vertex(e, bx, ay, az).color(argb);
         vc.vertex(e, bx, by, az).color(argb);
         vc.vertex(e, bx, by, bz).color(argb);
         vc.vertex(e, bx, ay, bz).color(argb);
         this.hasFill = true;
      }

      public void renderGlassPane(double x1, double y, double z1, double x2, double z2, Color tint, float intensity, double time) {
         if (tint.getAlpha() > 0 && !(intensity <= 0.0F) && !(x2 <= x1) && !(z2 <= z1)) {
            this.glassPanes.add(new ChunkGlassRenderer.Pane(x1, y, z1, x2, z2, tint, intensity));
         }
      }

      public void renderFilledBoxTriangles(double x1, double y1, double z1, double x2, double y2, double z2, Color color) {
         this.renderFilledBox(x1, y1, z1, x2, y2, z2, color);
      }

      public void renderOutlineBox(double x1, double y1, double z1, double x2, double y2, double z2, Color color) {
         VertexConsumer lc = this.lineImmediate.getBuffer(RenderLayers.lines());
         VertexRendering.drawOutline(this.matrices, lc, VoxelShapes.cuboid(x1, y1, z1, x2, y2, z2), 0.0, 0.0, 0.0, toArgb(color), 1.0F);
         this.hasLines = true;
      }

      public void renderLine(Color color, Vec3d start, Vec3d end, float lineWidth) {
         VertexConsumer lc = this.lineImmediate.getBuffer(RenderLayers.lines());
         int argb = toArgb(color);
         Entry e = this.matrices.peek();
         Vector3f n = new Vector3f((float)(end.x - start.x), (float)(end.y - start.y), (float)(end.z - start.z)).normalize();
         float w = Math.min(Math.max(lineWidth, 0.5F), 1.5F);
         lc.vertex(e, (float)start.x, (float)start.y, (float)start.z).color(argb).normal(e, n).lineWidth(w);
         lc.vertex(e, (float)end.x, (float)end.y, (float)end.z).color(argb).normal(e, n).lineWidth(w);
         this.hasLines = true;
      }

      public void flush() {
         this.flushInternal(519);
      }

      public void flushWithDepth() {
         this.flushInternal(515);
      }

      private void flushInternal(int depthFunc) {
         if (!this.closed) {
            boolean depthEnabled = GL11.glIsEnabled(2929);
            int prevDepthFunc = GL11.glGetInteger(2932);
            boolean depthMask = GL11.glGetBoolean(2930);

            try {
               GL11.glEnable(2929);
               GL11.glDepthFunc(depthFunc);
               GL11.glDepthMask(false);
               if (!this.glassPanes.isEmpty()) {
                  Matrix4f clip = new Matrix4f(ProjectionUtil.projectionMatrix).mul(this.matrices.peek().getPositionMatrix());
                  ChunkGlassRenderer.draw(clip, this.glassPanes);
               }

               if (this.hasFill) {
                  this.fillImmediate.draw();
               }

               if (this.hasLines) {
                  this.lineImmediate.draw();
               }
            } finally {
               if (depthEnabled) {
                  GL11.glEnable(2929);
               } else {
                  GL11.glDisable(2929);
               }

               GL11.glDepthFunc(prevDepthFunc);
               GL11.glDepthMask(depthMask);
               this.fillAllocator.close();
               this.lineAllocator.close();
               this.closed = true;
            }
         }
      }

      private static int toArgb(Color c) {
         return c.getAlpha() << 24 | c.getRed() << 16 | c.getGreen() << 8 | c.getBlue();
      }
   }
}

