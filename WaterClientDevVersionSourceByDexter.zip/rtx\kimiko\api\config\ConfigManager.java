package rtx.kimiko.api.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;
import net.fabricmc.loader.api.FabricLoader;
import rtx.kimiko.Kimiko;
import rtx.kimiko.api.drags.DragSystem;
import rtx.kimiko.api.drags.Draggable;
import rtx.kimiko.api.events.EventBus;
import rtx.kimiko.api.events.EventHandler;
import rtx.kimiko.api.events.impl.game.TickEvent;
import rtx.kimiko.api.events.impl.module.ModuleToggleEvent;
import rtx.kimiko.api.modules.Module;
import rtx.kimiko.api.modules.ModuleManager;
import rtx.kimiko.api.modules.impl.Interface.ClickGui;
import rtx.kimiko.api.modules.impl.Water.WaterModuleAdapter;
import rtx.kimiko.api.modules.settings.Setting;
import rtx.kimiko.api.modules.settings.impl.BindSetting;
import rtx.kimiko.api.modules.settings.impl.BooleanSetting;
import rtx.kimiko.api.modules.settings.impl.ColorSetting;
import rtx.kimiko.api.modules.settings.impl.HOLD;
import rtx.kimiko.api.modules.settings.impl.MultiSelectSetting;
import rtx.kimiko.api.modules.settings.impl.PositionSettings;
import rtx.kimiko.api.modules.settings.impl.SelectSetting;
import rtx.kimiko.api.modules.settings.impl.SliderSetting;
import rtx.kimiko.api.modules.settings.impl.TextSetting;
import rtx.kimiko.api.ui.theme.Theme;
import rtx.kimiko.api.ui.theme.ThemeManager;
import rtx.kimiko.utils.key.KeyBind;
import rtx.kimiko.utils.storage.RepositoryStorage;

public final class ConfigManager {
   private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
   private static final ConfigManager INSTANCE = new ConfigManager();
   private static final String MODULE_CONFIG = "autocfg";
   private static final String CONFIG_EXTENSION = ".kimiko";
   private static final String PREVIOUS_CONFIG_EXTENSION = ".tria";
   private static final long AUTOSAVE_INTERVAL_MS = 5000L;
   private boolean initialized;
   private boolean loading;
   private boolean dirty;
   private long lastAutosaveMs;
   private String lastSavedModuleConfig;
   private JsonObject activeRoot = new JsonObject();

   private ConfigManager() {
   }

   public static void init() {
      if (!INSTANCE.initialized) {
         INSTANCE.initialized = true;
         RepositoryStorage.migratePreviousFormat();
         ensureDefaultSystemFiles();
         INSTANCE.loading = true;

         try {
            loadAll();
         } finally {
            INSTANCE.loading = false;
         }

         saveModules(true);
         EventBus.get().subscribe(INSTANCE);
      }
   }

   private static int readInt(JsonObject jsonObject, String string, int n) {
      try {
         return jsonObject.has(string) ? jsonObject.get(string).getAsInt() : n;
      } catch (Exception var4) {
         return n;
      }
   }

   private static void loadModules() {
      applyModuleRoot(readModuleConfig());
   }

   private static boolean readBoolean(JsonObject jsonObject, String string, boolean bl) {
      try {
         return jsonObject.has(string) ? jsonObject.get(string).getAsBoolean() : bl;
      } catch (Exception var4) {
         return bl;
      }
   }

   public static void loadAll() {
      loadModules();
   }

   public static boolean isLoading() {
      return INSTANCE.loading;
   }

   public static void markDirty() {
      if (INSTANCE.initialized && !INSTANCE.loading) {
         INSTANCE.dirty = true;
      }
   }

   @EventHandler
   private void onTick(TickEvent tickEvent) {
      if (tickEvent.isPost()) {
         if (this.dirty) {
            long l = System.currentTimeMillis();
            if (l - this.lastAutosaveMs >= 5000L) {
               this.lastAutosaveMs = l;
               saveModules(false);
            }
         }
      }
   }

   private static void applyDrags(JsonObject jsonObject) {
      if (jsonObject.has("drags") && jsonObject.get("drags").isJsonObject()) {
         DragSystem.get().applyDrags(jsonObject.getAsJsonObject("drags"));
      }
   }

   public static Path systemConfigDirectory() {
      return RepositoryStorage.root();
   }

   private static void ensureDefaultSystemFiles() {
      RepositoryStorage.ensureObject("friends", objectWithArray("list"));
      RepositoryStorage.ensureObject("waypoints", objectWithArray("ways"));
      RepositoryStorage.ensureObject("macros", objectWithArray("macros"));
      RepositoryStorage.ensureObject("staff", objectWithArray("list"));
      JsonObject jsonObject = new JsonObject();
      jsonObject.addProperty("prefix", ".");
      RepositoryStorage.ensureObject("prefix", jsonObject);
   }

   @EventHandler
   private void onModuleToggle(ModuleToggleEvent moduleToggleEvent) {
      this.dirty = true;
      saveModules(false);
   }

   private static JsonObject objectWithArray(String string) {
      JsonObject jsonObject = new JsonObject();
      jsonObject.add(string, new JsonArray());
      return jsonObject;
   }

   private static JsonObject readModuleConfig() {
      Path configPath = moduleConfigPath();
      if (!Files.exists(configPath)) {
         Path triaPath = RepositoryStorage.root().resolve("autocfg.tria");
         if (Files.exists(triaPath)) {
            configPath = triaPath;
         } else {
            Path jsonPath = FabricLoader.getInstance().getGameDir().resolve("kimiko").resolve("autocfg.json");
            if (Files.exists(jsonPath)) {
               configPath = jsonPath;
            }
         }
      }

      if (!Files.exists(configPath)) {
         return new JsonObject();
      } else {
         try {
            JsonObject jsonObject;
            try (BufferedReader reader = Files.newBufferedReader(configPath)) {
               JsonElement jsonElement = JsonParser.parseReader(reader);
               jsonObject = jsonElement != null && jsonElement.isJsonObject() ? jsonElement.getAsJsonObject() : new JsonObject();
            }

            return jsonObject;
         } catch (Exception var9) {
            Kimiko.LOGGER.error("[ConfigManager] Failed to read module config", var9);
            return new JsonObject();
         }
      }
   }

   private static void applyModuleRoot(JsonObject jsonObject) {
      INSTANCE.activeRoot = jsonObject;
      if (jsonObject.has("theme") && jsonObject.get("theme").isJsonPrimitive()) {
         try {
            ThemeManager.set(Theme.valueOf(jsonObject.get("theme").getAsString()));
         } catch (Exception var7) {
         }
      }

      JsonObject jsonObject3 = jsonObject.has("modules") && jsonObject.get("modules").isJsonObject() ? jsonObject.getAsJsonObject("modules") : new JsonObject();

      for (Module module : ModuleManager.get().getAll()) {
         JsonObject jsonObject2 = findModuleObject(jsonObject3, module.getName());
         if (jsonObject2 != null) {
            if (jsonObject2.has("bind")) {
               module.setBind(new KeyBind(readInt(jsonObject2, "bind", KeyBind.NONE.getCode())));
            }

            if (jsonObject2.has("bindMode")) {
               try {
                  module.setBindMode(Module.BindMode.valueOf(jsonObject2.get("bindMode").getAsString()));
               } catch (Exception var6) {
               }
            }

            if (jsonObject2.has("settings") && jsonObject2.get("settings").isJsonObject() && !(module instanceof WaterModuleAdapter)) {
               applySettings(module, jsonObject2.getAsJsonObject("settings"));
            }
         }
      }

      Iterator<Module> iterator = ModuleManager.get().getAll().iterator();

      while (iterator.hasNext()) {
         Module modulex;
         JsonObject jsonObject2 = findModuleObject(jsonObject3, (modulex = iterator.next()).getName());
         if (!(modulex instanceof WaterModuleAdapter)) {
            modulex.setEnabled(jsonObject2 != null ? readBoolean(jsonObject2, "enabled", modulex.defaultEnabled()) : modulex.defaultEnabled());
         }
      }

      applyDrags(jsonObject);
   }

   private static JsonObject buildModuleRoot() {
      JsonObject jsonObject = new JsonObject();
      jsonObject.addProperty("version", 1);
      jsonObject.addProperty("theme", ThemeManager.current().name());
      JsonObject jsonObject2 = new JsonObject();

      for (Module module : ModuleManager.get().getAll()) {
         JsonObject jsonObject3 = new JsonObject();
         jsonObject3.addProperty("enabled", module.isEnabled());
         jsonObject3.addProperty("bind", module.getBind().getCode());
         jsonObject3.addProperty("bindMode", module.getBindMode().name());
         jsonObject3.add("settings", writeSettings(module));
         jsonObject2.add(module.getName(), jsonObject3);
      }

      jsonObject.add("modules", jsonObject2);
      jsonObject.add("drags", currentDrags());
      return jsonObject;
   }

   private static Path moduleConfigPath() {
      return RepositoryStorage.root().resolve("autocfg.kimiko");
   }

   private static JsonObject writeSettings(Module module) {
      JsonObject jsonObject = new JsonObject();
      if (module instanceof WaterModuleAdapter) {
         return jsonObject;
      } else {
         HashMap<String, Integer> hashMap = new HashMap<>();

         for (Setting setting : module.getSettings().all()) {
            String string = occurrenceKey(hashMap, setting.getConfigName());
            JsonElement jsonElement = serializeSetting(setting);
            if (jsonElement != null) {
               jsonObject.add(string, jsonElement);
            }
         }

         return jsonObject;
      }
   }

   private static JsonObject currentDrags() {
      JsonObject jsonObject = DragSystem.get().writeDrags();
      if (!jsonObject.entrySet().isEmpty()) {
         return jsonObject;
      } else {
         return INSTANCE.activeRoot.has("drags") && INSTANCE.activeRoot.get("drags").isJsonObject()
            ? INSTANCE.activeRoot.getAsJsonObject("drags").deepCopy()
            : jsonObject;
      }
   }

   private static JsonObject findModuleObject(JsonObject jsonObject, String string) {
      if (jsonObject.has(string) && jsonObject.get(string).isJsonObject()) {
         return jsonObject.getAsJsonObject(string);
      } else {
         for (String string2 : jsonObject.keySet()) {
            if (string2.equalsIgnoreCase(string) && jsonObject.get(string2).isJsonObject()) {
               return jsonObject.getAsJsonObject(string2);
            }
         }

         return null;
      }
   }

   private static void applySettings(Module module, JsonObject jsonObject) {
      HashMap<String, Integer> hashMap = new HashMap<>();

      for (Setting setting : module.getSettings().all()) {
         String string = occurrenceKey(hashMap, setting.getConfigName());
         JsonElement jsonElement = jsonObject.has(string) ? jsonObject.get(string) : findSettingValue(jsonObject, setting.getConfigName());
         if (jsonElement != null && !jsonElement.isJsonNull()) {
            applySetting(setting, jsonElement);
         }
      }
   }

   public static void applyActiveDrags() {
      INSTANCE.loading = true;

      try {
         applyDrags(INSTANCE.activeRoot);
      } finally {
         INSTANCE.loading = false;
      }
   }

   private static void saveModules(boolean bl) {
      if (bl || INSTANCE.dirty) {
         try {
            Files.createDirectories(RepositoryStorage.root());
            JsonObject jsonObject = buildModuleRoot();
            String string = GSON.toJson(jsonObject);
            if (!bl && string.equals(INSTANCE.lastSavedModuleConfig)) {
               INSTANCE.dirty = false;
               return;
            }

            try (BufferedWriter bufferedWriter = Files.newBufferedWriter(moduleConfigPath())) {
               bufferedWriter.write(string);
            }

            INSTANCE.lastSavedModuleConfig = string;
            INSTANCE.dirty = false;
         } catch (Exception var8) {
            Kimiko.LOGGER.error("[ConfigManager] Failed to save module config", var8);
         }
      }
   }

   public static List<String> listProfiles() {
      Path path2 = profilesDirectory();
      if (!Files.exists(path2)) {
         return new ArrayList<>();
      } else {
         ArrayList<String> arrayList = new ArrayList<>();

         try (Stream<Path> stream = Files.list(path2)) {
            stream.forEach(path -> {
               String string = path.getFileName().toString();
               if (string.endsWith(".kimiko")) {
                  arrayList.add(string.substring(0, string.length() - 7));
               } else if (string.endsWith(".tria") && !Files.exists(path.resolveSibling(string.substring(0, string.length() - 5) + ".kimiko"))) {
                  arrayList.add(string.substring(0, string.length() - 5));
               }
            });
         } catch (Exception var7) {
            Kimiko.LOGGER.error("[ConfigManager] Failed to list profiles", var7);
         }

         arrayList.sort(String.CASE_INSENSITIVE_ORDER);
         return arrayList;
      }
   }

   public static Path profilesDirectory() {
      return RepositoryStorage.root().resolve("profiles");
   }

   public static void saveProfile(String string) {
      String string2 = sanitizeProfileName(string);
      if (!string2.isEmpty()) {
         try {
            Path path = profilesDirectory();
            Files.createDirectories(path);

            try (BufferedWriter bufferedWriter = Files.newBufferedWriter(path.resolve("null.kimiko"))) {
               bufferedWriter.write(GSON.toJson(buildModuleRoot()));
            }
         } catch (Exception var8) {
            Kimiko.LOGGER.error("[ConfigManager] Failed to save profile {}", string, var8);
         }
      }
   }

   private static String sanitizeProfileName(String string) {
      return string == null ? "" : string.trim().replaceAll("[\\\\/:*?\"<>|]", "_");
   }

   private static Path profilePath(String string) {
      return profilesDirectory().resolve(sanitizeProfileName(string) + ".kimiko");
   }

   public static void loadProfile(String string) {
      Path path = profilePath(string);
      if (!Files.exists(path)) {
         path = previousProfilePath(string);
      }

      if (Files.exists(path)) {
         INSTANCE.loading = true;

         try (BufferedReader bufferedReader = Files.newBufferedReader(path)) {
            JsonElement jsonElement = JsonParser.parseReader(bufferedReader);
            if (jsonElement != null && jsonElement.isJsonObject()) {
               applyModuleRoot(jsonElement.getAsJsonObject());
            }
         } catch (Exception var12) {
            Kimiko.LOGGER.error("[ConfigManager] Failed to load profile {}", string, var12);
         } finally {
            INSTANCE.loading = false;
         }

         saveModules(true);
      }
   }

   public static Path userConfigDirectory() {
      return RepositoryStorage.configRoot();
   }

   private static Path previousProfilePath(String string) {
      return profilesDirectory().resolve(sanitizeProfileName(string) + ".tria");
   }

   private static void resetSetting(Setting setting) {
      try {
         if (setting instanceof BooleanSetting booleanSetting) {
            booleanSetting.setValue(booleanSetting.getDefaultValue());
         } else if (setting instanceof SliderSetting sliderSetting) {
            sliderSetting.setValue(sliderSetting.getDefaultValue());
         } else if (setting instanceof SelectSetting selectSetting) {
            selectSetting.setSelected(selectSetting.getDefaultSelected());
         } else if (setting instanceof MultiSelectSetting multiSelectSetting) {
            multiSelectSetting.selected(multiSelectSetting.getDefaultSelected().toArray(String[]::new));
         } else if (setting instanceof ColorSetting colorSetting) {
            colorSetting.setColor(colorSetting.getDefaultColor());
         } else if (setting instanceof TextSetting textSetting) {
            textSetting.setText(textSetting.getDefaultText());
         } else if (setting instanceof BindSetting bindSetting) {
            bindSetting.setKey(bindSetting.getDefaultKey());
         } else if (setting instanceof PositionSettings positionSettings) {
            if (positionSettings.isDefaultXCaptured()) {
               positionSettings.setX(positionSettings.getDefaultX());
            }

            if (positionSettings.isDefaultYCaptured()) {
               positionSettings.setY(positionSettings.getDefaultY());
            }

            if (positionSettings.isDefaultZCaptured()) {
               positionSettings.setZ(positionSettings.getDefaultZ());
            }
         }
      } catch (Exception var2) {
         Kimiko.LOGGER.warn("[ConfigManager] Failed to reset setting {}", setting.getName(), var2);
      }
   }

   private static String occurrenceKey(Map<String, Integer> map, String string) {
      int n = map.merge(string, 1, Integer::sum);
      return n == 1 ? string : string + "#" + n;
   }

   public static void deleteProfile(String string) {
      try {
         Files.deleteIfExists(profilePath(string));
         Files.deleteIfExists(previousProfilePath(string));
      } catch (Exception var2) {
         Kimiko.LOGGER.error("[ConfigManager] Failed to delete profile {}", string, var2);
      }
   }

   private static void applySetting(Setting setting, JsonElement jsonElement) {
      try {
         if (setting instanceof BooleanSetting) {
            Setting setting2 = (BooleanSetting)setting;
            if (jsonElement.isJsonPrimitive()) {
               ((BooleanSetting)setting2).setValue(jsonElement.getAsBoolean());
               return;
            }
         }

         if (setting instanceof SliderSetting) {
            Setting setting2 = (SliderSetting)setting;
            if (jsonElement.isJsonPrimitive()) {
               ((SliderSetting)setting2).setValue(jsonElement.getAsFloat());
               return;
            }
         }

         if (setting instanceof PositionSettings posSetting && jsonElement.isJsonObject()) {
            JsonObject jsonObject = jsonElement.getAsJsonObject();
            if (jsonObject.has("x")) {
               posSetting.setX(jsonObject.get("x").getAsFloat());
            }

            if (jsonObject.has("y")) {
               posSetting.setY(jsonObject.get("y").getAsFloat());
            }

            if (jsonObject.has("z")) {
               posSetting.setZ(jsonObject.get("z").getAsFloat());
            }

            return;
         }

         if (setting instanceof SelectSetting) {
            Setting setting2 = (SelectSetting)setting;
            if (jsonElement.isJsonPrimitive()) {
               ((SelectSetting)setting2).setSelected(jsonElement.getAsString());
               return;
            }
         }

         if (setting instanceof MultiSelectSetting) {
            Setting setting2 = (MultiSelectSetting)setting;
            if (jsonElement.isJsonArray()) {
               ArrayList<String> arrayList = new ArrayList<>();

               for (JsonElement jsonElement2 : jsonElement.getAsJsonArray()) {
                  if (jsonElement2.isJsonPrimitive()) {
                     String string = jsonElement2.getAsString();
                     if (((MultiSelectSetting)setting2).getOptions().contains(string)) {
                        arrayList.add(string);
                     }
                  }
               }

               if (arrayList.size() >= ((MultiSelectSetting)setting2).getMinSelectedCount()) {
                  ((MultiSelectSetting)setting2).selected(arrayList.toArray(String[]::new));
               }

               return;
            }
         }

         if (setting instanceof BindSetting) {
            Setting setting2 = (BindSetting)setting;
            if (jsonElement.isJsonObject()) {
               JsonObject jsonObjectx = jsonElement.getAsJsonObject();
               ((BindSetting)setting2).setKey(readInt(jsonObjectx, "key", ((BindSetting)setting2).getKey()));
               if (jsonObjectx.has("type")) {
                  ((BindSetting)setting2).setType(HOLD.valueOf(jsonObjectx.get("type").getAsString()));
               }

               return;
            }
         }

         if (setting instanceof ColorSetting) {
            Setting setting2 = (ColorSetting)setting;
            if (jsonElement.isJsonPrimitive()) {
               ((ColorSetting)setting2).setColor(jsonElement.getAsInt());
               return;
            }
         }

         if (setting instanceof TextSetting) {
            Setting setting2 = (TextSetting)setting;
            if (jsonElement.isJsonPrimitive()) {
               ((TextSetting)setting2).setText(jsonElement.getAsString());
            }
         }
      } catch (Exception var7) {
         Kimiko.LOGGER.warn("[ConfigManager] Failed to apply setting {}", setting.getName(), var7);
      }
   }

   private static JsonElement serializeSetting(Setting setting) {
      if (setting instanceof BooleanSetting booleanSetting) {
         return GSON.toJsonTree(booleanSetting.getValue());
      } else if (setting instanceof SliderSetting sliderSetting) {
         return GSON.toJsonTree(sliderSetting.getFloat());
      } else if (setting instanceof PositionSettings positionSettings) {
         JsonObject jsonObject = new JsonObject();
         jsonObject.addProperty("x", positionSettings.getX());
         jsonObject.addProperty("y", positionSettings.getY());
         jsonObject.addProperty("z", positionSettings.getZ());
         return jsonObject;
      } else if (setting instanceof SelectSetting selectSetting) {
         return GSON.toJsonTree(selectSetting.getValue());
      } else if (!(setting instanceof MultiSelectSetting multiSelectSetting)) {
         if (setting instanceof BindSetting bindSetting) {
            JsonObject jsonObject = new JsonObject();
            jsonObject.addProperty("key", bindSetting.getKey());
            jsonObject.addProperty("type", bindSetting.getType().name());
            return jsonObject;
         } else if (setting instanceof ColorSetting colorSetting) {
            return GSON.toJsonTree(colorSetting.getColor());
         } else {
            return setting instanceof TextSetting textSetting ? GSON.toJsonTree(textSetting.getText()) : null;
         }
      } else {
         JsonArray jsonArray = new JsonArray();

         for (String string : multiSelectSetting.getSelected()) {
            jsonArray.add(string);
         }

         return jsonArray;
      }
   }

   private static JsonElement findSettingValue(JsonObject jsonObject, String string) {
      if (jsonObject.has(string)) {
         return jsonObject.get(string);
      } else {
         for (String string2 : jsonObject.keySet()) {
            if (string2.equalsIgnoreCase(string)) {
               return jsonObject.get(string2);
            }
         }

         return null;
      }
   }

   public static String nextProfileName() {
      List<String> list = listProfiles();
      int n = 1;

      while (true) {
         String string = "Config " + n;
         if (list.stream().noneMatch(string::equalsIgnoreCase)) {
            return string;
         }

         n++;
      }
   }

   public static void resetToFactory() {
      INSTANCE.loading = true;

      try {
         ThemeManager.set(Theme.KIMIKO);

         for (Module object : ModuleManager.get().getAll()) {
            for (Setting setting : object.getSettings().all()) {
               resetSetting(setting);
            }

            if (object instanceof ClickGui) {
               object.setBind(KeyBind.keyboard(344));
            } else {
               object.setBind(KeyBind.NONE);
            }

            object.setEnabled(object.defaultEnabled());
         }

         for (Draggable draggable : DragSystem.get().getAll()) {
            draggable.resetToDefault();
         }
      } finally {
         INSTANCE.loading = false;
      }

      try {
         Files.deleteIfExists(moduleConfigPath());
      } catch (Exception var7) {
         Kimiko.LOGGER.error("[ConfigManager] Failed to delete active config during reset", var7);
      }

      saveModules(true);
   }

   public static boolean profileExists(String string) {
      return Files.exists(profilePath(string)) || Files.exists(previousProfilePath(string));
   }

   public static int profileEnabledCount(String string) {
      Path path = profilePath(string);
      if (!Files.exists(path)) {
         path = previousProfilePath(string);
      }

      if (!Files.exists(path)) {
         return 0;
      } else {
         try {
            int jsonObject2;
            try (BufferedReader bufferedReader = Files.newBufferedReader(path)) {
               JsonElement jsonElement = JsonParser.parseReader(bufferedReader);
               if (jsonElement != null && jsonElement.isJsonObject()) {
                  JsonObject jsonObject = jsonElement.getAsJsonObject();
                  if (jsonObject.has("modules") && jsonObject.get("modules").isJsonObject()) {
                     JsonObject jsonObject2x = jsonObject.getAsJsonObject("modules");
                     int n = 0;

                     for (String string2 : jsonObject2x.keySet()) {
                        if (jsonObject2x.get(string2).isJsonObject() && readBoolean(jsonObject2x.getAsJsonObject(string2), "enabled", false)) {
                           n++;
                        }
                     }

                     return n;
                  }

                  return 0;
               }

               int n = 0;
               jsonObject2 = n;
            }

            return jsonObject2;
         } catch (Exception var11) {
            return 0;
         }
      }
   }

   public static void saveAll() {
      saveModules(true);
   }
}

