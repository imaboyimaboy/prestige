package rtx.kimiko.api.mods.chathads;

import net.minecraft.client.network.PlayerListEntry;

public final class HeadData {
   public static final HeadData EMPTY = new HeadData(null, -1);
   public PlayerListEntry playerInfo;
   public int codePointIndex;

   public HeadData(PlayerListEntry playerListEntry, int n) {
      if (playerListEntry == null && n >= 0) {
         throw new AssertionError();
      } else {
         this.playerInfo = playerListEntry;
         this.codePointIndex = n;
      }
   }

   public static HeadData headDataOf(PlayerListEntry playerListEntry) {
      return playerListEntry == null ? EMPTY : new HeadData(playerListEntry, -1);
   }

   public boolean hasHeadPosition() {
      return this.codePointIndex >= 0;
   }
}

