package rtx.kimiko.api.mods.geckolib.loading.math.value;

import java.util.Set;
import rtx.kimiko.api.mods.geckolib.animation.state.ControllerState;
import rtx.kimiko.api.mods.geckolib.loading.math.MathValue;

public final class BooleanNegate implements MathValue {
   private MathValue value;

   public BooleanNegate(MathValue value) {
      this.value = value;
   }

   @Override
   public double get(ControllerState state) {
      return this.value.get(state) == 0.0 ? 1.0 : 0.0;
   }

   @Override
   public Set<Variable> getUsedVariables() {
      return this.value.getUsedVariables();
   }

   public MathValue value() {
      return this.value;
   }
}

