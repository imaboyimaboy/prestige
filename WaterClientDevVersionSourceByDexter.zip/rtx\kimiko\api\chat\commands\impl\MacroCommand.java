package rtx.kimiko.api.chat.commands.impl;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;
import net.minecraft.util.Formatting;
import rtx.kimiko.api.chat.commands.Command;
import rtx.kimiko.api.chat.commands.helpers.CommandDividers;
import rtx.kimiko.api.chat.commands.helpers.TabCompleteHelper;
import rtx.kimiko.utils.key.KeyHelper;
import rtx.kimiko.utils.storage.macro.Macro;
import rtx.kimiko.utils.storage.macro.MacroRepository;

public final class MacroCommand extends Command {
   public MacroCommand() {
      super("macro", "Manage macros");
   }

   @Override
   public void execute(String string, String[] stringArray) {
      MacroRepository var4 = MacroRepository.getInstance();
      if (stringArray.length == 0) {
         this.usage();
      } else {
         String var5 = stringArray[0].toLowerCase(Locale.ROOT);
         switch (var5.hashCode()) {
            case -1335458389:
               if (var5.equals("delete")) {
                  if (stringArray.length < 2) {
                     this.logDirect("Usage: macro remove <name>", Formatting.RED);
                     return;
                  }

                  var4.deleteMacroAndSave(stringArray[1]);
                  this.logDirect("Macro " + stringArray[1] + " removed.", Formatting.GREEN);
                  return;
               }
               break;
            case -934610812:
               if (var5.equals("remove")) {
                  if (stringArray.length < 2) {
                     this.logDirect("Usage: macro remove <name>", Formatting.RED);
                     return;
                  }

                  var4.deleteMacroAndSave(stringArray[1]);
                  this.logDirect("Macro " + stringArray[1] + " removed.", Formatting.GREEN);
                  return;
               }
               break;
            case 96417:
               if (var5.equals("add")) {
                  if (stringArray.length < 4) {
                     this.logDirect("Usage: macro add <name> <message> <key>", Formatting.RED);
                     return;
                  }

                  String var13 = stringArray[1];
                  String var14 = stringArray[stringArray.length - 1];
                  int var15 = KeyHelper.getKeyCode(var14);
                  if (var15 < 0) {
                     this.logDirect("Unknown key: null", Formatting.RED);
                     return;
                  }

                  String var16 = String.join(" ", Arrays.copyOfRange(stringArray, 2, stringArray.length - 1));
                  var4.addMacroAndSave(var13, var16, var15);
                  this.logDirect("Macro " + var13 + " added [" + KeyHelper.getKeyName(var15) + "]", Formatting.GREEN);
                  return;
               }
               break;
            case 99339:
               if (var5.equals("del")) {
                  if (stringArray.length < 2) {
                     this.logDirect("Usage: macro remove <name>", Formatting.RED);
                     return;
                  }

                  var4.deleteMacroAndSave(stringArray[1]);
                  this.logDirect("Macro " + stringArray[1] + " removed.", Formatting.GREEN);
                  return;
               }
               break;
            case 3322014:
               if (var5.equals("list")) {
                  if (var4.getMacroList().isEmpty()) {
                     this.logDirect("Macro list is empty.", Formatting.RED);
                     return;
                  }

                  String var12 = "MACROS";
                  List var8 = var4.getMacroList()
                     .stream()
                     .map(macro -> macro.name() + " [" + KeyHelper.getKeyName(macro.key()) + "] " + macro.message())
                     .toList();
                  int var9 = CommandDividers.calcLineCountForContent("MACROS", var8);
                  this.logDirectRaw(CommandDividers.header("MACROS", var9));
                  Iterator var10 = var4.getMacroList().iterator();
                  if (var10.hasNext()) {
                     while (true) {
                        Macro var11 = (Macro)var10.next();
                        this.logDirect("§f" + var11.name() + " §8[" + KeyHelper.getKeyName(var11.key()) + "] §7" + var11.message());
                        if (var10.hasNext()) {
                           continue;
                        }
                     }
                  }

                  this.logDirectRaw(CommandDividers.footer("MACROS", var9));
                  return;
               }
               break;
            case 94746189:
               if (var5.equals("clear")) {
                  int var7 = var4.size();
                  var4.clearListAndSave();
                  this.logDirect("Macros cleared. Removed: " + var7, Formatting.GREEN);
                  return;
               }
         }

         this.usage();
      }
   }

   @Override
   public List<String> getLongDesc() {
      return Arrays.asList("Manages macros.", "Usage:", "> macro add <name> <message> <key>", "> macro remove <name>", "> macro list", "> macro clear");
   }

   @Override
   public Stream<String> tabComplete(String string, String[] stringArray) {
      if (stringArray.length == 1) {
         return new TabCompleteHelper().append("add", "remove", "list", "clear").sortAlphabetically().filterPrefix(stringArray[0]).stream();
      } else if (stringArray.length >= 4 && stringArray[0].equalsIgnoreCase("add")) {
         return new TabCompleteHelper().append(KeyHelper.getAllKeyNames().toArray(new String[0])).filterPrefix(stringArray[stringArray.length - 1]).stream();
      } else {
         return stringArray.length == 2 && stringArray[0].equalsIgnoreCase("remove")
            ? new TabCompleteHelper().append(MacroRepository.getInstance().getMacroNames().toArray(new String[0])).filterPrefix(stringArray[1]).stream()
            : Stream.empty();
      }
   }
}

