package fun.shape.profile;

public enum Role {
   USER,
   BETA,
   MEDIA,
   ADMIN,
   DEVELOPER;

   private static Role[] $values() {
      return new Role[]{USER, BETA, MEDIA, ADMIN, DEVELOPER};
   }
}

