package rtx.kimiko.api.mods.geckolib.network;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.Entity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload.Id;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import rtx.kimiko.api.mods.geckolib.GeckoLibClient;
import rtx.kimiko.api.mods.geckolib.GeckoLibServices;
import rtx.kimiko.api.mods.geckolib.network.packet.MultiloaderPacket;
import rtx.kimiko.api.mods.geckolib.service.GeckoLibNetworking;

public final class GeckoLibNetworkingFabric implements GeckoLibNetworking {
   @Override
   public void sendToAllPlayersTrackingBlock(MultiloaderPacket multiloaderPacket, ServerWorld serverWorld, BlockPos blockPos) {
      for (ServerPlayerEntity serverPlayerEntity : PlayerLookup.tracking(serverWorld, blockPos)) {
         this.sendToPlayer(multiloaderPacket, serverPlayerEntity);
      }
   }

   @Override
   public void sendToAllPlayersTrackingEntity(MultiloaderPacket multiloaderPacket, Entity entity) {
      if (entity instanceof ServerPlayerEntity serverPlayerEntity) {
         this.sendToPlayer(multiloaderPacket, serverPlayerEntity);
      }

      for (ServerPlayerEntity serverPlayerEntity : PlayerLookup.tracking(entity)) {
         this.sendToPlayer(multiloaderPacket, serverPlayerEntity);
      }
   }

   @Override
   public <B extends PacketByteBuf, P extends MultiloaderPacket> void registerPacketInternal(Id<P> id, PacketCodec<B, P> packetCodec, boolean bl) {
      if (bl) {
         PayloadTypeRegistry.playS2C().register(id, (PacketCodec<? super RegistryByteBuf, P>)(PacketCodec)packetCodec);
         if (GeckoLibServices.PLATFORM.isPhysicalClient()) {
            GeckoLibClient.registerPacket(id);
         }
      } else {
         PayloadTypeRegistry.playC2S().register(id, (PacketCodec<? super RegistryByteBuf, P>)(PacketCodec)packetCodec);
         ServerPlayNetworking.registerGlobalReceiver(
            id,
            (multiloaderPacket, context) -> multiloaderPacket.receiveMessage(
               context.player(), arg_0 -> context.player().getEntityWorld().getServer().execute(arg_0)
            )
         );
      }
   }

   @Override
   public void sendToPlayer(MultiloaderPacket multiloaderPacket, ServerPlayerEntity serverPlayerEntity) {
      ServerPlayNetworking.send(serverPlayerEntity, multiloaderPacket);
   }
}

