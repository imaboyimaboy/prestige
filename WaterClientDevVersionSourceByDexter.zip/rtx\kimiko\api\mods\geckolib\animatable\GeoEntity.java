package rtx.kimiko.api.mods.geckolib.animatable;

import net.minecraft.entity.Entity;
import rtx.kimiko.api.mods.geckolib.GeckoLibServices;
import rtx.kimiko.api.mods.geckolib.animatable.manager.AnimatableManager;
import rtx.kimiko.api.mods.geckolib.constant.dataticket.SerializableDataTicket;

public interface GeoEntity extends GeoAnimatable {
   default <D> D getAnimData(SerializableDataTicket<D> serializableDataTicket) {
      return this.getAnimatableInstanceCache().getManagerForId(((Entity)this).getId()).getAnimatableData(serializableDataTicket);
   }

   default <D> void setAnimData(SerializableDataTicket<D> serializableDataTicket, D d) {
      Entity entity = (Entity)this;
      if (entity.getEntityWorld().isClient()) {
         this.getAnimatableInstanceCache().getManagerForId(entity.getId()).setAnimatableData(serializableDataTicket, d);
      } else {
         GeckoLibServices.NETWORK.syncEntityAnimData(entity, false, serializableDataTicket, d);
      }
   }

   default void triggerAnim(String string, String string2) {
      Entity entity = (Entity)this;
      if (entity.getEntityWorld().isClient()) {
         AnimatableManager<?> animatableManager = this.getAnimatableInstanceCache().getManagerForId(entity.getId());
         if (string != null) {
            animatableManager.tryTriggerAnimation(string, string2);
         } else {
            animatableManager.tryTriggerAnimation(string2);
         }
      } else {
         GeckoLibServices.NETWORK.triggerEntityAnim(entity, false, string, string2);
      }
   }

   default void stopTriggeredAnim(String string, String string2) {
      Entity entity = (Entity)this;
      if (entity.getEntityWorld().isClient()) {
         AnimatableManager<?> animatableManager = this.getAnimatableInstanceCache().getManagerForId(entity.getId());
         if (string != null) {
            animatableManager.stopTriggeredAnimation(string, string2);
         } else {
            animatableManager.stopTriggeredAnimation(string2);
         }
      } else {
         GeckoLibServices.NETWORK.stopTriggeredEntityAnim(entity, false, string, string2);
      }
   }
}

