package rtx.kimiko.api.mods.geckolib.network.packet.entity;

import java.util.function.Consumer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.network.packet.CustomPayload.Id;
import net.minecraft.world.World;
import rtx.kimiko.api.mods.geckolib.GeckoLibConstants;
import rtx.kimiko.api.mods.geckolib.animatable.GeoAnimatable;
import rtx.kimiko.api.mods.geckolib.animatable.stateless.StatelessAnimatable;
import rtx.kimiko.api.mods.geckolib.animation.RawAnimation;
import rtx.kimiko.api.mods.geckolib.network.packet.MultiloaderPacket;
import rtx.kimiko.api.mods.geckolib.util.ClientUtil;
import rtx.kimiko.api.mods.geckolib.util.RenderUtil;

public final class StatelessEntityPlayAnimPacket implements MultiloaderPacket {
   private int entityId;
   private boolean replacedEntity;
   private RawAnimation animation;
   public static final Id<StatelessEntityPlayAnimPacket> TYPE = new Id(GeckoLibConstants.id("stateless_entity_play_anim"));
   public static final PacketCodec<PacketByteBuf, StatelessEntityPlayAnimPacket> CODEC = PacketCodec.tuple(
      PacketCodecs.VAR_INT,
      StatelessEntityPlayAnimPacket::entityId,
      PacketCodecs.BOOLEAN,
      StatelessEntityPlayAnimPacket::isReplacedEntity,
      RawAnimation.STREAM_CODEC,
      StatelessEntityPlayAnimPacket::animation,
      StatelessEntityPlayAnimPacket::new
   );

   public StatelessEntityPlayAnimPacket(int entityId, boolean isReplacedEntity, RawAnimation animation) {
      this.entityId = entityId;
      this.replacedEntity = isReplacedEntity;
      this.animation = animation;
   }

   public Id<? extends CustomPayload> getId() {
      return TYPE;
   }

   @Override
   public void receiveMessage(PlayerEntity playerEntity, Consumer<Runnable> consumer) {
      consumer.accept(
         () -> {
            World world = ClientUtil.getLevel();
            Entity entity;
            if (world != null && (entity = world.getEntityById(this.entityId)) != null) {
               GeoAnimatable targetAnimatable = this.replacedEntity
                  ? RenderUtil.getReplacedAnimatable(entity.getType())
                  : (entity instanceof GeoAnimatable anim ? anim : null);
               if (targetAnimatable instanceof StatelessAnimatable stateless) {
                  stateless.handleClientAnimationPlay(targetAnimatable, this.entityId, this.animation);
               }
            }
         }
      );
   }

   public int entityId() {
      return this.entityId;
   }

   public boolean isReplacedEntity() {
      return this.replacedEntity;
   }

   public RawAnimation animation() {
      return this.animation;
   }
}

