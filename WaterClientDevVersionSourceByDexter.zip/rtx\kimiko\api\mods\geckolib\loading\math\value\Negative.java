package rtx.kimiko.api.mods.geckolib.loading.math.value;

import java.util.Set;
import rtx.kimiko.api.mods.geckolib.animation.state.ControllerState;
import rtx.kimiko.api.mods.geckolib.loading.math.MathValue;

public final class Negative implements MathValue {
   private MathValue value;

   public Negative(MathValue value) {
      this.value = value;
   }

   @Override
   public double get(ControllerState controllerState) {
      return -this.value.get(controllerState);
   }

   @Override
   public Set<Variable> getUsedVariables() {
      return this.value.getUsedVariables();
   }

   @Override
   public boolean isMutable() {
      return this.value.isMutable();
   }

   public MathValue value() {
      return this.value;
   }
}

