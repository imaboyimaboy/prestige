package rtx.kimiko.api.liteapi;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.UUID;

public final class LiteApiCodec {
   private LiteApiCodec() {
   }

   private static JsonObject obj(JsonObject jsonObject, String string) {
      return jsonObject != null && jsonObject.has(string) && jsonObject.get(string).isJsonObject() ? jsonObject.getAsJsonObject(string) : null;
   }

   private static String str(JsonObject jsonObject, String string) {
      return jsonObject != null && jsonObject.has(string) && jsonObject.get(string).isJsonPrimitive() ? jsonObject.get(string).getAsString() : null;
   }

   public static LiteApiCodec.Incoming parse(String string) {
      JsonObject jsonObject;
      try {
         JsonElement jsonElement = JsonParser.parseString(string);
         if (!jsonElement.isJsonObject()) {
            return null;
         }

         jsonObject = jsonElement.getAsJsonObject();
      } catch (RuntimeException var7) {
         return null;
      }

      JsonElement var8 = obj(jsonObject, "payload");
      if (!jsonObject.has("id") && jsonObject.has("event")) {
         return new Incoming(null, false, false, null, null, str(jsonObject, "event"), (JsonObject)var8);
      } else {
         String idStr = str(jsonObject, "id");
         boolean ok = jsonObject.has("ok") && jsonObject.get("ok").isJsonPrimitive() && jsonObject.get("ok").getAsBoolean();
         String errorStr = str(jsonObject, "error");
         String msgStr = str(jsonObject, "message");
         return new Incoming(idStr, true, ok, errorStr, msgStr, null, (JsonObject)var8);
      }
   }

   public static LiteApiCodec.Request checkFeatures(String clientName, Collection<String> collection) {
      String reqId = UUID.randomUUID().toString();
      JsonArray jsonArray = new JsonArray();

      for (String feature : collection) {
         jsonArray.add(feature);
      }

      JsonObject payload = new JsonObject();
      payload.addProperty("client", clientName);
      payload.add("features", jsonArray);
      JsonObject root = new JsonObject();
      root.addProperty("id", reqId);
      root.addProperty("method", "checkFeatures");
      root.add("payload", payload);
      return new Request(reqId, root.toString());
   }

   public static List<String> blocklist(JsonObject jsonObject) {
      ArrayList<String> arrayList = new ArrayList<>();
      if (jsonObject != null && jsonObject.has("blocklist") && jsonObject.get("blocklist").isJsonArray()) {
         for (JsonElement jsonElement : jsonObject.getAsJsonArray("blocklist")) {
            if (jsonElement != null && jsonElement.isJsonPrimitive()) {
               arrayList.add(jsonElement.getAsString());
            }
         }

         return arrayList;
      } else {
         return arrayList;
      }
   }

   public final static class Incoming {
      private String id;
      private boolean hasId;
      private boolean bool;
      private String error;
      private String message;
      private String event;
      private JsonObject payload;

      public Incoming(String id, boolean hasId, boolean ok, String error, String message, String event, JsonObject payload) {
         this.id = id;
         this.hasId = hasId;
         this.bool = ok;
         this.error = error;
         this.message = message;
         this.event = event;
         this.payload = payload;
      }

      public boolean isPushEvent() {
         return this.event != null;
      }

      public String id() {
         return this.id;
      }

      public boolean hasId() {
         return this.hasId;
      }

      public boolean isEnabled() {
         return this.bool;
      }

      public String error() {
         return this.error;
      }

      public String message() {
         return this.message;
      }

      public String event() {
         return this.event;
      }

      public JsonObject payload() {
         return this.payload;
      }
   }

   public final static class Request {
      private String id;
      private String json;

      public Request(String id, String json) {
         this.id = id;
         this.json = json;
      }

      public String id() {
         return this.id;
      }

      public String json() {
         return this.json;
      }
   }
}

