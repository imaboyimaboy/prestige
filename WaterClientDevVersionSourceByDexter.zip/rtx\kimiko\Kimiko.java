package rtx.kimiko;

import com.water.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rtx.kimiko.api.mods.geckolib.GeckoLib;
import rtx.kimiko.manager.Manager;
import ru.waterclient.WaterClient;

public class Kimiko implements ModInitializer, ClientModInitializer {
   public static final String MOD_ID = "kimiko";
   public static final Logger LOGGER = LoggerFactory.getLogger("kimiko");

   public void onInitializeClient() {
      try {
         new WaterClient().onInitializeClient();
      } catch (Throwable var3) {
         LOGGER.error("Failed to initialize Water legacy layer", var3);
      }

      ModuleManager.INSTANCE.init();
      Manager.init();

      try {
         new com.water.WaterClient().onInitializeClient();
      } catch (Throwable var2) {
         LOGGER.error("Failed to initialize Water module layer", var2);
      }
   }

   public void onInitialize() {
      new GeckoLib().onInitialize();
   }
}

