package rtx.kimiko.api.events.impl.game;

import rtx.kimiko.api.events.Event;

public final class TickEvent extends Event {
   private TickEvent.Phase phase;

   public TickEvent(TickEvent.Phase phase) {
      this.phase = phase;
   }

   public boolean isPost() {
      return this.phase == TickEvent.Phase.POST;
   }

   public boolean isPre() {
      return this.phase == TickEvent.Phase.PRE;
   }

   public TickEvent.Phase phase() {
      return this.phase;
   }

   public enum Phase {
      PRE,
      POST;

      private static TickEvent.Phase[] $values() {
         return new TickEvent.Phase[]{PRE, POST};
      }
   }
}

