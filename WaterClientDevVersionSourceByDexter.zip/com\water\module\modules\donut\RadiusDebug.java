package com.water.module.modules.donut;

import com.water.module.Category;
import com.water.module.Module;
import com.water.setting.Setting;
import com.water.utils.RenderUtils;
import java.awt.Color;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import org.lwjgl.opengl.GL11;

public final class RadiusDebug extends Module {
   private final Setting<Float> scanRadius = new Setting<>("Scan Radius", 3.0F, 1.0F, 16.0F);
   private final Setting<Float> kolision = new Setting<>("KOLISION", 1.0F, 1.0F, 10.0F);
   private final Setting<Color> color = new Setting<>("Color", new Color(160, 50, 255, 60));
   private final Setting<Float> fillAlpha = new Setting<>("Fill Alpha", 60.0F, 0.0F, 255.0F);
   private final Setting<Float> lineAlpha = new Setting<>("Line Alpha", 180.0F, 0.0F, 255.0F);
   private final Map<ChunkPos, Integer> foundGeodes = new ConcurrentHashMap<>();
   private int scanCursor = 0;

   public RadiusDebug() {
      super("RadiusDebug", Category.DONUT);
      this.addSetting(this.scanRadius);
      this.addSetting(this.kolision);
      this.addSetting(this.color);
      this.addSetting(this.fillAlpha);
      this.addSetting(this.lineAlpha);
   }

   private int getRequiredAmethyst() {
      return this.kolision.getValue().intValue() * 40;
   }

   @Override
   public void onEnable() {
      this.foundGeodes.clear();
      this.scanCursor = 0;
   }

   @Override
   public void onDisable() {
      this.foundGeodes.clear();
      this.scanCursor = 0;
   }

   @Override
   public void onTick() {
      if (mc.world != null && mc.player != null) {
         ChunkPos playerChunk = mc.player.getChunkPos();
         int radius = this.scanRadius.getValue().intValue();
         int side = radius * 2 + 1;
         int total = side * side;
         int req = this.getRequiredAmethyst();
         this.foundGeodes.keySet().removeIf(cpx -> Math.abs(cpx.x - playerChunk.x) > radius + 4 || Math.abs(cpx.z - playerChunk.z) > radius + 4);

         for (int i = 0; i < 8; i++) {
            int index = this.scanCursor % total;
            this.scanCursor = (this.scanCursor + 1) % total;
            int dx = index % side - radius;
            int dz = index / side - radius;
            int cx = playerChunk.x + dx;
            int cz = playerChunk.z + dz;
            WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(cx, cz, false);
            if (chunk != null && !chunk.isEmpty()) {
               ChunkPos cp = new ChunkPos(cx, cz);
               int count = this.countAmethyst(chunk);
               if (count >= req) {
                  boolean coveredByExisting = false;
                  ChunkPos weakerExisting = null;

                  for (Entry<ChunkPos, Integer> e : this.foundGeodes.entrySet()) {
                     if (Math.abs(e.getKey().x - cp.x) <= 8 && Math.abs(e.getKey().z - cp.z) <= 8) {
                        if (count > e.getValue()) {
                           weakerExisting = e.getKey();
                        } else {
                           coveredByExisting = true;
                        }
                        break;
                     }
                  }

                  if (weakerExisting != null) {
                     this.foundGeodes.remove(weakerExisting);
                     this.foundGeodes.put(cp, count);
                  } else if (!coveredByExisting) {
                     this.foundGeodes.put(cp, count);
                  }
               }
            }
         }

         this.foundGeodes.entrySet().removeIf(ex -> (Integer)ex.getValue() < req);
      }
   }

   private boolean isAmethyst(BlockState state) {
      return state.isOf(Blocks.AMETHYST_BLOCK)
         || state.isOf(Blocks.BUDDING_AMETHYST)
         || state.isOf(Blocks.AMETHYST_CLUSTER)
         || state.isOf(Blocks.LARGE_AMETHYST_BUD)
         || state.isOf(Blocks.MEDIUM_AMETHYST_BUD)
         || state.isOf(Blocks.SMALL_AMETHYST_BUD);
   }

   private int countAmethyst(WorldChunk chunk) {
      int count = 0;

      for (ChunkSection section : chunk.getSectionArray()) {
         if (section != null && !section.isEmpty() && section.hasAny(this::isAmethyst)) {
            for (int lx = 0; lx < 16; lx++) {
               for (int lz = 0; lz < 16; lz++) {
                  for (int ly = 0; ly < 16; ly++) {
                     if (this.isAmethyst(section.getBlockState(lx, ly, lz))) {
                        count++;
                     }
                  }
               }
            }
         }
      }

      return count;
   }

   @Override
   public void onRender(MatrixStack matrices, float tickDelta) {
      if (mc.world != null && mc.player != null && !this.foundGeodes.isEmpty()) {
         Camera camera = RenderUtils.getCamera();
         if (camera != null) {
            Vec3d cam = RenderUtils.getCameraPos(camera);
            Color base = this.color.getValue();
            Color fill = new Color(base.getRed(), base.getGreen(), base.getBlue(), Math.min(255, Math.max(0, this.fillAlpha.getValue().intValue())));
            Color line = new Color(base.getRed(), base.getGreen(), base.getBlue(), Math.min(255, Math.max(0, this.lineAlpha.getValue().intValue())));
            matrices.push();
            GL11.glDisable(2929);

            try {
               RenderUtils.WorldBatch batch = RenderUtils.beginWorldBatch(matrices);

               for (ChunkPos cp : this.foundGeodes.keySet()) {
                  double y1 = 49.0 - cam.y - 0.05;
                  double y2 = 49.0 - cam.y + 0.05;

                  for (int dx = -1; dx <= 2; dx++) {
                     for (int dz = -1; dz <= 2; dz++) {
                        ChunkPos rcp = new ChunkPos(cp.x + dx, cp.z + dz);
                        double x1 = rcp.getStartX() - cam.x;
                        double z1 = rcp.getStartZ() - cam.z;
                        double x2 = rcp.getEndX() - cam.x + 1.0;
                        double z2 = rcp.getEndZ() - cam.z + 1.0;
                        batch.renderFilledBox(x1, y1, z1, x2, y2, z2, fill);
                        batch.renderOutlineBox(x1, y1, z1, x2, y2, z2, line);
                     }
                  }
               }

               batch.flush();
            } finally {
               GL11.glEnable(2929);
            }

            matrices.pop();
         }
      }
   }
}

