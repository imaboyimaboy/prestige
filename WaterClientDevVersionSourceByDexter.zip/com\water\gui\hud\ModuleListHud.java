package com.water.gui.hud;

import com.water.module.Module;
import com.water.module.ModuleManager;
import com.water.module.modules.client.WaterPlus;
import com.water.utils.renderer.AwtFontRenderer;
import com.water.utils.renderer.RenderUtil;
import com.water.utils.renderer.blur.KawasePipeline;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import rtx.kimiko.api.ui.UI;

public final class ModuleListHud {
   public static final ModuleListHud INSTANCE = new ModuleListHud();
   private static final float RADIUS = 7.0F;
   private static final int TOP_OFFSET = 72;
   private static final int HEADER_H = 18;
   private static final int SEPARATOR_H = 3;
   private static final int ROW_H = 12;
   private static final int PAD_X = 7;

   private ModuleListHud() {
   }

   public void render(DrawContext context) {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client != null && client.options != null && !client.getDebugHud().shouldShowDebugHud()) {
         if (!(client.currentScreen instanceof UI)) {
            AwtFontRenderer font = AwtFontRenderer.INSTANCE;
            List<Module> enabledModules = new ArrayList<>();

            for (Module module : ModuleManager.INSTANCE.getModules()) {
               if (module.isEnabled()) {
                  enabledModules.add(module);
               }
            }

            if (!enabledModules.isEmpty()) {
               enabledModules.sort(Comparator.<Module>comparingInt(modulex -> font.getWidth(titleCase(modulex.getName()))).reversed());
               String title = "Modules";
               int maxTextW = font.getWidth(title);

               for (Module modulex : enabledModules) {
                  maxTextW = Math.max(maxTextW, font.getWidth(titleCase(modulex.getName())));
               }

               int panelW = maxTextW + 14 + 4;
               int panelH = 21 + enabledModules.size() * 12 + 5;
               int x = client.getWindow().getScaledWidth() - 10 - panelW;
               int bg = WaterPlus.getBackgroundARGB();

               for (int s = 3; s >= 1; s--) {
                  RenderUtil.drawRoundedRect(
                     context, (float)(x - s), (float)(72 - s + 1), (float)(panelW + s * 2), (float)(panelH + s * 2), 7.0F + s, 10 - s * 2 << 24, false
                  );
               }

               if (WaterPlus.menuBlurEnabled()) {
                  KawasePipeline.beginFrame();
                  RenderUtil.drawBlur(context, x, 72, panelW, panelH, 7.0F, 1.0F, false);
               }

               RenderUtil.drawRoundedRect(context, (float)x, (float)72, (float)panelW, (float)panelH, 7.0F, bg, false);
               RenderUtil.drawRoundedRect(context, (float)(x + 1), (float)73, (float)(panelW - 2), 18.0F, 7.0F, 285212671, false);
               RenderUtil.drawOutline(context, (float)x, (float)72, (float)panelW, (float)panelH, 7.0F, 1.0F, 721420287, false);
               font.drawString(context, title, x + 7, 77, -1);
               RenderUtil.drawRoundedRect(context, (float)x, (float)90, (float)panelW, 3.0F, 0.5F, 335544320, false);
               int rowY = 95;

               for (Module modulex : enabledModules) {
                  font.drawString(context, titleCase(modulex.getName()), x + 7, rowY, -1073741825);
                  rowY += 12;
               }
            }
         }
      }
   }

   private static String titleCase(String s) {
      if (s != null && !s.isEmpty()) {
         StringBuilder b = new StringBuilder(s.length());
         boolean newWord = true;

         for (char c : s.toCharArray()) {
            if (Character.isLetter(c)) {
               b.append(newWord ? Character.toUpperCase(c) : Character.toLowerCase(c));
               newWord = false;
            } else {
               b.append(c);
               newWord = c == ' ' || c == '_' || c == '-';
            }
         }

         return b.toString();
      } else {
         return s == null ? "" : s;
      }
   }

   static String _c11e65e0b35() {
      return "E";
   }
}

