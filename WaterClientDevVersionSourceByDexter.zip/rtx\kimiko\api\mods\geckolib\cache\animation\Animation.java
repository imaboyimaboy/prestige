package rtx.kimiko.api.mods.geckolib.cache.animation;

import it.unimi.dsi.fastutil.objects.ReferenceArraySet;
import it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet;
import java.util.Set;
import rtx.kimiko.api.mods.geckolib.animation.object.LoopType;
import rtx.kimiko.api.mods.geckolib.cache.animation.keyframeevent.CustomInstructionKeyframeData;
import rtx.kimiko.api.mods.geckolib.cache.animation.keyframeevent.ParticleKeyframeData;
import rtx.kimiko.api.mods.geckolib.cache.animation.keyframeevent.SoundKeyframeData;
import rtx.kimiko.api.mods.geckolib.loading.math.value.Variable;

public final class Animation {
   private String name;
   private double length;
   private LoopType loopType;
   private BoneAnimation[] boneAnimations;
   private Set<Variable> usedVariables;
   private Animation.KeyframeMarkers keyframeMarkers;

   public Animation(
      String name, double length, LoopType loopType, BoneAnimation[] boneAnimations, Set<Variable> usedVariables, Animation.KeyframeMarkers keyframeMarkers
   ) {
      this.name = name;
      this.length = length;
      this.loopType = loopType;
      this.boneAnimations = boneAnimations;
      this.usedVariables = usedVariables;
      this.keyframeMarkers = keyframeMarkers;
   }

   public static Animation create(String string, double d, LoopType loopType, BoneAnimation[] boneAnimationArray, Animation.KeyframeMarkers keyframeMarkers) {
      ReferenceOpenHashSet referenceOpenHashSet = new ReferenceOpenHashSet();

      for (BoneAnimation boneAnimation : boneAnimationArray) {
         referenceOpenHashSet.addAll(boneAnimation.getUsedVariables());
      }

      return new Animation(string, d, loopType, boneAnimationArray, new ReferenceArraySet(referenceOpenHashSet), keyframeMarkers);
   }

   public static Animation generateWaitAnimation(double d) {
      return new Animation(
         "internal.wait",
         d,
         LoopType.PLAY_ONCE,
         new BoneAnimation[0],
         Set.of(),
         new KeyframeMarkers(new SoundKeyframeData[0], new ParticleKeyframeData[0], new CustomInstructionKeyframeData[0])
      );
   }

   public String name() {
      return this.name;
   }

   public double length() {
      return this.length;
   }

   public LoopType loopType() {
      return this.loopType;
   }

   public BoneAnimation[] boneAnimations() {
      return this.boneAnimations;
   }

   public Set<Variable> usedVariables() {
      return this.usedVariables;
   }

   public Animation.KeyframeMarkers keyframeMarkers() {
      return this.keyframeMarkers;
   }

   public final static class KeyframeMarkers {
      private SoundKeyframeData[] sounds;
      private ParticleKeyframeData[] particles;
      private CustomInstructionKeyframeData[] customInstructions;

      public KeyframeMarkers(SoundKeyframeData[] sounds, ParticleKeyframeData[] particles, CustomInstructionKeyframeData[] customInstructions) {
         this.sounds = sounds;
         this.particles = particles;
         this.customInstructions = customInstructions;
      }

      public boolean isEmpty() {
         return this.sounds.length == 0 && this.particles.length == 0 && this.customInstructions.length == 0;
      }

      public SoundKeyframeData[] sounds() {
         return this.sounds;
      }

      public ParticleKeyframeData[] particles() {
         return this.particles;
      }

      public CustomInstructionKeyframeData[] customInstructions() {
         return this.customInstructions;
      }
   }
}

