package rtx.kimiko.api.mods.geckolib.animation.state;

import it.unimi.dsi.fastutil.objects.Reference2DoubleMap;
import rtx.kimiko.api.mods.geckolib.animation.object.EasingType;
import rtx.kimiko.api.mods.geckolib.loading.math.value.Variable;
import rtx.kimiko.api.mods.geckolib.renderer.base.GeoRenderState;

public final class ControllerState {
   private AnimationPoint animationPoint;
   private AnimationPoint prevAnimationPoint;
   private double transitionTime;
   private int transitionTicks;
   private boolean additive;
   private EasingType easingOverride;
   private GeoRenderState renderState;
   private Reference2DoubleMap<Variable> queryValues;

   public ControllerState(
      AnimationPoint animationPoint,
      AnimationPoint prevAnimationPoint,
      double transitionTime,
      int transitionTicks,
      boolean additive,
      EasingType easingOverride,
      GeoRenderState renderState,
      Reference2DoubleMap<Variable> queryValues
   ) {
      this.animationPoint = animationPoint;
      this.prevAnimationPoint = prevAnimationPoint;
      this.transitionTime = transitionTime;
      this.transitionTicks = transitionTicks;
      this.additive = additive;
      this.easingOverride = easingOverride;
      this.renderState = renderState;
      this.queryValues = queryValues;
   }

   public float partialTick() {
      return this.renderState.getPartialTick();
   }

   public double getQueryValue(Variable variable) {
      return this.queryValues.getDouble(variable);
   }

   public void setVariable(Variable variable, double value) {
      if (this.queryValues != null) {
         this.queryValues.put(variable, value);
      }
   }

   public void setVariable(String name, double value) {
      if (this.queryValues != null) {
         this.queryValues.put(new Variable(name, value), value);
      }
   }

   public AnimationPoint animationPoint() {
      return this.animationPoint;
   }

   public AnimationPoint prevAnimationPoint() {
      return this.prevAnimationPoint;
   }

   public double transitionTime() {
      return this.transitionTime;
   }

   public int transitionTicks() {
      return this.transitionTicks;
   }

   public boolean additive() {
      return this.additive;
   }

   public EasingType easingOverride() {
      return this.easingOverride;
   }

   public GeoRenderState renderState() {
      return this.renderState;
   }

   public Reference2DoubleMap<Variable> queryValues() {
      return this.queryValues;
   }
}

