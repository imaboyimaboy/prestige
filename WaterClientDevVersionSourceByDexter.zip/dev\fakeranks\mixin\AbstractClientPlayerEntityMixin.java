package dev.fakeranks.mixin;

import dev.fakeranks.FakeRanksClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.player.SkinTextures;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({AbstractClientPlayerEntity.class})
public abstract class AbstractClientPlayerEntityMixin {
   @Inject(
      method = {"getSkin"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 0
   )
   private void fakeranks$useStolenSkin(CallbackInfoReturnable<SkinTextures> info) {
      MinecraftClient client = MinecraftClient.getInstance();
      SkinTextures skin = FakeRanksClient.STATE.skinStealer().skin();
      if (FakeRanksClient.STATE.config().enabled && FakeRanksClient.STATE.config().skinStealEnabled && skin != null) {
         if (((Object)this) == client.player) {
            info.setReturnValue(skin);
         }
      }
   }
}

