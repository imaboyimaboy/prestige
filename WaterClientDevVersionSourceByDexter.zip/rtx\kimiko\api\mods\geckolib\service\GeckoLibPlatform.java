package rtx.kimiko.api.mods.geckolib.service;

import java.nio.file.Path;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;
import net.minecraft.component.ComponentType;
import net.minecraft.component.ComponentType.Builder;
import net.minecraft.entity.Entity;

public interface GeckoLibPlatform {
   boolean isDevelopmentEnvironment();

   Path getGameDir();

   <T> Supplier<ComponentType<T>> registerDataComponent(String var1, UnaryOperator<Builder<T>> var2);

   boolean isPhysicalClient();

   default boolean isInSwimmableFluid(Entity entity) {
      return entity.isTouchingWater();
   }
}

