package com.water.gui;

import com.water.module.modules.client.WaterPlus;
import com.water.spotify.SpotifyAPI;
import com.water.spotify.SpotifyAuth;
import com.water.utils.renderer.RenderUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;

public final class SpotifyBrowserScreen extends Screen {
   private static final int intVal = 420;
   private static final int intVal2 = 360;
   private static final int intVal3 = 10;
   private static final int PAD = 10;
   private static final int HEAD_H = 44;
   private static final int FOOT_H = 44;
   private static final int ROW_H = 22;
   private static final int SRCH_H = 24;
   private static final int TABS_H = 28;
   private Screen parent;
   private String search = "";
   private int scroll = 0;
   private int hoverRow = -1;
   private long openNs = 0L;
   private int tab = 0;
   private static final List<SpotifyAPI.Track> QUEUE_CACHE = new ArrayList<>();
   private static final List<String[]> PLAYLISTS_CACHE = new ArrayList<>();
   private static final List<SpotifyAPI.Track> TRACKS_CACHE = new ArrayList<>();
   private static volatile String selectedPlaylist = null;
   private static volatile String selectedPlaylistName = "";
   private List<Object> filtered = new ArrayList<>();
   private volatile boolean loading = false;
   private volatile String status = "";
   private final ExecutorService exec = Executors.newSingleThreadExecutor(r -> {
      Thread t = new Thread(r, "spotify-browser");
      t.setDaemon(true);
      return t;
   });
   private boolean enteringClientId = false;
   private String clientIdInput = "";

   public SpotifyBrowserScreen(Screen parent) {
      super(Text.literal(""));
      this.parent = parent;
   }

   private int getInt3() {
      return (this.width - 420) / 2;
   }

   private int getInt4() {
      return (this.height - 360) / 2;
   }

   private int listY() {
      return this.getInt4() + 44 + 28 + 24 + 10;
   }

   private int listH() {
      return 200;
   }

   private int maxRows() {
      return this.listH() / 22;
   }

   private int maxScroll() {
      return Math.max(0, this.filtered.size() - this.maxRows());
   }

   public void init() {
      String savedId = WaterPlus.getSpotifyClientId();
      if (savedId != null && !savedId.isBlank()) {
         SpotifyAuth.setClientId(savedId);
      }

      if (!SpotifyAuth.isConfigured()) {
         this.enteringClientId = true;
         this.clientIdInput = "";
         this.status = "Enter your Spotify Client ID";
      } else if (!SpotifyAuth.isAuthed()) {
         this.status = "Click CONNECT to login";
      } else {
         this.loadQueue();
      }
   }

   private void loadQueue() {
      this.loading = true;
      this.status = "Loading queue...";
      this.exec.submit(() -> {
         List<SpotifyAPI.Track> q = SpotifyAPI.getQueue();
         synchronized (QUEUE_CACHE) {
            QUEUE_CACHE.clear();
            QUEUE_CACHE.addAll(q);
         }

         this.status = q.isEmpty() ? "Queue is empty" : q.size() + " tracks";
         this.loading = false;
         this.client.execute(this::rebuild);
      });
   }

   private void loadPlaylists() {
      this.loading = true;
      this.status = "Loading playlists...";
      this.exec.submit(() -> {
         List<String[]> pl = SpotifyAPI.getUserPlaylists();
         synchronized (PLAYLISTS_CACHE) {
            PLAYLISTS_CACHE.clear();
            PLAYLISTS_CACHE.addAll(pl);
         }

         this.status = pl.size() + " playlists";
         this.loading = false;
         this.client.execute(this::rebuild);
      });
   }

   private void loadPlaylistTracks(String id, String name) {
      selectedPlaylist = id;
      selectedPlaylistName = name;
      this.loading = true;
      this.status = "Loading null...";
      this.tab = 2;
      this.exec.submit(() -> {
         List<SpotifyAPI.Track> tracks = SpotifyAPI.getPlaylistTracks(id);
         synchronized (TRACKS_CACHE) {
            TRACKS_CACHE.clear();
            TRACKS_CACHE.addAll(tracks);
         }

         this.status = tracks.size() + " tracks in " + name;
         this.loading = false;
         this.client.execute(this::rebuild);
      });
   }

   private void rebuild() {
      String q = this.search.trim().toLowerCase();
      this.filtered = new ArrayList<>();

      List<?> source = (List<?>)(switch (this.tab) {
         case 0 -> QUEUE_CACHE;
         case 1 -> PLAYLISTS_CACHE;
         case 2 -> TRACKS_CACHE;
         default -> new ArrayList();
      });
      synchronized (source) {
         for (Object item : source) {
            String disp = item instanceof SpotifyAPI.Track t ? t.display() : (item instanceof String[] pl ? pl[1] : "");
            if (q.isEmpty() || disp.toLowerCase().contains(q)) {
               this.filtered.add(item);
            }
         }
      }

      this.scroll = Math.max(0, Math.min(this.maxScroll(), this.scroll));
   }

   public void render(DrawContext ctx, int mx, int my, float delta) {
      if (this.openNs == 0L) {
         this.openNs = System.nanoTime();
      }

      float a = this.easeOut(Math.min(1.0F, (float)(System.nanoTime() - this.openNs) / 1.E8F));
      int px = this.getInt3();
      int py = this.getInt4();
      int accent = WaterPlus.getAccentARGB();
      int accentRgb = accent & 16777215;
      RenderUtil.drawRoundedRect(ctx, (float)px, (float)py, 420.0F, 360.0F, 10.0F, this.alphaScale(-234353645, a), false);
      RenderUtil.drawOutline(ctx, (float)px, (float)py, 420.0F, 360.0F, 10.0F, 1.5F, this.col(accentRgb, (int)(80.0F * a)), false);
      RenderUtil.drawRoundedRect(ctx, (float)px, (float)py, 420.0F, 44.0F, 10.0F, 10.0F, 0.0F, 0.0F, false, this.alphaScale(-871756264, a));
      ctx.fill(px, py + 44, px + 420, py + 44 + 1, this.alphaScale(553648127, a));
      ctx.fill(px, py + 10, px + 3, py + 44 - 10, this.col(accentRgb, (int)(255.0F * a)));
      ctx.drawText(this.textRenderer, "SPOTIFY", px + 10 + 8, py + 10, this.col(15659767, (int)(255.0F * a)), false);
      String sub = this.enteringClientId
         ? "Enter Client ID to connect"
         : (
            !SpotifyAuth.isConfigured()
               ? "Not configured"
               : (!SpotifyAuth.isAuthed() ? (SpotifyAuth.isAuthInProgress() ? "Connecting..." : "Click CONNECT") : this.status)
         );
      ctx.drawText(this.textRenderer, sub, px + 10 + 8, py + 25, this.col(6320256, (int)(180.0F * a)), false);
      if (!SpotifyAuth.isAuthed() && !this.enteringClientId) {
         int btnX = px + 420 - 10 - 80;
         int btnY2 = py + 22 - 9;
         boolean bh = this.hov(mx, my, btnX, btnY2, 80, 18);
         RenderUtil.drawRoundedRect(ctx, (float)btnX, (float)btnY2, 80.0F, 18.0F, 4.0F, this.col(accentRgb, bh ? (int)(50.0F * a) : (int)(20.0F * a)), false);
         RenderUtil.drawOutline(ctx, (float)btnX, (float)btnY2, 80.0F, 18.0F, 4.0F, 1.0F, this.col(accentRgb, (int)(150.0F * a)), false);
         String lbl = SpotifyAuth.isConfigured() ? "CONNECT" : "SETUP";
         ctx.drawText(this.textRenderer, lbl, btnX + (80 - this.textRenderer.getWidth(lbl)) / 2, btnY2 + 5, this.col(accentRgb, (int)(220.0F * a)), false);
      }

      if (this.enteringClientId) {
         this.renderClientIdSetup(ctx, px, py, mx, my, a, accentRgb);
      } else if (!SpotifyAuth.isAuthed()) {
         ctx.drawText(
            this.textRenderer,
            "Click CONNECT to login with Spotify",
            px + (420 - this.textRenderer.getWidth("Click CONNECT to login with Spotify")) / 2,
            py + 180 - 4,
            this.col(6320256, (int)(180.0F * a)),
            false
         );
         this.renderFooter(ctx, px, py, mx, my, a, accentRgb);
      } else {
         this.renderTabs(ctx, px, py, mx, my, a, accentRgb);
         int sy = py + 44 + 28 + 4;
         int sx = px + 10;
         int sw = 400;
         boolean hasS = !this.search.isEmpty();
         RenderUtil.drawRoundedRect(ctx, (float)sx, (float)sy, (float)sw, 24.0F, 6.0F, this.alphaScale(-16183784, a), false);
         RenderUtil.drawOutline(
            ctx, (float)sx, (float)sy, (float)sw, 24.0F, 6.0F, 1.0F, this.col(hasS ? accentRgb : 822083583, hasS ? (int)(120.0F * a) : (int)(50.0F * a)), false
         );
         ctx.drawText(
            this.textRenderer,
            hasS ? "⌕  " + this.search + "_" : "⌕  Search...",
            sx + 8,
            sy + 12 - 4,
            this.col(hasS ? 15659767 : 6320256, (int)(200.0F * a)),
            false
         );
         int lx = px + 10;
         int ly = this.listY();
         int lh = this.listH();
         RenderUtil.drawRoundedRect(ctx, (float)lx, (float)(ly - 2), (float)400, (float)(lh + 4), 6.0F, this.alphaScale(-1442444784, a), false);
         this.hoverRow = -1;
         if (this.loading && this.filtered.isEmpty()) {
            ctx.drawText(
               this.textRenderer,
               this.status,
               lx + (400 - this.textRenderer.getWidth(this.status)) / 2,
               ly + lh / 2 - 4,
               this.col(6320256, (int)(180.0F * a)),
               false
            );
         } else if (this.filtered.isEmpty()) {
            String msg = this.search.isEmpty() ? "Nothing here yet" : "No results for \"" + this.search + "\"";
            ctx.drawText(this.textRenderer, msg, lx + (400 - this.textRenderer.getWidth(msg)) / 2, ly + lh / 2 - 4, this.col(6320256, (int)(180.0F * a)), false);
         } else {
            int end = Math.min(this.scroll + this.maxRows(), this.filtered.size());

            for (int i = this.scroll; i < end; i++) {
               Object item = this.filtered.get(i);
               int ry = ly + (i - this.scroll) * 22;
               boolean rh = this.hov(mx, my, lx, ry, 400, 22);
               if (rh) {
                  this.hoverRow = i;
               }

               boolean isCurrent = item instanceof SpotifyAPI.Track t2 && t2 == this.filtered.get(0) && this.tab == 0;
               if (isCurrent) {
                  RenderUtil.drawRoundedRect(ctx, (float)lx, (float)ry, (float)400, 21.0F, 4.0F, this.col(accentRgb, (int)(25.0F * a)), false);
                  RenderUtil.drawOutline(ctx, (float)lx, (float)ry, (float)400, 21.0F, 4.0F, 1.0F, this.col(accentRgb, (int)(80.0F * a)), false);
               } else if (rh) {
                  RenderUtil.drawRoundedRect(ctx, (float)lx, (float)ry, (float)400, 21.0F, 4.0F, this.alphaScale(369098751, a), false);
               }

               int tx = lx + 8;
               if (isCurrent) {
                  ctx.fill(lx + 3, ry + 5, lx + 5, ry + 22 - 5, this.col(accentRgb, (int)(255.0F * a)));
                  tx = lx + 10;
               }

               String idx = i + 1 + ".";
               ctx.drawText(this.textRenderer, idx, tx, ry + 11 - 4, this.col(5267568, (int)(160.0F * a)), false);
               tx += this.textRenderer.getWidth(idx) + 4;
               if (item instanceof String[]) {
                  String arrow = ">";
                  ctx.drawText(this.textRenderer, arrow, lx + 400 - 14, ry + 11 - 4, this.col(accentRgb, (int)(160.0F * a)), false);
               }

               String disp = item instanceof SpotifyAPI.Track t3
                  ? this.textRenderer.trimToWidth(t3.display(), 400 - tx - 18)
                  : (item instanceof String[] pl ? this.textRenderer.trimToWidth(pl[1], 400 - tx - 18) : "");
               int tc = isCurrent ? this.col(accentRgb, (int)(255.0F * a)) : this.col(rh ? 15659767 : 10531008, (int)(220.0F * a));
               ctx.drawText(this.textRenderer, disp, tx, ry + 11 - 4, tc, false);
            }

            if (this.filtered.size() > this.maxRows()) {
               int sbX = lx + 400 + 2;
               float th = Math.max(20.0F, lh * ((float)this.maxRows() / this.filtered.size()));
               float ty = ly + (lh - th) * ((float)this.scroll / Math.max(1, this.maxScroll()));
               RenderUtil.drawRoundedRect(ctx, (float)sbX, (float)ly, 3.0F, (float)lh, 1.5F, this.alphaScale(318767103, a), false);
               RenderUtil.drawRoundedRect(ctx, (float)sbX, (float)((int)ty), 3.0F, (float)((int)th), 1.5F, this.col(accentRgb, (int)(150.0F * a)), false);
            }
         }

         this.renderFooter(ctx, px, py, mx, my, a, accentRgb);
      }
   }

   private void renderTabs(DrawContext ctx, int px, int py, int mx, int my, float a, int accentRgb) {
      int ty = py + 44 + 4;
      String[] labels = new String[]{"QUEUE", "PLAYLISTS", this.tab == 2 ? selectedPlaylistName : "TRACKS"};

      for (int i = 0; i < 3; i++) {
         int tx = px + 10 + i * 135;
         boolean active = this.tab == i;
         boolean hov = this.hov(mx, my, tx, ty, 133, 22);
         int bg = active ? this.col(accentRgb, (int)(35.0F * a)) : this.col(16777215, hov ? (int)(18.0F * a) : (int)(8.0F * a));
         int bd = active ? this.col(accentRgb, (int)(150.0F * a)) : this.col(16777215, (int)(30.0F * a));
         RenderUtil.drawRoundedRect(ctx, (float)tx, (float)ty, (float)133, 22.0F, 5.0F, bg, false);
         RenderUtil.drawOutline(ctx, (float)tx, (float)ty, (float)133, 22.0F, 5.0F, 1.0F, bd, false);
         String lbl = this.textRenderer.trimToWidth(labels[i], 125);
         ctx.drawText(
            this.textRenderer,
            lbl,
            tx + (133 - this.textRenderer.getWidth(lbl)) / 2,
            ty + 11 - 4,
            active ? this.col(accentRgb, (int)(255.0F * a)) : this.col(10531008, (int)(200.0F * a)),
            false
         );
      }
   }

   private void renderClientIdSetup(DrawContext ctx, int px, int py, int mx, int my, float a, int accentRgb) {
      int cy = py + 180 - 40;
      ctx.drawText(
         this.textRenderer,
         "Setup Spotify (free on developer.spotify.com)",
         px + (420 - this.textRenderer.getWidth("Setup Spotify (free on developer.spotify.com)")) / 2,
         cy - 20,
         this.col(10531008, (int)(200.0F * a)),
         false
      );
      ctx.drawText(this.textRenderer, "Enter Client ID:", px + 10, cy, this.col(15659767, (int)(255.0F * a)), false);
      RenderUtil.drawRoundedRect(ctx, (float)(px + 10), (float)(cy + 14), (float)400, (float)22, 5.0F, this.alphaScale(-16183784, a), false);
      RenderUtil.drawOutline(ctx, (float)(px + 10), (float)(cy + 14), (float)400, (float)22, 5.0F, 1.0F, this.col(accentRgb, (int)(150.0F * a)), false);
      String disp = this.clientIdInput.isEmpty() ? "Paste Client ID here..." : this.clientIdInput + "_";
      ctx.drawText(this.textRenderer, disp, px + 10 + 6, cy + 19, this.col(this.clientIdInput.isEmpty() ? 6320256 : 15659767, (int)(200.0F * a)), false);
      int btnY = cy + 46;
      boolean saveH = this.hov(mx, my, px + 10, btnY, 80, 22);
      boolean helpH = this.hov(mx, my, px + 420 - 10 - 80, btnY, 80, 22);
      RenderUtil.drawRoundedRect(
         ctx, (float)(px + 10), (float)btnY, (float)80, (float)22, 5.0F, this.col(accentRgb, saveH ? (int)(50.0F * a) : (int)(20.0F * a)), false
      );
      RenderUtil.drawOutline(ctx, (float)(px + 10), (float)btnY, (float)80, (float)22, 5.0F, 1.0F, this.col(accentRgb, (int)(150.0F * a)), false);
      ctx.drawText(this.textRenderer, "SAVE & CONNECT", px + 10 + 6, btnY + 7, this.col(accentRgb, (int)(220.0F * a)), false);
      ctx.drawText(
         this.textRenderer,
         "developer.spotify.com →",
         px + 420 - 10 - this.textRenderer.getWidth("developer.spotify.com →"),
         btnY + 7,
         this.col(6320256, (int)(160.0F * a)),
         false
      );
   }

   private void renderFooter(DrawContext ctx, int px, int py, int mx, int my, float a, int accentRgb) {
      RenderUtil.drawRoundedRect(ctx, (float)px, (float)(py + 360 - 44), 420.0F, 44.0F, 0.0F, 0.0F, 10.0F, 10.0F, false, this.alphaScale(-871756264, a));
      ctx.fill(px, py + 360 - 44, px + 420, py + 360 - 44 + 1, this.alphaScale(553648127, a));
      int btnY = py + 360 - 44 + 9;
      this.drawBtn(ctx, px + 10, btnY, 64, 26, "⏮ PREV", mx, my, a, accentRgb);
      this.drawBtn(ctx, px + 10 + 68, btnY, 80, 26, "⏸ PAUSE", mx, my, a, accentRgb);
      this.drawBtn(ctx, px + 10 + 152, btnY, 64, 26, "NEXT ⏭", mx, my, a, accentRgb);
      int clsX = px + 420 - 10 - 64;
      boolean clsH = this.hov(mx, my, clsX, btnY, 64, 26);
      RenderUtil.drawRoundedRect(ctx, (float)clsX, (float)btnY, 64.0F, 26.0F, 6.0F, this.alphaScale(clsH ? 637534207 : 285212671, a), false);
      RenderUtil.drawOutline(ctx, (float)clsX, (float)btnY, 64.0F, 26.0F, 6.0F, 1.0F, this.alphaScale(553648127, a), false);
      ctx.drawText(this.textRenderer, "CLOSE", clsX + (64 - this.textRenderer.getWidth("CLOSE")) / 2, btnY + 9, this.col(10531008, (int)(200.0F * a)), false);
   }

   private void drawBtn(DrawContext ctx, int x, int y, int w, int h, String lbl, int mx, int my, float a, int rgb) {
      boolean hov = this.hov(mx, my, x, y, w, h);
      RenderUtil.drawRoundedRect(ctx, (float)x, (float)y, (float)w, (float)h, 6.0F, this.col(rgb, hov ? (int)(45.0F * a) : (int)(18.0F * a)), false);
      RenderUtil.drawOutline(ctx, (float)x, (float)y, (float)w, (float)h, 6.0F, 1.0F, this.col(rgb, hov ? (int)(180.0F * a) : (int)(60.0F * a)), false);
      ctx.drawText(
         this.textRenderer, lbl, x + (w - this.textRenderer.getWidth(lbl)) / 2, y + h / 2 - 4, this.col(hov ? rgb : 10531008, (int)(220.0F * a)), false
      );
   }

   public boolean mouseClicked(Click click, boolean bl) {
      int mx = (int)click.x();
      int my = (int)click.y();
      int px = this.getInt3();
      int py = this.getInt4();
      if (this.enteringClientId) {
         int cy = py + 180 - 40;
         int btnY = cy + 46;
         int bw = 80;
         int bh = 22;
         if (this.hov(mx, my, px + 10, btnY, bw, bh) && !this.clientIdInput.isBlank()) {
            SpotifyAuth.setClientId(this.clientIdInput);
            this.enteringClientId = false;
            this.init();
         }

         return true;
      } else if (!SpotifyAuth.isAuthed()) {
         int bx = px + 420 - 10 - 80;
         int by = py + 22 - 9;
         if (this.hov(mx, my, bx, by, 80, 18)) {
            if (!SpotifyAuth.isConfigured()) {
               this.enteringClientId = true;
               this.clientIdInput = "";
            } else {
               SpotifyAuth.startAuth(() -> {
                  this.status = "Connected!";
                  this.loadQueue();
               }, () -> this.status = "Auth failed.");
            }
         }

         this.renderFooterClick(mx, my, px, py);
         return true;
      } else {
         int tabY = py + 44 + 4;
         int tw = 133;

         for (int i = 0; i < 3; i++) {
            int tx = px + 10 + i * 135;
            if (this.hov(mx, my, tx, tabY, tw, 22)) {
               if (i == 0 && this.tab != 0) {
                  this.tab = 0;
                  this.search = "";
                  this.loadQueue();
               } else if (i == 1 && this.tab != 1) {
                  this.tab = 1;
                  this.search = "";
                  if (PLAYLISTS_CACHE.isEmpty()) {
                     this.loadPlaylists();
                  } else {
                     this.rebuild();
                  }
               } else if (i == 2 && this.tab != 2 && selectedPlaylist != null) {
                  this.tab = 2;
                  this.search = "";
                  this.rebuild();
               }

               return true;
            }
         }

         if (this.renderFooterClick(mx, my, px, py)) {
            return true;
         } else {
            int lx = px + 10;
            int ly = this.listY();
            if (mx >= lx && mx < lx + 400 && my >= ly && my < ly + this.listH()) {
               int row = (my - ly) / 22 + this.scroll;
               if (row >= 0 && row < this.filtered.size()) {
                  Object item = this.filtered.get(row);
                  if (item instanceof SpotifyAPI.Track t) {
                     this.exec.submit(() -> {
                        boolean ok = SpotifyAPI.playTrack(t.uri);
                        if (!ok && selectedPlaylist != null) {
                           SpotifyAPI.playInContext("spotify:playlist:null", t.uri);
                        }

                        this.client.execute(() -> {
                           this.status = "Playing: " + t.name;
                           this.loadQueue();
                        });
                     });
                  } else if (item instanceof String[] pl) {
                     this.loadPlaylistTracks(pl[0], pl[1]);
                  }
               }

               return true;
            } else {
               return super.mouseClicked(click, bl);
            }
         }
      }
   }

   private boolean renderFooterClick(int mx, int my, int px, int py) {
      int btnY = py + 360 - 44 + 9;
      if (this.hov(mx, my, px + 420 - 10 - 64, btnY, 64, 26)) {
         this.client.setScreen(this.parent);
         return true;
      } else if (this.hov(mx, my, px + 10, btnY, 64, 26)) {
         this.exec.submit(SpotifyAPI::prev);
         return true;
      } else if (this.hov(mx, my, px + 10 + 68, btnY, 80, 26)) {
         this.exec.submit(SpotifyAPI::pause);
         return true;
      } else if (this.hov(mx, my, px + 10 + 152, btnY, 64, 26)) {
         this.exec.submit(SpotifyAPI::next);
         return true;
      } else {
         return false;
      }
   }

   public boolean charTyped(CharInput i) {
      String t = i.asString();
      if (t != null && !t.isEmpty()) {
         if (this.enteringClientId) {
            this.clientIdInput = this.clientIdInput + t;
         } else {
            this.search = this.search + t;
            this.rebuild();
         }

         return true;
      } else {
         return super.charTyped(i);
      }
   }

   public boolean keyPressed(KeyInput i) {
      if (i.getKeycode() != 259) {
         if (i.isEscape()) {
            this.client.setScreen(this.parent);
            return true;
         } else {
            return super.keyPressed(i);
         }
      } else {
         if (this.enteringClientId && !this.clientIdInput.isEmpty()) {
            this.clientIdInput = this.clientIdInput.substring(0, this.clientIdInput.length() - 1);
         } else if (!this.search.isEmpty()) {
            this.search = this.search.substring(0, this.search.length() - 1);
            this.rebuild();
         }

         return true;
      }
   }

   public boolean mouseScrolled(double mx, double my, double h, double v) {
      int lx = this.getInt3() + 10;
      int ly = this.listY();
      if (mx >= lx && mx < lx + 400 && my >= ly && my < ly + this.listH()) {
         this.scroll = Math.max(0, Math.min(this.maxScroll(), this.scroll + (v > 0.0 ? -1 : 1)));
         return true;
      } else {
         return super.mouseScrolled(mx, my, h, v);
      }
   }

   public boolean shouldPause() {
      return false;
   }

   public void renderBackground(DrawContext ctx, int mx, int my, float dt) {
   }

   private int alphaScale(int c, float a) {
      return Math.max(0, Math.min(255, (int)((c >> 24 & 0xFF) * a))) << 24 | c & 16777215;
   }

   private int col(int rgb, int alpha) {
      return Math.max(0, Math.min(255, alpha)) << 24 | rgb & 16777215;
   }

   private float easeOut(float t) {
      return 1.0F - (float)Math.pow(1.0F - Math.min(1.0F, t), 3.0);
   }

   private boolean hov(int mx, int my, int x, int y, int w, int h) {
      return mx >= x && mx <= x + w && my >= y && my <= y + h;
   }
}

