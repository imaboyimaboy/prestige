package dev.fakeranks.mixin;

import com.mojang.authlib.GameProfile;
import dev.fakeranks.FakeRanksClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.player.SkinTextures;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({PlayerListEntry.class})
public abstract class PlayerListEntryMixin {
   @Shadow
   public abstract GameProfile getProfile();

   @Inject(
      method = {"getSkinTextures"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 0
   )
   private void fakeranks$getSkinTextures(CallbackInfoReturnable<SkinTextures> info) {
      SkinTextures skin = FakeRanksClient.STATE.skinStealer().skin();
      if (FakeRanksClient.STATE.enabled() && skin != null) {
         GameProfile profile = this.getProfile();
         if (profile != null && FakeRanksClient.STATE.isLocalUuid(profile.id())) {
            info.setReturnValue(skin);
         }
      }
   }
}

