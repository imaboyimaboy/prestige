package rtx.kimiko.api.events.funtime;

import java.util.List;

public final class FunTimeEventsSnapshot {
   private List<FunTimeEvent> current;
   private List<FunTimeEvent> nearest;
   private long generatedAt;
   private boolean online;
   private String error;

   public FunTimeEventsSnapshot(List<FunTimeEvent> current, List<FunTimeEvent> nearest, long generatedAt, boolean online, String error) {
      this.current = current;
      this.nearest = nearest;
      this.generatedAt = generatedAt;
      this.online = online;
      this.error = error;
   }

   public static FunTimeEventsSnapshot offline(String string) {
      return new FunTimeEventsSnapshot(List.of(), List.of(), 0L, false, string);
   }

   public List<FunTimeEvent> current() {
      return this.current;
   }

   public List<FunTimeEvent> nearest() {
      return this.nearest;
   }

   public long generatedAt() {
      return this.generatedAt;
   }

   public boolean online() {
      return this.online;
   }

   public String error() {
      return this.error;
   }
}

