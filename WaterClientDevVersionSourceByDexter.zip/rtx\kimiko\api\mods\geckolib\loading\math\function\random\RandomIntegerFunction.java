package rtx.kimiko.api.mods.geckolib.loading.math.function.random;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import rtx.kimiko.api.mods.geckolib.animation.state.ControllerState;
import rtx.kimiko.api.mods.geckolib.loading.math.MathValue;
import rtx.kimiko.api.mods.geckolib.loading.math.function.MathFunction;

public final class RandomIntegerFunction extends MathFunction {
   private MathValue valueA;
   private MathValue valueB;
   private MathValue seed;
   private Random random;

   public RandomIntegerFunction(MathValue... mathValueArray) {
      super(mathValueArray);
      this.valueA = mathValueArray[0];
      this.valueB = mathValueArray.length >= 2 ? mathValueArray[1] : null;
      this.seed = mathValueArray.length >= 3 ? mathValueArray[2] : null;
      this.random = this.seed != null ? new Random() : null;
   }

   @Override
   public String getName() {
      return "math.random_integer";
   }

   @Override
   public double compute(ControllerState controllerState) {
      int n2 = (int)Math.round(this.valueA.get(controllerState));
      Random random;
      if (this.random != null && this.seed != null) {
         this.random.setSeed((long)this.seed.get(controllerState));
         random = this.random;
      } else {
         random = ThreadLocalRandom.current();
      }

      int n;
      if (this.valueB != null) {
         int n3 = (int)Math.round(this.valueB.get(controllerState));
         int n4 = Math.min(n2, n3);
         int n5 = Math.max(n2, n3);
         n = n4 + random.nextInt(n5 + 1 - n4);
      } else {
         n = random.nextInt(0, n2 + 1);
      }

      return n;
   }

   @Override
   public MathValue[] getArgs() {
      if (this.seed != null) {
         return new MathValue[]{this.valueA, this.valueB, this.seed};
      } else {
         return this.valueB != null ? new MathValue[]{this.valueA, this.valueB} : new MathValue[]{this.valueA};
      }
   }

   @Override
   public int getMinArgs() {
      return 1;
   }

   @Override
   public boolean isMutable(MathValue... mathValueArray) {
      return mathValueArray.length < 3 ? true : super.isMutable(mathValueArray);
   }
}

