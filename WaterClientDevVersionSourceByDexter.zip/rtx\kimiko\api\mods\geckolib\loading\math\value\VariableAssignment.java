package rtx.kimiko.api.mods.geckolib.loading.math.value;

import java.util.Set;
import rtx.kimiko.api.mods.geckolib.animation.state.ControllerState;
import rtx.kimiko.api.mods.geckolib.loading.math.MathValue;

public final class VariableAssignment implements MathValue {
   private Variable variable;
   private MathValue value;

   public VariableAssignment(Variable variable, MathValue value) {
      this.variable = variable;
      this.value = value;
   }

   @Override
   public double get(ControllerState state) {
      double v = this.value.get(state);
      if (state != null) {
         state.setVariable(this.variable, v);
      }

      return v;
   }

   @Override
   public Set<Variable> getUsedVariables() {
      return MathValue.collectUsedVariables(this.variable, this.value);
   }

   public Variable variable() {
      return this.variable;
   }

   public MathValue value() {
      return this.value;
   }
}

