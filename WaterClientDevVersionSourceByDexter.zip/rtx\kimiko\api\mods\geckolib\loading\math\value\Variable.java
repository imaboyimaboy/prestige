package rtx.kimiko.api.mods.geckolib.loading.math.value;

import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.ToDoubleFunction;
import rtx.kimiko.api.mods.geckolib.GeckoLibConstants;
import rtx.kimiko.api.mods.geckolib.animation.state.ControllerState;
import rtx.kimiko.api.mods.geckolib.loading.math.MathValue;

public final class Variable implements MathValue {
   private String name;
   private AtomicReference<ToDoubleFunction<ControllerState>> value;

   public Variable(String string, ToDoubleFunction<ControllerState> toDoubleFunction) {
      this(string, new AtomicReference<>(toDoubleFunction));
   }

   public Variable(String string, double d) {
      this(string, controllerState -> d);
   }

   public Variable(String name, AtomicReference<ToDoubleFunction<ControllerState>> value) {
      this.name = name;
      this.value = value;
   }

   @Override
   public int hashCode() {
      return this.name.hashCode();
   }

   @Override
   public double get(ControllerState controllerState) {
      try {
         return this.value.get().applyAsDouble(controllerState);
      } catch (Exception var3) {
         GeckoLibConstants.LOGGER
            .error("Attempted to use Molang variable for incompatible animatable type ({}). An animation json needs to be fixed", this.name);
         var3.printStackTrace();
         return 0.0;
      }
   }

   public void set(double d) {
      this.value.set(controllerState -> d);
   }

   public void set(ToDoubleFunction<ControllerState> toDoubleFunction) {
      this.value.set(toDoubleFunction);
   }

   @Override
   public Set<Variable> getUsedVariables() {
      return Set.of(this);
   }

   public String name() {
      return this.name;
   }

   public AtomicReference<ToDoubleFunction<ControllerState>> value() {
      return this.value;
   }
}

