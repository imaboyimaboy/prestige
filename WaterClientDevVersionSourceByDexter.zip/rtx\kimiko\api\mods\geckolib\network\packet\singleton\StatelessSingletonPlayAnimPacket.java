package rtx.kimiko.api.mods.geckolib.network.packet.singleton;

import java.util.function.Consumer;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.network.packet.CustomPayload.Id;
import rtx.kimiko.api.mods.geckolib.GeckoLibConstants;
import rtx.kimiko.api.mods.geckolib.animatable.GeoAnimatable;
import rtx.kimiko.api.mods.geckolib.animatable.stateless.StatelessGeoSingletonAnimatable;
import rtx.kimiko.api.mods.geckolib.animation.RawAnimation;
import rtx.kimiko.api.mods.geckolib.cache.SyncedSingletonAnimatableCache;
import rtx.kimiko.api.mods.geckolib.network.packet.MultiloaderPacket;

public final class StatelessSingletonPlayAnimPacket implements MultiloaderPacket {
   private String syncableId;
   private long instanceId;
   private RawAnimation animation;
   public static final Id<StatelessSingletonPlayAnimPacket> TYPE = new Id(GeckoLibConstants.id("stateless_singleton_play_anim"));
   public static final PacketCodec<PacketByteBuf, StatelessSingletonPlayAnimPacket> CODEC = PacketCodec.tuple(
      PacketCodecs.STRING,
      StatelessSingletonPlayAnimPacket::syncableId,
      PacketCodecs.VAR_LONG,
      StatelessSingletonPlayAnimPacket::instanceId,
      RawAnimation.STREAM_CODEC,
      StatelessSingletonPlayAnimPacket::animation,
      StatelessSingletonPlayAnimPacket::new
   );

   public StatelessSingletonPlayAnimPacket(String syncableId, long instanceId, RawAnimation animation) {
      this.syncableId = syncableId;
      this.instanceId = instanceId;
      this.animation = animation;
   }

   public Id<? extends CustomPayload> getId() {
      return TYPE;
   }

   @Override
   public void receiveMessage(PlayerEntity playerEntity, Consumer<Runnable> consumer) {
      consumer.accept(() -> {
         GeoAnimatable geoAnimatable = SyncedSingletonAnimatableCache.getSyncedAnimatable(this.syncableId);
         if (geoAnimatable instanceof StatelessGeoSingletonAnimatable statelessGeoSingletonAnimatable) {
            statelessGeoSingletonAnimatable.handleClientAnimationPlay(geoAnimatable, this.instanceId, this.animation);
         }
      });
   }

   public String syncableId() {
      return this.syncableId;
   }

   public long instanceId() {
      return this.instanceId;
   }

   public RawAnimation animation() {
      return this.animation;
   }
}

