package rtx.kimiko.api.mods.geckolib.animation.object;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import it.unimi.dsi.fastutil.doubles.Double2DoubleFunction;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.util.math.MathHelper;
import rtx.kimiko.api.mods.geckolib.animation.state.ControllerState;
import rtx.kimiko.api.mods.geckolib.animation.state.EasingState;
import rtx.kimiko.api.mods.geckolib.loading.math.MathValue;

public interface EasingType {
   Map<String, EasingType> EASING_TYPES = new ConcurrentHashMap<>(64);
   EasingType LINEAR = register("linear", register("none", d -> easeIn(EasingType::linear)));
   EasingType STEP = register("step", d -> easeIn(step(d)));
   EasingType EASE_IN_SINE = register("easeinsine", d -> easeIn(EasingType::sine));
   EasingType EASE_OUT_SINE = register("easeoutsine", d -> easeOut(EasingType::sine));
   EasingType EASE_IN_OUT_SINE = register("easeinoutsine", d -> easeInOut(EasingType::sine));
   EasingType EASE_IN_QUAD = register("easeinquad", d -> easeIn(EasingType::quadratic));
   EasingType EASE_OUT_QUAD = register("easeoutquad", d -> easeOut(EasingType::quadratic));
   EasingType EASE_IN_OUT_QUAD = register("easeinoutquad", d -> easeInOut(EasingType::quadratic));
   EasingType EASE_IN_CUBIC = register("easeincubic", d -> easeIn(EasingType::cubic));
   EasingType EASE_OUT_CUBIC = register("easeoutcubic", d -> easeOut(EasingType::cubic));
   EasingType EASE_IN_OUT_CUBIC = register("easeinoutcubic", d -> easeInOut(EasingType::cubic));
   EasingType EASE_IN_QUART = register("easeinquart", d -> easeIn(pow(4.0)));
   EasingType EASE_OUT_QUART = register("easeoutquart", d -> easeOut(pow(4.0)));
   EasingType EASE_IN_OUT_QUART = register("easeinoutquart", d -> easeInOut(pow(4.0)));
   EasingType EASE_IN_QUINT = register("easeinquint", d -> easeIn(pow(4.0)));
   EasingType EASE_OUT_QUINT = register("easeoutquint", d -> easeOut(pow(5.0)));
   EasingType EASE_IN_OUT_QUINT = register("easeinoutquint", d -> easeInOut(pow(5.0)));
   EasingType EASE_IN_EXPO = register("easeinexpo", d -> easeIn(EasingType::exp));
   EasingType EASE_OUT_EXPO = register("easeoutexpo", d -> easeOut(EasingType::exp));
   EasingType EASE_IN_OUT_EXPO = register("easeinoutexpo", d -> easeInOut(EasingType::exp));
   EasingType EASE_IN_CIRC = register("easeincirc", d -> easeIn(EasingType::circle));
   EasingType EASE_OUT_CIRC = register("easeoutcirc", d -> easeOut(EasingType::circle));
   EasingType EASE_IN_OUT_CIRC = register("easeinoutcirc", d -> easeInOut(EasingType::circle));
   EasingType EASE_IN_BACK = register("easeinback", d -> easeIn(back(d)));
   EasingType EASE_OUT_BACK = register("easeoutback", d -> easeOut(back(d)));
   EasingType EASE_IN_OUT_BACK = register("easeinoutback", d -> easeInOut(back(d)));
   EasingType EASE_IN_ELASTIC = register("easeinelastic", d -> easeIn(elastic(d)));
   EasingType EASE_OUT_ELASTIC = register("easeoutelastic", d -> easeOut(elastic(d)));
   EasingType EASE_IN_OUT_ELASTIC = register("easeinoutelastic", d -> easeInOut(elastic(d)));
   EasingType EASE_IN_BOUNCE = register("easeinbounce", d -> easeIn(bounce(d)));
   EasingType EASE_OUT_BOUNCE = register("easeoutbounce", d -> easeOut(bounce(d)));
   EasingType EASE_IN_OUT_BOUNCE = register("easeinoutbounce", d -> easeInOut(bounce(d)));
   EasingType CATMULLROM = register("catmullrom", new EasingType.CatmullRomEasing());

   static Double2DoubleFunction pow(double d) {
      return d2 -> Math.pow(d2, d);
   }

   static double exp(double d) {
      return Math.pow(2.0, 10.0 * (d - 1.0));
   }

   default double apply(EasingState easingState, ControllerState controllerState) {
      Double d = null;
      if (easingState.easingArgs().length != 0) {
         d = easingState.easingArgs()[0].get(controllerState);
      }

      return this.apply(easingState, d, easingState.delta(), controllerState);
   }

   default double apply(EasingState easingState, Double d, double d2, ControllerState controllerState) {
      return easingState.delta() >= 1.0
         ? easingState.toValue()
         : MathHelper.lerp((Double)this.buildTransformer(d).apply(d2), easingState.fromValue(), easingState.toValue());
   }

   static EasingType register(String string, EasingType easingType) {
      EASING_TYPES.putIfAbsent(string, easingType);
      return easingType;
   }

   static Double2DoubleFunction step(Double stepsArg) {
      double steps = stepsArg == null ? 2.0 : stepsArg;
      if (steps < 2.0) {
         throw new IllegalArgumentException("Steps must be >= 2, got: " + steps);
      } else {
         int n = (int)steps;
         return d -> {
            if (d < 0.0) {
               return 0.0;
            } else {
               double stepSize = 1.0 / n;
               double maxVal = (n - 1) * stepSize;
               if (d > 1.0) {
                  return maxVal;
               } else {
                  int n2 = 0;
                  int n3 = n - 1;

                  while (n3 - n2 != 1) {
                     int n4 = n2 + (n3 - n2) / 2;
                     if (d >= n4 * stepSize) {
                        n2 = n4;
                     } else {
                        n3 = n4;
                     }
                  }

                  return n2 * stepSize;
               }
            }
         };
      }
   }

   static Double2DoubleFunction back(Double d) {
      double d3 = d == null ? 1.70158 : d * 1.70158;
      return d2 -> d2 * d2 * ((d3 + 1.0) * d2 - d3);
   }

   static EasingType fromString(String string) {
      return EASING_TYPES.getOrDefault(string, LINEAR);
   }

   static double circle(double d) {
      return 1.0 - Math.sqrt(1.0 - d * d);
   }

   static Double2DoubleFunction elastic(Double d) {
      double d3 = d == null ? 1.0 : d;
      return d2 -> 1.0 - Math.pow(Math.cos(d2 * Math.PI / 2.0), 3.0) * Math.cos(d2 * d3 * Math.PI);
   }

   static double catmullRom(double d) {
      return 0.5 * (2.0 * (d + 1.0) + 2.0 + (2.0 * d - 5.0 * (d + 1.0) + 4.0 * (d + 2.0) - (d + 3.0)) + (3.0 * (d + 1.0) - d - 3.0 * (d + 2.0) + (d + 3.0)));
   }

   static Double2DoubleFunction easeIn(Double2DoubleFunction double2DoubleFunction) {
      return double2DoubleFunction;
   }

   static Double2DoubleFunction easeOut(Double2DoubleFunction double2DoubleFunction) {
      return d -> 1.0 - (Double)double2DoubleFunction.apply(1.0 - d);
   }

   static double cubic(double d) {
      return d * d * d;
   }

   static Double2DoubleFunction bounce(Double d3) {
      double d4 = d3 == null ? 0.5 : d3;
      Double2DoubleFunction double2DoubleFunction = d -> 7.5625 * d * d;
      Double2DoubleFunction double2DoubleFunction2 = d2 -> 30.25 * d4 * Math.pow(d2 - 0.54545456F, 2.0) + 1.0 - d4;
      Double2DoubleFunction double2DoubleFunction3 = d2 -> 121.0 * d4 * d4 * Math.pow(d2 - 0.8181818F, 2.0) + 1.0 - d4 * d4;
      Double2DoubleFunction double2DoubleFunction4 = d2 -> 484.0 * d4 * d4 * d4 * Math.pow(d2 - 0.95454544F, 2.0) + 1.0 - d4 * d4 * d4;
      return d -> Math.min(
         Math.min((Double)double2DoubleFunction.apply(d), (Double)double2DoubleFunction2.apply(d)),
         Math.min((Double)double2DoubleFunction3.apply(d), (Double)double2DoubleFunction4.apply(d))
      );
   }

   static double sine(double d) {
      return 1.0 - Math.cos(d * Math.PI / 2.0);
   }

   static Double2DoubleFunction easeInOut(Double2DoubleFunction double2DoubleFunction) {
      return d -> d < 0.5 ? (Double)double2DoubleFunction.apply(d * 2.0) / 2.0 : 1.0 - (Double)double2DoubleFunction.apply((1.0 - d) * 2.0) / 2.0;
   }

   static double quadratic(double d) {
      return d * d;
   }

   static double linear(double d) {
      return d;
   }

   static Double2DoubleFunction linear(Double2DoubleFunction double2DoubleFunction) {
      return double2DoubleFunction;
   }

   static EasingType fromJson(JsonElement jsonElement) {
      JsonPrimitive jsonPrimitive;
      return jsonElement instanceof JsonPrimitive && (jsonPrimitive = (JsonPrimitive)jsonElement).isString()
         ? fromString(jsonPrimitive.getAsString().toLowerCase(Locale.ROOT))
         : LINEAR;
   }

   static Double2DoubleFunction stepPositive(Double2DoubleFunction double2DoubleFunction) {
      return d -> d > 0.0 ? 1.0 : 0.0;
   }

   static double lerpWithOverride(EasingState easingState, ControllerState controllerState) {
      return easingState.easingType().apply(easingState, controllerState);
   }

   static Double2DoubleFunction stepNonNegative(Double2DoubleFunction double2DoubleFunction) {
      return d -> d >= 0.0 ? 1.0 : 0.0;
   }

   Double2DoubleFunction buildTransformer(Double var1);

   public class CatmullRomEasing implements EasingType {
      @Override
      public double apply(EasingState easingState, Double d, double d2, ControllerState controllerState) {
         if (easingState.delta() >= 1.0) {
            return easingState.toValue();
         } else {
            MathValue[] mathValueArray = easingState.easingArgs();
            return mathValueArray.length < 2
               ? MathHelper.lerp((Double)this.buildTransformer(d).apply(d2), easingState.fromValue(), easingState.toValue())
               : getPointOnSpline(
                  d2, mathValueArray[0].get(controllerState), easingState.fromValue(), easingState.toValue(), mathValueArray[1].get(controllerState)
               );
         }
      }

      @Override
      public Double2DoubleFunction buildTransformer(Double d) {
         return EasingType.easeInOut(EasingType::catmullRom);
      }

      public static double getPointOnSpline(double d, double d2, double d3, double d4, double d5) {
         return 0.5 * (2.0 * d3 + (d4 - d2) * d + (2.0 * d2 - 5.0 * d3 + 4.0 * d4 - d5) * d * d + (3.0 * d3 - d2 - 3.0 * d4 + d5) * d * d * d);
      }
   }
}

