package dev.fakeranks;

import java.util.List;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;

public enum FakeRank {
   NONE("None", "", 16777215, false),
   PLUS("+", "+", 41727, false),
   PLUS_PLUS("++", "++", 41727, false),
   PLUS_PLUS_PLUS("+++", "+++", 41727, false);

   private static final List<FakeRank> CYCLE = List.of(values());
   private String label;
   private String display;
   private int color;
   private boolean bold;

   private FakeRank(String label, String display, int color, boolean bold) {
      this.label = label;
      this.display = display;
      this.color = color;
      this.bold = bold;
   }

   public FakeRank next() {
      return CYCLE.get((this.ordinal() + 1) % CYCLE.size());
   }

   public String buttonLabel() {
      return "Rank: " + this.label;
   }

   public boolean visible() {
      return this != NONE;
   }

   public MutableText asText() {
      return Text.literal(this.display).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(this.color)).withBold(this.bold));
   }

   public String asLegacy() {
      return !this.visible() ? "" : FormattingUtil.legacyHex(this.color) + (this.bold ? "§l" : "") + this.display;
   }

   private static FakeRank[] $values() {
      return new FakeRank[]{NONE, PLUS, PLUS_PLUS, PLUS_PLUS_PLUS};
   }
}

