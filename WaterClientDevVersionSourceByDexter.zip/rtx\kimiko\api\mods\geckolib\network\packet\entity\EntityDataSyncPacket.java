package rtx.kimiko.api.mods.geckolib.network.packet.entity;

import java.util.function.Consumer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.network.packet.CustomPayload.Id;
import net.minecraft.world.World;
import rtx.kimiko.api.mods.geckolib.GeckoLibConstants;
import rtx.kimiko.api.mods.geckolib.animatable.GeoEntity;
import rtx.kimiko.api.mods.geckolib.animatable.GeoReplacedEntity;
import rtx.kimiko.api.mods.geckolib.constant.dataticket.SerializableDataTicket;
import rtx.kimiko.api.mods.geckolib.network.packet.MultiloaderPacket;
import rtx.kimiko.api.mods.geckolib.util.ClientUtil;
import rtx.kimiko.api.mods.geckolib.util.RenderUtil;

public final class EntityDataSyncPacket<D> implements MultiloaderPacket {
   private int entityId;
   private boolean replacedEntity;
   private SerializableDataTicket<D> dataTicket;
   private D data;
   public static final Id<EntityDataSyncPacket<?>> TYPE = new Id(GeckoLibConstants.id("entity_data_sync"));
   public static final PacketCodec<RegistryByteBuf, EntityDataSyncPacket<?>> CODEC = PacketCodec.ofStatic(
      (registryByteBuf, entityDataSyncPacket) -> {
         SerializableDataTicket.STREAM_CODEC.encode(registryByteBuf, entityDataSyncPacket.dataTicket);
         registryByteBuf.writeVarInt(entityDataSyncPacket.entityId);
         registryByteBuf.writeBoolean(entityDataSyncPacket.replacedEntity);
         ((PacketCodec<RegistryByteBuf, Object>)(Object)entityDataSyncPacket.dataTicket.streamCodec()).encode(registryByteBuf, entityDataSyncPacket.data);
      },
      registryByteBuf -> {
         SerializableDataTicket serializableDataTicket = (SerializableDataTicket)SerializableDataTicket.STREAM_CODEC.decode(registryByteBuf);
         return new EntityDataSyncPacket<>(
            registryByteBuf.readVarInt(), registryByteBuf.readBoolean(), serializableDataTicket, serializableDataTicket.streamCodec().decode(registryByteBuf)
         );
      }
   );

   public EntityDataSyncPacket(int entityId, boolean isReplacedEntity, SerializableDataTicket<D> dataTicket, D data) {
      this.entityId = entityId;
      this.replacedEntity = isReplacedEntity;
      this.dataTicket = dataTicket;
      this.data = data;
   }

   public Id<? extends CustomPayload> getId() {
      return TYPE;
   }

   @Override
   public void receiveMessage(PlayerEntity playerEntity, Consumer<Runnable> consumer) {
      consumer.accept(() -> {
         World world = ClientUtil.getLevel();
         Entity entity;
         if (world != null && (entity = world.getEntityById(this.entityId)) != null) {
            if (!this.replacedEntity) {
               if (entity instanceof GeoEntity geoEntity) {
                  geoEntity.setAnimData(this.dataTicket, this.data);
               }
            } else {
               if (RenderUtil.getReplacedAnimatable(entity.getType()) instanceof GeoReplacedEntity geoReplacedEntity) {
                  geoReplacedEntity.setAnimData(entity, this.dataTicket, this.data);
               }
            }
         }
      });
   }

   public int entityId() {
      return this.entityId;
   }

   public boolean isReplacedEntity() {
      return this.replacedEntity;
   }

   public SerializableDataTicket<D> dataTicket() {
      return this.dataTicket;
   }

   public D data() {
      return this.data;
   }
}

