package rtx.kimiko.api.events.impl.input;

import rtx.kimiko.api.events.CancellableEvent;

public final class MouseButtonEvent extends CancellableEvent {
   public int button;
   public int modifiers;
   public MouseButtonEvent.Action action;

   public MouseButtonEvent(int n, int n2, MouseButtonEvent.Action action) {
      this.button = n;
      this.modifiers = n2;
      this.action = action;
   }

   public enum Action {
      PRESS,
      RELEASE;

      public static MouseButtonEvent.Action mouseButtonEventActionOf(int n) {
         return n == 1 ? PRESS : RELEASE;
      }

      private static MouseButtonEvent.Action[] $values() {
         return new MouseButtonEvent.Action[]{PRESS, RELEASE};
      }
   }
}

