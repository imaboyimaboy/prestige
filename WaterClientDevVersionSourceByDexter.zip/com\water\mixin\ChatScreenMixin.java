package com.water.mixin;

import com.water.gui.HudEditor;
import com.water.gui.hud.SpotifyQueueHud;
import com.water.module.modules.client.SpotifyHud;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({ChatScreen.class})
public class ChatScreenMixin {
   @Inject(
      method = {"mouseClicked"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void water$mouseClicked(Click click, boolean bl, CallbackInfoReturnable<Boolean> cir) {
      double mouseX = click.x();
      double mouseY = click.y();
      int button = click.button();
      if (button == 0) {
         if (SpotifyHud.handleClick(mouseX, mouseY, button)) {
            cir.setReturnValue(true);
            return;
         }

         if (SpotifyQueueHud.onMouseClick(mouseX, mouseY, button)) {
            cir.setReturnValue(true);
            return;
         }

         if (HudEditor.INSTANCE.onMouseClick(mouseX, mouseY, button)) {
            HudEditor.isEditing = true;
            cir.setReturnValue(true);
         }
      } else if (button == 1 && SpotifyHud.handleClick(mouseX, mouseY, button)) {
         cir.setReturnValue(true);
      }
   }

   @Inject(
      method = {"render"},
      at = {@At("TAIL")}
   )
   private void water$render(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc != null) {
         boolean leftHeld = GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), 0) == 1;
         if (!leftHeld) {
            SpotifyQueueHud.onMouseRelease();
            HudEditor.INSTANCE.onMouseRelease();
            HudEditor.isEditing = false;
         }
      }

      HudEditor.INSTANCE.render(context, mouseX, mouseY);
   }
}

