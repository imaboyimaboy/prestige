package rtx.kimiko.api.mods.geckolib.loading.math.value;

import java.util.Set;
import rtx.kimiko.api.mods.geckolib.animation.state.ControllerState;
import rtx.kimiko.api.mods.geckolib.loading.math.MathValue;

public final class Ternary implements MathValue {
   private MathValue condition;
   private MathValue trueValue;
   private MathValue falseValue;

   public Ternary(MathValue condition, MathValue trueValue, MathValue falseValue) {
      this.condition = condition;
      this.trueValue = trueValue;
      this.falseValue = falseValue;
   }

   @Override
   public double get(ControllerState state) {
      return this.condition.get(state) != 0.0 ? this.trueValue.get(state) : this.falseValue.get(state);
   }

   @Override
   public Set<Variable> getUsedVariables() {
      return MathValue.collectUsedVariables(this.condition, this.trueValue, this.falseValue);
   }

   public MathValue condition() {
      return this.condition;
   }

   public MathValue trueValue() {
      return this.trueValue;
   }

   public MathValue falseValue() {
      return this.falseValue;
   }
}

