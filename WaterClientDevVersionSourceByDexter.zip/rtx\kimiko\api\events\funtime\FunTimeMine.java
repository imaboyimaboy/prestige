package rtx.kimiko.api.events.funtime;

public final class FunTimeMine {
   private String serverId;
   private String serverRuName;
   private String mineName;
   private String rarity;
   private String nextRarity;
   private long refillAtMs;
   public static final String RARITY_DEFAULT = "default";
   public static final String RARITY_MYTHICAL = "mythical";
   public static final String RARITY_LEGENDARY = "legendary";

   public FunTimeMine(String serverId, String serverRuName, String mineName, String rarity, String nextRarity, long refillAtMs) {
      this.serverId = serverId;
      this.serverRuName = serverRuName;
      this.mineName = mineName;
      this.rarity = rarity;
      this.nextRarity = nextRarity;
      this.refillAtMs = refillAtMs;
   }

   public String serverId() {
      return this.serverId;
   }

   public String serverRuName() {
      return this.serverRuName;
   }

   public String mineName() {
      return this.mineName;
   }

   public String rarity() {
      return this.rarity;
   }

   public String nextRarity() {
      return this.nextRarity;
   }

   public long refillAtMs() {
      return this.refillAtMs;
   }
}

