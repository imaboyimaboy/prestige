package rtx.kimiko.api.chat.irc;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.text.ClickEvent.SuggestCommand;
import net.minecraft.text.HoverEvent.ShowText;
import net.minecraft.util.Formatting;
import rtx.kimiko.api.chat.commands.CommandManager;
import rtx.kimiko.utils.net.Endpoints;
import rtx.kimiko.utils.profile.ProfileIdentity;
import rtx.kimiko.utils.storage.RepositoryStorage;
import rtx.kimiko.utils.string.chat.helper.TextHelper;

public final class IrcClient {
   public static final IrcClient INSTANCE = new IrcClient();
   private static final long POLL_MS = 50L;
   private static final String STORE = "irc";
   private final HttpClient httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(1L)).build();
   private final AtomicLong lastId = new AtomicLong(0L);
   private ScheduledExecutorService executor;
   private volatile boolean connected;
   private volatile boolean primed;
   private volatile int online;
   private volatile IrcPrefix prefix;
   private final Set<String> blocked = ConcurrentHashMap.newKeySet();
   private volatile boolean blockedLoaded;

   private IrcClient() {
   }

   public IrcPrefix prefix() {
      if (this.prefix == null) {
         this.loadPrefix();
      }

      return this.prefix;
   }

   public synchronized void start() {
      if (this.executor == null) {
         this.loadPrefix();
         this.lastId.set(0L);
         this.primed = false;
         this.executor = Executors.newSingleThreadScheduledExecutor(runnable -> {
            Thread thread = new Thread(runnable, "kimiko-irc");
            thread.setDaemon(true);
            return thread;
         });
         this.executor.scheduleWithFixedDelay(this::poll, 0L, 50L, TimeUnit.MILLISECONDS);
      }
   }

   public boolean unblock(String string) {
      if (string != null && !string.isBlank()) {
         this.ensureBlockedLoaded();
         boolean bl = this.blocked.remove(string.trim().toLowerCase());
         if (bl) {
            this.saveStore();
         }

         return bl;
      } else {
         return false;
      }
   }

   public boolean block(String string) {
      if (string != null && !string.isBlank()) {
         this.ensureBlockedLoaded();
         boolean bl = this.blocked.add(string.trim().toLowerCase());
         if (bl) {
            this.saveStore();
         }

         return bl;
      } else {
         return false;
      }
   }

   private void poll() {
      try {
         String string = URLEncoder.encode(this.effectiveName(), StandardCharsets.UTF_8);
         URI uRI = URI.create(Endpoints.irc() + "/api/messages?since=" + this.lastId.get() + "&me=" + string);
         HttpRequest httpRequest = HttpRequest.newBuilder(uRI).timeout(Duration.ofSeconds(2L)).header("Accept", "application/json").GET().build();
         HttpResponse<String> httpResponse = this.httpClient.send(httpRequest, BodyHandlers.ofString());
         if (httpResponse.statusCode() != 200) {
            this.connected = false;
            return;
         }

         JsonObject jsonObject = JsonParser.parseString(httpResponse.body()).getAsJsonObject();
         boolean bl = this.connected;
         this.connected = true;
         this.online = (int)number(jsonObject, "online", 0L);
         if (!bl) {
            this.statusLine("подключено", Formatting.GREEN);
         }

         if (!this.primed) {
            this.lastId.set(number(jsonObject, "latest", 0L));
            this.primed = true;
            return;
         }

         JsonElement jsonElement = jsonObject.get("messages");
         if (jsonElement == null || !jsonElement.isJsonArray()) {
            return;
         }

         long l = this.lastId.get();

         for (JsonElement jsonElement2 : jsonElement.getAsJsonArray()) {
            JsonObject jsonObject2;
            long l2;
            if (jsonElement2.isJsonObject() && (l2 = number(jsonObject2 = jsonElement2.getAsJsonObject(), "id", 0L)) > 0L) {
               IrcMessage ircMessage = new IrcMessage(
                  l2,
                  number(jsonObject2, "ts", System.currentTimeMillis()),
                  string(jsonObject2, "user", "Player"),
                  string(jsonObject2, "prefix", ""),
                  string(jsonObject2, "text", ""),
                  string(jsonObject2, "to", "")
               );
               boolean bl2 = this.isBlocked(ircMessage.user()) && !this.isMe(ircMessage.user());
               if (!bl2 && !ircMessage.text().isBlank()) {
                  this.display(ircMessage);
               }

               if (l2 > l) {
                  l = l2;
               }
            }
         }

         this.lastId.set(l);
      } catch (InterruptedException var18) {
         Thread.currentThread().interrupt();
      } catch (Exception var19) {
         this.connected = false;
      }
   }

   private static String string(JsonObject jsonObject, String string, String string2) {
      JsonElement jsonElement = jsonObject.get(string);
      return jsonElement != null && jsonElement.isJsonPrimitive() ? jsonElement.getAsString() : string2;
   }

   private void display(IrcMessage ircMessage) {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      minecraftClient.execute(() -> {
         if (minecraftClient.player != null) {
            minecraftClient.player.sendMessage(ircMessage.isPrivate() ? this.privateLine(ircMessage) : this.publicLine(ircMessage), false);
         }
      });
   }

   private static long number(JsonObject jsonObject, String string, long l) {
      JsonElement jsonElement = jsonObject.get(string);
      return jsonElement != null && jsonElement.isJsonPrimitive() && jsonElement.getAsJsonPrimitive().isNumber() ? jsonElement.getAsLong() : l;
   }

   public synchronized void stop() {
      if (this.executor != null) {
         this.executor.shutdownNow();
         this.executor = null;
         this.connected = false;
         this.primed = false;
         this.online = 0;
      }
   }

   public boolean isBlocked(String string) {
      if (string != null && !string.isBlank()) {
         this.ensureBlockedLoaded();
         return this.blocked.contains(string.trim().toLowerCase());
      } else {
         return false;
      }
   }

   private void loadPrefix() {
      try {
         JsonObject jsonObject = RepositoryStorage.readObject("irc");
         this.prefix = jsonObject.has("prefix") ? IrcPrefix.fromId(jsonObject.get("prefix").getAsString()) : IrcPrefix.NONE;
      } catch (Exception var2) {
         this.prefix = IrcPrefix.NONE;
      }
   }

   private boolean isMe(String string) {
      return string != null && string.equalsIgnoreCase(this.effectiveName());
   }

   private MutableText publicLine(IrcMessage ircMessage) {
      MutableText mutableText = brand();
      mutableText.append(IrcPrefix.fromId(ircMessage.prefix()).component());
      mutableText.append(nick(ircMessage.user()));
      mutableText.append(Text.literal(" → ").formatted(Formatting.DARK_GRAY));
      mutableText.append(Text.literal(ircMessage.text()).formatted(Formatting.GRAY));
      return mutableText;
   }

   private void saveStore() {
      this.ensureBlockedLoaded();
      JsonObject jsonObject = new JsonObject();
      jsonObject.addProperty("prefix", this.prefix == null ? IrcPrefix.NONE.id() : this.prefix.id());
      JsonArray jsonArray = new JsonArray();

      for (String string : this.blocked) {
         jsonArray.add(string);
      }

      jsonObject.add("blocked", jsonArray);
      RepositoryStorage.write("irc", jsonObject);
   }

   private static MutableText meLabel() {
      return Text.literal("я").formatted(Formatting.WHITE);
   }

   public boolean isConnected() {
      return this.connected;
   }

   public boolean isRunning() {
      return this.executor != null;
   }

   public static MutableText brand() {
      return (MutableText)TextHelper.applyPredefinedGradient("[IRC] ", "orange_white", false);
   }

   public void setPrefix(IrcPrefix ircPrefix) {
      this.prefix = ircPrefix == null ? IrcPrefix.NONE : ircPrefix;
      this.saveStore();
   }

   private void statusLine(String string, Formatting formatting) {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      minecraftClient.execute(() -> {
         if (minecraftClient.player != null) {
            minecraftClient.player.sendMessage(brand().append(Text.literal(string).formatted(formatting)), false);
         }
      });
   }

   private void ensureBlockedLoaded() {
      if (!this.blockedLoaded) {
         Set<String> set = this.blocked;
         synchronized (set) {
            if (!this.blockedLoaded) {
               try {
                  JsonObject jsonObject = RepositoryStorage.readObject("irc");
                  if (jsonObject.has("blocked") && jsonObject.get("blocked").isJsonArray()) {
                     for (JsonElement jsonElement : jsonObject.getAsJsonArray("blocked")) {
                        String string;
                        if (jsonElement.isJsonPrimitive() && !(string = jsonElement.getAsString().trim().toLowerCase()).isEmpty()) {
                           this.blocked.add(string);
                        }
                     }
                  }
               } catch (Exception var8) {
               }

               this.blockedLoaded = true;
            }
         }
      }
   }

   public List<String> blockedNames() {
      this.ensureBlockedLoaded();
      ArrayList<String> arrayList = new ArrayList<>(new LinkedHashSet<>(this.blocked));
      arrayList.sort(String.CASE_INSENSITIVE_ORDER);
      return arrayList;
   }

   private static String serverError(String string, int n) {
      try {
         JsonObject jsonObject = JsonParser.parseString(string).getAsJsonObject();
         String string2;
         if (jsonObject.has("error") && jsonObject.get("error").isJsonPrimitive() && !(string2 = jsonObject.get("error").getAsString().trim()).isEmpty()) {
            return string2;
         }
      } catch (Exception var4) {
      }

      return "Не отправлено (HTTP " + n + ")";
   }

   private MutableText privateLine(IrcMessage ircMessage) {
      boolean bl = this.isMe(ircMessage.user());
      MutableText mutableText = bl ? meLabel() : nick(ircMessage.user());
      MutableText mutableText2 = bl ? nick(ircMessage.to()) : meLabel();
      MutableText mutableText3 = brand();
      mutableText3.append(IrcPrefix.fromId(ircMessage.prefix()).component());
      mutableText3.append(Text.literal("[").formatted(Formatting.LIGHT_PURPLE));
      mutableText3.append(mutableText);
      mutableText3.append(Text.literal(" → ").formatted(Formatting.LIGHT_PURPLE));
      mutableText3.append(mutableText2);
      mutableText3.append(Text.literal("] ").formatted(Formatting.LIGHT_PURPLE));
      mutableText3.append(Text.literal(ircMessage.text()).formatted(Formatting.GRAY));
      return mutableText3;
   }

   public String effectiveName() {
      String string = "User";
      String var10000 = "User";
      return "User";
   }

   private void notifyError(String string) {
      this.statusLine(string, Formatting.RED);
   }

   public void send(String string) {
      this.send(string, null);
   }

   public void send(String string, String string2) {
      if (string != null && !string.isBlank()) {
         String string3 = this.effectiveName();
         String string4 = this.prefix().id();
         String string5 = string2 == null ? "" : string2.trim();
         Thread thread = new Thread(
            () -> {
               try {
                  JsonObject jsonObject = new JsonObject();
                  jsonObject.addProperty("user", string3);
                  jsonObject.addProperty("prefix", string4);
                  jsonObject.addProperty("text", string);
                  int n = ProfileIdentity.uid();
                  if (n > 0) {
                     jsonObject.addProperty("uid", n);
                  }

                  if (!string5.isEmpty()) {
                     jsonObject.addProperty("to", string5);
                  }

                  HttpResponse<String> httpResponse;
                  if ((httpResponse = this.httpClient
                           .send(
                              HttpRequest.newBuilder(URI.create(Endpoints.irc() + "/api/send"))
                                 .timeout(Duration.ofSeconds(2L))
                                 .header("Content-Type", "application/json")
                                 .POST(BodyPublishers.ofString(jsonObject.toString(), StandardCharsets.UTF_8))
                                 .build(),
                              BodyHandlers.ofString()
                           ))
                        .statusCode()
                     != 200) {
                     this.notifyError(serverError(httpResponse.body(), httpResponse.statusCode()));
                  }
               } catch (InterruptedException var9) {
                  Thread.currentThread().interrupt();
               } catch (Exception var10) {
                  this.notifyError("Чат недоступен (запусти сервер в Desktop/Irc)");
               }
            },
            "kimiko-irc-send"
         );
         thread.setDaemon(true);
         thread.start();
      }
   }

   public int online() {
      return this.online;
   }

   private static MutableText nick(String string) {
      String string2 = CommandManager.get().getPrefix();
      return Text.literal(string)
         .styled(
            style -> style.withColor(Formatting.WHITE)
               .withClickEvent(new SuggestCommand("nullirc pm null "))
               .withHoverEvent(new ShowText(Text.literal("Написать null").formatted(Formatting.GRAY)))
         );
   }
}

