package dev.fakeranks;

import java.util.List;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;

public enum FakeStaffBadge {
   NONE("None", "", 16777215),
   STAFF("Staff", "★", 4980794),
   DEV("Dev", "★", 9699583),
   OWNER("Owner", "★", 41727);

   private static final List<FakeStaffBadge> CYCLE = List.of(values());
   private String label;
   private String display;
   private int color;

   private FakeStaffBadge(String label, String display, int color) {
      this.label = label;
      this.display = display;
      this.color = color;
   }

   public FakeStaffBadge next() {
      return CYCLE.get((this.ordinal() + 1) % CYCLE.size());
   }

   public String buttonLabel() {
      return "Staff: " + this.label;
   }

   public boolean visible() {
      return this != NONE;
   }

   public MutableText asText() {
      return Text.literal(this.display).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(this.color)).withBold(false));
   }

   private static FakeStaffBadge[] $values() {
      return new FakeStaffBadge[]{NONE, STAFF, DEV, OWNER};
   }
}

