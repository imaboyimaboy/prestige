package rtx.kimiko.api.mods.geckolib.loading.json.raw;

import com.google.gson.JsonDeserializer;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import net.minecraft.util.JsonHelper;
import net.minecraft.util.math.MathHelper;
import rtx.kimiko.api.mods.geckolib.GeckoLibConstants;
import rtx.kimiko.api.mods.geckolib.util.JsonUtil;

public final class FaceUV {
   private String materialInstance;
   private double[] doubleArray;
   private double[] uvSize;
   private FaceUV.Rotation rotation;

   public FaceUV(String materialInstance, double[] uv, double[] uvSize, FaceUV.Rotation rotation) {
      this.materialInstance = materialInstance;
      this.doubleArray = uv;
      this.uvSize = uvSize;
      this.rotation = rotation;
   }

   public FaceUV.Rotation uvRotation() {
      return this.rotation;
   }

   public static JsonDeserializer<FaceUV> deserializer() throws JsonParseException {
      return (jsonElement, type, jsonDeserializationContext) -> {
         JsonObject jsonObject = jsonElement.getAsJsonObject();
         String string = JsonHelper.getString(jsonObject, "material_instance", null);
         double[] dArray = JsonUtil.jsonArrayToDoubleArray(JsonHelper.getArray(jsonObject, "uv", null));
         double[] dArray2 = JsonUtil.jsonArrayToDoubleArray(JsonHelper.getArray(jsonObject, "uv_size", null));
         FaceUV.Rotation rotation = FaceUV.Rotation.fromValue(JsonHelper.getInt(jsonObject, "uv_rotation", 0));
         return new FaceUV(string, dArray, dArray2, rotation);
      };
   }

   public String materialInstance() {
      return this.materialInstance;
   }

   public double[] getDoubleArray() {
      return this.doubleArray;
   }

   public double[] uvSize() {
      return this.uvSize;
   }

   public FaceUV.Rotation rotation() {
      return this.rotation;
   }

   public enum Rotation {
      NONE,
      CLOCKWISE_90,
      CLOCKWISE_180,
      CLOCKWISE_270;

      public static FaceUV.Rotation fromValue(int n) throws JsonParseException {
         try {
            return values()[n % 360 / 90];
         } catch (Exception var2) {
            GeckoLibConstants.LOGGER.error("Invalid Face UV rotation: {}", n);
            return fromValue(MathHelper.floor(Math.abs(n) / 90.0F) * 90);
         }
      }

      public float[] rotateUvs(float f, float f2, float f3, float f4) {
         float[] fArray;
         switch (this) {
            case NONE:
               float[] fArray2 = new float[8];
               fArray2[0] = f;
               fArray2[1] = f2;
               fArray2[2] = f3;
               fArray2[3] = f2;
               fArray2[4] = f3;
               fArray2[5] = f4;
               fArray2[6] = f;
               fArray = fArray2;
               fArray2[7] = f4;
               break;
            case CLOCKWISE_90:
               float[] fArray3 = new float[8];
               fArray3[0] = f3;
               fArray3[1] = f2;
               fArray3[2] = f3;
               fArray3[3] = f4;
               fArray3[4] = f;
               fArray3[5] = f4;
               fArray3[6] = f;
               fArray = fArray3;
               fArray3[7] = f2;
               break;
            case CLOCKWISE_180:
               float[] fArray4 = new float[8];
               fArray4[0] = f3;
               fArray4[1] = f4;
               fArray4[2] = f;
               fArray4[3] = f4;
               fArray4[4] = f;
               fArray4[5] = f2;
               fArray4[6] = f3;
               fArray = fArray4;
               fArray4[7] = f2;
               break;
            case CLOCKWISE_270:
               float[] fArray5 = new float[]{f, f4, f, f2, f3, f2, f3, 0.0F};
               fArray = fArray5;
               fArray5[7] = f4;
               break;
            default:
               throw new MatchException(null, null);
         }

         return fArray;
      }

      private static FaceUV.Rotation[] $values() {
         return new FaceUV.Rotation[]{NONE, CLOCKWISE_90, CLOCKWISE_180, CLOCKWISE_270};
      }
   }
}

