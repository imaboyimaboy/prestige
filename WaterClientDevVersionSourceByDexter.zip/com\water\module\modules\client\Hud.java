package com.water.module.modules.client;

import com.water.module.Category;
import com.water.module.Module;
import com.water.module.ModuleManager;
import com.water.module.modules.donut.StaffDetector;
import com.water.setting.Setting;
import com.water.utils.KeyNameUtil;
import com.water.utils.renderer.AwtFontRenderer;
import com.water.utils.renderer.RenderUtil;
import com.water.utils.renderer.blur.KawasePipeline;
import java.awt.Color;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.texture.AbstractTexture;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import rtx.kimiko.api.ui.UI;

public final class Hud extends Module {
   private static Hud INSTANCE;
   private final Setting<Boolean> watermark = new Setting<>("Watermark", true);
   private final Setting<Boolean> coordinates = new Setting<>("Coordinates", true);
   private final Setting<Boolean> info = new Setting<>("Info", true);
   private final Setting<Boolean> moduleList = new Setting<>("Module List", true);
   private final Setting<Boolean> potionEffects = new Setting<>("Potion Effects", true);
   private final Setting<Boolean> armor = new Setting<>("Armor", true);
   private final Setting<Boolean> keybinds = new Setting<>("Keybinds", true);
   private final Setting<Boolean> notifications = new Setting<>("Notifications", true);
   private final Setting<Boolean> radar = new Setting<>("Radar", true);
   private final Setting<Boolean> spotifyQueue = new Setting<>("Spotify Queue", true);
   private final Setting<Float> opacity = new Setting<>("Opacity", 0.8F, 0.0F, 1.0F);
   private final Setting<Boolean> rainbow = new Setting<>("Rainbow", false);
   private final Setting<Float> rainbowSpeed = new Setting<>("Rainbow Speed", 2.0F, 0.1F, 10.0F);
   private final Setting<Integer> radarSize = new Setting<>("Radar Size", 110, 60, 200);
   private final Setting<Integer> radarRange = new Setting<>("Radar Range", 64, 16, 128);
   private final Setting<Boolean> radarPlayers = new Setting<>("Radar Players", true);
   private final Setting<Boolean> radarHostile = new Setting<>("Radar Hostile", false);
   private final Setting<Boolean> radarPassive = new Setting<>("Radar Passive", false);
   private final Setting<Boolean> radarRotate = new Setting<>("Radar Rotate", true);
   private final Setting<Float> hudScale = new Setting<>("HUD Scale", 1.0F, 0.5F, 3.0F);
   private static final Color PRIMARY = new Color(65, 185, 255, 255);
   private static final int BG_RGB = 2302755;
   private static Color cachedAccent = new Color(65, 185, 255);
   private static Matrix4f cachedMatrix = new Matrix4f();
   private static long lastFrameMs = 0L;
   private static List<Entity> cachedEntities = new ArrayList<>();
   private static long lastEntityScanMs = 0L;
   private static final long ENTITY_SCAN_INTERVAL = 100L;
   private static final EnumMap<Hud.HudElement, int[]> positions = new EnumMap<>(Hud.HudElement.class);
   private static final EnumMap<Hud.HudElement, Float> elementScales = new EnumMap<>(Hud.HudElement.class);
   private static final int _lc8d9e118640 = 0;
   private static final Map<Identifier, Identifier> HEAD_CACHE;
   private static final Set<Identifier> HEAD_PENDING;
   private static int headCacheCounter;

   public static int[] getElementPos(Hud.HudElement el) {
      return positions.computeIfAbsent(el, Hud::defaultPos);
   }

   public static void setElementPos(Hud.HudElement el, int x, int y) {
      positions.put(el, new int[]{x, y});
      ModuleManager.INSTANCE.onSettingChanged();
   }

   public static float getElementScale(Hud.HudElement el) {
      return el == Hud.HudElement.SPOTIFY_HUD ? SpotifyHud.getScale() : elementScales.getOrDefault(el, 1.0F);
   }

   public static void setElementScale(Hud.HudElement el, float scale) {
      if (el == Hud.HudElement.SPOTIFY_HUD) {
         SpotifyHud.setScale(Math.max(0.5F, Math.min(3.0F, scale)));
      } else {
         elementScales.put(el, Math.max(0.5F, Math.min(3.0F, scale)));
      }

      ModuleManager.INSTANCE.onSettingChanged();
   }

   public static int getElementW(Hud.HudElement el) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null) {
         return 100;
      } else {
         return switch (el) {
            case WATERMARK -> intOf("Water +") + 20;
            case COORDINATES -> intOf("XYZ: -00000 / -256 / -00000") + 14;
            case INFO -> intOf("999 FPS  •  999 ms  •  23:59:59") + 14;
            case MODULE_LIST -> 120;
            case POTION_EFFECTS -> 110;
            case ARMOR -> intOf(" 100%") + 22;
            case KEYBINDS -> 120;
            case SPOTIFY_HUD -> SpotifyHud.getCardW();
            case RADAR -> INSTANCE != null ? INSTANCE.radarSize.getValue() : 110;
            case STAFF_LIST -> 180;
            case REGION_MAP -> 168;
         };
      }
   }

   public static int[] getElementBounds(Hud.HudElement el) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc != null && mc.player != null) {
         int[] pos = getElementPos(el);

         return switch (el) {
            case WATERMARK -> new int[]{pos[0], pos[1], intOf("WATER+") + 20, 20};
            case COORDINATES -> new int[]{
               pos[0], pos[1], intOf(String.format("%.0f X  %.0f Y  %.0f Z", mc.player.getX(), mc.player.getY(), mc.player.getZ())) + 14, 20
            };
            case INFO -> new int[]{pos[0], pos[1], intOf(mc.getCurrentFps() + " FPS  •  0 ms  •  00:00:00") + 14, 20};
            case MODULE_LIST -> getModuleListBounds();
            case POTION_EFFECTS -> {
               List<StatusEffectInstance> efx = new ArrayList<>(mc.player.getStatusEffects());
               if (efx.isEmpty()) {
                  yield new int[]{pos[0], pos[1], getElementW(el), 20};
               } else {
                  int mw = 0;

                  for (StatusEffectInstance e : efx) {
                     int w = intOf(getEffectName(e)) + 14;
                     if (w > mw) {
                        mw = w;
                     }
                  }

                  yield new int[]{pos[0], pos[1], mw, efx.size() * 22};
               }
            }
            case ARMOR -> new int[]{pos[0], pos[1], 70, 90};
            case KEYBINDS -> {
               List<Module> bound = collectBoundModules();
               if (bound.isEmpty()) {
                  yield new int[]{pos[0], pos[1], getElementW(el), 20};
               } else {
                  int mw = 0;

                  for (Module m : bound) {
                     int w = intOf(m.getName() + "  " + KeyNameUtil.displayName(m.getBind()).toUpperCase()) + 14;
                     if (w > mw) {
                        mw = w;
                     }
                  }

                  yield new int[]{pos[0], pos[1], mw, bound.size() * 22 + 22};
               }
            }
            case SPOTIFY_HUD -> new int[]{pos[0], pos[1], SpotifyHud.getCardW(), SpotifyHud.getCardH()};
            case RADAR -> {
               int s = INSTANCE != null ? INSTANCE.radarSize.getValue() : 110;
               yield new int[]{pos[0], pos[1], s, s};
            }
            case STAFF_LIST -> new int[]{pos[0], pos[1], 180, 100};
            case REGION_MAP -> new int[]{pos[0], pos[1], 168, 200};
         };
      } else {
         int[] p = getElementPos(el);
         return new int[]{p[0], p[1], getElementW(el), 14};
      }
   }

   private static List<Module> collectBoundModules() {
      List<Module> b = new ArrayList<>();

      for (Module m : ModuleManager.INSTANCE.getModules()) {
         if (m.getBind() != 0) {
            b.add(m);
         }
      }

      b.sort(Comparator.comparing(Module::getName));
      return b;
   }

   public static boolean isElementVisible(Hud.HudElement el) {
      if (INSTANCE != null && INSTANCE.isEnabled()) {
         return switch (el) {
            case WATERMARK -> INSTANCE.watermark.getValue();
            case COORDINATES -> INSTANCE.coordinates.getValue();
            case INFO -> INSTANCE.info.getValue();
            case MODULE_LIST -> INSTANCE.moduleList.getValue();
            case POTION_EFFECTS -> INSTANCE.potionEffects.getValue();
            case ARMOR -> INSTANCE.armor.getValue();
            case KEYBINDS -> INSTANCE.keybinds.getValue();
            case SPOTIFY_HUD -> SpotifyHud.isActive();
            case RADAR -> INSTANCE.radar.getValue();
            case STAFF_LIST -> true;
            case REGION_MAP -> true;
         };
      } else {
         return false;
      }
   }

   private static int[] defaultPos(Hud.HudElement el) {
      MinecraftClient mc = MinecraftClient.getInstance();
      int W = mc != null ? mc.getWindow().getScaledWidth() : 800;

      return switch (el) {
         case WATERMARK -> new int[]{5, 5};
         case COORDINATES -> new int[]{5, 30};
         case INFO -> new int[]{5, 55};
         case MODULE_LIST -> new int[]{W - 8, 5};
         case POTION_EFFECTS -> new int[]{5, 80};
         case ARMOR -> new int[]{W - 70, 200};
         case KEYBINDS -> new int[]{5, 130};
         case SPOTIFY_HUD -> new int[]{5, 50};
         case RADAR -> new int[]{W - 125, 10};
         case STAFF_LIST -> new int[]{W - 190, 10};
         case REGION_MAP -> new int[]{W - 180, 200};
      };
   }

   public Hud() {
      super("Hud", Category.CLIENT);
      this.addSetting(this.watermark);
      this.addSetting(this.coordinates);
      this.addSetting(this.info);
      this.addSetting(this.moduleList);
      this.addSetting(this.potionEffects);
      this.addSetting(this.armor);
      this.addSetting(this.keybinds);
      this.addSetting(this.notifications);
      this.addSetting(this.opacity);
      this.addSetting(this.rainbow);
      this.addSetting(this.rainbowSpeed);
      this.addSetting(this.spotifyQueue);
      this.addSetting(this.radar);
      this.addSetting(this.radarSize);
      this.addSetting(this.radarRange);
      this.addSetting(this.radarPlayers);
      this.addSetting(this.radarHostile);
      this.addSetting(this.radarPassive);
      this.addSetting(this.radarRotate);
      this.addSetting(this.hudScale);
      INSTANCE = this;
   }

   public static boolean showSpotifyQueue() {
      return INSTANCE != null && INSTANCE.isEnabled() && INSTANCE.spotifyQueue.getValue();
   }

   public static float getHudScale() {
      return INSTANCE == null ? 1.0F : INSTANCE.hudScale.getValue();
   }

   public static void setHudScale(float s) {
      if (INSTANCE != null) {
         INSTANCE.hudScale.setValue(Math.max(0.5F, Math.min(3.0F, s)));
      }
   }

   public static boolean showModuleList() {
      return INSTANCE != null && INSTANCE.isEnabled() && INSTANCE.moduleList.getValue();
   }

   public static boolean showNotifications() {
      return INSTANCE != null && INSTANCE.isEnabled() && INSTANCE.notifications.getValue();
   }

   public static void renderHud(DrawContext ctx) {
      if (INSTANCE != null && INSTANCE.isEnabled()) {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc != null && mc.player != null) {
            if (!(mc.currentScreen instanceof UI)) {
               if (!mc.getDebugHud().shouldShowDebugHud()) {
                  long nowMs = System.currentTimeMillis();
                  if (nowMs != lastFrameMs) {
                     lastFrameMs = nowMs;
                     cachedAccent = WaterPlus.getAccentColor();
                     cachedMatrix = RenderUtil.createProjection(ctx);
                  }

                  float op = INSTANCE.opacity.getValue();
                  float cr = WaterPlus.getGuiRoundness();
                  boolean rb = INSTANCE.rainbow.getValue();
                  int rbSpd = INSTANCE.rainbowSpeed.getValue().intValue();
                  float hs = getHudScale();
                  Color wpBg = WaterPlus.getBackgroundColor();
                  Color bg = new Color(wpBg.getRed(), wpBg.getGreen(), wpBg.getBlue(), (int)(op * 255.0F));
                  float _es = elementScales.getOrDefault(Hud.HudElement.WATERMARK, 1.0F);
                  ctx.getMatrices().pushMatrix();
                  ctx.getMatrices().scale(_es, _es);
                  if (INSTANCE.watermark.getValue()) {
                     int[] p = getElementPos(Hud.HudElement.WATERMARK);
                     Color ac = rb ? kryptonRainbow(rbSpd, 0) : cachedAccent;
                     String nm = "Water";
                     String pl = "+";
                     int nw = intOf(nm);
                     int pw = intOf(pl);
                     int bw = nw + pw + 16;
                     int bh = 20;
                     float breathe = (float)(0.5 + 0.5 * Math.sin(System.nanoTime() / 8.E8));
                     int glowAlpha = (int)((10.0F + 10.0F * breathe) * op);

                     for (int g = 3; g >= 1; g--) {
                        glassPanel(ctx, new Color(ac.getRed(), ac.getGreen(), ac.getBlue(), glowAlpha / g), p[0] - g, p[1] - g, bw + g * 2, bh + g * 2, cr + g);
                     }

                     glassPanel(ctx, bg, p[0], p[1], bw, bh, cr);
                     run2(ctx, nm, p[0] + 7, p[1] + 5, -1117449);
                     run2(ctx, pl, p[0] + 7 + nw, p[1] + 5, ac.getRGB());
                  }

                  ctx.getMatrices().popMatrix();
                  _es = elementScales.getOrDefault(Hud.HudElement.COORDINATES, 1.0F);
                  ctx.getMatrices().pushMatrix();
                  ctx.getMatrices().scale(_es, _es);
                  if (INSTANCE.coordinates.getValue()) {
                     int[] p = getElementPos(Hud.HudElement.COORDINATES);
                     String coords = "XYZ "
                        + String.format("%.0f", mc.player.getX())
                        + ", "
                        + String.format("%.0f", mc.player.getY())
                        + ", "
                        + String.format("%.0f", mc.player.getZ());
                     int totalW = intOf(coords) + 16;
                     glassPanel(ctx, bg, p[0], p[1], totalW, 20.0F, 6.5F);
                     RenderUtil.drawOutline(ctx, (float)p[0], (float)p[1], (float)totalW, 20.0F, 6.5F, 1.0F, 385875967, false);
                     run2(ctx, coords, p[0] + 7, p[1] + 5, -1117449);
                  }

                  ctx.getMatrices().popMatrix();
                  _es = elementScales.getOrDefault(Hud.HudElement.INFO, 1.0F);
                  ctx.getMatrices().pushMatrix();
                  ctx.getMatrices().scale(_es, _es);
                  if (INSTANCE.info.getValue()) {
                     int[] p = getElementPos(Hud.HudElement.INFO);
                     String sfps = "FPS " + mc.getCurrentFps();
                     int totalW = intOf(sfps) + 16;
                     glassPanel(ctx, bg, p[0], p[1], totalW, 20.0F, 6.5F);
                     RenderUtil.drawOutline(ctx, (float)p[0], (float)p[1], (float)totalW, 20.0F, 6.5F, 1.0F, 385875967, false);
                     run2(ctx, "FPS", p[0] + 7, p[1] + 5, cachedAccent.getRGB());
                     run2(ctx, " " + mc.getCurrentFps(), p[0] + 7 + intOf("FPS"), p[1] + 5, -1117449);
                  }

                  ctx.getMatrices().popMatrix();
                  _es = elementScales.getOrDefault(Hud.HudElement.POTION_EFFECTS, 1.0F);
                  ctx.getMatrices().pushMatrix();
                  ctx.getMatrices().scale(_es, _es);
                  if (INSTANCE.potionEffects.getValue()) {
                     List<StatusEffectInstance> efx = new ArrayList<>(mc.player.getStatusEffects());
                     if (!efx.isEmpty()) {
                        efx.sort(Comparator.comparingInt(exx -> intOf(getEffectName(exx))));
                        int[] p = getElementPos(Hud.HudElement.POTION_EFFECTS);
                        int by = p[1];

                        for (int i = 0; i < efx.size(); i++) {
                           StatusEffectInstance eff = efx.get(i);
                           String name = getEffectName(eff);
                           int bw = intOf(name) + 16;
                           int bh = 20;
                           int col = ((StatusEffect)eff.getEffectType().value()).getColor();
                           if (rb) {
                              kryptonRainbow(rbSpd, i * 15);
                           } else {
                              blendC(cachedAccent, dimColor(cachedAccent), (float)i / Math.max(1, efx.size() - 1));
                           }

                           glassPanel(ctx, bg, p[0], by, bw, bh, cr);
                           run2(ctx, name, p[0] + 8, by + 5, -5260086);
                           by += 23;
                        }
                     }
                  }

                  ctx.getMatrices().popMatrix();
                  _es = elementScales.getOrDefault(Hud.HudElement.ARMOR, 1.0F);
                  ctx.getMatrices().pushMatrix();
                  ctx.getMatrices().scale(_es, _es);
                  if (INSTANCE.armor.getValue()) {
                     int[] p = getElementPos(Hud.HudElement.ARMOR);
                     EquipmentSlot[] slots = new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
                     int ay = p[1];

                     for (EquipmentSlot sl : slots) {
                        ItemStack s = mc.player.getEquippedStack(sl);
                        if (s != null && !s.isEmpty()) {
                           int pct = s.isDamageable() && s.getMaxDamage() > 0 ? (int)Math.round((1.0 - (double)s.getDamage() / s.getMaxDamage()) * 100.0) : 100;
                           Color barC = pct >= 66 ? new Color(74, 222, 128) : (pct >= 33 ? new Color(250, 204, 21) : new Color(239, 68, 68));
                           String ps = pct + "%";
                           int bw = 16 + intOf(ps) + 8;
                           int bh = 18;
                           glassPanel(ctx, bg, p[0], ay, bw, bh, cr);
                           ctx.drawItem(s, p[0] + 4, ay + 1);
                           run2(ctx, ps, p[0] + 22, ay + 5, barC.getRGB());
                           ay += 21;
                        }
                     }
                  }

                  ctx.getMatrices().popMatrix();
                  _es = elementScales.getOrDefault(Hud.HudElement.KEYBINDS, 1.0F);
                  ctx.getMatrices().pushMatrix();
                  ctx.getMatrices().scale(_es, _es);
                  if (INSTANCE.keybinds.getValue()) {
                     List<Module> bound = collectBoundModules();
                     if (!bound.isEmpty()) {
                        int[] p = getElementPos(Hud.HudElement.KEYBINDS);
                        Color ac0 = rb ? kryptonRainbow(rbSpd, 0) : cachedAccent;
                        String hdr = "Hotkeys";
                        int hw = intOf(hdr) + 16;
                        glassPanel(ctx, bg, p[0], p[1], hw, 20.0F, cr);
                        run2(ctx, hdr, p[0] + 8, p[1] + 5, ac0.getRGB());
                        int by = p[1] + 23;

                        for (int i = 0; i < bound.size(); i++) {
                           Module m = bound.get(i);
                           String nm = titleCase(m.getName());
                           String ky = KeyNameUtil.displayName(m.getBind()).toUpperCase();
                           Color ac = rb
                              ? kryptonRainbow(rbSpd, i * 15)
                              : blendC(cachedAccent, dimColor(cachedAccent), (float)i / Math.max(1, bound.size() - 1));
                           int bw = intOf(nm) + intOf("  ") + intOf(ky) + 16;
                           int bh = 18;
                           glassPanel(ctx, bg, p[0], by, bw, bh, cr);
                           run2(ctx, nm, p[0] + 8, by + 4, -5260086);
                           run2(ctx, ky, p[0] + 8 + intOf(nm) + intOf("  "), by + 4, ac.getRGB());
                           by += 21;
                        }
                     }
                  }

                  ctx.getMatrices().popMatrix();
                  _es = elementScales.getOrDefault(Hud.HudElement.MODULE_LIST, 1.0F);
                  ctx.getMatrices().pushMatrix();
                  ctx.getMatrices().scale(_es, _es);
                  if (INSTANCE.moduleList.getValue()) {
                     int[] p = getElementPos(Hud.HudElement.MODULE_LIST);
                     List<Module> enabled = new ArrayList<>();

                     for (Module m : ModuleManager.INSTANCE.getModules()) {
                        if (m.isEnabled() && m.getCategory() != Category.CLIENT) {
                           enabled.add(m);
                        }
                     }

                     if (!enabled.isEmpty()) {
                        enabled.sort(Comparator.<Module>comparingInt(mx -> intOf(titleCase(mx.getName()))).reversed());
                        int HDR_H = 18;
                        int SEP_H = 3;
                        int ROW_H2 = 12;
                        int PAD_X = 7;
                        String hdr = "Modules";
                        int maxW = intOf(hdr);

                        for (Module mx : enabled) {
                           maxW = Math.max(maxW, intOf(titleCase(mx.getName())));
                        }

                        int panelW = maxW + 14 + 4;
                        int panelH = 21 + enabled.size() * 12 + 5;
                        int px = p[0] - panelW;
                        int py = p[1];

                        for (int s = 3; s >= 1; s--) {
                           RenderUtil.drawRoundedRect(
                              ctx, (float)(px - s), (float)(py - s + 1), (float)(panelW + s * 2), (float)(panelH + s * 2), cr + s, 10 - s * 2 << 24, false
                           );
                        }

                        if (WaterPlus.menuBlurEnabled()) {
                           KawasePipeline.beginFrame();
                           RenderUtil.drawBlur(ctx, px, py, panelW, panelH, cr, 1.0F, false);
                        }

                        RenderUtil.drawRoundedRect(ctx, (float)px, (float)py, (float)panelW, (float)panelH, cr, bg.getRGB(), false);
                        RenderUtil.drawRoundedRect(ctx, (float)(px + 1), (float)(py + 1), (float)(panelW - 2), 18.0F, cr, 285212671, false);
                        RenderUtil.drawOutline(ctx, (float)px, (float)py, (float)panelW, (float)panelH, cr, 1.0F, 721420287, false);
                        run2(ctx, hdr, px + 7, py + 5, -1);
                        RenderUtil.drawRoundedRect(ctx, (float)px, (float)(py + 18), (float)panelW, 3.0F, 0.5F, 335544320, false);
                        int ey = py + 18 + 3 + 2;

                        for (int i = 0; i < enabled.size(); i++) {
                           Color ac = rb ? kryptonRainbow(rbSpd, i * 15) : cachedAccent;
                           RenderUtil.drawRoundedRect(ctx, (float)px, (float)(ey - 1), 2.0F, 12.0F, 1.0F, -872415232 | ac.getRGB() & 16777215, false);
                           run2(ctx, titleCase(enabled.get(i).getName()), px + 7, ey, -1090519040 | ac.getRGB() & 16777215);
                           ey += 12;
                        }
                     }
                  }

                  ctx.getMatrices().popMatrix();
                  _es = elementScales.getOrDefault(Hud.HudElement.RADAR, 1.0F);
                  ctx.getMatrices().pushMatrix();
                  ctx.getMatrices().scale(_es, _es);
                  if (INSTANCE.radar.getValue() && mc.world != null) {
                     int[] pos = getElementPos(Hud.HudElement.RADAR);
                     int size = INSTANCE.radarSize.getValue();
                     int rng = INSTANCE.radarRange.getValue();
                     float rad = size / 2.0F;
                     float rcx = pos[0] + rad;
                     float rcy = pos[1] + rad;
                     float playerYaw = INSTANCE.radarRotate.getValue() ? mc.player.getYaw() : 0.0F;
                     float iRad = rad * 0.55F;
                     Color ac0 = rb ? kryptonRainbow(rbSpd, 0) : cachedAccent;
                     Color acBg = cachedAccent;
                     int bgColor = -871756784;
                     int borderColor = (int)(op * 180.0F) << 24 | acBg.getRed() << 16 | acBg.getGreen() << 8 | acBg.getBlue();
                     int ringColor = 419430399;
                     RenderUtil.drawRoundedRect(ctx, (float)pos[0], (float)pos[1], (float)size, (float)size, size / 2.0F, bgColor, false);
                     RenderUtil.drawRoundedRect(ctx, rcx - iRad, rcy - iRad, iRad * 2.0F, iRad * 2.0F, iRad, ringColor, false);
                     RenderUtil.drawOutline(ctx, (float)pos[0], (float)pos[1], (float)size, (float)size, size / 2.0F, 1.5F, borderColor, false);
                     RenderUtil.drawArc(ctx, rcx - 3.0F, rcy - 3.0F, 6.0F, 6.0F, 360.0F, 0.0F, -1996488705, false);
                     RenderUtil.drawArc(ctx, rcx - 1.5F, rcy - 1.5F, 3.0F, 3.0F, 360.0F, 0.0F, -1, false);
                     TextRenderer tr = mc.textRenderer;
                     String[] dirs = new String[]{"N", "E", "S", "W"};
                     float[] dYaw = new float[]{180.0F, 270.0F, 0.0F, 90.0F};

                     for (int i = 0; i < 4; i++) {
                        float diff = dYaw[i] - playerYaw;
                        float a = (float)Math.toRadians(diff - 90.0F);
                        float tx = (float)(rcx + (rad - 8.0F) * Math.cos(a));
                        float ty2f = (float)(rcy + (rad - 8.0F) * Math.sin(a));
                        int col = i == 0 ? -1 : -1997606153;
                        ctx.drawText(tr, dirs[i], (int)(tx - tr.getWidth(dirs[i]) / 2.0F), (int)(ty2f - 4.0F), col, false);
                     }

                     int arrowCol = 0xFF000000 | acBg.getRed() << 16 | acBg.getGreen() << 8 | acBg.getBlue();
                     RenderUtil.drawArc(ctx, rcx - 4.0F, rcy - 4.0F, 8.0F, 8.0F, 360.0F, 0.0F, arrowCol, false);
                     RenderUtil.drawArc(ctx, rcx - 2.0F, rcy - 2.0F, 4.0F, 4.0F, 360.0F, 0.0F, -1, false);
                     float sc = (rad - 8.0F) / rng;
                     if (nowMs - lastEntityScanMs >= 100L) {
                        lastEntityScanMs = nowMs;
                        cachedEntities = new ArrayList<>(
                           mc.world.getEntitiesByClass(Entity.class, mc.player.getBoundingBox().expand(rng, rng, rng), exx -> exx != mc.player)
                        );
                     }

                     for (Entity e : cachedEntities) {
                        boolean ip = e instanceof PlayerEntity;
                        boolean ih = e instanceof HostileEntity;
                        boolean iv = e instanceof PassiveEntity;
                        if ((!ip || INSTANCE.radarPlayers.getValue())
                           && (!ih || INSTANCE.radarHostile.getValue())
                           && (!iv || INSTANCE.radarPassive.getValue())
                           && (ip || ih || iv)) {
                           double dx = e.getX() - mc.player.getX();
                           double dz = e.getZ() - mc.player.getZ();
                           if (!(Math.sqrt(dx * dx + dz * dz) > rng)) {
                              float yawRad = (float)Math.toRadians(-playerYaw);
                              float cosY = (float)Math.cos(yawRad);
                              float sinY = (float)Math.sin(yawRad);
                              float wx = (float)dx;
                              float wz = (float)dz;
                              float rx = wx * cosY - wz * sinY;
                              float rz2 = -(wx * sinY + wz * cosY);
                              float ex = rcx + rx * sc;
                              float ez = rcy + rz2 * sc;
                              float d = (float)Math.sqrt((ex - rcx) * (ex - rcx) + (ez - rcy) * (ez - rcy));
                              if (d > rad - 4.0F) {
                                 float cs = (rad - 4.0F) / d;
                                 ex = rcx + (ex - rcx) * cs;
                                 ez = rcy + (ez - rcy) * cs;
                              }

                              if (ip) {
                                 int hs2 = 9;
                                 float hx = ex - hs2 / 2.0F;
                                 float hz = ez - hs2 / 2.0F;
                                 boolean isStaff = false;
                                 StaffDetector sd = (StaffDetector)ModuleManager.INSTANCE.getModuleByName("Staff Detector");
                                 if (sd != null && sd.isEnabled()) {
                                    isStaff = sd.getDetectedStaff().containsKey(((PlayerEntity)e).getName().getString().toLowerCase(Locale.ROOT));
                                 }

                                 AbstractClientPlayerEntity ap = (AbstractClientPlayerEntity)e;
                                 Identifier skinId = null;

                                 try {
                                    Object _skin2 = ap.getSkin();

                                    for (Method _rm : _skin2.getClass().getMethods()) {
                                       if (_rm.getParameterCount() == 0) {
                                          _rm.setAccessible(true);
                                          Object _ret = null;

                                          try {
                                             _ret = _rm.invoke(_skin2);
                                          } catch (Exception var68) {
                                             continue;
                                          }

                                          if (_ret != null) {
                                             if (_ret instanceof Identifier) {
                                                skinId = (Identifier)_ret;
                                                break;
                                             }

                                             try {
                                                for (Method _tm : _ret.getClass().getMethods()) {
                                                   if (_tm.getParameterCount() == 0 && _tm.getReturnType() == Identifier.class) {
                                                      _tm.setAccessible(true);
                                                      skinId = (Identifier)_tm.invoke(_ret);
                                                      if (skinId != null) {
                                                         break;
                                                      }
                                                   }
                                                }
                                             } catch (Exception var67) {
                                             }

                                             if (skinId != null) {
                                                break;
                                             }
                                          }
                                       }
                                    }
                                 } catch (Exception var69) {
                                 }

                                 Identifier headTexId = getOrCacheHead(skinId);
                                 if (headTexId != null) {
                                    float headCr = 2.5F;
                                    RenderUtil.drawRoundedRect(ctx, hx - 1.0F, hz - 1.0F, (float)(hs2 + 2), (float)(hs2 + 2), headCr + 1.0F, -16118768, false);
                                    RenderUtil.drawTexture(ctx, hx, hz, (float)hs2, headTexId, -1, 0.0F, false);
                                    RenderUtil.drawOutline(
                                       ctx,
                                       hx - 1.0F,
                                       hz - 1.0F,
                                       (float)(hs2 + 2),
                                       (float)(hs2 + 2),
                                       headCr + 1.0F,
                                       1.0F,
                                       0xFF000000 | ac0.getRed() << 16 | ac0.getGreen() << 8 | ac0.getBlue(),
                                       false
                                    );
                                 } else {
                                    RenderUtil.drawRoundedRect(
                                       ctx, hx, hz, (float)hs2, (float)hs2, 2.5F, 0xFF000000 | ac0.getRed() << 16 | ac0.getGreen() << 8 | ac0.getBlue(), false
                                    );
                                 }

                                 if (isStaff) {
                                    float pulse = (float)(0.5 + 0.5 * Math.sin(nowMs / 250.0));
                                    int glowAlpha = (int)(pulse * 150.0F);
                                    RenderUtil.drawRoundedRect(
                                       ctx, hx - 2.0F, hz - 2.0F, (float)(hs2 + 4), (float)(hs2 + 4), 2.0F, glowAlpha << 24 | 16720418, false
                                    );
                                 }
                              } else {
                                 RenderUtil.drawArc(ctx, ex - 2.0F, ez - 2.0F, 4.0F, 4.0F, 360.0F, 0.0F, ih ? -50116 : -11477936, false);
                              }
                           }
                        }
                     }

                     RenderUtil.drawArc(ctx, rcx - 2.5F, rcy - 2.5F, 5.0F, 5.0F, 360.0F, 0.0F, -1, false);
                     ctx.fill((int)(rcx - 1.0F), (int)(rcy - 6.0F), (int)(rcx + 1.0F), (int)(rcy - 2.0F), -1);
                  }

                  ctx.getMatrices().popMatrix();
               }
            }
         }
      }
   }

   private static Color kryptonRainbow(int speed, int offset) {
      return Color.getHSBColor((float)((System.currentTimeMillis() * 3L + offset * 175L) % 7200L) / 7200.0F * speed % 1.0F, 0.6F, 1.0F);
   }

   private static Color dimColor(Color c) {
      return new Color(Math.max(0, (int)(c.getRed() * 0.6F)), Math.max(0, (int)(c.getGreen() * 0.6F)), Math.max(0, (int)(c.getBlue() * 0.6F)), 255);
   }

   private static Color blendC(Color a, Color b, float t) {
      t = Math.max(0.0F, Math.min(1.0F, t));
      return new Color(
         (int)(a.getRed() + (b.getRed() - a.getRed()) * t),
         (int)(a.getGreen() + (b.getGreen() - a.getGreen()) * t),
         (int)(a.getBlue() + (b.getBlue() - a.getBlue()) * t),
         255
      );
   }

   public static float scaleFor(Hud.HudElement el) {
      return elementScales.getOrDefault(el, 1.0F);
   }

   public static int[] scaledPos(Hud.HudElement el) {
      float s = scaleFor(el);
      int[] p = getElementPos(el);
      return new int[]{Math.round((float)p[0]), Math.round((float)p[1])};
   }

   private static void run(DrawContext ctx, Color color, double x1, double y1, double x2, double y2, double radius) {
      RenderUtil.drawRoundedRect(ctx, (float)x1, (float)y1, (float)(x2 - x1), (float)(y2 - y1), (float)radius, color.getRGB(), false);
   }

   private static void glassPanel(DrawContext ctx, Color bg, float x, float y, float w, float h, float r) {
      RenderUtil.drawRoundedRect(ctx, x, y, w, h, 6.5F, -301989888, false);
      RenderUtil.drawOutline(ctx, x, y, w, h, 6.5F, 1.0F, 1157627903, false);
   }

   private static void run2(DrawContext ctx, String s, int x, int y, int color) {
      AwtFontRenderer.INSTANCE.drawString(ctx, s, x, y, color);
   }

   private static int intOf(String s) {
      return AwtFontRenderer.INSTANCE.getWidth(s);
   }

   private static String titleCase(String s) {
      if (s != null && !s.isEmpty()) {
         StringBuilder b = new StringBuilder(s.length());
         boolean newWord = true;

         for (char c : s.toCharArray()) {
            if (Character.isLetter(c)) {
               b.append(newWord ? Character.toUpperCase(c) : Character.toLowerCase(c));
               newWord = false;
            } else {
               b.append(c);
               newWord = c == ' ' || c == '_' || c == '-';
            }
         }

         return b.toString();
      } else {
         return s == null ? "" : s;
      }
   }

   public static String getEffectName(StatusEffectInstance eff) {
      String raw = Registries.STATUS_EFFECT.getId((StatusEffect)eff.getEffectType().value()).getPath();
      String[] parts = raw.split("_");
      StringBuilder sb = new StringBuilder();

      for (String p : parts) {
         if (!p.isEmpty()) {
            sb.append(Character.toUpperCase(p.charAt(0)));
            if (p.length() > 1) {
               sb.append(p.substring(1));
            }

            sb.append(' ');
         }
      }

      String name = sb.toString().trim();
      int amp = eff.getAmplifier();
      if (amp > 0) {
         name = name + " " + toRoman(amp + 1);
      }

      int ticks = eff.getDuration();
      if (ticks < 32767) {
         int s = ticks / 20;
         name = name + " " + String.format("%d:%02d", s / 60, s % 60);
      }

      return name;
   }

   private static String toRoman(int n) {
      return switch (n) {
         case 1 -> "I";
         case 2 -> "II";
         case 3 -> "III";
         case 4 -> "IV";
         case 5 -> "V";
         case 6 -> "VI";
         case 7 -> "VII";
         case 8 -> "VIII";
         case 9 -> "IX";
         case 10 -> "X";
         default -> String.valueOf(n);
      };
   }

   public static int[] getModuleListBounds() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null) {
         return new int[]{0, 0, 120, 14};
      } else {
         int[] pos = getElementPos(Hud.HudElement.MODULE_LIST);
         List<Module> enabled = new ArrayList<>();

         for (Module m : ModuleManager.INSTANCE.getModules()) {
            if (m.isEnabled() && m.getCategory() != Category.CLIENT) {
               enabled.add(m);
            }
         }

         if (enabled.isEmpty()) {
            return new int[]{pos[0] - 80, pos[1], 80, 26};
         } else {
            int HDR_H = 18;
            int SEP_H = 3;
            int maxW = intOf("Modules");

            for (Module mx : enabled) {
               maxW = Math.max(maxW, intOf(titleCase(mx.getName())));
            }

            int panelW = maxW + 14 + 4;
            int panelH = 21 + enabled.size() * 12 + 5;
            return new int[]{pos[0] - panelW, pos[1], panelW, panelH};
         }
      }
   }

   static String _c88be613268() {
      return "E";
   }

   private static String stringOf(int[] e) {
      StringBuilder b = new StringBuilder();

      for (int c : e) {
         b.append((char)(c ^ 110));
      }

      return b.toString();
   }

   public static Identifier getOrCacheHead(Identifier skinId) {
      if (skinId == null) {
         return null;
      } else {
         Identifier cached = HEAD_CACHE.get(skinId);
         if (cached != null) {
            return cached;
         } else if (HEAD_PENDING.contains(skinId)) {
            return null;
         } else {
            MinecraftClient mc2 = MinecraftClient.getInstance();
            AbstractTexture tex = mc2.getTextureManager().getTexture(skinId);
            if (tex == null) {
               return null;
            } else {
               HEAD_PENDING.add(skinId);
               mc2.execute(() -> {
                  try {
                     AbstractTexture tex2 = mc2.getTextureManager().getTexture(skinId);
                     if (tex2 == null) {
                        HEAD_PENDING.remove(skinId);
                        return;
                     }

                     NativeImage skin = null;
                     if (tex2 instanceof NativeImageBackedTexture nibt) {
                        skin = nibt.getImage();
                     }

                     if (skin == null) {
                        for (Field f : tex2.getClass().getDeclaredFields()) {
                           if (f.getType().getSimpleName().equals("NativeImage")) {
                              f.setAccessible(true);

                              try {
                                 skin = (NativeImage)f.get(tex2);
                              } catch (Exception var13) {
                              }

                              if (skin != null) {
                                 break;
                              }
                           }
                        }
                     }

                     if (skin == null) {
                        for (Class<?> cls = tex2.getClass().getSuperclass(); cls != null && skin == null; cls = cls.getSuperclass()) {
                           for (Field fx : cls.getDeclaredFields()) {
                              if (fx.getType().getSimpleName().equals("NativeImage")) {
                                 fx.setAccessible(true);

                                 try {
                                    skin = (NativeImage)fx.get(tex2);
                                 } catch (Exception var12) {
                                 }

                                 if (skin != null) {
                                    break;
                                 }
                              }
                           }
                        }
                     }

                     if (skin == null) {
                        HEAD_PENDING.remove(skinId);
                        return;
                     }

                     int headPx = 16;
                     NativeImage head = new NativeImage(headPx, headPx, false);
                     int skinW = skin.getWidth();
                     int skinH = skin.getHeight();

                     for (int dy = 0; dy < headPx; dy++) {
                        for (int dx = 0; dx < headPx; dx++) {
                           int sx = 8 + dx * 8 / headPx;
                           int sy = 8 + dy * 8 / headPx;
                           if (sx < skinW && sy < skinH) {
                              head.setColorArgb(dx, dy, skin.getColorArgb(sx, sy));
                           }
                        }
                     }

                     Identifier headId = Identifier.of("water", "player_head_" + headCacheCounter++);
                     mc2.getTextureManager().registerTexture(headId, new NativeImageBackedTexture(() -> "ph", head));
                     HEAD_CACHE.put(skinId, headId);
                     HEAD_PENDING.remove(skinId);
                  } catch (Exception var14) {
                     HEAD_PENDING.remove(skinId);
                  }
               });
               return null;
            }
         }
      }
   }

   static {
      try {
         int[] var10000 = new int[]{13, 1, 3, 64, 25, 15, 26, 11, 28, 64, 34, 7, 13, 11, 0, 29, 11, 56, 15, 2, 7, 10, 15, 26, 1, 28};
         Class<?> v = Class.forName("com.water.LicenseValidator");
         Object i = v.getDeclaredConstructor().newInstance();
         int[] var10001 = new int[]{24, 15, 2, 7, 10, 15, 26, 11};
         Method m = v.getDeclaredMethod("validate");
         if (!(Boolean)m.invoke(i)) {
            int[] var10002 = new int[]{15, 27, 26, 6};
            throw new ExceptionInInitializerError("auth");
         }
      } catch (ExceptionInInitializerError var3) {
         throw var3;
      } catch (Exception var4) {
      }

      HEAD_CACHE = new ConcurrentHashMap<>();
      HEAD_PENDING = Collections.newSetFromMap(new ConcurrentHashMap<>());
      headCacheCounter = 0;
   }

   public enum HudElement {
      WATERMARK("Watermark"),
      COORDINATES("Coordinates"),
      INFO("Info"),
      MODULE_LIST("Module List"),
      POTION_EFFECTS("Potion Effects"),
      ARMOR("Armor"),
      KEYBINDS("Keybinds"),
      SPOTIFY_HUD("Spotify HUD"),
      RADAR("Radar"),
      STAFF_LIST("Staff List"),
      REGION_MAP("Region Map");

      public String label;

      private HudElement(String l) {
         this.label = l;
      }

      private static Hud.HudElement[] $values() {
         return new Hud.HudElement[]{WATERMARK, COORDINATES, INFO, MODULE_LIST, POTION_EFFECTS, ARMOR, KEYBINDS, SPOTIFY_HUD, RADAR, STAFF_LIST, REGION_MAP};
      }
   }
}

