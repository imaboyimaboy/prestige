package rtx.kimiko.api.mods.geckolib.loading.json.raw;

import com.google.gson.JsonDeserializer;
import com.google.gson.JsonParseException;
import rtx.kimiko.api.mods.geckolib.util.JsonUtil;

public final class LocatorValue {
   private LocatorClass locatorClass;
   private double[] values;

   public LocatorValue(LocatorClass locatorClass, double[] values) {
      this.locatorClass = locatorClass;
      this.values = values;
   }

   public static JsonDeserializer<LocatorValue> deserializer() throws JsonParseException {
      return (jsonElement, type, jsonDeserializationContext) -> {
         if (jsonElement.isJsonArray()) {
            return new LocatorValue(null, JsonUtil.jsonArrayToDoubleArray(jsonElement.getAsJsonArray()));
         } else if (jsonElement.isJsonObject()) {
            return new LocatorValue((LocatorClass)jsonDeserializationContext.deserialize(jsonElement.getAsJsonObject(), LocatorClass.class), new double[0]);
         } else {
            throw new JsonParseException("Invalid format for LocatorValue in json");
         }
      };
   }

   public LocatorClass locatorClass() {
      return this.locatorClass;
   }

   public double[] values() {
      return this.values;
   }
}

