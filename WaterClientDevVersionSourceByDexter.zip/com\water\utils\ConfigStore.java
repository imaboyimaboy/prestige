package com.water.utils;

import com.water.module.Module;
import com.water.module.ModuleManager;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import net.minecraft.client.MinecraftClient;

public final class ConfigStore {
   private static final String EXT = ".txt";
   private static final Pattern SAFE = Pattern.compile("[^A-Za-z0-9_\\- ]");

   private ConfigStore() {
   }

   public static Path configsDir() {
      Path dir = MinecraftClient.getInstance().runDirectory.toPath().resolve("water_configs");

      try {
         Files.createDirectories(dir);
      } catch (IOException var2) {
      }

      return dir;
   }

   private static Path liveConfig() {
      return ModuleManager.INSTANCE.getCurrentConfigPath();
   }

   public static String sanitize(String name) {
      return name == null ? "" : SAFE.matcher(name.trim()).replaceAll("_");
   }

   public static List<String> list() {
      List<String> out = new ArrayList<>();
      Path dir = configsDir();
      if (!Files.isDirectory(dir)) {
         return out;
      } else {
         try {
            Files.list(dir).forEach(p -> {
               String fn = p.getFileName().toString();
               if (fn.endsWith(".txt")) {
                  out.add(fn.substring(0, fn.length() - 4));
               }
            });
         } catch (IOException var3) {
         }

         Collections.sort(out, String.CASE_INSENSITIVE_ORDER);
         return out;
      }
   }

   public static boolean saveAs(String name) {
      String safe = sanitize(name);
      if (safe.isEmpty()) {
         return false;
      } else {
         ModuleManager.INSTANCE.saveConfig();
         Path src = liveConfig();
         Path dst = configsDir().resolve("null.txt");

         try {
            Files.copy(src, dst, StandardCopyOption.REPLACE_EXISTING);
            return true;
         } catch (IOException var5) {
            return false;
         }
      }
   }

   public static boolean load(String name) {
      Path src = configsDir().resolve(sanitize(name) + ".txt");
      return !Files.isRegularFile(src) ? false : applyFromPath(src);
   }

   public static boolean delete(String name) {
      try {
         return Files.deleteIfExists(configsDir().resolve(sanitize(name) + ".txt"));
      } catch (IOException var2) {
         return false;
      }
   }

   public static String generateShareCode() {
      try {
         ModuleManager.INSTANCE.saveConfig();
         byte[] data = Files.readAllBytes(liveConfig());
         return "WCFG-" + Base64.getUrlEncoder().withoutPadding().encodeToString(data);
      } catch (IOException var1) {
         return null;
      }
   }

   public static boolean redeemShareCode(String code) {
      if (code == null) {
         return false;
      } else {
         String c = code.trim();
         if (c.startsWith("WCFG-")) {
            c = c.substring(5);
         }

         try {
            byte[] data = Base64.getUrlDecoder().decode(c);
            Path tmp = configsDir().resolve(".__shared_tmp.txt");
            Files.write(tmp, data);
            boolean ok = applyFromPath(tmp);

            try {
               Files.deleteIfExists(tmp);
            } catch (IOException var6) {
            }

            return ok;
         } catch (IOException | IllegalArgumentException var7) {
            return false;
         }
      }
   }

   private static boolean applyFromPath(Path src) {
      Map<String, Boolean> before = snapshotEnabled();
      if (!ModuleManager.INSTANCE.applyConfigFromPath(src)) {
         return false;
      } else {
         Map<String, Boolean> after = snapshotEnabled();

         for (Module m : ModuleManager.INSTANCE.getModules()) {
            boolean was = before.getOrDefault(m.getName(), false);
            boolean now = after.getOrDefault(m.getName(), false);
            if (was != now) {
               try {
                  if (now) {
                     m.onEnable();
                  } else {
                     m.onDisable();
                  }
               } catch (Throwable var8) {
               }
            }
         }

         ModuleManager.INSTANCE.saveConfig();
         return true;
      }
   }

   private static Map<String, Boolean> snapshotEnabled() {
      Map<String, Boolean> map = new HashMap<>();

      for (Module m : ModuleManager.INSTANCE.getModules()) {
         map.put(m.getName(), m.isEnabled());
      }

      return map;
   }

   public static String readClipboard() {
      try {
         return MinecraftClient.getInstance().keyboard.getClipboard();
      } catch (Throwable var1) {
         return "";
      }
   }

   public static void writeClipboard(String s) {
      try {
         MinecraftClient.getInstance().keyboard.setClipboard(s == null ? "" : s);
      } catch (Throwable var2) {
      }
   }

   public static byte[] utf8(String s) {
      return s.getBytes(StandardCharsets.UTF_8);
   }
}

