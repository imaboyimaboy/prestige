package com.water.module.modules.donut;

import com.water.module.Category;
import com.water.module.Module;
import com.water.setting.ModeSetting;
import com.water.setting.Setting;
import dev.fakeranks.FakeRank;
import dev.fakeranks.FakeRanksClient;
import dev.fakeranks.FakeRanksConfig;
import dev.fakeranks.FakeStaffBadge;
import java.util.Locale;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

public final class FakeTierBridge extends Module {
   private final Setting<String> name_2 = new Setting<>("Name", initialConfig().customName == null ? "" : initialConfig().customName);
   private final ModeSetting rank = new ModeSetting("Rank", rankName(initialConfig().rank), "None", "+", "++", "+++");
   private final ModeSetting staff = new ModeSetting("Staff", staffName(initialConfig().staffBadge), "None", "Staff", "Dev", "Owner");
   private final Setting<Boolean> media = new Setting<>("Media", initialConfig().mediaEnabled);
   private final Setting<Boolean> tierMods = new Setting<>("Tier Mods", initialConfig().tierTagsEnabled);
   private final Setting<Boolean> skinSteal = new Setting<>("Skin Steal", initialConfig().skinStealEnabled);
   private final Setting<Boolean> chatPrefix = new Setting<>("Chat Prefix", initialConfig().chatPrefixEnabled);
   private final Setting<Boolean> nametag = new Setting<>("Nametag", initialConfig().nametagEnabled);
   private String lastName = null;
   private FakeRank lastRank = null;
   private FakeStaffBadge lastStaff = null;
   private boolean lastMedia;
   private boolean lastTierMods;
   private boolean lastSkinSteal;
   private boolean lastChatPrefix;
   private boolean lastNametag;

   public FakeTierBridge() {
      super("Fake Tier", Category.DONUT);
      this.addSetting(this.name_2);
      this.addSetting(this.rank);
      this.addSetting(this.staff);
      this.addSetting(this.media);
      this.addSetting(this.tierMods);
      this.addSetting(this.skinSteal);
      this.addSetting(this.chatPrefix);
      this.addSetting(this.nametag);
      this.rememberCurrent();
      FakeRanksClient.setEnabled(false);
   }

   @Override
   public void onEnable() {
      this.applySettings(true);
   }

   @Override
   public void onDisable() {
      FakeRanksClient.setEnabled(false);
   }

   @Override
   public ItemStack getModuleIcon() {
      return new ItemStack(Items.NAME_TAG);
   }

   @Override
   public void onTick() {
      if (this.isEnabled()) {
         this.applySettings(false);
      }
   }

   @Override
   public void onBindPressed() {
      this.toggle();
   }

   private void applySettings(boolean force) {
      FakeRanksConfig config = FakeRanksClient.STATE.config();
      String cleanName = this.name_2.getValue() == null ? "" : this.name_2.getValue().trim();
      FakeRank selectedRank = parseRank(this.rank.getValue());
      FakeStaffBadge selectedStaff = parseStaff(this.staff.getValue());
      boolean changed = force
         || !cleanName.equals(this.lastName)
         || selectedRank != this.lastRank
         || selectedStaff != this.lastStaff
         || this.media.getValue() != this.lastMedia
         || this.tierMods.getValue() != this.lastTierMods
         || this.skinSteal.getValue() != this.lastSkinSteal
         || this.chatPrefix.getValue() != this.lastChatPrefix
         || this.nametag.getValue() != this.lastNametag;
      config.enabled = true;
      config.customName = cleanName;
      config.rank = selectedRank;
      config.staffBadge = selectedStaff;
      config.mediaEnabled = this.media.getValue();
      config.tierTagsEnabled = this.tierMods.getValue();
      config.skinStealEnabled = this.skinSteal.getValue();
      config.chatPrefixEnabled = this.chatPrefix.getValue();
      config.nametagEnabled = this.nametag.getValue();
      if (changed) {
         config.save();
         FakeRanksClient.STATE.invalidateCache();
         if (!cleanName.equals(this.lastName) || this.skinSteal.getValue() != this.lastSkinSteal || force) {
            FakeRanksClient.STATE.requestSkinForCurrentName();
         }

         this.rememberCurrent();
      }
   }

   private void rememberCurrent() {
      this.lastName = this.name_2.getValue() == null ? "" : this.name_2.getValue().trim();
      this.lastRank = parseRank(this.rank.getValue());
      this.lastStaff = parseStaff(this.staff.getValue());
      this.lastMedia = this.media.getValue();
      this.lastTierMods = this.tierMods.getValue();
      this.lastSkinSteal = this.skinSteal.getValue();
      this.lastChatPrefix = this.chatPrefix.getValue();
      this.lastNametag = this.nametag.getValue();
   }

   private static FakeRanksConfig initialConfig() {
      return FakeRanksClient.STATE.config();
   }

   private static String rankName(FakeRank rank) {
      return switch (rank == null ? FakeRank.NONE : rank) {
         case NONE -> "None";
         case PLUS -> "+";
         case PLUS_PLUS -> "++";
         case PLUS_PLUS_PLUS -> "+++";
      };
   }

   private static FakeRank parseRank(String value) {
      String var1 = value == null ? "None" : value.trim();
      switch (var1.hashCode()) {
         case 43:
            if (var1.equals("+")) {
               return FakeRank.PLUS;
            }
            break;
         case 1376:
            if (var1.equals("++")) {
               return FakeRank.PLUS_PLUS;
            }
            break;
         case 42699:
            if (var1.equals("+++")) {
               return FakeRank.PLUS_PLUS_PLUS;
            }
      }

      return FakeRank.NONE;
   }

   private static String staffName(FakeStaffBadge staff) {
      return switch (staff == null ? FakeStaffBadge.NONE : staff) {
         case NONE -> "None";
         case STAFF -> "Staff";
         case DEV -> "Dev";
         case OWNER -> "Owner";
      };
   }

   private static FakeStaffBadge parseStaff(String value) {
      String var1 = value == null ? "None" : value.trim().toLowerCase(Locale.ROOT);
      switch (var1.hashCode()) {
         case 99349:
            if (var1.equals("dev")) {
               return FakeStaffBadge.DEV;
            }
            break;
         case 106164915:
            if (var1.equals("owner")) {
               return FakeStaffBadge.OWNER;
            }
            break;
         case 109757152:
            if (var1.equals("staff")) {
               return FakeStaffBadge.STAFF;
            }
      }

      return FakeStaffBadge.NONE;
   }
}

