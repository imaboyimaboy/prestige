package com.water.setting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

public final class BlocksSetting extends Setting<Set<Block>> {
   private final List<Block> availableBlocks = Registries.BLOCK
      .stream()
      .filter(block -> block != Blocks.AIR)
      .sorted(Comparator.comparing(this::getDisplayName, String.CASE_INSENSITIVE_ORDER))
      .toList();
   private long version;

   public BlocksSetting(String name, Block... defaults) {
      super(name, createDefaultSet(defaults));
   }

   public void setValue(Set<Block> value) {
      LinkedHashSet<Block> next = new LinkedHashSet<>();
      if (value != null) {
         for (Block block : value) {
            if (block != null && block != Blocks.AIR) {
               next.add(block);
            }
         }
      }

      super.setValue(next);
      this.version++;
   }

   public boolean contains(Block block) {
      return block != null && this.getValue().contains(block);
   }

   public void toggle(Block block) {
      if (block != null && block != Blocks.AIR) {
         LinkedHashSet<Block> next = new LinkedHashSet<>(this.getValue());
         if (!next.add(block)) {
            next.remove(block);
         }

         this.setValue(next);
      }
   }

   public void clear() {
      if (!this.getValue().isEmpty()) {
         this.setValue(Collections.emptySet());
      }
   }

   public int size() {
      return this.getValue().size();
   }

   public long getVersion() {
      return this.version;
   }

   public Set<Block> getSelectedBlocks() {
      return Collections.unmodifiableSet(this.getValue());
   }

   public List<Block> getAvailableBlocks() {
      return this.availableBlocks;
   }

   public List<Block> filter(String query) {
      String normalized = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
      if (normalized.isEmpty()) {
         return this.availableBlocks;
      } else {
         List<Block> filtered = new ArrayList<>();

         for (Block block : this.availableBlocks) {
            String displayName = this.getDisplayName(block).toLowerCase(Locale.ROOT);
            Identifier id = Registries.BLOCK.getId(block);
            String idString = id == null ? "" : id.toString().toLowerCase(Locale.ROOT);
            if (displayName.contains(normalized) || idString.contains(normalized)) {
               filtered.add(block);
            }
         }

         return filtered;
      }
   }

   public String getDisplayName(Block block) {
      try {
         return block.getName().getString();
      } catch (Exception var4) {
         Identifier id = Registries.BLOCK.getId(block);
         return id == null ? "Block" : id.getPath();
      }
   }

   public String getSummary() {
      if (this.getValue().isEmpty()) {
         return "None";
      } else {
         Block first = this.getValue().iterator().next();
         String firstName = this.getDisplayName(first);
         int extra = this.getValue().size() - 1;
         return extra > 0 ? firstName + " +" + extra : firstName;
      }
   }

   private static Set<Block> createDefaultSet(Block... defaults) {
      LinkedHashSet<Block> selected = new LinkedHashSet<>();
      if (defaults != null) {
         Collections.addAll(selected, defaults);
         selected.remove(null);
         selected.remove(Blocks.AIR);
      }

      return selected;
   }
}

