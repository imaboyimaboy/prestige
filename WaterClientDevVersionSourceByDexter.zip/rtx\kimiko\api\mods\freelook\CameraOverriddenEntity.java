package rtx.kimiko.api.mods.freelook;

public interface CameraOverriddenEntity {
   void freelook_setCameraPitch(float var1);

   void freelook_setCameraYaw(float var1);

   float freelook_getCameraPitch();

   float freelook_getCameraYaw();
}

