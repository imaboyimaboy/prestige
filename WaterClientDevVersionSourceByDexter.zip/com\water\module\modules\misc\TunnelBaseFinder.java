package com.water.module.modules.misc;

import com.water.gui.notification.NotificationManager;
import com.water.module.Category;
import com.water.module.Module;
import com.water.module.modules.client.WaterPlus;
import com.water.setting.ModeSetting;
import com.water.setting.Setting;
import com.water.utils.RenderUtils;
import java.awt.Color;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;

public final class TunnelBaseFinder extends Module {
   private static final int[][] DIRECTIONS = new int[][]{{0, 1}, {-1, 0}, {0, -1}, {1, 0}};
   private final Setting<Integer> minY = new Setting<>("Min Y", -59, -64, 0);
   private final Setting<Integer> maxY = new Setting<>("Max Y", -50, -64, 0);
   private final Setting<Integer> storageThreshold = new Setting<>("Storage Threshold", 8, 1, 500);
   private final Setting<Integer> hazardRange = new Setting<>("Hazard Scan", 7, 3, 14);
   private final ModeSetting tunnelSize = new ModeSetting("Tunnel Size", "1x1", "1x1", "3x3 (Center Only)");
   private final Setting<Boolean> autoPickaxe = new Setting<>("Auto Pickaxe", true);
   private final Setting<Float> turnSpeed = new Setting<>("Turn Speed", 4.0F, 0.5F, 12.0F);
   private final Setting<Integer> mineDelay = new Setting<>("Mine Delay", 3, 1, 8);
   private final Setting<Boolean> noPauses = new Setting<>("No Pauses", false);
   private final Setting<Boolean> caveBypass = new Setting<>("Cave Bypass", true);
   private final Setting<Boolean> routeLine = new Setting<>("Route Line", true);
   private final Setting<Boolean> disconnectOnTotem = new Setting<>("Disconnect On Totem Pop", true);
   private final Set<ChunkPos> scannedChunks = new HashSet<>();
   private final Random random = new Random();
   private int direction;
   private int pauseTicks;
   private int decisionCooldown;
   private int miningCycleTicks;
   private int mineTicks;
   private int routeYOffset;
   private boolean found;
   private BlockPos miningTarget;

   public TunnelBaseFinder() {
      super("Tunnel Base Finder", Category.MISC);
      this.addSetting(this.minY);
      this.addSetting(this.maxY);
      this.addSetting(this.storageThreshold);
      this.addSetting(this.hazardRange);
      this.addSetting(this.tunnelSize);
      this.addSetting(this.autoPickaxe);
      this.addSetting(this.turnSpeed);
      this.addSetting(this.mineDelay);
      this.addSetting(this.noPauses);
      this.addSetting(this.caveBypass);
      this.addSetting(this.routeLine);
      this.addSetting(this.disconnectOnTotem);
   }

   @Override
   public void onEnable() {
      this.direction = mc.player == null ? 0 : Math.floorMod(Math.round(mc.player.getYaw() / 90.0F), 4);
      this.pauseTicks = 0;
      this.decisionCooldown = 0;
      this.miningCycleTicks = 0;
      this.mineTicks = 0;
      this.routeYOffset = 0;
      this.found = false;
      this.miningTarget = null;
      this.scannedChunks.clear();
   }

   @Override
   public void onDisable() {
      this.releaseControls();
      this.scannedChunks.clear();
   }

   @Override
   public void onTick() {
      if (mc.player != null && mc.world != null && mc.interactionManager != null && mc.currentScreen == null && !this.found) {
         this.scanStorage();
         int y = mc.player.getBlockY();
         if (this.found || y < Math.min(this.minY.getValue(), this.maxY.getValue()) || y > Math.max(this.minY.getValue(), this.maxY.getValue())) {
            this.releaseControls();
         } else if (!this.noPauses.getValue() && this.pauseTicks > 0) {
            this.pauseTicks--;
            this.releaseControls();
         } else {
            if (this.noPauses.getValue()) {
               this.pauseTicks = 0;
               this.miningCycleTicks = 0;
            }

            if (this.autoPickaxe.getValue() && !this.ensurePickaxe()) {
               this.notify("No pickaxe found in hotbar");
               this.setEnabled(false);
            } else if (!this.noPauses.getValue() && ++this.miningCycleTicks >= 4800) {
               this.miningCycleTicks = 0;
               this.pauseTicks = 200;
               this.releaseControls();
            } else {
               if (--this.decisionCooldown <= 0 || this.score(this.direction) < 0) {
                  this.direction = this.safestDirection();
                  this.decisionCooldown = 12 + this.random.nextInt(18);
               }

               this.routeYOffset = this.chooseRouteYOffset(this.direction);
               BlockHitResult currentHit = mc.crosshairTarget instanceof BlockHitResult hit ? hit : null;
               BlockPos target = this.selectMiningTarget(currentHit);
               if (target == null) {
                  mc.interactionManager.cancelBlockBreaking();
                  mc.options.attackKey.setPressed(false);
                  mc.options.forwardKey.setPressed(true);
               } else {
                  this.smoothLookAt(target);
                  if (this.noPauses.getValue()) {
                     mc.options.sprintKey.setPressed(true);
                     mc.options.forwardKey.setPressed(true);
                     mc.player.setSprinting(true);
                  }

                  if (!mc.world.getBlockState(target).isAir()) {
                     if (!this.noPauses.getValue()) {
                        mc.options.forwardKey.setPressed(false);
                     }

                     mc.crosshairTarget = new BlockHitResult(Vec3d.ofCenter(target), Direction.UP, target, false);
                     if (++this.mineTicks >= this.mineDelay.getValue()) {
                        this.mineTicks = 0;
                        mc.interactionManager.updateBlockBreakingProgress(target, Direction.UP);
                        mc.player.swingHand(Hand.MAIN_HAND);
                     }

                     mc.options.attackKey.setPressed(true);
                  } else {
                     mc.interactionManager.cancelBlockBreaking();
                     this.mineTicks = 0;
                     mc.options.attackKey.setPressed(false);
                     mc.options.forwardKey.setPressed(true);
                  }

                  mc.options.leftKey.setPressed(false);
                  mc.options.rightKey.setPressed(false);
               }
            }
         }
      } else {
         this.releaseControls();
      }
   }

   @Override
   public void onPacketReceive(Packet<?> packet) {
      if (this.disconnectOnTotem.getValue()
         && mc.world != null
         && mc.player != null
         && packet instanceof EntityStatusS2CPacket status
         && status.getStatus() == 35) {
         Entity entity = status.getEntity(mc.world);
         if (entity == mc.player) {
            this.releaseControls();
            if (mc.getNetworkHandler() != null && mc.getNetworkHandler().getConnection() != null) {
               mc.getNetworkHandler()
                  .getConnection()
                  .disconnect(
                     Text.literal(
                        "Tunnel Base Finder: totem popped at X: " + mc.player.getBlockX() + " Y: " + mc.player.getBlockY() + " Z: " + mc.player.getBlockZ()
                     )
                  );
            }
         }
      }
   }

   @Override
   public void onRender(MatrixStack matrices, float tickDelta) {
      if (this.routeLine.getValue() && mc.player != null && !this.found) {
         Camera camera = RenderUtils.getCamera();
         if (camera != null) {
            Vec3d cam = RenderUtils.getCameraPos(camera);
            Vec3d start = new Vec3d(mc.player.getX(), mc.player.getY() + 0.15, mc.player.getZ()).subtract(cam);
            int[] v = DIRECTIONS[this.direction];
            Vec3d end = start.add(v[0] * this.hazardRange.getValue(), this.routeYOffset, v[1] * this.hazardRange.getValue());
            RenderUtils.renderLine(matrices, new Color(70, 220, 255, 210), start, end, 2.25F);
         }
      }
   }

   private int safestDirection() {
      int best = this.direction;
      int bestScore = Integer.MIN_VALUE;

      for (int d = 0; d < 4; d++) {
         if (d != (this.direction + 2 & 3)) {
            int value = this.score(d) + (d == this.direction ? 5 : 0) + this.random.nextInt(3);
            if (value > bestScore) {
               bestScore = value;
               best = d;
            }
         }
      }

      return best;
   }

   private int score(int d) {
      return this.score(d, 0);
   }

   private int score(int d, int yOffset) {
      BlockPos p = mc.player.getBlockPos();
      int[] v = DIRECTIONS[d];
      int score = 0;
      int air = 0;

      for (int n = 1; n <= this.hazardRange.getValue(); n++) {
         for (int side = -1; side <= 1; side++) {
            for (int up = -1; up <= 2; up++) {
               BlockPos q = new BlockPos(p.getX() + v[0] * n + v[1] * side, p.getY() + yOffset + up, p.getZ() + v[1] * n - v[0] * side);
               BlockState state = mc.world.getBlockState(q);
               if (state.isOf(Blocks.LAVA) || !state.getFluidState().isEmpty()) {
                  return -10000;
               }

               if (state.isAir()) {
                  air++;
               } else {
                  score++;
               }
            }
         }
      }

      if (air > this.hazardRange.getValue() * 5) {
         score -= air * 3;
      }

      BlockPos floor = p.add(v[0], yOffset - 1, v[1]);
      if (mc.world.getBlockState(floor).isAir() || !mc.world.getFluidState(floor).isEmpty()) {
         score -= 200;
      }

      return score;
   }

   private int chooseRouteYOffset(int d) {
      if (!this.caveBypass.getValue()) {
         return 0;
      } else if (!this.isCaveAhead(d, 0)) {
         return 0;
      } else {
         int down = this.score(d, -2);
         int up = this.score(d, 2);
         int current = this.score(d, 0) - 120;
         if (down >= up && down > current) {
            return -2;
         } else {
            return up > current ? 2 : 0;
         }
      }
   }

   private boolean isCaveAhead(int d, int yOffset) {
      BlockPos p = mc.player.getBlockPos();
      int[] v = DIRECTIONS[d];
      int air = 0;
      int checked = 0;

      for (int n = 1; n <= Math.min(5, this.hazardRange.getValue()); n++) {
         for (int side = -1; side <= 1; side++) {
            for (int up = -1; up <= 2; up++) {
               BlockPos q = new BlockPos(p.getX() + v[0] * n + v[1] * side, p.getY() + yOffset + up, p.getZ() + v[1] * n - v[0] * side);
               BlockState state = mc.world.getBlockState(q);
               if (state.isOf(Blocks.LAVA) || !state.getFluidState().isEmpty()) {
                  return true;
               }

               if (state.isAir()) {
                  air++;
               }

               checked++;
            }
         }
      }

      return checked > 0 && air > checked * 0.42F;
   }

   private BlockPos selectMiningTarget(BlockHitResult currentHit) {
      if (this.miningTarget != null && mc.world.getBlockState(this.miningTarget).isAir()) {
         mc.interactionManager.cancelBlockBreaking();
         this.miningTarget = null;
      }

      if (this.miningTarget != null) {
         return this.miningTarget;
      } else {
         int[] v = DIRECTIONS[this.direction];
         BlockPos base = mc.player.getBlockPos();
         int targetYOffset = this.routeYOffset;
         if (this.tunnelSize.check("3x3 (Center Only)")) {
            targetYOffset++;
         }

         BlockPos direct = new BlockPos(base.getX() + v[0], base.getY() + targetYOffset, base.getZ() + v[1]);
         if (!mc.world.getBlockState(direct).isAir()) {
            this.miningTarget = direct.toImmutable();
            mc.interactionManager.cancelBlockBreaking();
            return this.miningTarget;
         } else if (currentHit != null && !mc.world.getBlockState(currentHit.getBlockPos()).isAir()) {
            this.miningTarget = currentHit.getBlockPos().toImmutable();
            mc.interactionManager.cancelBlockBreaking();
            return this.miningTarget;
         } else {
            return null;
         }
      }
   }

   private void smoothLookAt(BlockPos target) {
      Vec3d eyes = mc.player.getEyePos();
      Vec3d center = Vec3d.ofCenter(target);
      double dx = center.x - eyes.x;
      double dy = center.y - eyes.y;
      double dz = center.z - eyes.z;
      double horizontal = Math.sqrt(dx * dx + dz * dz);
      float targetYaw = MathHelper.wrapDegrees((float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0));
      float targetPitch = MathHelper.clamp((float)(-Math.toDegrees(Math.atan2(dy, horizontal))), -75.0F, 75.0F);
      float yawDelta = MathHelper.wrapDegrees(targetYaw - mc.player.getYaw());
      float pitchDelta = targetPitch - mc.player.getPitch();
      float yawStep = Math.min(Math.abs(yawDelta), this.turnSpeed.getValue() * (0.62F + this.random.nextFloat() * 0.18F));
      float pitchStep = Math.min(Math.abs(pitchDelta), Math.max(0.35F, this.turnSpeed.getValue() * 0.42F));
      float yaw = mc.player.getYaw() + Math.copySign(yawStep, yawDelta);
      float pitch = mc.player.getPitch() + Math.copySign(pitchStep, pitchDelta);
      mc.player.setYaw(yaw);
      mc.player.setPitch(pitch);
      mc.player.setHeadYaw(yaw);
      mc.player.setBodyYaw(yaw);
   }

   private void scanStorage() {
      ChunkPos center = mc.player.getChunkPos();
      int view = Math.min(mc.options.getClampedViewDistance(), 12);

      for (int cx = center.x - view; cx <= center.x + view; cx++) {
         for (int cz = center.z - view; cz <= center.z + view; cz++) {
            ChunkPos cp = new ChunkPos(cx, cz);
            if (this.scannedChunks.add(cp)) {
               WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(cx, cz, false);
               if (chunk != null) {
                  int count = 0;

                  for (BlockEntity be : chunk.getBlockEntities().values()) {
                     if (this.isStorage(be)) {
                        count++;
                     }
                  }

                  if (count >= this.storageThreshold.getValue()) {
                     this.found = true;
                     this.releaseControls();
                     String message = "Found " + count + " storages near X: " + cp.getCenterX() + " Z: " + cp.getCenterZ();
                     this.notify(message);
                     if (mc.player != null) {
                        mc.player.sendMessage(Text.literal("§8§7[Tunnel Base Finder] null"), false);
                     }

                     return;
                  }
               }
            }
         }
      }
   }

   private boolean ensurePickaxe() {
      if (this.isPickaxe(mc.player.getMainHandStack().getItem())) {
         return true;
      } else {
         for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (!stack.isEmpty() && this.isPickaxe(stack.getItem())) {
               mc.player.getInventory().setSelectedSlot(i);
               return true;
            }
         }

         return false;
      }
   }

   private boolean isPickaxe(Item item) {
      return Registries.ITEM.getId(item).getPath().endsWith("_pickaxe");
   }

   private boolean isStorage(BlockEntity be) {
      if (be == null) {
         return false;
      } else {
         BlockState state = be.getCachedState();
         return state.isOf(Blocks.CHEST)
            || state.isOf(Blocks.TRAPPED_CHEST)
            || state.isOf(Blocks.BARREL)
            || state.isOf(Blocks.ENDER_CHEST)
            || state.isOf(Blocks.SHULKER_BOX)
            || state.isOf(Blocks.WHITE_SHULKER_BOX)
            || state.isOf(Blocks.ORANGE_SHULKER_BOX)
            || state.isOf(Blocks.MAGENTA_SHULKER_BOX)
            || state.isOf(Blocks.LIGHT_BLUE_SHULKER_BOX)
            || state.isOf(Blocks.YELLOW_SHULKER_BOX)
            || state.isOf(Blocks.LIME_SHULKER_BOX)
            || state.isOf(Blocks.PINK_SHULKER_BOX)
            || state.isOf(Blocks.GRAY_SHULKER_BOX)
            || state.isOf(Blocks.LIGHT_GRAY_SHULKER_BOX)
            || state.isOf(Blocks.CYAN_SHULKER_BOX)
            || state.isOf(Blocks.PURPLE_SHULKER_BOX)
            || state.isOf(Blocks.BLUE_SHULKER_BOX)
            || state.isOf(Blocks.BROWN_SHULKER_BOX)
            || state.isOf(Blocks.GREEN_SHULKER_BOX)
            || state.isOf(Blocks.RED_SHULKER_BOX)
            || state.isOf(Blocks.BLACK_SHULKER_BOX);
      }
   }

   private void notify(String message) {
      try {
         NotificationManager.INSTANCE.push("Tunnel Base Finder", message, Items.DIAMOND_PICKAXE.getDefaultStack(), WaterPlus.getAccentARGB());
      } catch (Throwable var3) {
      }
   }

   private void releaseControls() {
      if (mc.options != null) {
         mc.options.forwardKey.setPressed(false);
         mc.options.leftKey.setPressed(false);
         mc.options.rightKey.setPressed(false);
         mc.options.sprintKey.setPressed(false);
         mc.options.attackKey.setPressed(false);
      }

      if (mc.interactionManager != null) {
         mc.interactionManager.cancelBlockBreaking();
      }

      this.mineTicks = 0;
      this.miningTarget = null;
   }
}

