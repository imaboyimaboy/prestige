package com.water.module.modules.render;

import com.water.module.Category;
import com.water.module.Module;
import com.water.setting.Setting;
import net.minecraft.client.option.Perspective;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector3d;

public class Freecam extends Module {
   private static final float MIN_SCROLL_SPEED = 0.1F;
   private static final float MAX_SCROLL_SPEED = 10.0F;
   private static final float SCROLL_SPEED_STEP = 0.2F;
   public final Vector3d currentPosition = new Vector3d();
   public final Vector3d previousPosition = new Vector3d();
   private final Vector3d velocity = new Vector3d();
   public float yaw;
   public float pitch;
   public float previousYaw;
   public float previousPitch;
   public final Setting<Float> speed = new Setting<>("Speed", 1.0F, 0.1F, 10.0F);
   public final Setting<Boolean> smoothing = new Setting<>("Smooth", Boolean.TRUE);
   public final Setting<Boolean> keepSneak = new Setting<>("Keep Sneak", Boolean.FALSE);
   public final Setting<Boolean> keepMovement = new Setting<>("Keep Movement", Boolean.FALSE);
   public final Setting<Boolean> tracerStickToEye = new Setting<>("Stick to Eye", Boolean.FALSE);
   private float lookSensitivity = 0.5F;
   private float currentSpeed;
   private Perspective savedPerspective;
   private boolean savedChunkCullingEnabled;
   private long lastFrameNanos;
   private float savedPlayerYaw;
   private float savedPlayerPitch;
   public boolean wasSneaking;
   private boolean heldForward;
   private boolean heldBackward;
   private boolean heldLeft;
   private boolean heldRight;
   private boolean heldJump;
   private boolean heldSneak;
   private boolean heldSprint;
   public static Freecam instance;

   public Freecam() {
      super("Freecam", Category.RENDER);
      instance = this;
      this.addSetting(this.speed);
      this.addSetting(this.smoothing);
      this.addSetting(this.keepSneak);
      this.addSetting(this.keepMovement);
      this.addSetting(this.tracerStickToEye);
   }

   @Override
   public void onEnable() {
      if (mc.player != null && mc.world != null) {
         this.savedPerspective = mc.options.getPerspective();
         this.savedChunkCullingEnabled = mc.chunkCullingEnabled;
         mc.chunkCullingEnabled = false;
         this.savedPlayerYaw = mc.player.getYaw();
         this.savedPlayerPitch = mc.player.getPitch();
         this.wasSneaking = mc.player.isSneaking();
         this.captureHeldMovement();
         this.yaw = mc.player.getYaw();
         this.pitch = mc.player.getPitch();
         Vec3d eyePos = mc.player.getCameraPosVec(1.0F);
         this.currentPosition.set(eyePos.x, eyePos.y, eyePos.z);
         this.previousPosition.set(eyePos.x, eyePos.y, eyePos.z);
         this.previousYaw = this.yaw;
         this.previousPitch = this.pitch;
         this.lastFrameNanos = System.nanoTime();
         this.velocity.set(0.0, 0.0, 0.0);
         this.currentSpeed = this.getConfiguredSpeed();
      } else {
         this.toggle();
      }
   }

   @Override
   public void onDisable() {
      if (mc.player != null) {
         mc.player.setYaw(this.savedPlayerYaw);
         mc.player.setPitch(this.savedPlayerPitch);
         mc.player.setHeadYaw(this.savedPlayerYaw);
         mc.player.setBodyYaw(this.savedPlayerYaw);
         mc.player.setYaw(this.savedPlayerYaw);
         mc.player.setHeadYaw(this.savedPlayerYaw);
         mc.player.setBodyYaw(this.savedPlayerYaw);
         mc.player.setSneaking(this.wasSneaking);
      }

      if (mc.options != null) {
         if (this.savedPerspective != null) {
            mc.options.setPerspective(this.savedPerspective);
         } else {
            mc.options.setPerspective(Perspective.FIRST_PERSON);
         }
      }

      mc.chunkCullingEnabled = this.savedChunkCullingEnabled;
      this.velocity.set(0.0, 0.0, 0.0);
      this.currentSpeed = this.getConfiguredSpeed();
      this.clearHeldMovement();
   }

   @Override
   public void onTick() {
      if (this.isEnabled() && mc.player != null && mc.world != null) {
         mc.player.setYaw(this.savedPlayerYaw);
         mc.player.setPitch(this.savedPlayerPitch);
         mc.player.setHeadYaw(this.savedPlayerYaw);
         mc.player.setBodyYaw(this.savedPlayerYaw);
         if (this.keepMovement.getValue()) {
            mc.player.setSneaking(this.heldSneak);
            mc.player.setSprinting(this.heldSprint);
         } else if (this.keepSneak.getValue() || this.wasSneaking) {
            mc.player.setSneaking(this.wasSneaking || this.keepSneak.getValue());
         }
      }
   }

   private void captureHeldMovement() {
      if (mc.options == null) {
         this.clearHeldMovement();
      } else {
         this.heldForward = mc.options.forwardKey.isPressed();
         this.heldBackward = mc.options.backKey.isPressed();
         this.heldLeft = mc.options.leftKey.isPressed();
         this.heldRight = mc.options.rightKey.isPressed();
         this.heldJump = mc.options.jumpKey.isPressed();
         this.heldSneak = mc.options.sneakKey.isPressed() || this.wasSneaking;
         this.heldSprint = mc.options.sprintKey.isPressed() || mc.player.isSprinting();
      }
   }

   private void clearHeldMovement() {
      this.heldForward = false;
      this.heldBackward = false;
      this.heldLeft = false;
      this.heldRight = false;
      this.heldJump = false;
      this.heldSneak = false;
      this.heldSprint = false;
   }

   public void updateCameraMovement() {
      long currentTime = System.nanoTime();
      float deltaTime = (float)((currentTime - this.lastFrameNanos) / 1.E9);
      this.lastFrameNanos = currentTime;
      this.updateCameraMovement(deltaTime);
   }

   public void updateCameraMovement(float deltaTime) {
      if (mc.player != null) {
         if (Float.isFinite(deltaTime) && !(deltaTime <= 0.0F)) {
            deltaTime = Math.min(deltaTime, 0.25F);
            this.previousPosition.set(this.currentPosition);
            this.previousYaw = this.yaw;
            this.previousPitch = this.pitch;
            float yawRad = (float)Math.toRadians(this.yaw);
            double forwardX = -Math.sin(yawRad);
            double forwardZ = Math.cos(yawRad);
            double rightX = -Math.cos(yawRad);
            double rightZ = -Math.sin(yawRad);
            double moveX = 0.0;
            double moveY = 0.0;
            double moveZ = 0.0;
            double moveSpeed = this.currentSpeed * 2.0;
            if (mc.options != null && mc.options.sprintKey.isPressed()) {
               moveSpeed *= 2.0;
            }

            if (mc.options.forwardKey.isPressed()) {
               moveX += forwardX * moveSpeed;
               moveZ += forwardZ * moveSpeed;
            }

            if (mc.options.backKey.isPressed()) {
               moveX -= forwardX * moveSpeed;
               moveZ -= forwardZ * moveSpeed;
            }

            if (mc.options.rightKey.isPressed()) {
               moveX += rightX * moveSpeed;
               moveZ += rightZ * moveSpeed;
            }

            if (mc.options.leftKey.isPressed()) {
               moveX -= rightX * moveSpeed;
               moveZ -= rightZ * moveSpeed;
            }

            if (mc.options.jumpKey.isPressed()) {
               moveY += moveSpeed;
            }

            if (mc.options.sneakKey.isPressed()) {
               moveY -= moveSpeed;
            }

            if (this.smoothing.getValue()) {
               double lerpFactor = 1.0 - Math.pow(0.001, deltaTime);
               this.velocity.x = MathHelper.lerp(lerpFactor, this.velocity.x, moveX * 5.0);
               this.velocity.y = MathHelper.lerp(lerpFactor, this.velocity.y, moveY * 5.0);
               this.velocity.z = MathHelper.lerp(lerpFactor, this.velocity.z, moveZ * 5.0);
            } else {
               double fastFactor = 1.0 - Math.exp(-deltaTime / 0.012);
               this.velocity.x = MathHelper.lerp(fastFactor, this.velocity.x, moveX * 5.0);
               this.velocity.y = MathHelper.lerp(fastFactor, this.velocity.y, moveY * 5.0);
               this.velocity.z = MathHelper.lerp(fastFactor, this.velocity.z, moveZ * 5.0);
            }

            this.currentPosition.x = this.currentPosition.x + this.velocity.x * deltaTime;
            this.currentPosition.y = this.currentPosition.y + this.velocity.y * deltaTime;
            this.currentPosition.z = this.currentPosition.z + this.velocity.z * deltaTime;
         }
      }
   }

   public void onScrollWheel(double scrollDelta) {
      float current = this.currentSpeed;
      float newVal = current + (float)scrollDelta * 0.5F;
      this.currentSpeed = MathHelper.clamp(newVal, 0.1F, 10.0F);
   }

   public void updateRotation(double deltaYaw, double deltaPitch) {
      this.yaw += (float)deltaYaw;
      this.pitch += (float)deltaPitch;
      this.yaw = MathHelper.wrapDegrees(this.yaw);
      this.pitch = MathHelper.clamp(this.pitch, -90.0F, 90.0F);
   }

   public double getInterpolatedX(float partialTicks) {
      return this.currentPosition.x;
   }

   public double getInterpolatedY(float partialTicks) {
      return this.currentPosition.y;
   }

   public double getInterpolatedZ(float partialTicks) {
      return this.currentPosition.z;
   }

   public float getInterpolatedYaw(float partialTicks) {
      return this.yaw;
   }

   public float getInterpolatedPitch(float partialTicks) {
      return this.pitch;
   }

   public float getLookSensitivity() {
      return this.lookSensitivity;
   }

   public float getFrozenPlayerYaw() {
      return this.savedPlayerYaw;
   }

   public float getFrozenPlayerPitch() {
      return this.savedPlayerPitch;
   }

   public void adjustSpeed(double scrollAmount) {
      if (scrollAmount != 0.0) {
         float nextSpeed = this.currentSpeed + (float)Math.signum(scrollAmount) * 0.2F;
         this.currentSpeed = MathHelper.clamp(nextSpeed, 0.1F, 10.0F);
      }
   }

   private float getConfiguredSpeed() {
      return MathHelper.clamp(this.speed.getValue(), 0.1F, 10.0F);
   }

   public boolean shouldKeepMovement() {
      return this.keepMovement.getValue();
   }

   public PlayerInput getHeldMovementInput() {
      return new PlayerInput(this.heldForward, this.heldBackward, this.heldLeft, this.heldRight, this.heldJump, this.heldSneak, this.heldSprint);
   }

   public Vec2f getHeldMovementVector() {
      float sideways = 0.0F;
      float forward = 0.0F;
      if (this.heldForward) {
         forward++;
      }

      if (this.heldBackward) {
         forward--;
      }

      if (this.heldLeft) {
         sideways++;
      }

      if (this.heldRight) {
         sideways--;
      }

      if (sideways != 0.0F && forward != 0.0F) {
         float inv = (float)(1.0 / Math.sqrt(sideways * sideways + forward * forward));
         sideways *= inv;
         forward *= inv;
      }

      return new Vec2f(sideways, forward);
   }

   public boolean shouldRenderSneaking() {
      return this.keepMovement.getValue() ? this.heldSneak : this.keepSneak.getValue() || this.wasSneaking;
   }

   public boolean shouldTracersStickToEye() {
      return this.tracerStickToEye.getValue();
   }

   public static Vec3d resolveTracerOrigin(Vec3d fallbackCameraPos, float tickDelta) {
      return instance != null && instance.isEnabled() && instance.shouldTracersStickToEye() && mc.player != null
         ? mc.player.getCameraPosVec(tickDelta)
         : fallbackCameraPos;
   }
}

