package com.water.mixin;

import com.water.module.modules.render.DevSpawnerVisuals;
import java.util.List;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.block.BlockRenderManager;
import net.minecraft.client.render.model.BlockModelPart;
import net.minecraft.client.render.model.BlockStateModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.BlockRenderView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({BlockRenderManager.class})
public class BlockRenderManagerMixin {
   @Inject(
      method = {"renderBlock"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void water$renderSelectedBlocksAsSpawner(
      BlockState state,
      BlockPos pos,
      BlockRenderView world,
      MatrixStack matrices,
      VertexConsumer vertexConsumer,
      boolean cull,
      List<BlockModelPart> parts,
      CallbackInfo ci
   ) {
      if (DevSpawnerVisuals.shouldRenderAsSpawner(state)) {
         DevSpawnerVisuals.markRendered(pos);
         BlockRenderManager renderer = (BlockRenderManager)(Object)this;
         BlockState spawnerState = Blocks.SPAWNER.getDefaultState();
         BlockStateModel spawnerModel = renderer.getModel(spawnerState);
         List<BlockModelPart> spawnerParts = spawnerModel.getParts(Random.create(pos.asLong()));
         renderer.renderBlock(spawnerState, pos, world, matrices, vertexConsumer, cull, spawnerParts);
         ci.cancel();
      }
   }
}

