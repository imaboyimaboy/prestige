package rtx.kimiko.api.mods.geckolib.loading.math;

import it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet;
import java.util.Set;
import java.util.function.ToDoubleFunction;
import rtx.kimiko.api.mods.geckolib.animation.state.ControllerState;
import rtx.kimiko.api.mods.geckolib.loading.math.value.Variable;

public interface MathValue extends ToDoubleFunction<ControllerState> {
   double get(ControllerState var1);

   default double applyAsDouble(ControllerState controllerState) {
      return this.get(controllerState);
   }

   default Set<Variable> getUsedVariables() {
      return Set.of();
   }

   static Set<Variable> collectUsedVariables(MathValue... mathValueArray) {
      if (mathValueArray.length == 0) {
         return Set.of();
      } else if (mathValueArray.length == 1) {
         return mathValueArray[0].getUsedVariables();
      } else {
         ReferenceOpenHashSet referenceOpenHashSet = new ReferenceOpenHashSet();

         for (MathValue mathValue : mathValueArray) {
            referenceOpenHashSet.addAll(mathValue.getUsedVariables());
         }

         return referenceOpenHashSet;
      }
   }

   default boolean isMutable() {
      return true;
   }
}

