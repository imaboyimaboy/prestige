package rtx.kimiko.api.drags.components;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Formatting;
import rtx.kimiko.api.drags.DragSystem;
import rtx.kimiko.api.modules.impl.Interface.PotionsModule;
import rtx.kimiko.utils.color.ColorUtil;
import rtx.kimiko.utils.render.render2d.Render2D;

public final class PotionsComp extends ListHudComp {
   private static final RegistryEntry<StatusEffect>[] PREVIEW_EFFECTS = new RegistryEntry[]{
      StatusEffects.SPEED, StatusEffects.JUMP_BOOST, StatusEffects.REGENERATION, StatusEffects.FIRE_RESISTANCE
   };
   private static final int NEGATIVE_COLOR = ColorUtil.lerpColor(-3355444, -53714, 0.32F);
   private static final float ICON_SCALE = 0.5F;
   private static final float EFFECT_ICON_SIZE = 8.0F;
   private long previewSwitchMs;
   private int previewIndex;
   private static final int PULSE_THRESHOLD_TICKS = 200;
   private static final long PULSE_PERIOD_MS = 900L;
   private static final float PULSE_MIN_ALPHA = 0.2F;

   public PotionsComp() {
      super("potions", "Potions", PotionsModule.class, 104.0F, 33.0F);
   }

   private static boolean isNegative(RegistryEntry<StatusEffect> registryEntry) {
      return ((StatusEffect)registryEntry.value()).getCategory() == StatusEffectCategory.HARMFUL
         ? true
         : registryEntry.value() == StatusEffects.SLOW_FALLING.value();
   }

   private static float smooth(float f) {
      f = Math.max(0.0F, Math.min(1.0F, f));
      return f * f * (3.0F - 2.0F * f);
   }

   @Override
   protected String headerIconGlyph() {
      return "s";
   }

   @Override
   protected List<ListHudComp.Row> collectRows() {
      ArrayList<ListHudComp.Row> arrayList = new ArrayList<>();
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      if (minecraftClient.player == null) {
         if (DragSystem.get().isDragModeActive()) {
            arrayList.add(this.previewRow());
         }

         return arrayList;
      } else {
         for (StatusEffectInstance statusEffectInstance : minecraftClient.player.getStatusEffects()) {
            if (statusEffectInstance != null) {
               RegistryEntry registryEntry = statusEffectInstance.getEffectType();
               Object object = Formatting.strip(((StatusEffect)registryEntry.value()).getName().getString());
               int n = statusEffectInstance.getAmplifier();
               if (n > 0) {
                  object = (String)object + " " + (n + 1);
               }

               int n2 = isNegative(registryEntry) ? -3355444 : 0;
               arrayList.add(
                  new Row(
                     registryEntry,
                     (String)object,
                     formatDuration(statusEffectInstance),
                     (drawContext, f, f2, f3, f4) -> drawEffectIcon(registryEntry, f, f2, f3, f4),
                     expiryPulse(statusEffectInstance),
                     n2
                  )
               );
            }
         }

         if (arrayList.isEmpty() && DragSystem.get().isDragModeActive()) {
            arrayList.add(this.previewRow());
         }

         return arrayList;
      }
   }

   private static String formatDuration(StatusEffectInstance statusEffectInstance) {
      if (statusEffectInstance.isInfinite()) {
         return "**:**";
      } else {
         int n = Math.max(0, statusEffectInstance.getDuration()) / 20;
         int n2 = n / 60;
         return n2 + ":" + String.format(Locale.ROOT, "%02d", n % 60);
      }
   }

   private static void drawEffectIcon(RegistryEntry<StatusEffect> registryEntry, float f, float f2, float f3, float f4) {
      float f5 = (f3 - 8.0F) * 0.5F;
      Render2D.effectIcon(registryEntry, f + f5, f2 + f5, 8.0F, ColorUtil.multAlpha(-1, f4));
   }

   private static ListHudComp.AlphaPulse expiryPulse(StatusEffectInstance statusEffectInstance) {
      return !statusEffectInstance.isInfinite() && statusEffectInstance.getDuration() <= 200 ? () -> {
         int n = Math.max(0, statusEffectInstance.getDuration());
         if (n > 200) {
            return 1.0F;
         } else {
            float f = 1.0F - n / 200.0F;
            float f2 = smooth(f) * 0.8F;
            float f3 = (float)(System.currentTimeMillis() % 900L) / 900.0F;
            float f4 = 0.5F - 0.5F * (float)Math.cos(f3 * 2.0 * Math.PI);
            return 1.0F - f2 * f4;
         }
      } : null;
   }

   private ListHudComp.Row previewRow() {
      long l = System.currentTimeMillis();
      if (l - this.previewSwitchMs >= 1000L) {
         this.previewIndex = (this.previewIndex + 1) % PREVIEW_EFFECTS.length;
         this.previewSwitchMs = l;
      }

      RegistryEntry<StatusEffect> registryEntry = PREVIEW_EFFECTS[this.previewIndex];
      return new Row("preview", "Example effect", "**:**", (drawContext, f, f2, f3, f4) -> drawEffectIcon(registryEntry, f, f2, f3, f4));
   }
}

