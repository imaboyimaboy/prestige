package com.water.utils.renderer.blur;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;
import com.water.utils.renderer.RenderUtil;
import java.nio.ByteBuffer;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.GpuSampler;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.system.MemoryUtil;

public class KawasePipeline {
   private static final int BLUR_ITERATIONS = 5;
   private static final int DOWNSAMPLE_SCALE = 2;
   private static final int BUFFER_SIZE = 256;
   private static final RenderPipeline PIPELINE_BLUR = RenderPipelines.register(
      RenderPipeline.builder(new Snippet[]{RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET})
         .withLocation(Identifier.of("water", "pipeline/blur_pass"))
         .withVertexShader(Identifier.of("water", "blur_pass_vertex"))
         .withFragmentShader(Identifier.of("water", "blur_pass_fragment"))
         .withVertexFormat(VertexFormats.EMPTY, DrawMode.TRIANGLES)
         .withUniform("BlurData", UniformType.UNIFORM_BUFFER)
         .withSampler("Sampler0")
         .withBlend(BlendFunction.TRANSLUCENT)
         .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
         .withDepthWrite(false)
         .withCull(false)
         .build()
   );
   private static final RenderPipeline PIPELINE_FINAL = RenderPipelines.register(
      RenderPipeline.builder(new Snippet[]{RenderPipelines.TRANSFORMS_AND_PROJECTION_SNIPPET})
         .withLocation(Identifier.of("water", "pipeline/blur_final"))
         .withVertexShader(Identifier.of("water", "blur_final_vertex"))
         .withFragmentShader(Identifier.of("water", "blur_final_fragment"))
         .withVertexFormat(VertexFormats.EMPTY, DrawMode.TRIANGLES)
         .withUniform("BlurData", UniformType.UNIFORM_BUFFER)
         .withSampler("Sampler0")
         .withBlend(BlendFunction.TRANSLUCENT)
         .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
         .withDepthWrite(false)
         .withCull(false)
         .build()
   );
   private static final Vector4f COLOR_MODULATOR = new Vector4f(1.0F, 1.0F, 1.0F, 1.0F);
   private static final Vector3f MODEL_OFFSET = new Vector3f(0.0F, 0.0F, 0.0F);
   private static final Matrix4f TEXTURE_MATRIX = new Matrix4f();
   private static GpuBuffer uniformBuffer;
   private static GpuBuffer dummyVertexBuffer;
   private static ByteBuffer dataBuffer;
   private static final int PASS_POOL_SIZE = 24;
   private static final GpuBuffer[] passBuffers = new GpuBuffer[24];
   private static final ByteBuffer[] passData = new ByteBuffer[24];
   private static int passCursor = 0;
   private static GpuTexture copyTexture;
   private static GpuTextureView copyTextureView;
   private static GpuTexture[] pingPongTextures = new GpuTexture[2];
   private static GpuTextureView[] pingPongViews = new GpuTextureView[2];
   private static int lastWidth = 0;
   private static int lastHeight = 0;
   private static boolean initialized = false;
   private static long lastFrameTime = -1L;
   private static int cachedBlurSrc = 0;
   private static float cachedStrength = 0.0F;
   private static boolean frameDirty = true;

   public static void beginFrame() {
      frameDirty = true;
   }

   public static void init() {
      if (!initialized) {
         ByteBuffer dummyData = MemoryUtil.memAlloc(4);
         dummyData.putInt(0);
         dummyData.flip();
         dummyVertexBuffer = RenderSystem.getDevice().createBuffer(() -> "water:blur_dummy_vertex", 32, dummyData);
         MemoryUtil.memFree(dummyData);
         initialized = true;
      }
   }

   public static void captureFramebuffer() {
      MinecraftClient client = MinecraftClient.getInstance();
      int fbWidth = client.getFramebuffer().textureWidth;
      int fbHeight = client.getFramebuffer().textureHeight;
      ensureTextures(fbWidth, fbHeight);
      CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
      encoder.copyTextureToTexture(client.getFramebuffer().getColorAttachment(), copyTexture, 0, 0, 0, 0, 0, fbWidth, fbHeight);
      lastFrameTime = -1L;
   }

   private static void ensureTextures(int fbWidth, int fbHeight) {
      int blurWidth = fbWidth / 2;
      int blurHeight = fbHeight / 2;
      if (copyTexture == null || fbWidth != lastWidth || fbHeight != lastHeight) {
         if (copyTextureView != null) {
            copyTextureView.close();
            copyTextureView = null;
         }

         if (copyTexture != null) {
            copyTexture.close();
            copyTexture = null;
         }

         copyTexture = RenderSystem.getDevice().createTexture(() -> "water:blur_copy", 5, TextureFormat.RGBA8, fbWidth, fbHeight, 1, 1);
         copyTextureView = RenderSystem.getDevice().createTextureView(copyTexture);

         for (int i = 0; i < 2; i++) {
            if (pingPongViews[i] != null) {
               pingPongViews[i].close();
               pingPongViews[i] = null;
            }

            if (pingPongTextures[i] != null) {
               pingPongTextures[i].close();
               pingPongTextures[i] = null;
            }

            int idx = i;
            pingPongTextures[i] = RenderSystem.getDevice().createTexture(() -> "water:blur_pp_" + idx, 13, TextureFormat.RGBA8, blurWidth, blurHeight, 1, 1);
            pingPongViews[i] = RenderSystem.getDevice().createTextureView(pingPongTextures[i]);
         }

         lastWidth = fbWidth;
         lastHeight = fbHeight;
         lastFrameTime = -1L;
      }
   }

   public static void draw(Matrix4f matrix, float x, float y, float width, float height, float radius, float strength, float z) {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client.getFramebuffer() != null) {
         if (client.getFramebuffer().getColorAttachment() != null) {
            init();
            int fbWidth = client.getFramebuffer().textureWidth;
            int fbHeight = client.getFramebuffer().textureHeight;
            int blurWidth = fbWidth / 2;
            int blurHeight = fbHeight / 2;
            ensureTextures(fbWidth, fbHeight);
            long currentTime = System.nanoTime() / 16666666L;
            boolean needsBlur = frameDirty || Math.abs(strength - cachedStrength) > 0.01F;
            GpuSampler sampler = RenderSystem.getSamplerCache().get(FilterMode.LINEAR);
            GpuBufferSlice dynamicTransforms = RenderSystem.getDynamicUniforms()
               .write(RenderSystem.getModelViewMatrix(), COLOR_MODULATOR, MODEL_OFFSET, TEXTURE_MATRIX);
            CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
            if (needsBlur) {
               encoder.copyTextureToTexture(client.getFramebuffer().getColorAttachment(), copyTexture, 0, 0, 0, 0, 0, fbWidth, fbHeight);
               prepareBlurData(fbWidth, fbHeight, blurWidth, blurHeight, 1.0F, strength);
               encoder.writeToBuffer(uniformBuffer.slice(), dataBuffer);
               RenderPass downsample = encoder.createRenderPass(
                  () -> "water:blur_downsample", pingPongViews[0], OptionalInt.empty(), null, OptionalDouble.empty()
               );

               try {
                  downsample.setPipeline(PIPELINE_BLUR);
                  downsample.setVertexBuffer(0, dummyVertexBuffer);
                  downsample.bindTexture("Sampler0", copyTextureView, sampler);
                  RenderSystem.bindDefaultUniforms(downsample);
                  downsample.setUniform("DynamicTransforms", dynamicTransforms);
                  downsample.setUniform("BlurData", uniformBuffer);
                  downsample.draw(0, 6);
               } catch (Throwable var34) {
                  if (downsample != null) {
                     try {
                        downsample.close();
                     } catch (Throwable var31) {
                        var34.addSuppressed(var31);
                     }
                  }

                  throw var34;
               }

               if (downsample != null) {
                  downsample.close();
               }

               int iterations = Math.min(10, Math.max(2, (int)(5.0F * strength)));
               float[] offsets = new float[]{1.0F, 2.0F, 2.0F, 3.0F};

               for (int i = 0; i < iterations; i++) {
                  int src = i % 2;
                  int dst = (i + 1) % 2;
                  float offset = i < offsets.length ? offsets[i] : 3.0F;
                  int passIdx = i;
                  prepareBlurData(blurWidth, blurHeight, blurWidth, blurHeight, offset, 1.0F);
                  encoder.writeToBuffer(uniformBuffer.slice(), dataBuffer);
                  RenderPass pass = encoder.createRenderPass(
                     () -> "water:blur_" + passIdx, pingPongViews[dst], OptionalInt.empty(), null, OptionalDouble.empty()
                  );

                  try {
                     pass.setPipeline(PIPELINE_BLUR);
                     pass.setVertexBuffer(0, dummyVertexBuffer);
                     pass.bindTexture("Sampler0", pingPongViews[src], sampler);
                     RenderSystem.bindDefaultUniforms(pass);
                     pass.setUniform("DynamicTransforms", dynamicTransforms);
                     pass.setUniform("BlurData", uniformBuffer);
                     pass.draw(0, 6);
                  } catch (Throwable var33) {
                     if (pass != null) {
                        try {
                           pass.close();
                        } catch (Throwable var30) {
                           var33.addSuppressed(var30);
                        }
                     }

                     throw var33;
                  }

                  if (pass != null) {
                     pass.close();
                  }
               }

               cachedBlurSrc = iterations % 2;
               lastFrameTime = currentTime;
               cachedStrength = strength;
               frameDirty = false;
            }

            float[] radii = new float[]{radius, radius, radius, radius};
            int scaledW = RenderUtil.getFixedScaledWidth();
            int scaledH = RenderUtil.getFixedScaledHeight();
            prepareFinalData(matrix, x, y, width, height, scaledW, scaledH, radii, z);
            encoder.writeToBuffer(uniformBuffer.slice(), dataBuffer);
            RenderPass finalPass = encoder.createRenderPass(
               () -> "water:blur_final",
               client.getFramebuffer().getColorAttachmentView(),
               OptionalInt.empty(),
               client.getFramebuffer().getDepthAttachmentView(),
               OptionalDouble.of(1.0)
            );

            try {
               RenderUtil.applyScissor(finalPass);
               finalPass.setPipeline(PIPELINE_FINAL);
               finalPass.setVertexBuffer(0, dummyVertexBuffer);
               finalPass.bindTexture("Sampler0", pingPongViews[cachedBlurSrc], sampler);
               RenderSystem.bindDefaultUniforms(finalPass);
               finalPass.setUniform("DynamicTransforms", dynamicTransforms);
               finalPass.setUniform("BlurData", uniformBuffer);
               finalPass.draw(0, 6);
            } catch (Throwable var32) {
               if (finalPass != null) {
                  try {
                     finalPass.close();
                  } catch (Throwable var29) {
                     var32.addSuppressed(var29);
                  }
               }

               throw var32;
            }

            if (finalPass != null) {
               finalPass.close();
            }
         }
      }
   }

   private static void advancePassSlot() {
      passCursor = (passCursor + 1) % 24;
      if (passData[passCursor] == null) {
         passData[passCursor] = MemoryUtil.memAlloc(256);
      }

      dataBuffer = passData[passCursor];
   }

   private static void prepareBlurData(int screenW, int screenH, int texW, int texH, float offset, float strength) {
      advancePassSlot();
      dataBuffer.clear();

      for (int i = 0; i < 16; i++) {
         dataBuffer.putFloat(0.0F);
      }

      dataBuffer.putFloat(0.0F).putFloat(0.0F).putFloat(screenW).putFloat(screenH);
      dataBuffer.putFloat(screenW).putFloat(screenH).putFloat(1.0F).putFloat(offset);
      dataBuffer.putFloat(texW).putFloat(texH).putFloat(1.0F).putFloat(strength);
      dataBuffer.putFloat(0.0F).putFloat(0.0F).putFloat(0.0F).putFloat(0.0F);
      dataBuffer.putFloat(0.0F).putFloat(0.0F).putFloat(0.0F).putFloat(0.0F);
      dataBuffer.flip();
      ensureBuffer();
   }

   private static void prepareFinalData(Matrix4f matrix, float x, float y, float w, float h, int fbW, int fbH, float[] r, float z) {
      advancePassSlot();
      dataBuffer.clear();
      dataBuffer.putFloat(matrix.m00()).putFloat(matrix.m01()).putFloat(matrix.m02()).putFloat(matrix.m03());
      dataBuffer.putFloat(matrix.m10()).putFloat(matrix.m11()).putFloat(matrix.m12()).putFloat(matrix.m13());
      dataBuffer.putFloat(matrix.m20()).putFloat(matrix.m21()).putFloat(matrix.m22()).putFloat(matrix.m23());
      dataBuffer.putFloat(matrix.m30()).putFloat(matrix.m31()).putFloat(matrix.m32()).putFloat(matrix.m33());
      dataBuffer.putFloat(x).putFloat(y).putFloat(w).putFloat(h);
      dataBuffer.putFloat(fbW).putFloat(fbH).putFloat(0.0F).putFloat(0.0F);
      dataBuffer.putFloat(fbW).putFloat(fbH).putFloat(1.0F).putFloat(0.0F);
      dataBuffer.putFloat(r[0]).putFloat(r[1]).putFloat(r[2]).putFloat(r[3]);
      dataBuffer.putFloat(z).putFloat(0.0F).putFloat(0.0F).putFloat(0.0F);
      dataBuffer.flip();
      ensureBuffer();
   }

   private static void ensureBuffer() {
      int size = dataBuffer.remaining();
      if (passBuffers[passCursor] == null || passBuffers[passCursor].size() < size) {
         if (passBuffers[passCursor] != null) {
            passBuffers[passCursor].close();
         }

         int idx = passCursor;
         passBuffers[passCursor] = RenderSystem.getDevice().createBuffer(() -> "water:blur_uniform_" + idx, 136, size);
      }

      uniformBuffer = passBuffers[passCursor];
   }

   public static GpuTextureView getBlurTextureView() {
      return initialized && pingPongViews[cachedBlurSrc] != null ? pingPongViews[cachedBlurSrc] : null;
   }

   public static void shutdown() {
      uniformBuffer = null;
      dataBuffer = null;

      for (int i = 0; i < 24; i++) {
         if (passBuffers[i] != null) {
            passBuffers[i].close();
            passBuffers[i] = null;
         }

         if (passData[i] != null) {
            MemoryUtil.memFree(passData[i]);
            passData[i] = null;
         }
      }

      passCursor = 0;
      if (dummyVertexBuffer != null) {
         dummyVertexBuffer.close();
         dummyVertexBuffer = null;
      }

      if (copyTextureView != null) {
         copyTextureView.close();
         copyTextureView = null;
      }

      if (copyTexture != null) {
         copyTexture.close();
         copyTexture = null;
      }

      for (int i = 0; i < 2; i++) {
         if (pingPongViews[i] != null) {
            pingPongViews[i].close();
            pingPongViews[i] = null;
         }

         if (pingPongTextures[i] != null) {
            pingPongTextures[i].close();
            pingPongTextures[i] = null;
         }
      }

      lastWidth = 0;
      lastHeight = 0;
      initialized = false;
      lastFrameTime = -1L;
   }
}

