package com.water.module.modules.donut;

import com.water.module.Category;
import com.water.module.Module;
import com.water.setting.Setting;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.scoreboard.ScoreAccess;
import net.minecraft.scoreboard.ScoreHolder;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardCriterion;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardEntry;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.Team;
import net.minecraft.scoreboard.ScoreboardCriterion.RenderType;
import net.minecraft.scoreboard.number.BlankNumberFormat;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;

public final class FakeStats extends Module {
   private static FakeStats INSTANCE;
   private static final String OBJECTIVE_NAME = "water_fake_stats";
   private static final int MAX_SIDEBAR_LINES = 15;
   private final Setting<String> money = new Setting<>("Money", "0");
   private final Setting<String> shards = new Setting<>("Shards", "0");
   private final Setting<String> kills = new Setting<>("Kills", "0");
   private final Setting<String> deaths = new Setting<>("Deaths", "0");
   private final Setting<String> playtime = new Setting<>("Playtime", "0m");
   private final Random randomSource = new Random();
   private ScoreboardObjective originalObjective;
   private String originalObjectiveName;
   private ScoreboardObjective customObjective;
   private FakeStats.AppliedStats appliedStats;
   private Object lastWorld;
   private String lastSnapshotSignature = "";
   private boolean needsRefresh;
   private long lastRebuildMs = 0L;
   private static final long REBUILD_COOLDOWN_MS = 500L;

   public static FakeStats getInstance() {
      return INSTANCE;
   }

   public FakeStats() {
      super("FakeStats", Category.DONUT);
      INSTANCE = this;
      this.addSetting(this.money);
      this.addSetting(this.shards);
      this.addSetting(this.kills);
      this.addSetting(this.deaths);
      this.addSetting(this.playtime);
   }

   @Override
   public void onEnable() {
      this.lastWorld = mc.world;
      this.originalObjective = null;
      this.originalObjectiveName = null;
      this.customObjective = null;
      this.lastSnapshotSignature = "";
      this.randomizeSettings();
      this.applyCurrentValues();
      this.needsRefresh = true;
   }

   @Override
   public void onDisable() {
      this.lastWorld = null;
      this.lastSnapshotSignature = "";
      this.needsRefresh = false;
      ScoreboardObjective toRestore = this.originalObjective;
      ScoreboardObjective toRemove = this.customObjective;
      this.originalObjective = null;
      this.originalObjectiveName = null;
      this.customObjective = null;
      if (mc.world != null) {
         Scoreboard sb = mc.world.getScoreboard();

         try {
            if (toRemove != null) {
               sb.removeObjective(toRemove);
            }

            if (toRestore != null && sb.getObjectives().contains(toRestore)) {
               sb.setObjectiveSlot(ScoreboardDisplaySlot.SIDEBAR, toRestore);
            }
         } catch (Exception var5) {
         }
      }
   }

   @Override
   public void onTick() {
      if (mc.world == null) {
         this.originalObjective = null;
         this.originalObjectiveName = null;
         this.customObjective = null;
         this.lastWorld = null;
         this.lastSnapshotSignature = "";
      } else {
         if (mc.world != this.lastWorld) {
            this.originalObjective = null;
            this.originalObjectiveName = null;
            this.customObjective = null;
            this.lastSnapshotSignature = "";
            this.lastWorld = mc.world;
            this.needsRefresh = true;
         }

         this.captureOriginalObjective();
         if (this.originalObjective != null) {
            Scoreboard scoreboard = mc.world.getScoreboard();
            if (!scoreboard.getObjectives().contains(this.originalObjective)) {
               this.originalObjective = null;
               this.captureOriginalObjective();
               if (this.originalObjective == null) {
                  return;
               }
            }

            FakeStats.Snapshot snapshot = this.createSnapshot(scoreboard, this.originalObjective);
            if (snapshot != null) {
               this.syncAppliedStatsWithSettings();
               if (!snapshot.signature().equals(this.lastSnapshotSignature) || this.customObjective == null) {
                  this.needsRefresh = true;
               }

               this.rebuildIfPossible(scoreboard, snapshot);
               if (this.customObjective != null && scoreboard.getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR) != this.customObjective) {
                  scoreboard.setObjectiveSlot(ScoreboardDisplaySlot.SIDEBAR, this.customObjective);
               }
            }
         }
      }
   }

   private void randomizeSettings() {
      this.money.setValue(this.formatCompactNumber(this.randomBetweenLong(10000L, 5000000000L)));
      this.shards.setValue(this.formatCompactNumber(this.randomBetweenLong(0L, 2500000L)));
      this.kills.setValue(String.valueOf(this.randomBetweenLong(0L, 2000L)));
      this.deaths.setValue(String.valueOf(this.randomBetweenLong(0L, 1000L)));
      this.playtime.setValue(this.formatCompactPlaytime(this.randomBetweenLong(0L, 15552000L)));
   }

   private void applyCurrentValues() {
      this.appliedStats = new AppliedStats(
         this.sanitize(this.money.getValue(), "0"),
         this.sanitize(this.shards.getValue(), "0"),
         this.sanitize(this.kills.getValue(), "0"),
         this.sanitize(this.deaths.getValue(), "0"),
         this.sanitize(this.playtime.getValue(), "0m")
      );
      this.needsRefresh = true;
   }

   private void syncAppliedStatsWithSettings() {
      FakeStats.AppliedStats current = new AppliedStats(
         this.sanitize(this.money.getValue(), "0"),
         this.sanitize(this.shards.getValue(), "0"),
         this.sanitize(this.kills.getValue(), "0"),
         this.sanitize(this.deaths.getValue(), "0"),
         this.sanitize(this.playtime.getValue(), "0m")
      );
      if (this.appliedStats == null || !this.appliedStats.signature().equals(current.signature())) {
         this.appliedStats = current;
         this.needsRefresh = true;
      }
   }

   private void captureOriginalObjective() {
      if (mc.world != null) {
         Scoreboard scoreboard = mc.world.getScoreboard();
         ScoreboardObjective current = scoreboard.getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR);
         if (current != null && !"water_fake_stats".equals(current.getName())) {
            this.originalObjective = current;
            this.originalObjectiveName = current.getName();
         } else if (this.originalObjective == null || !scoreboard.getObjectives().contains(this.originalObjective)) {
            if (this.originalObjectiveName != null) {
               ScoreboardObjective namedObjective = scoreboard.getNullableObjective(this.originalObjectiveName);
               if (namedObjective != null && !"water_fake_stats".equals(namedObjective.getName())) {
                  this.originalObjective = namedObjective;
                  return;
               }
            }

            for (ScoreboardObjective objective : scoreboard.getObjectives()) {
               if (!"water_fake_stats".equals(objective.getName())) {
                  this.originalObjective = objective;
                  this.originalObjectiveName = objective.getName();
                  return;
               }
            }
         }
      }
   }

   private FakeStats.Snapshot createSnapshot(Scoreboard scoreboard, ScoreboardObjective objective) {
      List<FakeStats.SourceLine> lines = new ArrayList<>();
      List<ScoreboardEntry> entries = new ArrayList<>(scoreboard.getScoreboardEntries(objective));
      entries.removeIf(ScoreboardEntry::hidden);
      entries.sort(Comparator.comparingInt(ScoreboardEntry::value).reversed());
      if (entries.size() > 15) {
         entries = new ArrayList<>(entries.subList(0, 15));
      }

      for (ScoreboardEntry entry : entries) {
         lines.add(new SourceLine(entry.value(), this.getVisibleLine(scoreboard, entry)));
      }

      Text title = objective.getDisplayName() != null ? objective.getDisplayName().copy() : Text.literal("Donut SMP");
      StringBuilder signature = new StringBuilder(title.getString());

      for (FakeStats.SourceLine line : lines) {
         signature.append('\n').append(line.score()).append(':').append(line.text().getString());
      }

      signature.append('\n').append(this.appliedStats != null ? this.appliedStats.signature() : "");
      return new Snapshot(title, lines, signature.toString());
   }

   private Text getVisibleLine(Scoreboard scoreboard, ScoreboardEntry entry) {
      if (entry.display() != null) {
         return entry.display().copy();
      } else {
         Text baseText = entry.name() != null ? entry.name().copy() : Text.literal(entry.owner());
         Team team = scoreboard.getScoreHolderTeam(entry.owner());
         return Team.decorateName(team, baseText).copy();
      }
   }

   private void rebuildIfPossible(Scoreboard scoreboard, FakeStats.Snapshot snapshot) {
      if (this.needsRefresh && this.appliedStats != null) {
         long now = System.currentTimeMillis();
         if (now - this.lastRebuildMs >= 500L) {
            this.lastRebuildMs = now;
            ScoreboardObjective existing = scoreboard.getNullableObjective("water_fake_stats");
            if (existing != null) {
               scoreboard.removeObjective(existing);
            }

            this.customObjective = scoreboard.addObjective(
               "water_fake_stats", ScoreboardCriterion.DUMMY, snapshot.title().copy(), RenderType.INTEGER, true, BlankNumberFormat.INSTANCE
            );
            scoreboard.setObjectiveSlot(ScoreboardDisplaySlot.SIDEBAR, this.customObjective);
            List<FakeStats.SourceLine> lines = snapshot.lines();
            int statLineIndex = 0;

            for (int i = 0; i < lines.size(); i++) {
               FakeStats.SourceLine line = lines.get(i);
               ScoreHolder holder = ScoreHolder.fromName("fake_stats_line_" + i);
               ScoreAccess score = scoreboard.getOrCreateScore(holder, this.customObjective);
               score.setScore(lines.size() - i);
               String lineStr = line.text().getString().trim();
               boolean hasNumber = lineStr.matches(".*\\d.*");
               if (hasNumber) {
                  score.setDisplayText(this.replaceStatByIndex(line.text(), statLineIndex));
                  statLineIndex++;
               } else {
                  score.setDisplayText(line.text().copy());
               }

               score.setNumberFormat(BlankNumberFormat.INSTANCE);
            }

            this.lastSnapshotSignature = snapshot.signature();
            this.needsRefresh = false;
         }
      }
   }

   private Text replaceStatByIndex(Text originalText, int index) {
      String[] values = new String[]{
         this.appliedStats.money(), this.appliedStats.shards(), this.appliedStats.kills(), this.appliedStats.deaths(), this.appliedStats.playtime()
      };
      if (index >= values.length) {
         return originalText.copy();
      } else {
         String newValue = values[index];
         List<FakeStats.TextSegment> segments = this.collectSegments(originalText);
         String full = originalText.getString();
         int numStart = -1;

         for (int i = 0; i < full.length(); i++) {
            char ch = full.charAt(i);
            if (Character.isDigit(ch) || ch == '-' && i + 1 < full.length() && Character.isDigit(full.charAt(i + 1))) {
               numStart = i;
               break;
            }
         }

         if (numStart >= 0) {
            MutableText result = Text.empty();
            this.appendTextRange(result, segments, numStart);
            result.append(Text.literal(newValue).setStyle(this.findStyleAt(segments, numStart)));
            return result;
         } else {
            MutableText result = Text.empty();

            for (FakeStats.TextSegment seg : segments) {
               result.append(Text.literal(seg.value()).setStyle(seg.style()));
            }

            return result;
         }
      }
   }

   private List<FakeStats.TextSegment> collectSegments(Text text) {
      List<FakeStats.TextSegment> segments = new ArrayList<>();
      text.visit((style, string) -> {
         if (!string.isEmpty()) {
            segments.add(new TextSegment(string, style));
         }

         return Optional.empty();
      }, Style.EMPTY);
      return segments;
   }

   private void appendTextRange(MutableText result, List<FakeStats.TextSegment> segments, int endExclusive) {
      int remaining = Math.max(0, endExclusive);

      for (FakeStats.TextSegment segment : segments) {
         if (remaining <= 0) {
            return;
         }

         String value = segment.value();
         int length = Math.min(value.length(), remaining);
         result.append(Text.literal(value.substring(0, length)).setStyle(segment.style()));
         remaining -= length;
      }
   }

   private Style findStyleAt(List<FakeStats.TextSegment> segments, int charIndex) {
      int index = Math.max(0, charIndex);
      Style fallback = Style.EMPTY;

      for (FakeStats.TextSegment segment : segments) {
         if (!segment.value().isEmpty()) {
            fallback = segment.style();
         }

         if (index < segment.value().length()) {
            return segment.style();
         }

         index -= segment.value().length();
      }

      return fallback;
   }

   private void restoreOriginalScoreboard() {
      if (mc.world != null) {
         Scoreboard scoreboard = mc.world.getScoreboard();
         ScoreboardObjective existing = scoreboard.getNullableObjective("water_fake_stats");
         if (existing != null) {
            scoreboard.removeObjective(existing);
         }

         if (this.originalObjective != null && scoreboard.getObjectives().contains(this.originalObjective)) {
            scoreboard.setObjectiveSlot(ScoreboardDisplaySlot.SIDEBAR, this.originalObjective);
         }
      }
   }

   private long randomBetweenLong(long min, long max) {
      return min >= max ? min : min + (long)Math.floor(this.randomSource.nextDouble() * (max - min + 1L));
   }

   private String formatCompactNumber(long value) {
      long absolute = Math.abs(value);
      if (absolute < 1000L) {
         return Long.toString(value);
      } else if (absolute < 1000000L) {
         return this.formatCompactValue(value / 1000.0, "K");
      } else {
         return absolute < 1000000000L ? this.formatCompactValue(value / 1000000.0, "M") : this.formatCompactValue(value / 1.E9, "B");
      }
   }

   private String formatCompactValue(double value, String suffix) {
      String pattern = value >= 100.0 ? "%.0f%s" : (value >= 10.0 ? "%.1f%s" : "%.2f%s");
      return String.format(Locale.US, pattern, value, suffix);
   }

   private String formatCompactPlaytime(long totalSeconds) {
      long totalHours = totalSeconds / 3600L;
      long totalDays = totalHours / 24L;
      long hours = totalHours % 24L;
      long minutes = totalSeconds % 3600L / 60L;
      if (totalDays > 0L) {
         return String.format(Locale.US, "%dd %dh", totalDays, hours);
      } else {
         return totalHours > 0L ? String.format(Locale.US, "%dh %dm", totalHours, minutes) : String.format(Locale.US, "%dm", minutes);
      }
   }

   private String sanitize(String value, String fallback) {
      if (value == null) {
         return fallback;
      } else {
         String trimmed = value.trim();
         return trimmed.isEmpty() ? fallback : trimmed;
      }
   }

   public Text fakeFooterText(Text footer) {
      if (this.appliedStats == null) {
         return footer;
      } else {
         String raw = footer.getString();
         Pattern p = Pattern.compile("(\\$\\s*)([0-9][0-9.,]*[KkMmBbTt]?)");
         Matcher m = p.matcher(raw);
         if (!m.find()) {
            return footer;
         } else {
            String newRaw = raw.substring(0, m.start(2)) + this.appliedStats.money() + raw.substring(m.end(2));
            List<FakeStats.TextSegment> segs = this.collectSegments(footer);
            Style style = segs.isEmpty() ? Style.EMPTY : segs.get(0).style();
            return Text.literal(newRaw).setStyle(style);
         }
      }
   }

   final class AppliedStats {
      private String money;
      private String shards;
      private String kills;
      private String deaths;
      private String playtime;

      private AppliedStats(String money, String shards, String kills, String deaths, String playtime) {
         this.money = money;
         this.shards = shards;
         this.kills = kills;
         this.deaths = deaths;
         this.playtime = playtime;
      }

      private String signature() {
         return this.money + "|" + this.shards + "|" + this.kills + "|" + this.deaths + "|" + this.playtime;
      }

      public String money() {
         return this.money;
      }

      public String shards() {
         return this.shards;
      }

      public String kills() {
         return this.kills;
      }

      public String deaths() {
         return this.deaths;
      }

      public String playtime() {
         return this.playtime;
      }
   }

   final static class Snapshot {
      private Text title;
      private List<FakeStats.SourceLine> lines;
      private String signature;

      private Snapshot(Text title, List<FakeStats.SourceLine> lines, String signature) {
         this.title = title;
         this.lines = lines;
         this.signature = signature;
      }

      public Text title() {
         return this.title;
      }

      public List<FakeStats.SourceLine> lines() {
         return this.lines;
      }

      public String signature() {
         return this.signature;
      }
   }

   final class SourceLine {
      private int score;
      private Text text;

      private SourceLine(int score, Text text) {
         this.score = score;
         this.text = text;
      }

      public int score() {
         return this.score;
      }

      public Text text() {
         return this.text;
      }
   }

   final class TextSegment {
      private String value;
      private Style style;

      private TextSegment(String value, Style style) {
         this.value = value;
         this.style = style;
      }

      public String value() {
         return this.value;
      }

      public Style style() {
         return this.style;
      }
   }
}

