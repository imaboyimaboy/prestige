package rtx.kimiko.api.chat.commands.impl;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;
import net.minecraft.util.Formatting;
import rtx.kimiko.api.chat.commands.Command;
import rtx.kimiko.api.modules.impl.Visuals.ViewModel;

public final class ViewModelCommand extends Command {
   public ViewModelCommand() {
      super("vm", "ViewModel: управление расположением рук.", "viewmodel");
   }

   @Override
   public void execute(String string, String[] stringArray) {
      if (stringArray.length == 0) {
         this.usage();
      } else if ("reset".equalsIgnoreCase(stringArray[0])) {
         ViewModel viewModel = ViewModel.getInstance();
         if (viewModel == null) {
            this.logDirect("Модуль ViewModel недоступен.", Formatting.RED);
         } else {
            viewModel.resetLayout();
            this.logDirect("Расположение рук сброшено.", Formatting.GREEN);
         }
      } else {
         this.usage();
      }
   }

   @Override
   public List<String> getLongDesc() {
      return Arrays.asList("Управление ViewModel.", "> vm reset — сбросить положение и размер рук");
   }

   @Override
   public Stream<String> tabComplete(String string2, String[] stringArray) {
      return stringArray.length == 1 ? Stream.of("reset").filter(string -> string.startsWith(stringArray[0].toLowerCase())) : Stream.empty();
   }
}

