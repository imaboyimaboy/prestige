package dev.fakeranks.mixin;

import dev.fakeranks.FakeRanksClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.entity.PlayerLikeEntity;
import net.minecraft.entity.player.SkinTextures;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({PlayerEntityRenderer.class})
public abstract class PlayerEntityRendererMixin {
   @Inject(
      method = {"updateRenderState"},
      at = {@At("TAIL")},
      require = 0
   )
   private void fakeranks$decorateOwnRenderState(PlayerLikeEntity entity, PlayerEntityRenderState state, float tickProgress, CallbackInfo info) {
      MinecraftClient client = MinecraftClient.getInstance();
      if (entity instanceof AbstractClientPlayerEntity && entity == client.player) {
         if (FakeRanksClient.STATE.config().enabled) {
            if (FakeRanksClient.STATE.config().nametagEnabled) {
               state.playerName = null;
               state.displayName = FakeRanksClient.STATE.decoratedNameText();
            }

            SkinTextures skin = FakeRanksClient.STATE.skinStealer().skin();
            if (FakeRanksClient.STATE.config().skinStealEnabled && skin != null) {
               state.skinTextures = skin;
            }
         }
      }
   }
}

