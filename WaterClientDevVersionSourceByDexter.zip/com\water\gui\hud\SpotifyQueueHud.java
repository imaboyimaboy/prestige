package com.water.gui.hud;

import com.water.module.modules.client.SpotifyHud;
import com.water.module.modules.client.WaterPlus;
import com.water.utils.renderer.RenderUtil;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public final class SpotifyQueueHud {
   public static int posX = 10;
   public static int posY = 200;
   public static boolean visible = true;
   private static boolean dragging = false;
   private static double dragOffX = 0.0;
   private static double dragOffY = 0.0;
   private static final int intVal = 220;
   private static final int HEAD_H = 18;
   private static final int ROW_H = 13;
   private static final int MAX_ROWS = 12;
   private static final int PAD = 5;
   private static final int MAX_KNOWN = 300;
   private static final List<String[]> ALL_KNOWN = new ArrayList<>();
   private static volatile String currentTitle = "";
   private static volatile String currentArtist = "";
   private static volatile int currentIdx = 0;
   private static int scroll = 0;
   private static final ExecutorService exec = Executors.newSingleThreadExecutor(r -> {
      Thread t = new Thread(r, "spotify-queue");
      t.setDaemon(true);
      return t;
   });
   private static final AtomicBoolean historyLoaded = new AtomicBoolean(false);
   private static volatile long lastClickMs = 0L;
   private static final long CLICK_DEBOUNCE_MS = 500L;

   private static void ensureLoaded() {
      if (historyLoaded.compareAndSet(false, true)) {
         loadFromDisk();
      }
   }

   public static void onSongChanged(String artist, String title) {
      ensureLoaded();
      if (title != null && !title.isEmpty()) {
         if (!title.equals(currentTitle) || !artist.equals(currentArtist)) {
            currentTitle = title;
            currentArtist = artist;
            synchronized (ALL_KNOWN) {
               boolean found = false;

               for (int i = 0; i < ALL_KNOWN.size(); i++) {
                  if (ALL_KNOWN.get(i)[1].equals(title) && ALL_KNOWN.get(i)[0].equals(artist)) {
                     currentIdx = i;
                     found = true;
                     break;
                  }
               }

               if (!found) {
                  ALL_KNOWN.add(new String[]{artist, title});
                  currentIdx = ALL_KNOWN.size() - 1;
                  if (ALL_KNOWN.size() > 300) {
                     int removeCount = ALL_KNOWN.size() - 300;

                     for (int ix = 0; ix < removeCount; ix++) {
                        ALL_KNOWN.remove(0);
                     }

                     currentIdx = Math.max(0, currentIdx - removeCount);
                     scroll = Math.max(0, scroll - removeCount);
                  }

                  exec.submit(SpotifyQueueHud::saveToDisk);
               }
            }

            scrollToCurrent();
         }
      }
   }

   private static void scrollToCurrent() {
      if (currentIdx < scroll) {
         scroll = Math.max(0, currentIdx);
      } else if (currentIdx >= scroll + 12) {
         scroll = currentIdx - 12 + 1;
      }
   }

   private static int maxScroll() {
      synchronized (ALL_KNOWN) {
         return Math.max(0, ALL_KNOWN.size() - 12);
      }
   }

   public static void render(DrawContext ctx, double mx, double my) {
      if (visible) {
         ensureLoaded();
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc != null) {
            TextRenderer tr = mc.textRenderer;
            int accent = WaterPlus.getAccentARGB();
            int accentRgb = accent & 16777215;
            List<String[]> display;
            synchronized (ALL_KNOWN) {
               display = new ArrayList<>(ALL_KNOWN);
            }

            int rows = Math.max(1, Math.min(12, display.size()));
            int H = 18 + rows * 13 + 2;
            RenderUtil.drawRoundedRect(ctx, (float)posX, (float)posY, 220.0F, (float)H, 8.0F, -871556572, false);
            RenderUtil.drawOutline(ctx, (float)posX, (float)posY, 220.0F, (float)H, 8.0F, 1.0F, 1073741824 | accentRgb, false);
            ctx.fill(posX + 1, posY + 1, posX + 220 - 1, posY + 2, 369098751);
            ctx.fill(posX, posY, posX + 220, posY + 18, 587202559);
            ctx.fill(posX, posY + 3, posX + 3, posY + 18 - 3, 0xFF000000 | accentRgb);
            String hdr = "QUEUE  " + (display.isEmpty() ? "play a song" : display.size() + " songs");
            ctx.drawText(tr, hdr, posX + 5 + 5, posY + 9 - 4, -1117449, false);
            if (display.isEmpty()) {
               ctx.drawText(tr, "Play a song to start", posX + 5, posY + 18 + 4, 1442840575, false);
            } else {
               int end = Math.min(scroll + 12, display.size());

               for (int i = scroll; i < end; i++) {
                  String[] song = display.get(i);
                  int ry = posY + 18 + (i - scroll) * 13;
                  boolean isCur = song[1].equals(currentTitle) && song[0].equals(currentArtist);
                  boolean rh = mx >= posX && mx < posX + 220 && my >= ry && my < ry + 13;
                  boolean isPast = i < currentIdx;
                  if (isCur) {
                     ctx.fill(posX, ry, posX + 220, ry + 13, 620756992 | accentRgb);
                     ctx.fill(posX, ry, posX + 3, ry + 13, 0xFF000000 | accentRgb);
                  } else if (rh) {
                     ctx.fill(posX, ry, posX + 220, ry + 13, 369098751);
                  }

                  int tc = isCur ? 0xFF000000 | accentRgb : (isPast ? -10456960 : -5588020);
                  String disp = (song[0].isEmpty() ? "" : song[0] + " - ") + song[1];
                  String trimmed = tr.trimToWidth(disp, 210 - (isCur ? 6 : 2));
                  ctx.drawText(tr, trimmed, posX + 5 + (isCur ? 5 : 2), ry + 6 - 4, tc, false);
               }

               if (display.size() > 12) {
                  int sbX = posX + 220 - 3;
                  int sbY = posY + 18;
                  int sbH = rows * 13;
                  float th = Math.max(16.0F, sbH * (12.0F / display.size()));
                  float ty = sbY + (sbH - th) * ((float)scroll / Math.max(1, maxScroll()));
                  ctx.fill(sbX, sbY, sbX + 3, sbY + sbH, 369098751);
                  ctx.fill(sbX, (int)ty, sbX + 3, (int)(ty + th), -2147483648 | accentRgb);
               }
            }
         }
      }
   }

   public static boolean onMouseClick(double mx, double my, int button) {
      if (!visible) {
         return false;
      } else {
         List<String[]> display;
         synchronized (ALL_KNOWN) {
            display = new ArrayList<>(ALL_KNOWN);
         }

         int rows = Math.max(1, Math.min(12, display.size()));
         int H = 18 + rows * 13 + 2;
         if (mx < posX || mx > posX + 220 || my < posY || my > posY + H) {
            return false;
         } else if (my < posY + 18) {
            if (button == 0) {
               dragging = true;
               dragOffX = mx - posX;
               dragOffY = my - posY;
            }

            return true;
         } else {
            if (button == 0 && my < posY + 18 + rows * 13) {
               int row = ((int)my - posY - 18) / 13 + scroll;
               if (row >= 0 && row < display.size()) {
                  skipTo(display.get(row)[0], display.get(row)[1], row);
                  return true;
               }
            }

            return true;
         }
      }
   }

   public static boolean onMouseDrag(double mx, double my) {
      if (!dragging) {
         return false;
      } else {
         posX = (int)(mx - dragOffX);
         posY = (int)(my - dragOffY);
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc != null) {
            posX = Math.max(0, Math.min(mc.getWindow().getScaledWidth() - 220, posX));
            posY = Math.max(0, Math.min(mc.getWindow().getScaledHeight() - 50, posY));
         }

         return true;
      }
   }

   public static void onMouseRelease() {
      dragging = false;
   }

   public static boolean isDragging() {
      return dragging;
   }

   public static boolean onScroll(double mx, double my, double v) {
      if (!visible) {
         return false;
      } else {
         List<String[]> display;
         synchronized (ALL_KNOWN) {
            display = new ArrayList<>(ALL_KNOWN);
         }

         int rows = Math.max(1, Math.min(12, display.size()));
         int H = 18 + rows * 13 + 2;
         if (!(mx < posX) && !(mx > posX + 220) && !(my < posY) && !(my > posY + H)) {
            scroll = Math.max(0, Math.min(maxScroll(), scroll + (v > 0.0 ? -1 : 1)));
            return true;
         } else {
            return false;
         }
      }
   }

   private static void skipTo(String artist, String title, int targetIdx) {
      if (!title.equals(currentTitle) || !artist.equals(currentArtist)) {
         long now = System.currentTimeMillis();
         if (now - lastClickMs >= 500L) {
            lastClickMs = now;
            int diff = targetIdx - currentIdx;
            if (diff != 0) {
               SpotifyHud.runAction(diff > 0 ? "next" : "prev");
            }
         }
      }
   }

   private static Path queueFile() {
      MinecraftClient mc = MinecraftClient.getInstance();
      return mc != null && mc.runDirectory != null ? mc.runDirectory.toPath().resolve("water_spotify_history.txt") : null;
   }

   private static void loadFromDisk() {
      try {
         Path f = queueFile();
         if (f == null || !Files.isRegularFile(f)) {
            return;
         }

         List<String> lines = Files.readAllLines(f, StandardCharsets.UTF_8);
         synchronized (ALL_KNOWN) {
            ALL_KNOWN.clear();

            for (String line : lines) {
               if (line != null && !line.isBlank()) {
                  int tab = line.indexOf(9);
                  if (tab >= 0) {
                     String artist = line.substring(0, tab);
                     String title = line.substring(tab + 1);
                     if (!title.isEmpty()) {
                        ALL_KNOWN.add(new String[]{artist, title});
                     }
                  }
               }
            }

            if (ALL_KNOWN.size() > 300) {
               int removeCount = ALL_KNOWN.size() - 300;

               for (int i = 0; i < removeCount; i++) {
                  ALL_KNOWN.remove(0);
               }
            }
         }
      } catch (Exception var10) {
      }
   }

   private static void saveToDisk() {
      try {
         Path f = queueFile();
         if (f == null) {
            return;
         }

         List<String[]> snapshot;
         synchronized (ALL_KNOWN) {
            snapshot = new ArrayList<>(ALL_KNOWN);
         }

         Files.createDirectories(f.getParent());

         try (BufferedWriter w = Files.newBufferedWriter(f, StandardCharsets.UTF_8)) {
            for (String[] song : snapshot) {
               String artist = clean(song[0]);
               String title = clean(song[1]);
               w.write(artist);
               w.write(9);
               w.write(title);
               w.newLine();
            }
         }
      } catch (IOException var10) {
      }
   }

   private static String clean(String s) {
      return s == null ? "" : s.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ');
   }
}

