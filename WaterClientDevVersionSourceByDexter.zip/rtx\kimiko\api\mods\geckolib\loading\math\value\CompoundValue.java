package rtx.kimiko.api.mods.geckolib.loading.math.value;

import java.util.Set;
import rtx.kimiko.api.mods.geckolib.animation.state.ControllerState;
import rtx.kimiko.api.mods.geckolib.loading.math.MathValue;

public final class CompoundValue implements MathValue {
   private MathValue[] values;

   public CompoundValue(MathValue[] values) {
      this.values = values;
   }

   @Override
   public double get(ControllerState state) {
      double last = 0.0;

      for (MathValue v : this.values) {
         last = v.get(state);
      }

      return last;
   }

   @Override
   public Set<Variable> getUsedVariables() {
      return MathValue.collectUsedVariables(this.values);
   }

   public MathValue[] values() {
      return this.values;
   }
}

