package com.water.utils.renderer;

import com.water.module.modules.client.WaterPlus;
import com.water.utils.renderer.texture.TexturePipeline;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.GraphicsEnvironment;
import java.awt.RenderingHints;
import java.awt.font.FontRenderContext;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.LinkedHashMap;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;
import javax.imageio.ImageIO;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.resource.Resource;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;

public class AwtFontRenderer {
   public static final AwtFontRenderer INSTANCE = new AwtFontRenderer();
   private static volatile AwtFontRenderer.FontChoice currentFont = AwtFontRenderer.FontChoice.INTER;
   private Font awtFont;
   private AwtFontRenderer.FontChoice loadedFont = null;
   private boolean explicitFontOverride;
   private static volatile int clipBottom = -1;
   private final AtomicInteger idCounter = new AtomicInteger(0);
   private final LinkedHashMap<String, AwtFontRenderer.Entry> cache = new LinkedHashMap<String, AwtFontRenderer.Entry>() {
      @Override
      protected boolean removeEldestEntry(java.util.Map.Entry<String, AwtFontRenderer.Entry> eldest) {
         if (this.size() > 300) {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc != null) {
               try {
                  mc.getTextureManager().destroyTexture(eldest.getValue().id);
               } catch (Exception var4) {
               }
            } else {
               eldest.getValue().tex.close();
            }

            return true;
         } else {
            return false;
         }
      }
   };

   public static void setClipBottom(int y) {
      clipBottom = y;
   }

   public static void clearClip() {
      clipBottom = -1;
   }

   public static void setFont(AwtFontRenderer.FontChoice choice) {
      if (choice != currentFont) {
         currentFont = choice;
         INSTANCE.awtFont = null;
         INSTANCE.loadedFont = null;
         INSTANCE.cache.clear();
      }
   }

   public static AwtFontRenderer.FontChoice getFont() {
      return currentFont;
   }

   public static String[] getFontNames() {
      AwtFontRenderer.FontChoice[] all = AwtFontRenderer.FontChoice.values();
      String[] names = new String[all.length];

      for (int i = 0; i < all.length; i++) {
         names[i] = all[i].displayName;
      }

      return names;
   }

   public static AwtFontRenderer.FontChoice fromDisplayName(String name) {
      if (name != null) {
         for (AwtFontRenderer.FontChoice choice : AwtFontRenderer.FontChoice.values()) {
            if (choice.displayName.equalsIgnoreCase(name.trim())) {
               return choice;
            }
         }
      }

      return AwtFontRenderer.FontChoice.BLISS_BLOOM;
   }

   private void syncConfiguredFont() {
      if (!this.explicitFontOverride) {
         AwtFontRenderer.FontChoice configured = WaterPlus.getSelectedFontChoice();
         if (configured != currentFont) {
            currentFont = configured;
            this.awtFont = null;
            this.loadedFont = null;
            this.cache.clear();
         }
      }
   }

   private void initFont() {
      this.syncConfiguredFont();
      AwtFontRenderer.FontChoice target = currentFont;
      if (this.loadedFont != target || this.awtFont == null) {
         if (target == AwtFontRenderer.FontChoice.VANILLA) {
            this.awtFont = null;
            this.loadedFont = target;
         } else {
            this.awtFont = this.loadBundledFont(target);
            if (this.awtFont == null) {
               this.awtFont = this.loadBundledFont(AwtFontRenderer.FontChoice.INTER);
            }

            if (this.awtFont == null) {
               this.awtFont = this.loadBundledFont(AwtFontRenderer.FontChoice.MINECRAFT_TEN);
            }

            if (this.awtFont == null) {
               this.awtFont = new Font("Monospaced", 1, 16);
            }

            this.loadedFont = target;
         }
      }
   }

   private Font loadBundledFont(AwtFontRenderer.FontChoice choice) {
      if (choice != null && choice.resourcePath != null) {
         byte[] data = this.readBundledFontBytes(choice);
         if (data != null && data.length != 0) {
            Font font = this.createFontFromBytes(data, 0, choice.size);
            if (font == null) {
               font = this.createFontFromBytes(data, 1, choice.size);
            }

            if (font == null) {
               return null;
            } else {
               try {
                  GraphicsEnvironment.getLocalGraphicsEnvironment().registerFont(font);
               } catch (Throwable var5) {
               }

               return font.deriveFont(0, choice.size);
            }
         } else {
            return null;
         }
      } else {
         return null;
      }
   }

   private Font createFontFromBytes(byte[] data, int type, float size) {
      try {
         Font var5;
         try (ByteArrayInputStream in = new ByteArrayInputStream(data)) {
            var5 = Font.createFont(type, in).deriveFont(0, size);
         }

         return var5;
      } catch (Throwable var9) {
         return null;
      }
   }

   private byte[] readBundledFontBytes(AwtFontRenderer.FontChoice choice) {
      String path = choice.resourcePath;

      try {
         label135: {
            byte[] resourcePath;
            try (InputStream in = this.getClass().getResourceAsStream(path)) {
               if (in == null) {
                  break label135;
               }

               resourcePath = in.readAllBytes();
            }

            return resourcePath;
         }
      } catch (Throwable var18) {
      }

      try {
         ClassLoader cl = Thread.currentThread().getContextClassLoader();
         String normalized = path.startsWith("/") ? path.substring(1) : path;
         if (cl != null) {
            try (InputStream in = cl.getResourceAsStream(normalized)) {
               if (in != null) {
                  return in.readAllBytes();
               }
            }
         }
      } catch (Throwable var16) {
      }

      try {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc != null && mc.getResourceManager() != null) {
            String resourcePath = path.startsWith("/assets/water/") ? path.substring(14) : path;
            if (resourcePath.startsWith("/")) {
               resourcePath = resourcePath.substring(1);
            }

            Identifier id = Identifier.of("water", resourcePath);
            Optional<Resource> resource = mc.getResourceManager().getResource(id);
            if (resource.isPresent()) {
               byte[] var8;
               try (InputStream inx = resource.get().getInputStream()) {
                  var8 = inx.readAllBytes();
               }

               return var8;
            }
         }
      } catch (Throwable var14) {
      }

      return null;
   }

   private AwtFontRenderer.Entry get(String text) {
      String key = currentFont.name() + ":" + text;
      AwtFontRenderer.Entry e = this.cache.get(key);
      if (e != null) {
         return e;
      } else {
         e = this.build(text);
         if (e != null) {
            this.cache.put(key, e);
         }

         return e;
      }
   }

   private AwtFontRenderer.Entry build(String text) {
      this.initFont();
      if (this.awtFont == null) {
         return null;
      } else {
         BufferedImage probe = new BufferedImage(1, 1, 2);
         Graphics2D pg = probe.createGraphics();
         pg.setFont(this.awtFont);
         FontRenderContext frc = pg.getFontRenderContext();
         Rectangle2D bounds = this.awtFont.getStringBounds(text, frc);
         pg.dispose();
         int w = Math.max(1, (int)Math.ceil(bounds.getWidth()) + 6);
         int h = Math.max(1, (int)Math.ceil(this.awtFont.getSize() * 1.3F));
         BufferedImage img = new BufferedImage(w, h, 2);
         Graphics2D g = img.createGraphics();
         g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
         g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
         g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
         g.setFont(this.awtFont);
         g.setColor(Color.WHITE);
         g.drawString(text, 1, this.awtFont.getSize() - 1);
         g.dispose();

         try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ImageIO.write(img, "png", baos);
            NativeImage ni = NativeImage.read(new ByteArrayInputStream(baos.toByteArray()));
            NativeImageBackedTexture tex = new NativeImageBackedTexture(() -> "water_font_cache", ni);
            Identifier id = Identifier.of("water", "font_cache_" + this.idCounter.getAndIncrement());
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc != null) {
               mc.getTextureManager().registerTexture(id, tex);
            }

            return new Entry(tex, id, w / 2, h / 2);
         } catch (Exception var15) {
            return null;
         }
      }
   }

   public void drawString(DrawContext ctx, String text, float x, float y, int argbColor) {
      if (text != null && !text.isEmpty()) {
         if (clipBottom < 0 || !(y >= clipBottom)) {
            this.syncConfiguredFont();
            if (currentFont == AwtFontRenderer.FontChoice.VANILLA) {
               MinecraftClient mc = MinecraftClient.getInstance();
               if (mc != null) {
                  ctx.drawText(mc.textRenderer, text, (int)x, (int)y, argbColor, false);
               }
            } else {
               AwtFontRenderer.Entry e = this.get(text);
               if (e != null && e.tex.getGlTextureView() != null) {
                  Matrix4f matrix = RenderUtil.createProjection(ctx);
                  TexturePipeline.drawWH(matrix, x, y, e.displayW, e.displayH, e.tex.getGlTextureView(), argbColor, 0.0F);
               }
            }
         }
      }
   }

   public void drawStringWithFont(DrawContext ctx, String text, float x, float y, int argbColor, AwtFontRenderer.FontChoice choice) {
      if (choice == null) {
         this.drawString(ctx, text, x, y, argbColor);
      } else {
         AwtFontRenderer.FontChoice previous = currentFont;
         Font previousFont = this.awtFont;
         AwtFontRenderer.FontChoice previousLoaded = this.loadedFont;
         boolean previousOverride = this.explicitFontOverride;

         try {
            this.explicitFontOverride = true;
            currentFont = choice;
            if (this.loadedFont != choice) {
               this.awtFont = null;
               this.loadedFont = null;
            }

            this.drawString(ctx, text, x, y, argbColor);
         } finally {
            currentFont = previous;
            this.awtFont = previousFont;
            this.loadedFont = previousLoaded;
            this.explicitFontOverride = previousOverride;
         }
      }
   }

   public int getWidth(String text) {
      if (text != null && !text.isEmpty()) {
         this.syncConfiguredFont();
         if (currentFont == AwtFontRenderer.FontChoice.VANILLA) {
            MinecraftClient mc = MinecraftClient.getInstance();
            return mc != null ? mc.textRenderer.getWidth(text) : text.length() * 6;
         } else {
            this.initFont();
            if (this.awtFont == null) {
               return text.length() * 6;
            } else {
               BufferedImage probe = new BufferedImage(1, 1, 2);
               Graphics2D g = probe.createGraphics();
               g.setFont(this.awtFont);
               int w = g.getFontMetrics().stringWidth(text) / 2;
               g.dispose();
               return w;
            }
         }
      } else {
         return 0;
      }
   }

   public int getWidth(CharSequence text) {
      return this.getWidth(text != null ? text.toString() : "");
   }

   static class Entry {
      NativeImageBackedTexture tex;
      Identifier id;
      int displayW;
      int displayH;

      Entry(NativeImageBackedTexture t, Identifier id, int dw, int dh) {
         this.tex = t;
         this.id = id;
         this.displayW = dw;
         this.displayH = dh;
      }
   }

   public enum FontChoice {
      INTER("Inter", "/assets/waterclient/fonts/medium.ttf", 14.0F, 0),
      DEKATRON("Dekatron", "/assets/water/font/dekatron.otf", 16.0F, 0),
      MINECRAFT_TEN("Minecraft Ten", "/assets/water/font/minecraft_ten.ttf", 16.0F, 0),
      BASKETBALL("Basketball", "/assets/water/font/basketball.otf", 16.0F, 0),
      SECOND_TIME("Second Time", "/assets/water/font/second_time_demo.ttf", 16.0F, 0),
      UNDER_TRAINED("Under Trained", "/assets/water/font/under_trained.ttf", 16.0F, 0),
      BELASH("Belash", "/assets/water/font/belash.ttf", 16.0F, 0),
      BLISS_BLOOM("Bliss Bloom", "/assets/water/font/bliss_bloom.otf", 16.0F, 0),
      NEVO("Nevo", "/assets/water/font/nevo.ttf", 16.0F, 0),
      BOLDRIC("Boldric", "/assets/water/font/boldric.ttf", 16.0F, 0),
      VANILLA("Vanilla", null, 16.0F, -1);

      public String displayName;
      public String resourcePath;
      public float size;
      public int fontType;

      private FontChoice(String displayName, String resourcePath, float size, int fontType) {
         this.displayName = displayName;
         this.resourcePath = resourcePath;
         this.size = size;
         this.fontType = fontType;
      }

      private static AwtFontRenderer.FontChoice[] $values() {
         return new AwtFontRenderer.FontChoice[]{
            INTER, DEKATRON, MINECRAFT_TEN, BASKETBALL, SECOND_TIME, UNDER_TRAINED, BELASH, BLISS_BLOOM, NEVO, BOLDRIC, VANILLA
         };
      }
   }
}

