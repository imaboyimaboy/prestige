package com.water.setting;

public final class ActionSetting extends Setting<String> {
   private Runnable action;

   public ActionSetting(String name, String label, Runnable action) {
      super(name, label);
      this.action = action;
   }

   public void trigger() {
      if (this.action != null) {
         this.action.run();
      }
   }
}

