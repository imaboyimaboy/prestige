package rtx.kimiko.api.drags;

import net.minecraft.client.gui.DrawContext;
import rtx.kimiko.utils.render.fonts.Fonts;
import rtx.kimiko.utils.render.render2d.Render2D;

public final class DragOverlayRenderer {
   public static void render(DrawContext context, DragController controller, float width, float height, float overlayWidth, float overlayHeight, float alpha) {
      float x = controller.getTargetX();
      float y = controller.getTargetY();
      float sourceX = controller.getOriginX();
      float sourceY = controller.getOriginY();
      int white = color(235, alpha);
      int faint = color(65, alpha);

      for (int i = 2; i >= 0; i--) {
         float pad = i * 2.5F;
         Render2D.outline(x - pad, y - pad, overlayWidth + pad * 2.0F, overlayHeight + pad * 2.0F, 7.0F + pad, 0.9F, i == 0 ? white : faint);
      }

      dashed(sourceX, sourceY, x, y, alpha);
      dashed(sourceX + width, sourceY, x + overlayWidth, y, alpha);
      dashed(sourceX, sourceY + height, x, y + overlayHeight, alpha);
      dashed(sourceX + width, sourceY + height, x + overlayWidth, y + overlayHeight, alpha);
      Render2D.line(x, 0.0F, x, Position.screenHeight(), 0.5F, faint);
      Render2D.line(0.0F, y, Position.screenWidth(), y, 0.5F, faint);
      String hint = "Press RMB to cancel the action.";
      float textWidth = Fonts.MONTSERRAT_MEDIUM.width(hint, 6.5F);
      float hintWidth = textWidth + 18.0F;
      float hintX = Position.clampX(x + (overlayWidth - hintWidth) * 0.5F, hintWidth);
      float hintY = Position.clampY(y + overlayHeight + 12.0F, 17.0F);
      Render2D.rect(hintX, hintY, hintWidth, 17.0F, 8.0F, (int)(195.0F * alpha) << 24 | 3155512);
      Fonts.MONTSERRAT_MEDIUM.draw(hint, hintX + 9.0F, hintY + 5.0F, 6.5F, white);
   }

   private static int color(int opacity, float alpha) {
      return (int)(opacity * Math.clamp(alpha, 0.0F, 1.0F)) << 24 | 16777215;
   }

   private static void dashed(float x1, float y1, float x2, float y2, float alpha) {
      float distance = (float)Math.hypot(x2 - x1, y2 - y1);
      if (!(distance < 1.0F)) {
         for (float start = 0.0F; start < distance; start += 8.0F) {
            float from = start / distance;
            float to = Math.min(start + 4.0F, distance) / distance;
            Render2D.line(x1 + (x2 - x1) * from, y1 + (y2 - y1) * from, x1 + (x2 - x1) * to, y1 + (y2 - y1) * to, 0.8F, color(165, alpha));
         }
      }
   }

   public static void clampToScreen(DragController controller, float width, float height) {
      controller.setTargetX(Position.clampX(controller.getTargetX(), width));
      controller.setTargetY(Position.clampY(controller.getTargetY(), height));
   }

   public static void applyGridSnap(DragController controller, float width, float height) {
   }
}

