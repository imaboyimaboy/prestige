package rtx.kimiko.api.chat.commands.impl;

import com.mojang.authlib.GameProfile;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.stream.Stream;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.util.Formatting;
import rtx.kimiko.api.chat.commands.Command;
import rtx.kimiko.api.modules.ModuleManager;
import rtx.kimiko.api.modules.impl.Utils.Party;
import rtx.kimiko.api.party.PartyChat;
import rtx.kimiko.api.party.PartyClient;
import rtx.kimiko.api.party.PartyMember;
import rtx.kimiko.api.party.PartySnapshot;
import rtx.kimiko.utils.storage.friend.FriendUtils;

public final class PartyCommand extends Command {
   public PartyCommand() {
      super("party", "Система Party: create / invite / info / kick / leave / disband.", "p");
   }

   @Override
   public void execute(String string, String[] stringArray) {
      if (stringArray.length == 0) {
         this.usage();
      } else {
         label81: {
            String var3 = stringArray[0].toLowerCase();
            switch (var3.hashCode()) {
               case -1423461112:
                  if (var3.equals("accept")) {
                     this.handleRespond(stringArray, true);
                     return;
                  }
                  break;
               case -1352294148:
                  if (var3.equals("create")) {
                     this.handleCreate(stringArray);
                     return;
                  }
                  break;
               case -1183699191:
                  if (var3.equals("invite")) {
                     this.handleInvite(stringArray);
                     return;
                  }
                  break;
               case 99:
                  if (var3.equals("c")) {
                     break label81;
                  }
                  break;
               case 108417:
                  if (var3.equals("msg")) {
                     break label81;
                  }
                  break;
               case 3052376:
                  if (var3.equals("chat")) {
                     break label81;
                  }
                  break;
               case 3237038:
                  if (var3.equals("info")) {
                     this.handleInfo();
                     return;
                  }
                  break;
               case 3291718:
                  if (var3.equals("kick")) {
                     this.handleKick(stringArray);
                     return;
                  }
                  break;
               case 102846135:
                  if (var3.equals("leave")) {
                     this.handleLeave();
                     return;
                  }
                  break;
               case 1542349558:
                  if (var3.equals("decline")) {
                     this.handleRespond(stringArray, false);
                     return;
                  }
                  break;
               case 1671336899:
                  if (var3.equals("disband")) {
                     this.handleDisband();
                     return;
                  }
            }

            this.usage();
            return;
         }

         this.handleChat(stringArray);
      }
   }

   @Override
   public List<String> getLongDesc() {
      return Arrays.asList(
         "Система Party для друзей (до 10 человек).",
         "> party create <название>",
         "> party invite <ник>",
         "> party info",
         "> party chat <сообщение>",
         "> party kick <ник>",
         "> party leave",
         "> party disband"
      );
   }

   @Override
   public Stream<String> tabComplete(String string3, String[] stringArray) {
      if (stringArray.length == 1) {
         return Stream.of("create", "invite", "info", "chat", "kick", "leave", "disband").filter(string -> string.startsWith(stringArray[0].toLowerCase()));
      } else {
         if (stringArray.length == 2) {
            String string4 = stringArray[0].toLowerCase();
            String string5 = stringArray[1].toLowerCase();
            if (string4.equals("invite")) {
               return this.inviteCandidates().stream().filter(string2 -> string2.toLowerCase().startsWith(string5));
            }

            if (string4.equals("kick")) {
               return this.memberNames().stream().filter(string2 -> string2.toLowerCase().startsWith(string5));
            }
         }

         return Stream.empty();
      }
   }

   private void handleDisband() {
      if (this.ensureLink()) {
         PartyClient.INSTANCE.disband();
      }
   }

   private List<String> memberNames() {
      ArrayList<String> arrayList = new ArrayList<>();
      PartySnapshot partySnapshot = PartyClient.INSTANCE.snapshot();

      for (PartyMember partyMember : partySnapshot.members()) {
         if (!partyMember.leader()) {
            arrayList.add(partyMember.name());
         }
      }

      return arrayList;
   }

   private void handleRespond(String[] stringArray, boolean bl) {
      if (stringArray.length < 2) {
         this.logDirect("Нет идентификатора приглашения.", Formatting.RED);
      } else {
         if (this.ensureLink()) {
            PartyClient.INSTANCE.respondInvite(stringArray[1].trim(), bl);
         }
      }
   }

   private void handleInvite(String[] stringArray) {
      if (stringArray.length < 2) {
         this.logDirect("Использование: party invite <ник>", Formatting.RED);
      } else {
         String string = stringArray[1].trim();
         if (string.isEmpty()) {
            this.logDirect("Укажите ник игрока.", Formatting.RED);
         } else {
            if (this.ensureLink()) {
               PartyClient.INSTANCE.inviteUser(string);
            }
         }
      }
   }

   private void handleCreate(String[] stringArray) {
      if (stringArray.length < 2) {
         this.logDirect("Использование: party create <название>", Formatting.RED);
      } else {
         String string = String.join(" ", Arrays.copyOfRange(stringArray, 1, stringArray.length)).trim();
         if (string.isEmpty()) {
            this.logDirect("Укажите название Party.", Formatting.RED);
         } else {
            if (this.ensureLink()) {
               PartyClient.INSTANCE.create(string);
            }
         }
      }
   }

   private List<String> inviteCandidates() {
      LinkedHashSet<String> linkedHashSet = new LinkedHashSet<>();
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      if (minecraftClient.player != null && minecraftClient.player.networkHandler != null) {
         for (PlayerListEntry playerListEntry : minecraftClient.player.networkHandler.getPlayerList()) {
            GameProfile gameProfile = playerListEntry.getProfile();
            if (gameProfile != null && gameProfile.name() != null) {
               linkedHashSet.add(gameProfile.name());
            }
         }
      }

      linkedHashSet.addAll(FriendUtils.getFriendNames());
      if (minecraftClient.getSession() != null && minecraftClient.getSession().getUsername() != null) {
         linkedHashSet.remove(minecraftClient.getSession().getUsername());
      }

      return new ArrayList<>(linkedHashSet);
   }

   private void handleLeave() {
      if (this.ensureLink()) {
         PartyClient.INSTANCE.leave();
      }
   }

   private void handleInfo() {
      PartyChat.renderInfo(PartyClient.INSTANCE.snapshot());
   }

   private void handleChat(String[] stringArray) {
      if (stringArray.length < 2) {
         this.logDirect("Использование: party chat <сообщение>", Formatting.RED);
      } else {
         String string = String.join(" ", Arrays.copyOfRange(stringArray, 1, stringArray.length)).trim();
         if (string.isEmpty()) {
            this.logDirect("Введите сообщение.", Formatting.RED);
         } else {
            if (this.ensureLink()) {
               PartyClient.INSTANCE.sendChat(string);
            }
         }
      }
   }

   private void handleKick(String[] stringArray) {
      if (stringArray.length < 2) {
         this.logDirect("Использование: party kick <ник>", Formatting.RED);
      } else {
         String string = stringArray[1].trim();
         if (string.isEmpty()) {
            this.logDirect("Укажите ник игрока.", Formatting.RED);
         } else {
            if (this.ensureLink()) {
               PartyClient.INSTANCE.kick(string);
            }
         }
      }
   }

   private boolean ensureLink() {
      if (PartyClient.INSTANCE.isConnected()) {
         return true;
      } else {
         Party party = ModuleManager.get().get(Party.class);
         if (party != null && !party.isEnabled()) {
            party.enable();
            this.logDirect("Модуль Party включён — подключаюсь к серверу. Повторите команду через пару секунд.", Formatting.YELLOW);
         } else {
            this.logDirect("Нет связи с Party-сервером. Попробуйте позже.", Formatting.RED);
         }

         return false;
      }
   }
}

