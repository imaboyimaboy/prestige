package dev.fakeranks;

import java.util.Objects;
import java.util.UUID;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;

public class FakeRanksState {
   public static final int MEDIA_COLOR = 16711907;
   public static final String MEDIA_ICON = "\ud83d\udcf9";
   private final SkinStealer skinStealer = new SkinStealer();
   private FakeRanksConfig config = FakeRanksConfig.load();
   private MutableText cachedPlainName;
   private MutableText cachedDecoratedName;
   private String cachedRealName = "";
   private String cachedCustomName = "";
   private FakeRank cachedRank = FakeRank.NONE;
   private FakeStaffBadge cachedStaff = FakeStaffBadge.NONE;
   private boolean cachedMedia;
   private boolean cachedTierTags;
   private UUID cachedTierUuid;

   public FakeRanksConfig config() {
      return this.config;
   }

   public SkinStealer skinStealer() {
      return this.skinStealer;
   }

   public void reload() {
      this.config = FakeRanksConfig.load();
      this.invalidateCache();
      this.requestSkinForCurrentName();
   }

   public String realPlayerName() {
      MinecraftClient client = MinecraftClient.getInstance();
      return client.getSession() != null ? client.getSession().getUsername() : "Player";
   }

   public String customName() {
      String name = this.config.customName == null ? "" : this.config.customName.trim();
      return name.isEmpty() ? this.realPlayerName() : name;
   }

   public boolean enabled() {
      return this.config.enabled;
   }

   public boolean isLocalUuid(UUID uuid) {
      MinecraftClient client = MinecraftClient.getInstance();
      return uuid != null && client.getGameProfile() != null && uuid.equals(client.getGameProfile().id());
   }

   public MutableText plainNameText() {
      if (this.cachedPlainName == null || !this.customName().equals(this.cachedCustomName)) {
         this.cachedCustomName = this.customName();
         this.cachedPlainName = Text.literal(this.cachedCustomName).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(16777215)).withBold(false));
      }

      return this.cachedPlainName.copy();
   }

   public Text replaceOwnName(Text original) {
      if (this.enabled() && original != null) {
         String value = original.getString();
         String realName = this.realPlayerName();
         return (Text)(!value.equals(realName) && !value.equals(this.customName()) ? original : this.plainNameText());
      } else {
         return original;
      }
   }

   public void setCustomName(String name) {
      this.config.customName = this.sanitizeName(name);
   }

   public void cycleRank() {
      this.config.rank = (this.config.rank == null ? FakeRank.NONE : this.config.rank).next();
      this.config.save();
      this.invalidateCache();
   }

   public void cycleStaffBadge() {
      this.config.staffBadge = (this.config.staffBadge == null ? FakeStaffBadge.NONE : this.config.staffBadge).next();
      this.config.save();
      this.invalidateCache();
   }

   public void toggleMedia() {
      this.config.mediaEnabled = !this.config.mediaEnabled;
      this.config.save();
      this.invalidateCache();
   }

   public void toggleTierTags() {
      this.config.tierTagsEnabled = !this.config.tierTagsEnabled;
      this.config.save();
      this.invalidateCache();
      this.requestTiersForCurrentName();
   }

   public void applyAndSave(String name) {
      this.setCustomName(name);
      this.config.save();
      this.invalidateCache();
      this.requestSkinForCurrentName();
      this.requestTiersForCurrentName();
   }

   public void requestSkinForCurrentName() {
      if (this.config.enabled && this.config.skinStealEnabled) {
         this.skinStealer.request(this.customName());
      }
   }

   public void requestTiersForCurrentName() {
   }

   public MutableText decoratedNameText() {
      FakeRank rank = this.config.rank == null ? FakeRank.NONE : this.config.rank;
      FakeStaffBadge staff = this.config.staffBadge == null ? FakeStaffBadge.NONE : this.config.staffBadge;
      UUID tierUuid = this.skinStealer.profileUuid();
      String realName = this.realPlayerName();
      String customName = this.customName();
      if (this.cachedDecoratedName != null
         && this.cachedRealName.equals(realName)
         && this.cachedCustomName.equals(customName)
         && this.cachedRank == rank
         && this.cachedStaff == staff
         && this.cachedMedia == this.config.mediaEnabled
         && this.cachedTierTags == this.config.tierTagsEnabled
         && Objects.equals(this.cachedTierUuid, tierUuid)) {
         return this.cachedDecoratedName.copy();
      } else {
         MutableText name = Text.literal(this.customName()).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(16777215)).withBold(false));
         if (this.config.tierTagsEnabled) {
            Text withTier = ExternalTierBridge.apply(this.customName(), this.skinStealer.profileUuid(), name);
            name = withTier.copy();
         }

         this.cachedRealName = realName;
         this.cachedCustomName = customName;
         this.cachedRank = rank;
         this.cachedStaff = staff;
         this.cachedMedia = this.config.mediaEnabled;
         this.cachedTierTags = this.config.tierTagsEnabled;
         this.cachedTierUuid = tierUuid;
         this.cachedDecoratedName = this.insertMarkersBeforeName(name, customName, this.markerText());
         return this.cachedDecoratedName.copy();
      }
   }

   public MutableText localChatLine(String message) {
      return this.decoratedNameText()
         .append(Text.literal(": ").setStyle(Style.EMPTY.withColor(TextColor.fromRgb(16777215))))
         .append(Text.literal(message).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(16777215))));
   }

   private String sanitizeName(String name) {
      String trimmed = name == null ? "" : name.trim();
      if (trimmed.isEmpty()) {
         return this.realPlayerName();
      } else {
         StringBuilder clean = new StringBuilder();

         for (int i = 0; i < trimmed.length() && clean.length() < 16; i++) {
            char c = trimmed.charAt(i);
            if (Character.isLetterOrDigit(c) || c == '_') {
               clean.append(c);
            }
         }

         return clean.isEmpty() ? this.realPlayerName() : clean.toString();
      }
   }

   private MutableText markerText() {
      MutableText markers = Text.empty();
      FakeRank rank = this.config.rank == null ? FakeRank.NONE : this.config.rank;
      if (rank.visible()) {
         markers.append(rank.asText());
      }

      FakeStaffBadge staffBadge = this.config.staffBadge == null ? FakeStaffBadge.NONE : this.config.staffBadge;
      if (staffBadge.visible()) {
         markers.append(staffBadge.asText());
      }

      if (this.config.mediaEnabled) {
         markers.append(Text.literal("\ud83d\udcf9").setStyle(Style.EMPTY.withColor(TextColor.fromRgb(16711907)).withBold(false)));
      }

      return markers;
   }

   private MutableText insertMarkersBeforeName(Text text, String name, MutableText markers) {
      if (markers.getString().isEmpty()) {
         return text.copy();
      } else {
         FakeRanksState.Replacement replacement = this.replaceNameLeaf(text, name, markers);
         return replacement.replaced() ? replacement.text() : Text.empty().append(markers.copy()).append(text.copy());
      }
   }

   private FakeRanksState.Replacement replaceNameLeaf(Text text, String name, MutableText markers) {
      String literal = text.getLiteralString();
      if (name.equals(literal)) {
         return new Replacement(Text.empty().append(markers.copy()).append(text.copy()), true);
      } else {
         MutableText copy = text.getContent() == null ? Text.empty() : text.copyContentOnly();
         copy.setStyle(text.getStyle());
         boolean replaced = false;

         for (Text sibling : text.getSiblings()) {
            FakeRanksState.Replacement child = this.replaceNameLeaf(sibling, name, markers);
            copy.append(child.text());
            replaced = replaced || child.replaced();
         }

         return new Replacement(copy, replaced);
      }
   }

   public void invalidateCache() {
      this.cachedPlainName = null;
      this.cachedDecoratedName = null;
   }

   final class Replacement {
      private MutableText text;
      private boolean replaced;

      private Replacement(MutableText text, boolean replaced) {
         this.text = text;
         this.replaced = replaced;
      }

      public MutableText text() {
         return this.text;
      }

      public boolean replaced() {
         return this.replaced;
      }
   }
}

