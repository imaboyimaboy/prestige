package rtx.kimiko.api.mods.geckolib.cache.animation;

import it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import rtx.kimiko.api.mods.geckolib.animation.object.EasingType;
import rtx.kimiko.api.mods.geckolib.loading.math.MathValue;
import rtx.kimiko.api.mods.geckolib.loading.math.value.Variable;
import rtx.kimiko.api.mods.geckolib.util.MiscUtil;

public final class Keyframe {
   private double startTime;
   private double length;
   private MathValue startValue;
   private MathValue endValue;
   private EasingType easingType;
   private MathValue[] easingArgs;

   public Keyframe(double d, double d2, MathValue mathValue, MathValue mathValue2, EasingType easingType, List<MathValue> list) {
      this(d, d2, mathValue, mathValue2, easingType, list.toArray(new MathValue[0]));
   }

   public Keyframe(double d, double d2, MathValue mathValue, MathValue mathValue2, EasingType easingType) {
      this(d, d2, mathValue, mathValue2, easingType, new MathValue[0]);
   }

   public Keyframe(double d, double d2, MathValue mathValue, MathValue mathValue2) {
      this(d, d2, mathValue, mathValue2, EasingType.LINEAR);
   }

   public Keyframe(double startTime, double length, MathValue startValue, MathValue endValue, EasingType easingType, MathValue[] easingArgs) {
      this.startTime = startTime;
      this.length = length;
      this.startValue = startValue;
      this.endValue = endValue;
      this.easingType = easingType;
      this.easingArgs = easingArgs;
   }

   @Override
   public boolean equals(Object object) {
      if (this == object) {
         return true;
      } else if (object != null && this.getClass() == object.getClass()) {
         Keyframe keyframe = (Keyframe)object;
         if (!MiscUtil.areFloatsEqual(this.length, keyframe.length)) {
            return false;
         } else if (!this.startValue.equals(keyframe.startValue) || !this.endValue.equals(keyframe.endValue)) {
            return false;
         } else {
            return this.easingType != keyframe.easingType ? false : Arrays.equals((Object[])this.easingArgs, (Object[])keyframe.easingArgs);
         }
      } else {
         return false;
      }
   }

   @Override
   public int hashCode() {
      return Objects.hash(this.length, this.startValue, this.endValue, this.easingType, Arrays.hashCode((Object[])this.easingArgs));
   }

   public Set<Variable> getUsedVariables() {
      ReferenceOpenHashSet referenceOpenHashSet = new ReferenceOpenHashSet();
      if (this.startValue.isMutable()) {
         referenceOpenHashSet.addAll(this.startValue.getUsedVariables());
      }

      if (this.endValue.isMutable()) {
         referenceOpenHashSet.addAll(this.endValue.getUsedVariables());
      }

      for (MathValue mathValue : this.easingArgs) {
         if (mathValue.isMutable()) {
            referenceOpenHashSet.addAll(mathValue.getUsedVariables());
         }
      }

      return referenceOpenHashSet;
   }

   public double startTime() {
      return this.startTime;
   }

   public double length() {
      return this.length;
   }

   public MathValue startValue() {
      return this.startValue;
   }

   public MathValue endValue() {
      return this.endValue;
   }

   public EasingType easingType() {
      return this.easingType;
   }

   public MathValue[] easingArgs() {
      return this.easingArgs;
   }
}

