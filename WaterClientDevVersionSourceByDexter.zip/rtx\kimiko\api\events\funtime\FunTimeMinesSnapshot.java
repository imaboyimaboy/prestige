package rtx.kimiko.api.events.funtime;

import java.util.List;

public final class FunTimeMinesSnapshot {
   private List<FunTimeMine> mines;
   private long generatedAt;
   private boolean online;
   private String error;

   public FunTimeMinesSnapshot(List<FunTimeMine> mines, long generatedAt, boolean online, String error) {
      this.mines = mines;
      this.generatedAt = generatedAt;
      this.online = online;
      this.error = error;
   }

   public static FunTimeMinesSnapshot offline(String string) {
      return new FunTimeMinesSnapshot(List.of(), 0L, false, string);
   }

   public List<FunTimeMine> mines() {
      return this.mines;
   }

   public long generatedAt() {
      return this.generatedAt;
   }

   public boolean online() {
      return this.online;
   }

   public String error() {
      return this.error;
   }
}

