package rtx.kimiko.api.drags;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import rtx.kimiko.Kimiko;
import rtx.kimiko.api.config.ConfigManager;
import rtx.kimiko.api.drags.components.ArmorComp;
import rtx.kimiko.api.drags.components.ArrayListComp;
import rtx.kimiko.api.drags.components.CooldownsComp;
import rtx.kimiko.api.drags.components.HPFocusComp;
import rtx.kimiko.api.drags.components.HotKeysComp;
import rtx.kimiko.api.drags.components.InventoryComp;
import rtx.kimiko.api.drags.components.KeyStrokesComp;
import rtx.kimiko.api.drags.components.PotionsComp;
import rtx.kimiko.api.drags.components.TargetHudComp;
import rtx.kimiko.api.drags.components.WatermarkComp;
import rtx.kimiko.api.drags.hud.InfoHud;
import rtx.kimiko.api.events.EventBus;
import rtx.kimiko.api.events.EventHandler;
import rtx.kimiko.api.events.impl.game.CloseScreenEvent;
import rtx.kimiko.api.events.impl.input.MouseButtonEvent;
import rtx.kimiko.api.events.impl.render.HudRenderEvent;
import rtx.kimiko.api.modules.impl.Interface.InterfaceModule;
import rtx.kimiko.api.ui.settings.Setting;
import rtx.kimiko.utils.render.others.LoadingVisualGuard;
import rtx.kimiko.utils.render.others.RectUtil;
import rtx.kimiko.utils.render.post.hitbubbles.HitBubblesRenderer;
import rtx.kimiko.utils.render.render2d.Render2D;

public final class DragSystem {
   private static final DragSystem INSTANCE = new DragSystem();
   private final List<Draggable> elements = new ArrayList<>();
   private final Set<String> renderFailures = new HashSet<>();
   private Draggable activeDrag = null;

   private DragSystem() {
   }

   public static DragSystem get() {
      return INSTANCE;
   }

   public void register(Draggable draggable) {
      this.elements.add(draggable);
   }

   public void init() {
      this.register(new WatermarkComp());
      this.register(new HotKeysComp());
      this.register(new TargetHudComp());
      this.register(new PotionsComp());
      this.register(new CooldownsComp());
      this.register(new ArrayListComp());
      this.register(new ArmorComp());
      this.register(new InventoryComp());
      this.register(new HPFocusComp());
      this.register(new KeyStrokesComp());
      new InfoHud();
      ConfigManager.applyActiveDrags();
      EventBus.get().subscribe(this);
   }

   public void unregister(Draggable draggable) {
      this.elements.remove(draggable);
      if (this.activeDrag == draggable) {
         this.activeDrag = null;
      }
   }

   @EventHandler
   public void onCloseScreen(CloseScreenEvent closeScreenEvent) {
      if (closeScreenEvent.getScreen() instanceof ChatScreen) {
         if (this.activeDrag != null) {
            this.activeDrag.getDrag().release();
            this.activeDrag = null;
            ConfigManager.markDirty();
         }
      }
   }

   public void bringToFront(Draggable draggable) {
      int n = this.elements.indexOf(draggable);
      if (n >= 0 && n != this.elements.size() - 1) {
         this.elements.remove(n);
         this.elements.add(draggable);
      }
   }

   public boolean isDragModeActive() {
      return MinecraftClient.getInstance().currentScreen instanceof ChatScreen;
   }

   private void handleRenderFailure(Draggable draggable, Throwable throwable) {
      try {
         RectUtil.clearSplitOverride();
         Render2D.flush();
      } catch (Throwable var4) {
      }

      String string = draggable.getClass().getName();
      if (this.renderFailures.add(string)) {
         Kimiko.LOGGER.error("[DragSystem] Component {} failed to render and was isolated", string, throwable);
      }
   }

   private void releaseInterruptedDrag() {
      boolean bl = false;
      if (this.activeDrag != null) {
         this.activeDrag.getDrag().release();
         this.activeDrag = null;
         bl = true;
      }

      for (Draggable draggable : this.elements) {
         if (draggable.getDrag().isDragging()) {
            draggable.getDrag().release();
            bl = true;
         }
      }

      if (bl) {
         ConfigManager.markDirty();
      }
   }

   public void applyDragDistortion(Framebuffer framebuffer) {
      if (framebuffer != null && this.isDragModeActive() && framebuffer.textureWidth > 0 && framebuffer.textureHeight > 0) {
         InterfaceModule interfaceModule = InterfaceModule.getInstance();
         if (interfaceModule == null || !interfaceModule.dragStyle.check("Обычный") && interfaceModule.dragWaves.getValue()) {
            MinecraftClient minecraftClient = MinecraftClient.getInstance();
            if (minecraftClient.getWindow() != null) {
               float f = Math.max(1.0F, Position.screenWidth());
               float f2 = Math.max(1.0F, Position.screenHeight());
               float f3 = (float)framebuffer.textureWidth / Math.max(1, framebuffer.textureHeight);
               long l = System.currentTimeMillis();
               float f4 = DragController.pulsePhase();
               float f5 = Math.max(0.0F, Math.min(1.0F, f4 / 0.12F));
               float f6 = f5 * (1.0F - f4);
               float f7 = 0.02F * f6;
               float[] fArray = new float[152];
               int n = 0;

               for (Draggable draggable : this.elements) {
                  if (n >= 16) {
                     break;
                  }

                  if (draggable.getDrag().isDragging()) {
                     float f8 = draggable.width();
                     float f9 = draggable.height();
                     float f10 = draggable.getDrag().getRenderX() + f8 * 0.5F;
                     float f11 = draggable.getDrag().getRenderY() + f9 * 0.5F;
                     float f12 = f10 / f;
                     float f13 = 1.0F - f11 / f2;
                     float f14 = Math.max(f8, f9) * 0.5F / f2;
                     float f15 = Math.max(0.04F, Math.min(0.15F, f14 * 0.6F));
                     float f16 = f4 * (f14 + 0.1F);
                     int n2 = 24 + n * 8;
                     fArray[n2] = f12;
                     fArray[n2 + 1] = f13;
                     fArray[n2 + 2] = f16;
                     fArray[n2 + 3] = f15;
                     fArray[n2 + 4] = f7;
                     fArray[n2 + 5] = f6;
                     fArray[n2 + 6] = f14;
                     n++;
                  }
               }

               if (n != 0) {
                  fArray[0] = n;
                  fArray[1] = f3;
                  fArray[2] = (float)(l % 100000L) / 1000.0F;
                  fArray[3] = 0.0F;
                  fArray[4] = 1.0F;
                  HitBubblesRenderer.apply(framebuffer, fArray);
               }
            }
         }
      }
   }

   public List<Draggable> getAll() {
      return Collections.unmodifiableList(this.elements);
   }

   @EventHandler
   public void onHud(HudRenderEvent hudRenderEvent) {
      if (!LoadingVisualGuard.shouldSuppressHud(MinecraftClient.getInstance())) {
         DrawContext drawContext = hudRenderEvent.getGraphics();
         boolean bl = this.isDragModeActive();
         if (!bl) {
            this.releaseInterruptedDrag();
         }

         float f = Position.mouseX();
         float f2 = Position.mouseY();
         InterfaceModule interfaceModule = InterfaceModule.getInstance();
         boolean bl2 = interfaceModule != null && interfaceModule.dragStyle.check("Обычный");
         boolean bl3 = bl2 && interfaceModule.dragTilt.getValue();
         MitosisController mitosisController = MitosisController.get();
         mitosisController.beginFrame();
         mitosisController.stage();
         if (bl) {
            for (Draggable draggable : this.elements) {
               if (draggable.isInteractive() && !mitosisController.isSplitting(draggable)) {
                  draggable.getDrag().tick(f, f2, draggable.overlayWidth(), draggable.overlayHeight(), bl2);
               }
            }
         }

         for (Draggable draggablex : this.elements) {
            draggablex.getDrag().updateTilt(f, bl3);
         }

         for (Draggable draggablex : this.elements) {
            Object object = draggablex.getDrag();
            if (!((DragController)object).isDragging() && !mitosisController.isSplitting(draggablex)) {
               ((DragController)object).applyScreenClamp(draggablex.width(), draggablex.height());
            }
         }

         for (Draggable draggablexx : this.elements) {
            if (draggablexx.isVisible() && !mitosisController.isSplitting(draggablexx)) {
               Object object = mitosisController.overrideFor(draggablexx);
               if (object != null) {
                  RectUtil.armSplitOverride(
                     ((MitosisController.SplitDraw)object).floatVal,
                     ((MitosisController.SplitDraw)object).floatVal2,
                     ((MitosisController.SplitDraw)object).width,
                     ((MitosisController.SplitDraw)object).height,
                     ((MitosisController.SplitDraw)object).radius,
                     ((MitosisController.SplitDraw)object).index,
                     ((MitosisController.SplitDraw)object).childX,
                     ((MitosisController.SplitDraw)object).childY,
                     ((MitosisController.SplitDraw)object).childW,
                     ((MitosisController.SplitDraw)object).childH,
                     ((MitosisController.SplitDraw)object).childRadius
                  );

                  try {
                     draggablexx.renderNormal(drawContext);
                  } catch (Throwable var21) {
                     this.handleRenderFailure(draggablexx, var21);
                  } finally {
                     RectUtil.clearSplitOverride();
                     continue;
                  }
               } else {
                  try {
                     draggablexx.renderNormal(drawContext);
                  } catch (Throwable var20) {
                     this.handleRenderFailure(draggablexx, var20);
                  }
               }
            }
         }

         if (bl) {
            for (Draggable draggablexxx : this.elements) {
               if (draggablexxx.isInteractive() && !mitosisController.isSplitting(draggablexxx)) {
                  try {
                     draggablexxx.getDrag()
                        .renderOverlay(drawContext, draggablexxx.width(), draggablexxx.height(), draggablexxx.overlayWidth(), draggablexxx.overlayHeight());
                  } catch (Throwable var19) {
                     this.handleRenderFailure(draggablexxx, var19);
                  }
               }
            }
         }
      }
   }

   public JsonObject writeDrags() {
      JsonObject jsonObject = new JsonObject();

      for (Draggable draggable : this.elements) {
         JsonObject jsonObject2 = new JsonObject();
         jsonObject2.addProperty("x", draggable.getDrag().getTargetX());
         jsonObject2.addProperty("y", draggable.getDrag().getTargetY());
         jsonObject.add(draggable.getId(), jsonObject2);
      }

      return jsonObject;
   }

   public void applyDrags(JsonObject jsonObject) {
      if (jsonObject != null) {
         for (Draggable draggable : this.elements) {
            JsonElement jsonElement = jsonObject.has(draggable.getId()) ? jsonObject.get(draggable.getId()) : null;
            if (jsonElement != null && jsonElement.isJsonObject()) {
               JsonObject jsonObject2 = jsonElement.getAsJsonObject();

               try {
                  if (jsonObject2.has("x")) {
                     draggable.getDrag().setTargetX(jsonObject2.get("x").getAsFloat());
                  }

                  if (jsonObject2.has("y")) {
                     draggable.getDrag().setTargetY(jsonObject2.get("y").getAsFloat());
                  }

                  draggable.getDrag().syncToTarget();
               } catch (Exception var7) {
               }
            }
         }
      }
   }

   @EventHandler
   public void onMouseButton(MouseButtonEvent mouseButtonEvent) {
      if (this.isDragModeActive()) {
         float f = Position.mouseX();
         float f2 = Position.mouseY();
         if (mouseButtonEvent.action == MouseButtonEvent.Action.PRESS && mouseButtonEvent.button == 1 && this.activeDrag != null) {
            this.activeDrag.getDrag().cancel();
            this.activeDrag = null;
            ConfigManager.markDirty();
            mouseButtonEvent.cancel();
         } else if (mouseButtonEvent.action == MouseButtonEvent.Action.PRESS && mouseButtonEvent.button == 1) {
            for (int i = this.elements.size() - 1; i >= 0; i--) {
               Draggable draggable = this.elements.get(i);
               if (draggable.isInteractive() && draggable.hitTest(f, f2) && MitosisController.get().split(draggable)) {
                  mouseButtonEvent.cancel();
                  return;
               }
            }
         } else if (mouseButtonEvent.button == 0) {
            if (mouseButtonEvent.action == MouseButtonEvent.Action.PRESS) {
               MitosisController mitosisController = MitosisController.get();

               for (int ix = this.elements.size() - 1; ix >= 0; ix--) {
                  Draggable draggable = this.elements.get(ix);
                  if (draggable.isInteractive() && !mitosisController.isAnimating(draggable)) {
                     List<Setting> list;
                     SplitRectComp splitRectComp;
                     if (draggable instanceof SplitRectComp
                        && (splitRectComp = (SplitRectComp)draggable).origin() != null
                        && !(list = splitRectComp.origin().hudSettings()).isEmpty()
                        && HudSettingsPanel.click(f, f2, draggable.getDrag().getRenderX(), draggable.getDrag().getRenderY(), draggable.width(), list)) {
                        ConfigManager.markDirty();
                        mouseButtonEvent.cancel();
                        return;
                     }

                     if (draggable.getDrag().tryGrab(f, f2, draggable.width(), draggable.height())) {
                        this.activeDrag = draggable;
                        this.bringToFront(draggable);
                        mouseButtonEvent.cancel();
                        return;
                     }
                  }
               }
            } else if (mouseButtonEvent.action == MouseButtonEvent.Action.RELEASE && this.activeDrag != null) {
               this.activeDrag.getDrag().release();
               this.activeDrag = null;
               ConfigManager.markDirty();
               mouseButtonEvent.cancel();
            }
         }
      }
   }
}

