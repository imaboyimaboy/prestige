package rtx.kimiko.api.mods.geckolib.cache;

import java.util.Map;
import net.minecraft.util.Identifier;
import rtx.kimiko.api.mods.geckolib.GeckoLibConstants;
import rtx.kimiko.api.mods.geckolib.cache.animation.Animation;
import rtx.kimiko.api.mods.geckolib.loading.object.BakedAnimations;

public final class BakedAnimationCache {
   private Map<Identifier, BakedAnimations> cache;

   public BakedAnimationCache(Map<Identifier, BakedAnimations> cache) {
      this.cache = cache;
   }

   public Animation getAnimation(Identifier identifier, Identifier[] identifierArray, String string) {
      BakedAnimations bakedAnimations = null;

      for (int i = -1; i < identifierArray.length; i++) {
         Identifier identifier2 = i == -1 ? identifier : identifierArray[i];
         bakedAnimations = this.cache.get(identifier2);
         if (bakedAnimations == null) {
            Identifier stripped = stripLegacyPath(identifier2);
            if (!stripped.equals(identifier2)) {
               GeckoLibConstants.LOGGER.error("Superfluous prefix or suffix found in animation resource path: '{}'. Should be '{}'", identifier2, stripped);
               identifier = stripped;
               bakedAnimations = this.cache.get(stripped);
            }
         }

         if (bakedAnimations != null) {
            Animation anim = bakedAnimations.getAnimation(string);
            if (anim != null) {
               return anim;
            }
         }
      }

      if (bakedAnimations == null) {
         throw new IllegalArgumentException("Unable to find animation file '" + identifier + "'");
      } else {
         GeckoLibConstants.LOGGER.error("Unable to find animation: '{}' in animation file '{}'", string, identifier);
         return null;
      }
   }

   private static Identifier stripLegacyPath(Identifier identifier) {
      String string = identifier.getPath();
      if (string.startsWith("geckolib/")) {
         string = string.substring(9);
      }

      if (string.startsWith("animations/")) {
         string = string.substring(11);
      }

      if (string.endsWith(".json")) {
         string = string.substring(0, string.length() - 5);
      }

      if (string.endsWith(".animations")) {
         string = string.substring(0, string.length() - 10);
      }

      return !string.equals(identifier.getPath()) ? identifier.withPath(string) : identifier;
   }

   public Map<Identifier, BakedAnimations> cache() {
      return this.cache;
   }
}

