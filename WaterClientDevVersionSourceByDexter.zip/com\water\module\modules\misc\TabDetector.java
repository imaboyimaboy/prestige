package com.water.module.modules.misc;

import com.water.gui.notification.NotificationManager;
import com.water.module.Category;
import com.water.module.Module;
import com.water.setting.ModeSetting;
import com.water.setting.Setting;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;

public final class TabDetector extends Module {
   private final ModeSetting detectMode = new ModeSetting("Detect", "List", "Any", "List");
   private final Setting<String> targetPlayers = new Setting<>("Target Players", "");
   private final ModeSetting notificationMode = new ModeSetting("Notification Mode", "Both", "Chat", "Toast", "Both");
   private final Setting<Boolean> logOffline = new Setting<>("Log Offline", true);
   private final Set<String> currentTargetsOnline = new HashSet<>();
   private final Set<String> previousTargetsOnline = new HashSet<>();

   public TabDetector() {
      super("TabDetector", Category.MISC);
      this.targetPlayers.visibleWhen(() -> this.detectMode.check("List"));
      this.addSetting(this.detectMode);
      this.addSetting(this.targetPlayers);
      this.addSetting(this.notificationMode);
      this.addSetting(this.logOffline);
   }

   @Override
   public void onEnable() {
      this.currentTargetsOnline.clear();
      this.previousTargetsOnline.clear();
      this.snapshotOnlineTargetsInto(this.previousTargetsOnline);
   }

   @Override
   public void onDisable() {
      this.currentTargetsOnline.clear();
      this.previousTargetsOnline.clear();
   }

   @Override
   public void onTick() {
      if (mc.player != null && mc.world != null && mc.getNetworkHandler() != null) {
         boolean any = this.detectMode.check("Any");
         Set<String> wanted = any ? Set.of() : this.parseTargets(this.targetPlayers.getValue());
         if (!any && wanted.isEmpty()) {
            this.currentTargetsOnline.clear();
            this.previousTargetsOnline.clear();
         } else {
            this.currentTargetsOnline.clear();

            for (PlayerListEntry entry : mc.getNetworkHandler().getPlayerList()) {
               String name = this.safeProfileName(entry);
               if (!name.isEmpty()
                  && (mc.player == null || !name.equalsIgnoreCase(mc.player.getName().getString()))
                  && (any || this.containsIgnoreCase(wanted, name))) {
                  this.currentTargetsOnline.add(name);
               }
            }

            Set<String> joined = new HashSet<>(this.currentTargetsOnline);
            joined.removeAll(this.previousTargetsOnline);
            if (!joined.isEmpty()) {
               this.handleJoin(joined);
            }

            if (this.logOffline.getValue()) {
               Set<String> left = new HashSet<>(this.previousTargetsOnline);
               left.removeAll(this.currentTargetsOnline);
               if (!left.isEmpty()) {
                  this.handleLeave(left);
               }
            }

            this.previousTargetsOnline.clear();
            this.previousTargetsOnline.addAll(this.currentTargetsOnline);
         }
      }
   }

   private void handleJoin(Set<String> players) {
      String list = String.join(", ", players);
      String msg = players.size() == 1 ? "Target player joined: null" : "Target players joined: null";
      this.notify(msg, players.size() == 1 ? "Target Player Joined!" : "Target Players Joined!", -1938838);
   }

   private void handleLeave(Set<String> players) {
      String list = String.join(", ", players);
      String msg = players.size() == 1 ? "Target player left: null" : "Target players left: null";
      this.notify(msg, players.size() == 1 ? "Target Player Left!" : "Target Players Left!", -11152222);
   }

   private void notify(String chatMessage, String toastTitle, int accent) {
      String mode = this.notificationMode.getValue();
      boolean toChat = "Chat".equalsIgnoreCase(mode) || "Both".equalsIgnoreCase(mode);
      boolean toToast = "Toast".equalsIgnoreCase(mode) || "Both".equalsIgnoreCase(mode);
      if (toChat) {
         try {
            mc.inGameHud.getChatHud().addMessage(Text.literal("[TabDetector] null"));
         } catch (Throwable var8) {
         }
      }

      if (toToast) {
         NotificationManager.INSTANCE.push("TabDetector", toastTitle, ItemStack.EMPTY, accent);
      }
   }

   private void snapshotOnlineTargetsInto(Set<String> out) {
      out.clear();
      if (mc.getNetworkHandler() != null) {
         boolean any = this.detectMode.check("Any");
         Set<String> wanted = any ? Set.of() : this.parseTargets(this.targetPlayers.getValue());
         if (any || !wanted.isEmpty()) {
            for (PlayerListEntry entry : mc.getNetworkHandler().getPlayerList()) {
               String name = this.safeProfileName(entry);
               if (!name.isEmpty()
                  && (mc.player == null || !name.equalsIgnoreCase(mc.player.getName().getString()))
                  && (any || this.containsIgnoreCase(wanted, name))) {
                  out.add(name);
               }
            }
         }
      }
   }

   private String safeProfileName(PlayerListEntry entry) {
      try {
         if (entry != null && entry.getProfile() != null) {
            try {
               String n = entry.getProfile().name();
               return n == null ? "" : n;
            } catch (Throwable var3) {
               return "";
            }
         } else {
            return "";
         }
      } catch (Throwable var4) {
         return "";
      }
   }

   private boolean containsIgnoreCase(Set<String> loweredSet, String value) {
      return loweredSet.contains(value.toLowerCase(Locale.ROOT));
   }

   private Set<String> parseTargets(String raw) {
      if (raw != null && !raw.isBlank()) {
         String normalized = raw.replace('\n', ',').replace('\r', ',');
         LinkedHashSet<String> out = new LinkedHashSet<>();

         for (String part : normalized.split(",")) {
            String t = part == null ? "" : part.trim();
            if (!t.isEmpty()) {
               out.add(t.toLowerCase(Locale.ROOT));
            }
         }

         return out;
      } else {
         return Set.of();
      }
   }
}

