package dev.fakeranks.mixin;

import dev.fakeranks.FakeRanksClient;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({PlayerListHud.class})
public abstract class PlayerListHudMixin {
   @Inject(
      method = {"getPlayerName"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 0
   )
   private void fakeranks$getPlayerName(PlayerListEntry entry, CallbackInfoReturnable<Text> info) {
      if (FakeRanksClient.STATE.enabled()) {
         if (FakeRanksClient.STATE.isLocalUuid(entry.getProfile().id())) {
            info.setReturnValue(FakeRanksClient.STATE.decoratedNameText());
         }
      }
   }
}

