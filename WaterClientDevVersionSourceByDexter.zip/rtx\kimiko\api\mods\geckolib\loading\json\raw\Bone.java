package rtx.kimiko.api.mods.geckolib.loading.json.raw;

import com.google.gson.JsonDeserializer;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import java.util.Map;
import net.minecraft.util.JsonHelper;
import rtx.kimiko.api.mods.geckolib.util.JsonUtil;

public final class Bone {
   private Cube[] cubes;
   private Boolean debug;
   private Double inflate;
   private Map<String, LocatorValue> locators;
   private Boolean mirror;
   private String name;
   private Boolean neverRender;
   private String parent;
   private double[] pivot;
   private PolyMesh polyMesh;
   private Long renderGroupId;
   private double[] rotation;
   private TextureMesh[] textureMeshes;

   public Bone(
      Cube[] cubes,
      Boolean debug,
      Double inflate,
      Map<String, LocatorValue> locators,
      Boolean mirror,
      String name,
      Boolean neverRender,
      String parent,
      double[] pivot,
      PolyMesh polyMesh,
      Long renderGroupId,
      double[] rotation,
      TextureMesh[] textureMeshes
   ) {
      this.cubes = cubes;
      this.debug = debug;
      this.inflate = inflate;
      this.locators = locators;
      this.mirror = mirror;
      this.name = name;
      this.neverRender = neverRender;
      this.parent = parent;
      this.pivot = pivot;
      this.polyMesh = polyMesh;
      this.renderGroupId = renderGroupId;
      this.rotation = rotation;
      this.textureMeshes = textureMeshes;
   }

   public static JsonDeserializer<Bone> deserializer() throws JsonParseException {
      return (jsonElement, type, jsonDeserializationContext) -> {
         JsonObject jsonObject = jsonElement.getAsJsonObject();
         Cube[] cubeArray = JsonUtil.jsonArrayToObjectArray(JsonHelper.getArray(jsonObject, "cubes", null), jsonDeserializationContext, Cube.class);
         Boolean bl = JsonUtil.getOptionalBoolean(jsonObject, "debug");
         Double d = JsonUtil.getOptionalDouble(jsonObject, "inflate");
         Map<String, LocatorValue> map = jsonObject.has("locators")
            ? JsonUtil.jsonObjToMap(JsonHelper.getObject(jsonObject, "locators"), jsonDeserializationContext, LocatorValue.class)
            : null;
         Boolean bl2 = JsonUtil.getOptionalBoolean(jsonObject, "mirror");
         String string = JsonHelper.getString(jsonObject, "name");
         Boolean bl3 = JsonUtil.getOptionalBoolean(jsonObject, "neverRender");
         String string2 = JsonHelper.getString(jsonObject, "parent", null);
         double[] dArray = JsonUtil.jsonArrayToDoubleArray(JsonHelper.getArray(jsonObject, "pivot", null));
         PolyMesh polyMesh = (PolyMesh)JsonHelper.deserialize(jsonObject, "poly_mesh", null, jsonDeserializationContext, PolyMesh.class);
         Long l = JsonUtil.getOptionalLong(jsonObject, "render_group_id");
         double[] dArray2 = JsonUtil.jsonArrayToDoubleArray(JsonHelper.getArray(jsonObject, "rotation", null));
         TextureMesh[] textureMeshArray = JsonUtil.jsonArrayToObjectArray(
            JsonHelper.getArray(jsonObject, "texture_meshes", null), jsonDeserializationContext, TextureMesh.class
         );
         if (cubeArray == null) {
            cubeArray = new Cube[0];
         }

         return new Bone(cubeArray, bl, d, map, bl2, string, bl3, string2, dArray, polyMesh, l, dArray2, textureMeshArray);
      };
   }

   public Cube[] cubes() {
      return this.cubes;
   }

   public Boolean debug() {
      return this.debug;
   }

   public Double inflate() {
      return this.inflate;
   }

   public Map<String, LocatorValue> locators() {
      return this.locators;
   }

   public Boolean mirror() {
      return this.mirror;
   }

   public String name() {
      return this.name;
   }

   public Boolean neverRender() {
      return this.neverRender;
   }

   public String parent() {
      return this.parent;
   }

   public double[] pivot() {
      return this.pivot;
   }

   public PolyMesh polyMesh() {
      return this.polyMesh;
   }

   public Long renderGroupId() {
      return this.renderGroupId;
   }

   public double[] rotation() {
      return this.rotation;
   }

   public TextureMesh[] textureMeshes() {
      return this.textureMeshes;
   }
}

