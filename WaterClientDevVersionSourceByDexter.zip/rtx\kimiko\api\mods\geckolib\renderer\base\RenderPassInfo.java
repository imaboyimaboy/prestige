package rtx.kimiko.api.mods.geckolib.renderer.base;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.Reference2ObjectArrayMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Map.Entry;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import rtx.kimiko.api.mods.geckolib.GeckoLibConstants;
import rtx.kimiko.api.mods.geckolib.animation.state.BoneSnapshot;
import rtx.kimiko.api.mods.geckolib.cache.model.BakedGeoModel;
import rtx.kimiko.api.mods.geckolib.cache.model.GeoBone;
import rtx.kimiko.api.mods.geckolib.constant.DataTickets;
import rtx.kimiko.api.mods.geckolib.constant.dataticket.DataTicket;
import rtx.kimiko.api.mods.geckolib.model.GeoModel;
import rtx.kimiko.api.mods.geckolib.object.DeferredCache;

public class RenderPassInfo<R extends GeoRenderState> {
   protected final GeoRenderer<?, ?, R> geoRenderer;
   protected R geoRenderState;
   protected MatrixStack matrixStack;
   protected BakedGeoModel bakedGeoModel;
   protected CameraRenderState cameraRenderState;
   protected boolean bool;
   protected net.minecraft.client.util.math.MatrixStack.Entry objectRenderPose;
   protected net.minecraft.client.util.math.MatrixStack.Entry modelRenderPose;
   protected final DeferredCache<List<RenderPassInfo.BoneUpdater<R>>, BoneSnapshot[]> boneUpdates = new DeferredCache<>(
      new ObjectArrayList(), list -> this.compileBoneUpdates(list)
   );
   protected final Map<GeoBone, List<PerBoneRender<R>>> boneRenderTasks = new Reference2ObjectArrayMap();
   protected final Map<GeoBone, List<RenderPassInfo.BonePositionListener>> bonePositionListeners = new Reference2ObjectArrayMap();

   protected RenderPassInfo(
      GeoRenderer<?, ?, R> geoRenderer, R r, MatrixStack matrixStack, BakedGeoModel bakedGeoModel, CameraRenderState cameraRenderState, boolean bl
   ) {
      this.geoRenderer = geoRenderer;
      this.geoRenderState = r;
      this.matrixStack = matrixStack;
      this.bakedGeoModel = bakedGeoModel;
      this.cameraRenderState = cameraRenderState;
      this.bool = bl;
      this.objectRenderPose = new net.minecraft.client.util.math.MatrixStack.Entry();
      this.modelRenderPose = new net.minecraft.client.util.math.MatrixStack.Entry();
      this.objectRenderPose.copy(matrixStack.peek());
   }

   public static <R extends GeoRenderState> RenderPassInfo<R> create(
      GeoRenderer<?, ?, R> geoRenderer, R r, MatrixStack matrixStack, CameraRenderState cameraRenderState, boolean bl
   ) {
      GeoModel geoModel = geoRenderer.getGeoModel();
      BakedGeoModel bakedGeoModel = geoModel.getBakedModel(geoModel.getModelResource(r));
      RenderPassInfo renderPassInfo = new RenderPassInfo<>(geoRenderer, r, matrixStack, bakedGeoModel, cameraRenderState, bl);
      renderPassInfo.addBoneUpdater(geoRenderer::applyAnimationControllers);
      renderPassInfo.addBoneUpdater(geoRenderer::adjustModelBonesForRender);
      return renderPassInfo;
   }

   public BakedGeoModel model() {
      return this.bakedGeoModel;
   }

   public GeoRenderer<?, ?, R> renderer() {
      return this.geoRenderer;
   }

   public CameraRenderState cameraState() {
      return this.cameraRenderState;
   }

   public Matrix4f getModelRenderMatrixState() {
      if ((this.modelRenderPose.getPositionMatrix().properties() & 4) != 0) {
         throw new IllegalStateException("Attempting to access model render matrix state before it has been set");
      } else {
         return this.modelRenderPose.getPositionMatrix();
      }
   }

   public void captureModelRenderPose() {
      this.modelRenderPose.copy(this.matrixStack.peek());
   }

   public int renderColor() {
      return this.geoRenderState.getOrDefaultGeckolibData(DataTickets.RENDER_COLOR, -1);
   }

   public void addBoneUpdater(RenderPassInfo.BoneUpdater<R> boneUpdater) {
      try {
         this.boneUpdates.getInput().add(boneUpdater);
      } catch (IllegalStateException var3) {
         GeckoLibConstants.LOGGER.error("BoneUpdater added after render pass submission", var3);
      }
   }

   public void addPerBoneRender(GeoBone geoBone2, PerBoneRender<R> perBoneRender) {
      this.boneRenderTasks.computeIfAbsent(geoBone2, geoBone -> new ObjectArrayList()).add(perBoneRender);
   }

   public void renderPosed(Runnable runnable) {
      BoneSnapshot[] boneSnapshotArray = this.boneUpdates.compute();

      for (int n = 0; n < boneSnapshotArray.length; n++) {
         boneSnapshotArray[n].apply();
      }

      if (!this.bonePositionListeners.isEmpty()) {
         for (Entry<GeoBone, List<RenderPassInfo.BonePositionListener>> object : this.bonePositionListeners.entrySet()) {
            object.getKey().positionListeners = object.getValue().toArray(new RenderPassInfo.BonePositionListener[0]);
         }
      }

      try {
         runnable.run();
      } catch (Exception var9) {
         Exception exception = var9;

         try {
            GeckoLibConstants.LOGGER.error("Error while rendering GeckoLib model", exception);
         } catch (Throwable var8) {
            for (int i = 0; i < boneSnapshotArray.length; i++) {
               boneSnapshotArray[i].cleanup();
            }

            if (!this.bonePositionListeners.isEmpty()) {
               for (GeoBone geoBone : this.bonePositionListeners.keySet()) {
                  geoBone.positionListeners = null;
               }
            }

            throw var8;
         }

         for (int i = 0; i < boneSnapshotArray.length; i++) {
            boneSnapshotArray[i].cleanup();
         }

         if (!this.bonePositionListeners.isEmpty()) {
            for (GeoBone geoBone : this.bonePositionListeners.keySet()) {
               geoBone.positionListeners = null;
            }
         }
      }

      for (int var10 = 0; var10 < boneSnapshotArray.length; var10++) {
         boneSnapshotArray[var10].cleanup();
      }

      if (!this.bonePositionListeners.isEmpty()) {
         for (GeoBone geoBone : this.bonePositionListeners.keySet()) {
            geoBone.positionListeners = null;
         }
      }
   }

   public Map<GeoBone, List<PerBoneRender<R>>> getBoneRenderTasks() {
      return this.boneRenderTasks;
   }

   public net.minecraft.client.util.math.MatrixStack.Entry getModelRenderMatrixPose() {
      return this.modelRenderPose;
   }

   public int packedLight() {
      return this.geoRenderState.getPackedLight();
   }

   public int packedOverlay() {
      return this.geoRenderState.getOrDefaultGeckolibData(DataTickets.PACKED_OVERLAY, OverlayTexture.DEFAULT_UV);
   }

   public <D> D getOrDefaultGeckolibData(DataTicket<D> dataTicket, D d) {
      return this.renderState().getOrDefaultGeckolibData(dataTicket, d);
   }

   public <D> D getGeckolibData(DataTicket<D> dataTicket) {
      return this.renderState().getGeckolibData(dataTicket);
   }

   public MatrixStack poseStack() {
      return this.matrixStack;
   }

   public R renderState() {
      return this.geoRenderState;
   }

   public Matrix4f getPreRenderMatrixState() {
      return this.objectRenderPose.getPositionMatrix();
   }

   public boolean willRender() {
      return this.bool;
   }

   private Optional lambda_compileBoneUpdates_4(List list, String string) {
      return this.bakedGeoModel.getBone(string).map(geoBone -> {
         if (geoBone.frameSnapshot == null) {
            geoBone.frameSnapshot = BoneSnapshot.create(geoBone);
            list.add(geoBone.frameSnapshot);
         }

         return geoBone.frameSnapshot;
      });
   }

   public void addBonePositionListener(String string, RenderPassInfo.BonePositionListener bonePositionListener) {
      this.bakedGeoModel.getBone(string).ifPresent(geoBone -> this.addBonePositionListener(geoBone, bonePositionListener));
   }

   public void addBonePositionListener(GeoBone geoBone2, RenderPassInfo.BonePositionListener bonePositionListener) {
      this.bonePositionListeners.computeIfAbsent(geoBone2, geoBone -> new ObjectArrayList()).add(bonePositionListener);
   }

   public net.minecraft.client.util.math.MatrixStack.Entry getPreRenderMatrixPose() {
      return this.objectRenderPose;
   }

   protected BoneSnapshot[] compileBoneUpdates(List<RenderPassInfo.BoneUpdater<R>> list) {
      ObjectArrayList objectArrayList = new ObjectArrayList(list.size());

      for (RenderPassInfo.BoneUpdater boneUpdater : list) {
         boneUpdater.run(this, arg_0 -> this.lambda_compileBoneUpdates_4(objectArrayList, arg_0));
      }

      BoneSnapshot[] boneSnapshotArray = (BoneSnapshot[])objectArrayList.toArray(new BoneSnapshot[0]);

      for (int i = 0; i < boneSnapshotArray.length; i++) {
         boneSnapshotArray[i].cleanup();
      }

      return boneSnapshotArray;
   }

   @FunctionalInterface
   public interface BonePositionListener {
      void accept(Vec3d var1, Vec3d var2, Vec3d var3);
   }

   public interface BoneUpdater<R extends GeoRenderState> {
      void run(RenderPassInfo<R> var1, BoneSnapshots var2);
   }
}

