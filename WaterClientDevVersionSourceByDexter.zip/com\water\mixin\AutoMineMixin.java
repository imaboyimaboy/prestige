package com.water.mixin;

import com.water.module.Module;
import com.water.module.ModuleManager;
import com.water.module.modules.misc.AutoMine;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({MinecraftClient.class})
public class AutoMineMixin {
   @Inject(
      method = {"doAttack"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void water$limitAutoMineStart(CallbackInfoReturnable<Boolean> ci) {
      MinecraftClient mc = (MinecraftClient)(Object)this;

      for (Module module : ModuleManager.INSTANCE.getModules()) {
         if (module instanceof AutoMine mine && mine.isEnabled()) {
            if (mc.currentScreen != null || !(mc.crosshairTarget instanceof BlockHitResult hit && hit.getType() == Type.BLOCK && mine.allowsMining(hit))) {
               ci.setReturnValue(false);
            }

            return;
         }
      }
   }

   @Inject(
      method = {"handleBlockBreaking"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void water$limitAutoMine(boolean breaking, CallbackInfo ci) {
      MinecraftClient mc = (MinecraftClient)(Object)this;

      for (Module module : ModuleManager.INSTANCE.getModules()) {
         if (module instanceof AutoMine mine && mine.isEnabled()) {
            if (mc.currentScreen != null || !(mc.crosshairTarget instanceof BlockHitResult hit && hit.getType() == Type.BLOCK && mine.allowsMining(hit))) {
               if (mc.interactionManager != null) {
                  mc.interactionManager.cancelBlockBreaking();
               }

               ci.cancel();
            }

            return;
         }
      }
   }
}

