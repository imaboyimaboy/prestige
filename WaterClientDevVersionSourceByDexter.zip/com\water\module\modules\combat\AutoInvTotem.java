package com.water.module.modules.combat;

public final class AutoInvTotem extends AutoTotem {
   public AutoInvTotem() {
      super("Auto Inv Totem");
   }
}

