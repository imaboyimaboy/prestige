package com.water.module.modules.render;

import com.water.module.Category;
import com.water.module.Module;
import com.water.setting.Setting;
import com.water.utils.renderer.ProjectionUtil;
import java.awt.Color;
import java.io.InputStream;
import java.nio.FloatBuffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL14;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

public final class SkyShaders extends Module {
   private static final String VERTEX_PATH = "/assets/water/shaders/sky_shaders_vertex.vsh";
   private static final String FRAGMENT_PATH = "/assets/water/shaders/sky_shaders_fragment.fsh";
   private static final int DOME_SEGMENTS = 96;
   private static final int DOME_RINGS = 32;
   private static final float DOME_RADIUS = 768.0F;
   private final Setting<Integer> alpha = new Setting<>("Alpha", 120, 0, 255);
   private final Setting<Integer> intensity = new Setting<>("Intensity", 120, 0, 300);
   private final Setting<Integer> speed = new Setting<>("Speed", 100, 0, 300);
   private final Setting<Integer> fov = new Setting<>("FOV", 90, 30, 140);
   private final Setting<Color> colorOne = new Setting<>("Color 1", new Color(255, 120, 70, 255));
   private final Setting<Color> colorTwo = new Setting<>("Color 2", new Color(255, 70, 170, 255));
   private final Setting<Color> starColor = new Setting<>("Star Color", new Color(255, 220, 120, 255));
   private int program = 0;
   private int vao = 0;
   private int vbo = 0;
   private int vertexCount = 0;
   private long startTime = System.currentTimeMillis();
   private boolean failed = false;

   public SkyShaders() {
      super("Sky Shaders", Category.RENDER);
      this.addSetting(this.alpha);
      this.addSetting(this.intensity);
      this.addSetting(this.speed);
      this.addSetting(this.fov);
      this.addSetting(this.colorOne);
      this.addSetting(this.colorTwo);
      this.addSetting(this.starColor);
   }

   @Override
   public void onEnable() {
      this.startTime = System.currentTimeMillis();
      this.failed = false;
   }

   @Override
   public void onDisable() {
      if (this.program != 0) {
         GL20.glDeleteProgram(this.program);
         this.program = 0;
      }

      if (this.vao != 0) {
         GL30.glDeleteVertexArrays(this.vao);
         this.vao = 0;
      }

      if (this.vbo != 0) {
         GL15.glDeleteBuffers(this.vbo);
         this.vbo = 0;
      }

      this.vertexCount = 0;
   }

   @Override
   public void onRender(MatrixStack matrices, float tickDelta) {
      Camera camera = mc != null && mc.gameRenderer != null ? mc.gameRenderer.getCamera() : null;
      this.renderSky(camera, matrices);
   }

   public void renderSky(Camera camera, MatrixStack matrices) {
      if (mc != null && mc.getWindow() != null && !this.failed) {
         if (this.program != 0 || this.initShader()) {
            int width = Math.max(1, mc.getWindow().getFramebufferWidth());
            int height = Math.max(1, mc.getWindow().getFramebufferHeight());
            float time = (float)(System.currentTimeMillis() - this.startTime) / 1000.0F;
            Quaternionf rotation = this.cameraRotation(camera);
            Matrix4f mvp = new Matrix4f(ProjectionUtil.projectionMatrix).mul(matrices.peek().getPositionMatrix());
            int oldProgram = GL11.glGetInteger(35725);
            int oldVao = GL11.glGetInteger(34229);
            int oldArrayBuffer = GL11.glGetInteger(34964);
            int oldDepthFunc = GL11.glGetInteger(2932);
            boolean oldDepth = GL11.glIsEnabled(2929);
            boolean oldBlend = GL11.glIsEnabled(3042);
            boolean oldCull = GL11.glIsEnabled(2884);
            boolean oldDepthMask = GL11.glGetBoolean(2930);

            try {
               GL11.glEnable(2929);
               GL11.glDepthFunc(515);
               GL11.glDepthMask(false);
               GL11.glDisable(2884);
               GL11.glEnable(3042);
               GL14.glBlendFuncSeparate(770, 771, 1, 771);
               GL20.glUseProgram(this.program);
               GL30.glBindVertexArray(this.vao);
               this.setUniforms(width, height, time, rotation, mvp);
               GL11.glDrawArrays(4, 0, this.vertexCount);
            } finally {
               GL15.glBindBuffer(34962, oldArrayBuffer);
               GL30.glBindVertexArray(oldVao);
               GL20.glUseProgram(oldProgram);
               GL11.glDepthFunc(oldDepthFunc);
               if (oldDepth) {
                  GL11.glEnable(2929);
               } else {
                  GL11.glDisable(2929);
               }

               if (oldBlend) {
                  GL11.glEnable(3042);
               } else {
                  GL11.glDisable(3042);
               }

               if (oldCull) {
                  GL11.glEnable(2884);
               } else {
                  GL11.glDisable(2884);
               }

               GL11.glDepthMask(oldDepthMask);
            }
         }
      }
   }

   private void setUniforms(int width, int height, float time, Quaternionf rotation, Matrix4f mvp) {
      this.set4("uResolution", width, height, time, this.speed.getValue().intValue() / 100.0F);
      this.set4("uSettings", this.intensity.getValue().intValue() / 100.0F, this.alpha.getValue().intValue() / 255.0F, this.fov.getValue().intValue(), 0.0F);
      this.set4("uCameraDir", rotation.x, rotation.y, rotation.z, rotation.w);
      this.setColor("uNebColor1", this.colorOne.getValue());
      this.setColor("uNebColor2", this.colorTwo.getValue());
      this.setColor("uStarColor", this.starColor.getValue());
      this.set4("uSkyZenith", 0.02F, 0.04F, 0.13F, 1.0F);
      this.set4("uSkyHorizon", 0.25F, 0.12F, 0.35F, 1.0F);
      this.set4("uFogColor", 0.0F, 0.0F, 0.0F, 1.0F);
      this.set4("uFogRange", 0.0F, 1.0F, 0.0F, 0.0F);
      int mvpLoc = GL20.glGetUniformLocation(this.program, "uMvp");
      if (mvpLoc >= 0) {
         FloatBuffer buffer = BufferUtils.createFloatBuffer(16);
         mvp.get(buffer);
         GL20.glUniformMatrix4fv(mvpLoc, false, buffer);
      }
   }

   private void setColor(String name, Color color) {
      this.set4(name, color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F);
   }

   private void set4(String name, float x, float y, float z, float w) {
      int loc = GL20.glGetUniformLocation(this.program, name);
      if (loc >= 0) {
         GL20.glUniform4f(loc, x, y, z, w);
      }
   }

   private Quaternionf cameraRotation(Camera camera) {
      return camera == null
         ? new Quaternionf()
         : new Quaternionf().rotateY((float)Math.toRadians(-camera.getYaw())).rotateX((float)Math.toRadians(camera.getPitch()));
   }

   private boolean initShader() {
      try {
         this.program = compileProgram(loadShader("/assets/water/shaders/sky_shaders_vertex.vsh"), loadShader("/assets/water/shaders/sky_shaders_fragment.fsh"));
         this.createDomeMesh();
         return true;
      } catch (Throwable var2) {
         this.failed = true;
         System.err.println("[SkyShaders] Shader init failed: " + var2.getMessage());
         return false;
      }
   }

   private void createDomeMesh() {
      float[] vertices = this.buildDomeVertices();
      this.vertexCount = vertices.length / 3;
      this.vao = GL30.glGenVertexArrays();
      this.vbo = GL15.glGenBuffers();
      FloatBuffer buffer = BufferUtils.createFloatBuffer(vertices.length);
      buffer.put(vertices).flip();
      GL30.glBindVertexArray(this.vao);
      GL15.glBindBuffer(34962, this.vbo);
      GL15.glBufferData(34962, buffer, 35044);
      GL20.glEnableVertexAttribArray(0);
      GL20.glVertexAttribPointer(0, 3, 5126, false, 12, 0L);
      GL15.glBindBuffer(34962, 0);
      GL30.glBindVertexArray(0);
   }

   private float[] buildDomeVertices() {
      ArrayList<Float> out = new ArrayList<>();

      for (int ring = 0; ring < 32; ring++) {
         float t0 = ring / 32.0F;
         float t1 = (ring + 1) / 32.0F;
         float elev0 = (float)Math.toRadians(-8.0 + t0 * 98.0);
         float elev1 = (float)Math.toRadians(-8.0 + t1 * 98.0);

         for (int seg = 0; seg < 96; seg++) {
            float a0 = (float)(seg * Math.PI * 2.0 / 96.0);
            float a1 = (float)((seg + 1) * Math.PI * 2.0 / 96.0);
            addVertex(out, elev0, a0);
            addVertex(out, elev1, a0);
            addVertex(out, elev1, a1);
            addVertex(out, elev0, a0);
            addVertex(out, elev1, a1);
            addVertex(out, elev0, a1);
         }
      }

      float[] vertices = new float[out.size()];

      for (int i = 0; i < out.size(); i++) {
         vertices[i] = out.get(i);
      }

      return vertices;
   }

   private static void addVertex(ArrayList<Float> out, float elevation, float angle) {
      float cos = (float)Math.cos(elevation);
      out.add((float)Math.sin(angle) * cos * 768.0F);
      out.add((float)Math.sin(elevation) * 768.0F);
      out.add((float)Math.cos(angle) * cos * 768.0F);
   }

   private static String loadShader(String path) {
      try {
         String var2;
         try (InputStream stream = SkyShaders.class.getResourceAsStream(path)) {
            if (stream == null) {
               throw new IllegalStateException("Missing shader: null");
            }

            var2 = new String(stream.readAllBytes(), StandardCharsets.UTF_8);
         }

         return var2;
      } catch (Exception var6) {
         throw new IllegalStateException("Could not load shader: null", var6);
      }
   }

   private static int compileProgram(String vertexSource, String fragmentSource) {
      int vertex = compileShader(35633, vertexSource);
      int fragment = compileShader(35632, fragmentSource);
      int createdProgram = GL20.glCreateProgram();
      GL20.glAttachShader(createdProgram, vertex);
      GL20.glAttachShader(createdProgram, fragment);
      GL20.glLinkProgram(createdProgram);
      GL20.glDeleteShader(vertex);
      GL20.glDeleteShader(fragment);
      if (GL20.glGetProgrami(createdProgram, 35714) == 0) {
         String log = GL20.glGetProgramInfoLog(createdProgram);
         GL20.glDeleteProgram(createdProgram);
         throw new IllegalStateException("Program link failed: null");
      } else {
         return createdProgram;
      }
   }

   private static int compileShader(int type, String source) {
      int shader = GL20.glCreateShader(type);
      GL20.glShaderSource(shader, source);
      GL20.glCompileShader(shader);
      if (GL20.glGetShaderi(shader, 35713) == 0) {
         String log = GL20.glGetShaderInfoLog(shader);
         GL20.glDeleteShader(shader);
         throw new IllegalStateException("Shader compile failed: null");
      } else {
         return shader;
      }
   }
}

