package rtx.kimiko.api.liteapi.packets;

import java.nio.charset.StandardCharsets;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.network.packet.CustomPayload.Id;
import net.minecraft.util.Identifier;

public final class LiteApiPayload implements CustomPayload {
   private String json;
   public static final Identifier CHANNEL = Identifier.of("liteapi", "feature-control");
   public static final Id<LiteApiPayload> TYPE = new Id(CHANNEL);
   private static final int MAX_BYTES = 262144;
   public static final PacketCodec<PacketByteBuf, LiteApiPayload> CODEC = PacketCodec.ofStatic((packetByteBuf, liteApiPayload) -> {
      byte[] byArray = liteApiPayload.json().getBytes(StandardCharsets.UTF_8);
      packetByteBuf.writeBytes(byArray);
   }, packetByteBuf -> {
      try {
         int n = packetByteBuf.readableBytes();
         if (n > 0 && n <= 262144) {
            byte[] byArray = new byte[n];
            packetByteBuf.readBytes(byArray);
            return new LiteApiPayload(new String(byArray, StandardCharsets.UTF_8));
         } else {
            if (n > 0) {
               packetByteBuf.skipBytes(n);
            }

            return new LiteApiPayload("");
         }
      } catch (RuntimeException var3) {
         if (packetByteBuf.isReadable()) {
            packetByteBuf.skipBytes(packetByteBuf.readableBytes());
         }

         return new LiteApiPayload("");
      }
   });

   public LiteApiPayload(String json) {
      this.json = json;
   }

   public Id<LiteApiPayload> getId() {
      return TYPE;
   }

   public String json() {
      return this.json;
   }
}

