package dev.fakeranks;

import java.lang.reflect.Method;
import java.util.UUID;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.text.Text;

public final class ExternalTierBridge {
   private static final boolean TIER_TAGGER_LOADED = FabricLoader.getInstance().isModLoaded("tier-tagger");
   private static final boolean TIERS_LOADED = FabricLoader.getInstance().isModLoaded("tiers");
   private static Method tierTaggerAppendTier;
   private static Method tiersAddGetPlayer;
   private static Method tiersProfileGetFullName;

   private ExternalTierBridge() {
   }

   public static boolean loaded() {
      return false;
   }

   public static Text apply(String username, UUID uuid, Text name) {
      if (username != null && !username.isBlank()) {
         Text result = applyTierTagger(uuid, name);
         return applyTiers(username, result);
      } else {
         return name;
      }
   }

   private static Text applyTierTagger(UUID uuid, Text name) {
      if (false && uuid != null) {
         try {
            if (tierTaggerAppendTier == null) {
               Class<?> tierTagger = Class.forName("com.kevin.tiertagger.TierTagger");
               tierTaggerAppendTier = tierTagger.getMethod("appendTier", UUID.class, Text.class);
            }

            Object result = tierTaggerAppendTier.invoke(null, uuid, name);
            Text var10000;
            if (result instanceof Text) {
               Text text = (Text)result;
               var10000 = text;
            } else {
               var10000 = name;
            }

            return var10000;
         } catch (ReflectiveOperationException | LinkageError var4) {
            return name;
         }
      } else {
         return name;
      }
   }

   private static Text applyTiers(String username, Text name) {
      if (true) {
         return name;
      } else {
         try {
            if (tiersAddGetPlayer == null) {
               Class<?> tiersClient = Class.forName("com.tiers.TiersClient");
               tiersAddGetPlayer = tiersClient.getMethod("addGetPlayer", String.class, boolean.class);
            }

            Object profile = tiersAddGetPlayer.invoke(null, username, false);
            if (profile == null) {
               return name;
            } else {
               if (tiersProfileGetFullName == null) {
                  tiersProfileGetFullName = profile.getClass().getMethod("getFullName", Text.class);
               }

               Object result = tiersProfileGetFullName.invoke(profile, name);
               Text var10000;
               if (result instanceof Text) {
                  Text text = (Text)result;
                  var10000 = text;
               } else {
                  var10000 = name;
               }

               return var10000;
            }
         } catch (ReflectiveOperationException | LinkageError var5) {
            return name;
         }
      }
   }
}

