package rtx.kimiko.api.mods.geckolib.renderer;

import java.util.List;
import java.util.function.Function;
import net.minecraft.block.AbstractSkullBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.item.ItemModelManager;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory.Context;
import net.minecraft.client.render.entity.feature.ArmorFeatureRenderer;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ProfileComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.scoreboard.Team;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.ColorHelper;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import rtx.kimiko.api.mods.geckolib.GeckoLibClientServices;
import rtx.kimiko.api.mods.geckolib.animatable.GeoAnimatable;
import rtx.kimiko.api.mods.geckolib.constant.DataTickets;
import rtx.kimiko.api.mods.geckolib.model.DefaultedEntityGeoModel;
import rtx.kimiko.api.mods.geckolib.model.GeoModel;
import rtx.kimiko.api.mods.geckolib.renderer.base.GeoRenderState;
import rtx.kimiko.api.mods.geckolib.renderer.base.GeoRenderer;
import rtx.kimiko.api.mods.geckolib.renderer.base.RenderPassInfo;
import rtx.kimiko.api.mods.geckolib.renderer.layer.GeoRenderLayer;
import rtx.kimiko.api.mods.geckolib.renderer.layer.GeoRenderLayersContainer;
import rtx.kimiko.api.mods.geckolib.util.ClientUtil;
import rtx.kimiko.api.mods.geckolib.util.MiscUtil;

public class GeoEntityRenderer<T extends Entity & GeoAnimatable, R extends EntityRenderState & GeoRenderState>
   extends EntityRenderer<T, R>
   implements GeoRenderer<T, Void, R> {
   protected final GeoRenderLayersContainer<T, Void, R> renderLayers = new GeoRenderLayersContainer<>(this);
   protected GeoModel<T> model;
   protected ItemModelManager itemModelResolver;
   protected float scaleWidth = 1.0F;
   protected float scaleHeight = 1.0F;

   public GeoEntityRenderer(Context context, EntityType<? extends T> entityType) {
      this(context, new DefaultedEntityGeoModel<>(Registries.ENTITY_TYPE.getId(entityType)));
   }

   public GeoEntityRenderer(Context context, GeoModel<T> geoModel) {
      super(context);
      this.model = geoModel;
      this.itemModelResolver = context.getItemModelManager();
   }

   public RenderLayer getRenderType(R r, Identifier identifier) {
      if (r.invisible && !r.getOrDefaultGeckolibData(DataTickets.INVISIBLE_TO_PLAYER, false)) {
         return RenderLayers.itemEntityTranslucentCull(identifier);
      } else if (!r.invisible) {
         return GeoRenderer.super.getRenderType(r, identifier);
      } else {
         return r.hasOutline() ? RenderLayers.outlineNoCull(identifier) : null;
      }
   }

   public final R getAndUpdateRenderState0(T entity, float tickProgress) {
      R r = this.createRenderState(entity, null);
      this.updateRenderState(entity, r, tickProgress);
      this.updateShadow(entity, r);
      return r;
   }

   public double getNameRenderCutoffDistance(T t) {
      return 32.0;
   }

   protected void extractLivingEntityRenderState(
      LivingEntity livingEntity, LivingEntityRenderState livingEntityRenderState, float f, ItemModelManager itemModelManager
   ) {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      float f2 = MathHelper.lerpAngleDegrees(f, livingEntity.lastHeadYaw, livingEntity.headYaw);
      Text text = livingEntity.getCustomName();
      ItemStack itemStack = livingEntity.getEquippedStack(EquipmentSlot.HEAD);
      livingEntityRenderState.bodyYaw = LivingEntityRenderer.clampBodyYaw(livingEntity, f2, f);
      livingEntityRenderState.relativeHeadYaw = MathHelper.wrapDegrees(f2 - livingEntityRenderState.bodyYaw);
      livingEntityRenderState.pitch = livingEntity.getLerpedPitch(f);
      boolean bl = livingEntityRenderState.flipUpsideDown = text != null && LivingEntityRenderer.shouldFlipUpsideDown(text.getString());
      if (livingEntityRenderState.flipUpsideDown) {
         livingEntityRenderState.pitch *= -1.0F;
         livingEntityRenderState.relativeHeadYaw *= -1.0F;
      }

      if (!livingEntity.hasVehicle() && livingEntity.isAlive()) {
         livingEntityRenderState.limbSwingAnimationProgress = livingEntity.limbAnimator.getAnimationProgress(f);
         livingEntityRenderState.limbSwingAmplitude = livingEntity.limbAnimator.getAmplitude(f);
      } else {
         livingEntityRenderState.limbSwingAnimationProgress = 0.0F;
         livingEntityRenderState.limbSwingAmplitude = 0.0F;
      }

      if (livingEntity.getVehicle() instanceof LivingEntity livingEntity2) {
         livingEntityRenderState.headItemAnimationProgress = livingEntity2.limbAnimator.getAnimationProgress(f);
      } else {
         livingEntityRenderState.headItemAnimationProgress = livingEntityRenderState.limbSwingAnimationProgress;
      }

      livingEntityRenderState.baseScale = livingEntity.getScale();
      livingEntityRenderState.ageScale = livingEntity.getScaleFactor();
      livingEntityRenderState.pose = livingEntity.getPose();
      livingEntityRenderState.sleepingDirection = livingEntity.getSleepingDirection();
      if (livingEntityRenderState.sleepingDirection != null) {
         livingEntityRenderState.standingEyeHeight = livingEntity.getEyeHeight(EntityPose.STANDING);
      }

      livingEntityRenderState.shaking = livingEntity.isFrozen();
      livingEntityRenderState.baby = livingEntity.isBaby();
      livingEntityRenderState.touchingWater = livingEntity.isTouchingWater();
      livingEntityRenderState.usingRiptide = livingEntity.isUsingRiptide();
      livingEntityRenderState.hurt = livingEntity.hurtTime > 0 || livingEntity.deathTime > 0;
      if (itemStack.getItem() instanceof BlockItem blockItem && blockItem.getBlock() instanceof AbstractSkullBlock skullBlock) {
         livingEntityRenderState.wearingSkullType = skullBlock.getSkullType();
         livingEntityRenderState.wearingSkullProfile = (ProfileComponent)itemStack.get(DataComponentTypes.PROFILE);
         livingEntityRenderState.headItemRenderState.clear();
      } else {
         livingEntityRenderState.wearingSkullType = null;
         livingEntityRenderState.wearingSkullProfile = null;
         if (!ArmorFeatureRenderer.hasModel(itemStack, EquipmentSlot.HEAD)) {
            this.itemModelResolver.updateForLivingEntity(livingEntityRenderState.headItemRenderState, itemStack, ItemDisplayContext.HEAD, livingEntity);
         } else {
            livingEntityRenderState.headItemRenderState.clear();
         }
      }

      livingEntityRenderState.deathTime = livingEntity.deathTime > 0 ? livingEntity.deathTime + f : 0.0F;
      livingEntityRenderState.invisibleToPlayer = livingEntityRenderState.invisible
         && minecraftClient.player != null
         && livingEntity.isInvisibleTo(minecraftClient.player);
   }

   @Override
   public void fireCompileRenderLayersEvent() {
      GeckoLibClientServices.EVENTS.fireCompileEntityRenderLayers(this);
   }

   public void fireCompileRenderStateEvent(T t, Void void_, R r, float f) {
      GeckoLibClientServices.EVENTS.fireCompileEntityRenderState(this, r, t);
   }

   @Override
   public void scaleModelForRender(RenderPassInfo<R> renderPassInfo, float f, float f2) {
      float f3;
      if (renderPassInfo.renderState() instanceof LivingEntityRenderState livingEntityRenderState) {
         f3 = livingEntityRenderState.baseScale;
      } else {
         f3 = 1.0F;
      }

      GeoRenderer.super.scaleModelForRender(renderPassInfo, f * this.scaleWidth * f3, f2 * this.scaleHeight * f3);
   }

   @Override
   public void adjustRenderPose(RenderPassInfo<R> renderPassInfo) {
      MatrixStack poseStack = renderPassInfo.poseStack();
      var entityRenderState = renderPassInfo.renderState();
      LivingEntityRenderState livingEntityRenderState = entityRenderState instanceof LivingEntityRenderState
         ? (LivingEntityRenderState)entityRenderState
         : null;
      if (livingEntityRenderState != null && entityRenderState.getGeckolibData(DataTickets.ENTITY_POSE) == EntityPose.SLEEPING) {
         Direction direction = livingEntityRenderState.sleepingDirection;
         if (livingEntityRenderState.sleepingDirection != null) {
            float f = livingEntityRenderState.standingEyeHeight - 0.1F;
            poseStack.translate(-direction.getOffsetX() * f, 0.0F, -direction.getOffsetZ() * f);
         }
      }

      this.applyRotations(renderPassInfo, poseStack, livingEntityRenderState != null ? livingEntityRenderState.baseScale : 1.0F);
      poseStack.translate(0.0F, 0.01F, 0.0F);
   }

   protected void applyRotations(RenderPassInfo<R> renderPassInfo, MatrixStack matrixStack, float f) {
      var entityRenderState = renderPassInfo.renderState();
      float f2 = ((GeoRenderState)entityRenderState).getOrDefaultGeckolibData(DataTickets.ENTITY_BODY_YAW, 0.0F);
      if (((GeoRenderState)entityRenderState).getOrDefaultGeckolibData(DataTickets.IS_SHAKING, false)) {
         f2 += (float)(Math.cos(entityRenderState.age * 3.25) * Math.PI * 0.4);
      }

      boolean bl = ((GeoRenderState)entityRenderState).getGeckolibData(DataTickets.ENTITY_POSE) == EntityPose.SLEEPING;
      if (!bl) {
         matrixStack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180.0F - f2));
      }

      if (entityRenderState instanceof LivingEntityRenderState livingEntityRenderState) {
         if (livingEntityRenderState.deathTime > 0.0F) {
            matrixStack.multiply(
               RotationAxis.POSITIVE_Z
                  .rotationDegrees(
                     Math.min(MathHelper.sqrt((livingEntityRenderState.deathTime - 1.0F) / 20.0F * 1.6F), 1.0F)
                        * this.getDeathMaxRotation((GeoRenderState)entityRenderState)
                  )
            );
         } else if (livingEntityRenderState.usingRiptide) {
            matrixStack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-90.0F - livingEntityRenderState.pitch));
            matrixStack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(entityRenderState.age * -75.0F));
         } else if (bl) {
            Direction direction = livingEntityRenderState.sleepingDirection;
            matrixStack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(direction != null ? MiscUtil.getDirectionAngle(direction) : f2));
            matrixStack.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(this.getDeathMaxRotation((GeoRenderState)entityRenderState)));
            matrixStack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(270.0F));
         } else if (livingEntityRenderState.flipUpsideDown) {
            matrixStack.translate(0.0F, (livingEntityRenderState.height + 0.1F) / f, 0.0F);
            matrixStack.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(180.0F));
         }
      }
   }

   protected float getDeathMaxRotation(GeoRenderState geoRenderState) {
      return 90.0F;
   }

   protected float calculateYRot(T t, float f, float f2) {
      if (!(t.getVehicle() instanceof LivingEntity livingEntity)) {
         float f3;
         if (t instanceof LivingEntity livingEntityx) {
            f3 = MathHelper.lerpAngleDegrees(f2, livingEntityx.lastBodyYaw, livingEntityx.bodyYaw);
         } else {
            f3 = t.getBodyYaw();
         }

         return f3;
      } else {
         float f4 = MathHelper.lerpAngleDegrees(f2, livingEntity.lastBodyYaw, livingEntity.bodyYaw);
         float f5 = MathHelper.clamp(MathHelper.wrapDegrees(-f4), -85.0F, 85.0F);
         f4 = f - f4;
         if (Math.abs(f5) > 50.0F) {
            f4 += f5 * 0.2F;
         }

         return f4;
      }
   }

   protected <S extends LivingEntityRenderState> S convertRenderStateToLiving(R r) {
      return (S)((LivingEntityRenderState)r);
   }

   public GeoEntityRenderer<T, R> withRenderLayer(Function<? super GeoEntityRenderer<T, R>, GeoRenderLayer<T, Void, R>> function) {
      return this.withRenderLayer(function.apply(this));
   }

   public GeoEntityRenderer<T, R> withRenderLayer(GeoRenderLayer<T, Void, R> geoRenderLayer) {
      this.renderLayers.addLayer(geoRenderLayer);
      return this;
   }

   @Override
   public GeoModel<T> getGeoModel() {
      return this.model;
   }

   @Override
   public List<GeoRenderLayer<T, Void, R>> getRenderLayers() {
      return this.renderLayers.getRenderLayers();
   }

   public int getPackedOverlay(T t, Void void_, float f, float f2) {
      return !(t instanceof LivingEntity livingEntity)
         ? OverlayTexture.DEFAULT_UV
         : OverlayTexture.packUv(OverlayTexture.getU(f), OverlayTexture.getV(livingEntity.hurtTime > 0 || livingEntity.deathTime > 0));
   }

   public void captureDefaultRenderState(T t, Void void_, R r, float f) {
      GeoRenderer.super.captureDefaultRenderState(t, void_, r, f);
      r.addGeckolibData(DataTickets.VELOCITY, t.getVelocity());
      r.addGeckolibData(DataTickets.BLOCKPOS, t.getBlockPos());
      r.addGeckolibData(DataTickets.SPRINTING, t.isSprinting());
      r.addGeckolibData(DataTickets.IS_CROUCHING, t.isInSneakingPose());
      r.addGeckolibData(DataTickets.POSITION, t.getEntityPos());
      GeoRenderState geoRenderState = r;
      double d;
      if (t instanceof LivingEntity livingEntity) {
         d = livingEntity.limbAnimator.getSpeed();
      } else {
         d = t.getVelocity().lengthSquared();
      }

      geoRenderState.addGeckolibData(DataTickets.IS_MOVING, d >= this.getMotionAnimThreshold(t));
      if (t instanceof LivingEntity livingEntity) {
         r.addGeckolibData(DataTickets.SWINGING_ARM, livingEntity.handSwinging);
         r.addGeckolibData(DataTickets.IS_DEAD_OR_DYING, livingEntity.isDead());
      }

      if (!(r instanceof LivingEntityRenderState)) {
         r.addGeckolibData(
            DataTickets.INVISIBLE_TO_PLAYER, t.isInvisible() && (ClientUtil.getClientPlayer() == null || t.isInvisibleTo(ClientUtil.getClientPlayer()))
         );
         r.addGeckolibData(DataTickets.IS_SHAKING, t.isFrozen());
         r.addGeckolibData(DataTickets.ENTITY_POSE, t.getPose());
         r.addGeckolibData(DataTickets.ENTITY_PITCH, t.getLerpedPitch(f));
         r.addGeckolibData(DataTickets.ENTITY_YAW, this.calculateYRot(t, 0.0F, f));
         r.addGeckolibData(DataTickets.ENTITY_BODY_YAW, r.getOrDefaultGeckolibData(DataTickets.ENTITY_YAW, 0.0F));
      }
   }

   public int getRenderColor(T t, Void void_, float f) {
      int n = GeoRenderer.super.getRenderColor(t, void_, f);
      PlayerEntity playerEntity = ClientUtil.getClientPlayer();
      if (t.isInvisible() && playerEntity != null && !t.isInvisibleTo(playerEntity)) {
         n = ColorHelper.withAlpha(MathHelper.ceil(ColorHelper.getAlpha(n) * 38 / 255.0F), n);
      }

      return n;
   }

   public long getInstanceId(T t, Void void_) {
      return t.getId();
   }

   @Override
   public boolean firePreRenderEvent(RenderPassInfo<R> renderPassInfo, OrderedRenderCommandQueue orderedRenderCommandQueue) {
      return GeckoLibClientServices.EVENTS.fireEntityPreRender(this, renderPassInfo, orderedRenderCommandQueue);
   }

   @Override
   public void postRenderPass(RenderPassInfo<R> renderPassInfo, OrderedRenderCommandQueue orderedRenderCommandQueue) {
      super.render(renderPassInfo.renderState(), renderPassInfo.poseStack(), orderedRenderCommandQueue, renderPassInfo.cameraState());
   }

   public R createRenderState(T t, Void void_) {
      return (R)(t instanceof LivingEntity ? new LivingEntityRenderState() : new EntityRenderState());
   }

   public boolean hasLabel(T entity, double squaredDistanceToCamera) {
      if (!(entity instanceof LivingEntity)) {
         return super.hasLabel(entity, squaredDistanceToCamera);
      } else {
         double d;
         if (entity.isSneaky() && squaredDistanceToCamera >= (d = this.getNameRenderCutoffDistance(entity)) * d) {
            return false;
         } else if (!(entity instanceof MobEntity) || entity.shouldRenderName() || entity.hasCustomName() && entity == this.dispatcher.targetedEntity) {
            MinecraftClient minecraftClient = MinecraftClient.getInstance();
            PlayerEntity playerEntity = ClientUtil.getClientPlayer();
            boolean bl = playerEntity != null && !entity.isInvisibleTo(playerEntity);
            Team team = entity.getScoreboardTeam();
            if (playerEntity != null && team != null) {
               Team team2 = ClientUtil.getClientPlayer().getScoreboardTeam();

               return switch (team.getNameTagVisibilityRule()) {
                  case ALWAYS -> bl;
                  case NEVER -> false;
                  case HIDE_FOR_OTHER_TEAMS -> team2 == null ? bl : team.isEqual(team2) && (team.shouldShowFriendlyInvisibles() || bl);
                  case HIDE_FOR_OWN_TEAM -> team2 == null ? bl : !team.isEqual(team2) && bl;
                  default -> throw new MatchException(null, null);
               };
            } else {
               return MinecraftClient.isHudEnabled() && entity != minecraftClient.getCameraEntity() && bl && !entity.hasPassengers();
            }
         } else {
            return false;
         }
      }
   }

   public void render(R renderState, MatrixStack matrices, OrderedRenderCommandQueue queue, CameraRenderState cameraState) {
      GeoRenderer.super.performRenderPass(renderState, matrices, queue, cameraState);
   }

   public R createRenderState() {
      return this.createRenderState(null, null);
   }

   public void updateRenderState(T entity, R state, float tickProgress) {
      super.updateRenderState(entity, state, tickProgress);
      if (state instanceof LivingEntityRenderState livingEntityRenderState) {
         this.extractLivingEntityRenderState((LivingEntity)entity, livingEntityRenderState, tickProgress, this.itemModelResolver);
      }

      this.fillRenderState(entity, null, state, tickProgress);
   }

   public GeoEntityRenderer<T, R> withScale(float f, float f2) {
      this.scaleWidth = f;
      this.scaleHeight = f2;
      return this;
   }

   public GeoEntityRenderer<T, R> withScale(float f) {
      return this.withScale(f, f);
   }
}

