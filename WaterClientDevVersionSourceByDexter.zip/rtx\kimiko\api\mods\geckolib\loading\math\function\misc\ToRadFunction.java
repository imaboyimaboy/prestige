package rtx.kimiko.api.mods.geckolib.loading.math.function.misc;

import rtx.kimiko.api.mods.geckolib.animation.state.ControllerState;
import rtx.kimiko.api.mods.geckolib.loading.math.MathValue;
import rtx.kimiko.api.mods.geckolib.loading.math.function.MathFunction;

public final class ToRadFunction extends MathFunction {
   private MathValue value;

   public ToRadFunction(MathValue... mathValueArray) {
      super(mathValueArray);
      this.value = mathValueArray[0];
   }

   @Override
   public String getName() {
      return "math.to_rad";
   }

   @Override
   public double compute(ControllerState controllerState) {
      return Math.toRadians(this.value.get(controllerState));
   }

   @Override
   public MathValue[] getArgs() {
      return new MathValue[]{this.value};
   }

   @Override
   public int getMinArgs() {
      return 1;
   }
}

