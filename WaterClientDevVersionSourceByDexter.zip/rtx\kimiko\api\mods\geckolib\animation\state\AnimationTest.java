package rtx.kimiko.api.mods.geckolib.animation.state;

import java.util.Objects;
import rtx.kimiko.api.mods.geckolib.animatable.GeoAnimatable;
import rtx.kimiko.api.mods.geckolib.animatable.manager.AnimatableManager;
import rtx.kimiko.api.mods.geckolib.animation.AnimationController;
import rtx.kimiko.api.mods.geckolib.animation.RawAnimation;
import rtx.kimiko.api.mods.geckolib.animation.object.PlayState;
import rtx.kimiko.api.mods.geckolib.constant.DataTickets;
import rtx.kimiko.api.mods.geckolib.constant.dataticket.DataTicket;
import rtx.kimiko.api.mods.geckolib.renderer.base.GeoRenderState;

public final class AnimationTest<T extends GeoAnimatable> {
   private T animatable;
   private GeoRenderState renderState;
   private AnimatableManager<T> manager;
   private AnimationController<T> controller;

   public AnimationTest(T animatable, GeoRenderState renderState, AnimatableManager<T> manager, AnimationController<T> controller) {
      this.animatable = animatable;
      this.renderState = renderState;
      this.manager = manager;
      this.controller = controller;
   }

   public <D> D getData(DataTicket<D> dataTicket) {
      return this.renderState.getGeckolibData(dataTicket);
   }

   public boolean hasData(DataTicket<?> dataTicket) {
      return this.renderState.hasGeckolibData(dataTicket);
   }

   public <D> D getDataOrDefault(DataTicket<D> dataTicket, D d) {
      D d2 = this.getData(dataTicket);
      return d2 == null && !this.renderState.hasGeckolibData(dataTicket) ? d : d2;
   }

   public void setAnimation(RawAnimation rawAnimation) {
      this.controller.setAnimation(rawAnimation);
   }

   public boolean isMoving() {
      return this.renderState.getOrDefaultGeckolibData(DataTickets.IS_MOVING, false);
   }

   public PlayState setAndContinue(RawAnimation rawAnimation) {
      this.controller.setAnimation(rawAnimation);
      return PlayState.CONTINUE;
   }

   public boolean isCurrentAnimation(RawAnimation rawAnimation) {
      return Objects.equals(this.controller.getCurrentRawAnimation(), rawAnimation);
   }

   public boolean isCurrentAnimationStage(String string) {
      return this.controller.getCurrentAnimationPoint() != null && this.controller.getCurrentAnimationPoint().animation().name().equals(string);
   }

   public void setControllerSpeed(float f) {
      this.controller.animationSpeed = f;
   }

   public T animatable() {
      return this.animatable;
   }

   public GeoRenderState renderState() {
      return this.renderState;
   }

   public AnimatableManager<T> manager() {
      return this.manager;
   }

   public AnimationController<T> controller() {
      return this.controller;
   }
}

