package rtx.kimiko.api.mods.geckolib.service;

import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.render.block.entity.state.BlockEntityRenderState;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.state.BipedEntityRenderState;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.entity.Entity;
import net.minecraft.item.Item;
import rtx.kimiko.api.mods.geckolib.animatable.GeoAnimatable;
import rtx.kimiko.api.mods.geckolib.animatable.GeoBlockEntity;
import rtx.kimiko.api.mods.geckolib.animatable.GeoItem;
import rtx.kimiko.api.mods.geckolib.renderer.GeoArmorRenderer;
import rtx.kimiko.api.mods.geckolib.renderer.GeoBlockRenderer;
import rtx.kimiko.api.mods.geckolib.renderer.GeoEntityRenderer;
import rtx.kimiko.api.mods.geckolib.renderer.GeoItemRenderer;
import rtx.kimiko.api.mods.geckolib.renderer.GeoObjectRenderer;
import rtx.kimiko.api.mods.geckolib.renderer.GeoReplacedEntityRenderer;
import rtx.kimiko.api.mods.geckolib.renderer.base.GeoRenderState;
import rtx.kimiko.api.mods.geckolib.renderer.base.RenderPassInfo;

public interface GeckoLibEvents {
   <T extends BlockEntity & GeoBlockEntity, R extends BlockEntityRenderState & GeoRenderState> void fireCompileBlockRenderLayers(GeoBlockRenderer<T, R> var1);

   <T extends BlockEntity & GeoBlockEntity, R extends BlockEntityRenderState & GeoRenderState> void fireCompileBlockRenderState(
      GeoBlockRenderer<T, R> var1, R var2, T var3
   );

   <T extends Item & GeoItem, R extends BipedEntityRenderState & GeoRenderState> void fireCompileArmorRenderLayers(GeoArmorRenderer<T, R> var1);

   <T extends Entity & GeoAnimatable, R extends EntityRenderState & GeoRenderState> void fireCompileEntityRenderLayers(GeoEntityRenderer<T, R> var1);

   <T extends Entity & GeoAnimatable, R extends EntityRenderState & GeoRenderState> void fireCompileEntityRenderState(
      GeoEntityRenderer<T, R> var1, R var2, T var3
   );

   <T extends Entity & GeoAnimatable, R extends EntityRenderState & GeoRenderState> boolean fireEntityPreRender(
      GeoEntityRenderer<T, R> var1, RenderPassInfo<R> var2, OrderedRenderCommandQueue var3
   );

   <T extends GeoAnimatable, E extends Entity, R extends EntityRenderState & GeoRenderState> void fireCompileReplacedEntityRenderLayers(
      GeoReplacedEntityRenderer<T, E, R> var1
   );

   <T extends Item & GeoItem, O extends GeoArmorRenderer.RenderData, R extends BipedEntityRenderState & GeoRenderState> void fireCompileArmorRenderState(
      GeoArmorRenderer<T, R> var1, R var2, T var3, O var4
   );

   <T extends GeoAnimatable, E extends Entity, R extends EntityRenderState & GeoRenderState> boolean fireReplacedEntityPreRender(
      GeoReplacedEntityRenderer<T, E, R> var1, RenderPassInfo<R> var2, OrderedRenderCommandQueue var3
   );

   <T extends GeoAnimatable, E extends Entity, R extends EntityRenderState & GeoRenderState> void fireCompileReplacedEntityRenderState(
      GeoReplacedEntityRenderer<T, E, R> var1, R var2, T var3, E var4
   );

   <T extends Item & GeoItem> void fireCompileItemRenderLayers(GeoItemRenderer<T> var1);

   <T extends GeoAnimatable, E, R extends GeoRenderState> void fireCompileObjectRenderLayers(GeoObjectRenderer<T, E, R> var1);

   <T extends GeoAnimatable, E, R extends GeoRenderState> void fireCompileObjectRenderState(GeoObjectRenderer<T, E, R> var1, R var2, T var3, E var4);

   <T extends Item & GeoItem, O extends GeoItemRenderer.RenderData, R extends GeoRenderState> void fireCompileItemRenderState(
      GeoItemRenderer<T> var1, R var2, T var3, O var4
   );

   <T extends Item & GeoItem> boolean fireItemPreRender(GeoItemRenderer<T> var1, RenderPassInfo<GeoRenderState> var2, OrderedRenderCommandQueue var3);

   <T extends GeoAnimatable, E, R extends GeoRenderState> boolean fireObjectPreRender(
      GeoObjectRenderer<T, E, R> var1, RenderPassInfo<R> var2, OrderedRenderCommandQueue var3
   );

   <T extends BlockEntity & GeoBlockEntity, R extends BlockEntityRenderState & GeoRenderState> boolean fireBlockPreRender(
      GeoBlockRenderer<T, R> var1, RenderPassInfo<R> var2, OrderedRenderCommandQueue var3
   );

   <T extends Item & GeoItem, R extends BipedEntityRenderState & GeoRenderState> boolean fireArmorPreRender(
      GeoArmorRenderer<T, R> var1, RenderPassInfo<R> var2, OrderedRenderCommandQueue var3
   );
}

