package com.water.gui.notification;

import com.water.module.modules.client.WaterPlus;
import com.water.utils.renderer.AwtFontRenderer;
import com.water.utils.renderer.RenderUtil;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Util;

public final class NotificationManager {
   public static final NotificationManager INSTANCE = new NotificationManager();
   private static final long DISPLAY_MS = 3500L;
   private static final long ANIMATION_MS = 220L;
   private static final int MAX_NOTIFICATIONS = 5;
   private static final float CARD_WIDTH = 170.0F;
   private static final float CARD_HEIGHT = 36.0F;
   private static final float CARD_GAP = 5.0F;
   private static final float ICON_SIZE = 16.0F;
   private static final float ICON_PAD = 7.0F;
   private static final float ACCENT_BAR = 3.0F;
   private final List<NotificationManager.NotificationEntry> notifications = new CopyOnWriteArrayList<>();

   private NotificationManager() {
   }

   public void pushToggle(String moduleName, boolean enabled) {
   }

   public void pushToggle(String moduleName, boolean enabled, ItemStack icon) {
   }

   public void renderToasts(DrawContext context) {
      this.render(context);
   }

   public void push(String message, String details, ItemStack stack, int accentColor) {
      this.notifications
         .add(
            0,
            new NotificationEntry(
               message == null ? "" : message,
               details == null ? "" : details,
               stack == null ? ItemStack.EMPTY : stack.copy(),
               accentColor,
               Util.getMeasuringTimeMs()
            )
         );

      while (this.notifications.size() > 5) {
         this.notifications.remove(this.notifications.size() - 1);
      }
   }

   public void render(DrawContext context) {
      if (!this.notifications.isEmpty()) {
         MinecraftClient client = MinecraftClient.getInstance();
         long now = Util.getMeasuringTimeMs();
         this.notifications.removeIf(entryx -> entryx.isExpired(now));
         if (!this.notifications.isEmpty()) {
            context.createNewRootLayer();
            float baseX = client.getWindow().getScaledWidth() - 170.0F - 8.0F;
            float baseY = client.getWindow().getScaledHeight() - 36.0F - 8.0F;
            float radius = WaterPlus.getGuiRoundness();

            for (int i = 0; i < this.notifications.size(); i++) {
               NotificationManager.NotificationEntry entry = this.notifications.get(i);
               float vis = entry.getVisibility(now);
               if (!(vis <= 0.0F)) {
                  float x = baseX + (1.0F - vis) * 184.0F;
                  float y = baseY - i * 41.0F;
                  int accent = withAlpha(entry.accentColor, vis);
                  int bg = withAlpha(WaterPlus.getBackgroundARGB(), vis * 0.97F);
                  int shadow = withAlpha(-16777216, vis * 0.45F);
                  int outline = withAlpha(blendColors(WaterPlus.getBackgroundARGB(), entry.accentColor, 0.25F), vis);
                  RenderUtil.drawRoundedRect(context, x + 2.0F, y + 2.0F, 170.0F, 36.0F, radius, shadow, false);
                  RenderUtil.drawRoundedRect(context, x, y, 170.0F, 36.0F, radius, bg, false);
                  RenderUtil.drawOutline(context, x, y, 170.0F, 36.0F, radius, 1.0F, outline, false);
                  float iconX = x + 7.0F + 3.0F;
                  float iconY = y + 10.0F;
                  int slotBg = withAlpha(-15724528, vis * 0.7F);
                  RenderUtil.drawRoundedRect(context, iconX - 2.0F, iconY - 2.0F, 20.0F, 20.0F, radius * 0.5F, slotBg, false);
                  if (!entry.stack.isEmpty()) {
                     context.drawItem(entry.stack, (int)iconX, (int)iconY);
                  }

                  AwtFontRenderer font = AwtFontRenderer.INSTANCE;
                  int titleColor = withAlpha(-1, vis);
                  int detailColor = withAlpha(entry.accentColor | 0xFF000000, vis);
                  float textX = iconX + 16.0F + 6.0F;
                  float textY1 = y + 18.0F - font.getWidth("A") * 0.5F - 3.0F;
                  float textY2 = textY1 + 11.0F;
                  font.drawString(context, entry.message, textX, y + 8.0F, titleColor);
                  font.drawString(context, entry.details, textX, y + 20.0F, detailColor);
               }
            }
         }
      }
   }

   private static int withAlpha(int color, float alphaScale) {
      int alpha = Math.max(0, Math.min(255, Math.round((color >>> 24 & 0xFF) * alphaScale)));
      return color & 16777215 | alpha << 24;
   }

   private static int blendColors(int a, int b, float t) {
      int ar = a >> 16 & 0xFF;
      int ag = a >> 8 & 0xFF;
      int ab = a & 0xFF;
      int br = b >> 16 & 0xFF;
      int bg = b >> 8 & 0xFF;
      int bb = b & 0xFF;
      int r = (int)(ar + (br - ar) * t);
      int g = (int)(ag + (bg - ag) * t);
      int blue = (int)(ab + (bb - ab) * t);
      return 0xFF000000 | r << 16 | g << 8 | blue;
   }

   static String _c98900d3603() {
      return "R";
   }

   final class NotificationEntry {
      private String message;
      private String details;
      private ItemStack stack;
      private int accentColor;
      private long createdAt;

      private NotificationEntry(String message, String details, ItemStack stack, int accentColor, long createdAt) {
         this.message = message;
         this.details = details;
         this.stack = stack;
         this.accentColor = accentColor | 0xFF000000;
         this.createdAt = createdAt;
      }

      private boolean isExpired(long now) {
         return now - this.createdAt >= 3500L;
      }

      private float getVisibility(long now) {
         long age = now - this.createdAt;
         if (age <= 0L) {
            return 0.0F;
         } else if (age < 220L) {
            return this.easeOut((float)age / 220.0F);
         } else {
            return age > 3280L ? this.easeOut(Math.max(0.0F, 1.0F - (float)(age - 3280L) / 220.0F)) : 1.0F;
         }
      }

      private float easeOut(float t) {
         float inv = 1.0F - Math.max(0.0F, Math.min(1.0F, t));
         return 1.0F - inv * inv * inv;
      }
   }
}

