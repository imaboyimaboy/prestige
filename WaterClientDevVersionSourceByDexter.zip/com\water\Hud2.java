package com.water;

public final class Hud2 {
   private static final int intVal = 28234;
   private static final int[][] intArray = new int[][]{
      intArrayOf("Auto Crystal"),
      intArrayOf("Auto Totem"),
      intArrayOf("Storage ESP"),
      intArrayOf("Block ESP"),
      intArrayOf("Freecam"),
      intArrayOf("SpawnerProtect"),
      intArrayOf("AntiTrap"),
      intArrayOf("AutoDoubleHand"),
      intArrayOf("Auto Inv Totem"),
      intArrayOf("Water-CoordSnapper"),
      intArrayOf("Water-SkinChanger"),
      intArrayOf("Water +"),
      intArrayOf("Water Menu"),
      intArrayOf("Water Configs"),
      intArrayOf("AutoLog"),
      intArrayOf("AutoTPA"),
      intArrayOf("NameProtect"),
      intArrayOf("Sprint"),
      intArrayOf("FullBright"),
      intArrayOf("NoRender"),
      intArrayOf("Hole ESP"),
      intArrayOf("Player ESP"),
      intArrayOf("Mob ESP"),
      intArrayOf("Chat Macro"),
      intArrayOf("Chunk Toggle"),
      intArrayOf("ChunkFinder"),
      intArrayOf("Config Share"),
      intArrayOf("CoordSnapper"),
      intArrayOf("Double Anchor"),
      intArrayOf("FakeRoles"),
      intArrayOf("FakeStats"),
      intArrayOf("Fast Place"),
      intArrayOf("FreeLook"),
      intArrayOf("Friends"),
      intArrayOf("FutureDebug"),
      intArrayOf("Growth Finder"),
      intArrayOf("Hitbox"),
      intArrayOf("HomeSetter"),
      intArrayOf("Hud"),
      intArrayOf("JumpCircles"),
      intArrayOf("Light Debug"),
      intArrayOf("NameTags"),
      intArrayOf("RadiusDebug"),
      intArrayOf("Shield Breaker"),
      intArrayOf("SkinChanger"),
      intArrayOf("Spawner Notifier"),
      intArrayOf("SpearSwap"),
      intArrayOf("Spotify HUD"),
      intArrayOf("SwingSpeed"),
      intArrayOf("TabDetector"),
      intArrayOf("Triggerbot"),
      intArrayOf("WeatherNotifier"),
      intArrayOf("Hover Totem"),
      intArrayOf("Anchor Macro"),
      intArrayOf("Amethyst ESP"),
      intArrayOf("ActivityDebug"),
      intArrayOf("BoneDropper"),
      intArrayOf("AutoHitCrystal"),
      intArrayOf("Water"),
      intArrayOf("Initialisiere Water Client (Yarn Mappings)"),
      intArrayOf("Watermark"),
      intArrayOf("Auto Crystal"),
      intArrayOf("AnchorMacro")
   };

   private Hud2() {
   }

   public static String stringOf(int i) {
      int[] enc = intArray[i];
      char[] out = new char[enc.length];

      for (int j = 0; j < enc.length; j++) {
         out[j] = (char)(enc[j] ^ 28234);
      }

      return new String(out);
   }

   private static int[] intArrayOf(String s) {
      int[] r = new int[s.length()];

      for (int i = 0; i < s.length(); i++) {
         r[i] = s.charAt(i) ^ 28234;
      }

      return r;
   }
}

