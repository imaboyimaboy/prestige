package com.water.gui;

import com.water.module.modules.render.DevSpawnerVisuals;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public final class FakeSpawnerScreen extends Screen {
   private static final Identifier TEXTURE = Identifier.of("minecraft", "textures/gui/container/generic_54.png");
   private static final int WIDTH = 176;
   private static final int HEIGHT = 221;
   private static final int TOP_HEIGHT = 125;
   private static final int SLOT = 18;
   private final ItemStack[] shown = new ItemStack[]{new ItemStack(Items.GOLD_INGOT), new ItemStack(Items.SKELETON_SKULL), new ItemStack(Items.DROPPER)};
   private int spawnerCount;
   private int left;
   private int top;

   public FakeSpawnerScreen(int spawnerCount) {
      super(Text.literal("Skeleton Spawners"));
      this.spawnerCount = Math.max(1, Math.min(999, spawnerCount));
   }

   protected void init() {
      this.left = (this.width - 176) / 2;
      this.top = (this.height - 221) / 2;
   }

   private Text titleText() {
      return Text.literal(this.spawnerCount + (this.spawnerCount == 1 ? " Skeleton Spawner" : " Skeleton Spawners"));
   }

   public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
   }

   public void render(DrawContext context, int mouseX, int mouseY, float delta) {
      super.renderBackground(context, mouseX, mouseY, delta);
      context.drawTexture(RenderPipelines.GUI_TEXTURED, TEXTURE, this.left, this.top, 0.0F, 0.0F, 176, 125, 256, 256);
      context.drawTexture(RenderPipelines.GUI_TEXTURED, TEXTURE, this.left, this.top + 125, 0.0F, 126.0F, 176, 96, 256, 256);
      context.drawText(this.textRenderer, this.titleText(), this.left + 8, this.top + 6, -12566464, false);
      int boneStacks = DevSpawnerVisuals.getGeneratedBoneStacks();

      for (int slot = 0; slot < boneStacks; slot++) {
         int slotX = this.left + 8 + slot % 9 * 18;
         int slotY = this.top + 18 + slot / 9 * 18;
         ItemStack bones = new ItemStack(Items.BONE, 64);
         context.drawItem(bones, slotX, slotY);
         context.drawStackOverlay(this.textRenderer, bones, slotX, slotY);
      }

      int row = 5;
      int firstColumn = (9 - this.shown.length) / 2;

      for (int i = 0; i < this.shown.length; i++) {
         int slotX = this.left + 8 + (firstColumn + i) * 18;
         int slotY = this.top + 18 + 90;
         context.drawItem(this.shown[i], slotX, slotY);
      }

      this.drawPlayerInventory(context);
      super.render(context, mouseX, mouseY, delta);
   }

   private void drawPlayerInventory(DrawContext context) {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client.player != null) {
         int inventoryY = this.top + 140;

         for (int row = 0; row < 3; row++) {
            for (int column = 0; column < 9; column++) {
               ItemStack stack = client.player.getInventory().getStack(9 + row * 9 + column);
               this.drawStack(context, stack, this.left + 8 + column * 18, inventoryY + row * 18);
            }
         }

         int hotbarY = inventoryY + 54 + 4;

         for (int column = 0; column < 9; column++) {
            ItemStack stack = client.player.getInventory().getStack(column);
            this.drawStack(context, stack, this.left + 8 + column * 18, hotbarY);
         }
      }
   }

   private void drawStack(DrawContext context, ItemStack stack, int x, int y) {
      if (stack != null && !stack.isEmpty()) {
         context.drawItem(stack, x, y);
         context.drawStackOverlay(MinecraftClient.getInstance().textRenderer, stack, x, y);
      }
   }

   public boolean shouldPause() {
      return false;
   }

   public boolean mouseClicked(Click click, boolean doubled) {
      return true;
   }

   public boolean keyPressed(KeyInput input) {
      if (!input.isEscape() && input.getKeycode() != 69) {
         return super.keyPressed(input);
      } else {
         this.close();
         return true;
      }
   }
}

