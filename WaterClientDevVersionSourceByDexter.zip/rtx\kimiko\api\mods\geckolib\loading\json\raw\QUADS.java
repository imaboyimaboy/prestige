package rtx.kimiko.api.mods.geckolib.loading.json.raw;

public enum QUADS {
   TRIANGLES,
   QUADS;

   private static QUADS[] $values() {
      return new QUADS[]{TRIANGLES, QUADS};
   }
}

