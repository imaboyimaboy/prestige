package com.water.module.modules.render.netherite;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.world.biome.Biome;

public class OrePlacements {
   public int index;
   public int step;
   public int size;
   public float rarityChance;
   public float discardOnAirChance;
   public boolean scattered;
   public OrePlacements.HeightProvider height;
   public OrePlacements.HeightContext heightContext;
   public OrePlacements.CountProvider count;

   public OrePlacements(
      int index,
      int step,
      int size,
      float rarityChance,
      float discardOnAirChance,
      boolean scattered,
      OrePlacements.HeightProvider height,
      OrePlacements.HeightContext heightContext,
      OrePlacements.CountProvider count
   ) {
      this.index = index;
      this.step = step;
      this.size = size;
      this.rarityChance = rarityChance;
      this.discardOnAirChance = discardOnAirChance;
      this.scattered = scattered;
      this.height = height;
      this.heightContext = heightContext;
      this.count = count;
   }

   public boolean isDebris() {
      return true;
   }

   public static Map<RegistryEntry<Biome>, List<OrePlacements>> buildBiomeTable(Iterable<RegistryEntry<Biome>> biomes) {
      Map<RegistryEntry<Biome>, List<OrePlacements>> table = new HashMap<>();
      OrePlacements normalDebris = new OrePlacements(
         0, 7, 3, 1.0F, 1.0F, false, new TriangleHeightProvider(8, 24), new HeightContext(-64, 320), new ConstantCount(1)
      );
      OrePlacements scatteredDebris = new OrePlacements(
         1, 7, 2, 1.0F, 1.0F, true, new UniformHeightProvider(8, 119), new HeightContext(-64, 320), new ConstantCount(1)
      );
      List<OrePlacements> debrisPlacements = List.of(normalDebris, scatteredDebris);

      for (RegistryEntry<Biome> biome : biomes) {
         table.put(biome, new ArrayList<>(debrisPlacements));
      }

      return table;
   }

   public static class ConstantCount implements OrePlacements.CountProvider {
      private int value;

      public ConstantCount(int value) {
         this.value = value;
      }

      @Override
      public int getMaxValue(Random random) {
         return this.value;
      }
   }

   public interface CountProvider {
      int getMaxValue(Random var1);
   }

   public static class HeightContext {
      public int minY;
      public int height;

      public HeightContext(int minY, int height) {
         this.minY = minY;
         this.height = height;
      }
   }

   public interface HeightProvider {
      int sample(Random var1, OrePlacements.HeightContext var2);
   }

   public static class TriangleHeightProvider implements OrePlacements.HeightProvider {
      private int minInclusive;
      private int maxInclusive;

      public TriangleHeightProvider(int min, int max) {
         this.minInclusive = min;
         this.maxInclusive = max;
      }

      @Override
      public int sample(Random random, OrePlacements.HeightContext context) {
         int mid = (this.minInclusive + this.maxInclusive) / 2;
         int range = (this.maxInclusive - this.minInclusive) / 2;
         return range <= 0 ? mid : mid + random.nextInt(range * 2 + 1) - range;
      }
   }

   public static class UniformHeightProvider implements OrePlacements.HeightProvider {
      private int minInclusive;
      private int maxInclusive;

      public UniformHeightProvider(int min, int max) {
         this.minInclusive = min;
         this.maxInclusive = max;
      }

      @Override
      public int sample(Random random, OrePlacements.HeightContext context) {
         return this.maxInclusive <= this.minInclusive ? this.minInclusive : this.minInclusive + random.nextInt(this.maxInclusive - this.minInclusive + 1);
      }
   }
}

