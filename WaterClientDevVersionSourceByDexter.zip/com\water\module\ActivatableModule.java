package com.water.module;

public abstract class ActivatableModule extends Module {
   private int activationKey = 0;
   public boolean wasActivationKeyPressed = false;

   public ActivatableModule(String name, Category category) {
      super(name, category);
   }

   public void onActivationKeyPressed() {
      this.toggle();
   }

   public int getActivationKey() {
      return this.activationKey;
   }

   public void setActivationKey(int activationKey) {
      this.activationKey = activationKey;
      ModuleManager.INSTANCE.saveConfig();
   }

   void applyActivationKey(int activationKey) {
      this.activationKey = activationKey;
   }

   static String _c1d949c2507() {
      return "C";
   }
}

