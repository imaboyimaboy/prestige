package rtx.kimiko.api.mods.chathads;

import com.mojang.datafixers.util.Pair;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.component.type.ProfileComponent;
import net.minecraft.text.MutableText;
import net.minecraft.text.ObjectTextContent;
import net.minecraft.text.PlainTextContent;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextContent;
import net.minecraft.text.TextVisitFactory;
import net.minecraft.text.TranslatableTextContent;
import net.minecraft.text.ClickEvent.SuggestCommand;
import net.minecraft.text.object.PlayerTextObjectContents;
import net.minecraft.text.object.TextObjectContents;
import net.minecraft.util.Formatting;

public class ComponentProcessor {
   public static ArrayList<Text> split(Text text2) {
      ArrayList<Text> arrayList = new ArrayList<>();
      walkTree(text2, (text, style2) -> {
         if (text.getContent() instanceof PlainTextContent plainTextContent) {
            Style[] styleArray = new Style[]{style2};
            StringBuilder stringBuilder = new StringBuilder();
            TextVisitFactory.visitFormatted(plainTextContent.string(), styleArray[0], (n, style, n2) -> {
               if (!style.equals(styleArray[0])) {
                  if (!stringBuilder.isEmpty()) {
                     arrayList.add(Text.literal(stringBuilder.toString()).setStyle(styleArray[0]));
                  }

                  stringBuilder.setLength(0);
                  styleArray[0] = style;
               }

               stringBuilder.appendCodePoint(n2);
               return true;
            });
            if (!stringBuilder.isEmpty()) {
               arrayList.add(Text.literal(stringBuilder.toString()).setStyle(styleArray[0]));
            }
         } else {
            MutableText copy = text.copyContentOnly().setStyle(style2);
            arrayList.add(copy);
         }
      });
      return arrayList;
   }

   public static Text join(List<Text> list) {
      if (list.size() == 1) {
         return list.getFirst();
      } else {
         MutableText mutableText = Text.empty();

         for (Text text : list) {
            mutableText.getSiblings().add(text);
         }

         return mutableText;
      }
   }

   public static void walkTree(Text text, ComponentProcessor.StyledComponentConsumer styledComponentConsumer) {
      walkTree(text, Style.EMPTY, styledComponentConsumer);
   }

   public static void walkTree(Text text, Style style, ComponentProcessor.StyledComponentConsumer styledComponentConsumer) {
      style = text.getStyle().withParent(style);
      styledComponentConsumer.accept(text, style);

      for (Text text2 : text.getSiblings()) {
         walkTree(text2, style, styledComponentConsumer);
      }
   }

   public static PlayerListEntry addChatHeadForClickTellCommand(ArrayList<Text> arrayList2, ChatHeads.PlayerInfoCache playerInfoCache) {
      for (int i = 0; i < arrayList2.size(); i++) {
         Text text = arrayList2.get(i);
         String string = getTellReceiver(text);
         PlayerListEntry playerListEntry;
         if (string != null && (playerListEntry = playerInfoCache.get(string)) != null) {
            MutableText mutableText2 = createChatHeadComponent(playerListEntry, text);
            MutableText mutableText = Text.empty().append(mutableText2).append(text);
            arrayList2.set(i, mutableText);
            return playerListEntry;
         }

         if (text.getContent() instanceof TranslatableTextContent translatableTextContent) {
            int idx = i;
            PlayerListEntry res = processTranslatableArguments(
               text, translatableTextContent, list -> addChatHeadForClickTellCommand(list, playerInfoCache), replacement -> arrayList2.set(idx, replacement)
            );
            if (res != null) {
               return res;
            }
         }
      }

      return null;
   }

   public static void walkLiteralSequencesAndTranslatables(
      ArrayList<Text> arrayList, Predicate<ComponentProcessor.FoundLiteralSequence> predicate, Predicate<ComponentProcessor.FoundTranslatable> predicate2
   ) {
      StringBuilder stringBuilder = new StringBuilder();
      int n = -1;
      int n2 = -1;

      for (int i = 0; i < arrayList.size(); i++) {
         TextContent textContent = arrayList.get(i).getContent();
         if (textContent instanceof PlainTextContent plainTextContent) {
            if (n == -1) {
               n = i;
            }

            n2 = i;
            stringBuilder.append(plainTextContent.string());
         } else {
            if (!stringBuilder.isEmpty() && predicate.test(new FoundLiteralSequence(stringBuilder.toString(), n, n2))) {
               return;
            }

            stringBuilder = new StringBuilder();
            n = -1;
            TranslatableTextContent translatableTextContent;
            if (textContent instanceof TranslatableTextContent
               && predicate2.test(
                  new FoundTranslatable(
                     translatableTextContent = (TranslatableTextContent)textContent, i
                  )
               )) {
               return;
            }
         }
      }

      n2 = arrayList.size() - 1;
      if (stringBuilder.isEmpty() || !predicate.test(new FoundLiteralSequence(stringBuilder.toString(), n, n2))) {
         ;
      }
   }

   private static void lambda_addChatHeadForClickTellCommand_3(ArrayList arrayList, int n, Text text) {
      arrayList.set(n, text);
   }

   public static <T> T processTranslatableArguments(
      Text text, TranslatableTextContent translatableTextContent, Function<ArrayList<Text>, T> function, Consumer<Text> consumer
   ) {
      Object[] objectArray = translatableTextContent.getArgs();
      int n = Objects.equals(translatableTextContent.getKey(), "chat.type.text") ? 1 : objectArray.length;

      for (int i = 0; i < n; i++) {
         Object rawArg = objectArray[i];
         if (rawArg instanceof String strArg) {
            rawArg = Text.literal(strArg);
            objectArray[i] = rawArg;
         }

         if (rawArg instanceof Text textArg) {
            ArrayList<Text> splitList = split(textArg);
            T t = function.apply(splitList);
            if (t != null) {
               Text text2 = join(splitList);
               Object[] objectArray2 = Arrays.copyOf(objectArray, objectArray.length);
               objectArray2[i] = text2;
               MutableText mutableText = Text.translatableWithFallback(translatableTextContent.getKey(), translatableTextContent.getFallback(), objectArray2);
               mutableText.setStyle(text.getStyle());
               text.getSiblings().forEach(sibling -> mutableText.append(sibling));
               consumer.accept(mutableText);
               return t;
            }
         }
      }

      return null;
   }

   public static boolean containsPlayerSprite(ArrayList<Text> arrayList) {
      for (Text text : arrayList) {
         if (text.getContent() instanceof ObjectTextContent objectTextContent) {
            TextObjectContents textObjectContents = objectTextContent.contents();
            if (textObjectContents instanceof PlayerTextObjectContents) {
               return true;
            }
         }
      }

      return false;
   }

   public static PlayerListEntry addChatHeadForPlayerName(ArrayList<Text> arrayList, ChatHeads.PlayerInfoCache playerInfoCache) {
      PlayerListEntry[] playerListEntryArray = new PlayerListEntry[1];
      walkLiteralSequencesAndTranslatables(
         arrayList,
         foundLiteralSequence -> {
            HeadData headData = ChatHeads.scanForPlayerName(foundLiteralSequence.text, playerInfoCache);
            if (headData == HeadData.EMPTY) {
               return false;
            } else {
               int n = headData.codePointIndex;

               for (int i = foundLiteralSequence.startIndex; i <= foundLiteralSequence.endIndex; i++) {
                  Text text = arrayList.get(i);
                  PlainTextContent plainTextContent = (PlainTextContent)text.getContent();
                  int n2 = (int)plainTextContent.string().codePoints().count();
                  if (n < n2) {
                     MutableText mutableText2 = createChatHeadComponent(headData.playerInfo, text);
                     Pair<MutableText, MutableText> pair = splitLiteral(text, n);
                     MutableText mutableText;
                     if (pair == null) {
                        mutableText = Text.empty().append(mutableText2).append(text);
                     } else {
                        MutableText mutableText3 = (MutableText)pair.getFirst();
                        MutableText mutableText4 = (MutableText)pair.getSecond();
                        mutableText = Text.empty().append(mutableText3).append(mutableText2).append(mutableText4);
                     }

                     arrayList.set(i, mutableText);
                     playerListEntryArray[0] = headData.playerInfo;
                     return true;
                  }

                  n -= n2;
               }

               return false;
            }
         },
         foundTranslatable -> {
            Text text2 = arrayList.get(foundTranslatable.index);
            TranslatableTextContent translatableTextContent;
            PlayerListEntry playerListEntry = processTranslatableArguments(
               text2,
               translatableTextContent = foundTranslatable.contents,
               subList -> addChatHeadForPlayerName(subList, playerInfoCache),
               text -> arrayList.set(foundTranslatable.index, text)
            );
            if (playerListEntry != null) {
               playerListEntryArray[0] = playerListEntry;
               return true;
            } else {
               return false;
            }
         }
      );
      return playerListEntryArray[0];
   }

   public static MutableText createChatHeadComponent(PlayerListEntry playerListEntry) {
      return Text.object(new PlayerTextObjectContents(ProfileComponent.ofStatic(playerListEntry.getProfile()), playerListEntry.shouldShowHat()))
         .formatted(Formatting.WHITE);
   }

   public static MutableText createChatHeadComponent(PlayerListEntry playerListEntry, Text text) {
      MutableText mutableText = createChatHeadComponent(playerListEntry);
      return text.getStyle().isStrikethrough() ? mutableText.formatted(Formatting.STRIKETHROUGH) : mutableText;
   }

   public static String getTellReceiver(Text text) {
      if (!(text.getStyle().getClickEvent() instanceof SuggestCommand suggestCommand)) {
         return null;
      } else {
         try {
            String string2 = suggestCommand.command();
            if (string2 == null) {
               return null;
            } else {
               return !string2.startsWith("/tell ") ? null : string2.substring(6).trim();
            }
         } catch (Throwable var5) {
            throw new MatchException(var5.toString(), var5);
         }
      }
   }

   public static String codePointSubstring(String string, int n, int n2) {
      int n3 = string.offsetByCodePoints(0, n);
      int n4 = string.offsetByCodePoints(n3, n2 - n);
      return string.substring(n3, n4);
   }

   public static String codePointSubstring(String string, int n) {
      return string.substring(string.offsetByCodePoints(0, n));
   }

   public static Pair<MutableText, MutableText> splitLiteral(Text text, int n) {
      if (n == 0) {
         return null;
      } else {
         String string = ((PlainTextContent)text.getContent()).string();
         String string2 = codePointSubstring(string, 0, n);
         String string3 = codePointSubstring(string, n);
         MutableText mutableText = Text.literal(string2).setStyle(text.getStyle());
         MutableText mutableText2 = Text.literal(string3).setStyle(text.getStyle());
         text.getSiblings().forEach(arg_0 -> mutableText2.append(arg_0));
         return new Pair(mutableText, mutableText2);
      }
   }

   public final static class FoundLiteralSequence {
      private String text;
      private int startIndex;
      private int endIndex;

      public FoundLiteralSequence(String text, int startIndex, int endIndex) {
         this.text = text;
         this.startIndex = startIndex;
         this.endIndex = endIndex;
      }

      public String text() {
         return this.text;
      }

      public int startIndex() {
         return this.startIndex;
      }

      public int endIndex() {
         return this.endIndex;
      }
   }

   public final static class FoundTranslatable {
      private TranslatableTextContent contents;
      private int index;

      public FoundTranslatable(TranslatableTextContent contents, int index) {
         this.contents = contents;
         this.index = index;
      }

      public TranslatableTextContent contents() {
         return this.contents;
      }

      public int index() {
         return this.index;
      }
   }

   public interface StyledComponentConsumer {
      void accept(Text var1, Style var2);
   }
}

