package rtx.kimiko.api.mods.geckolib.event.entity;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.entity.Entity;
import rtx.kimiko.api.mods.geckolib.animatable.GeoAnimatable;
import rtx.kimiko.api.mods.geckolib.event.GeoRenderEvent;
import rtx.kimiko.api.mods.geckolib.renderer.GeoEntityRenderer;
import rtx.kimiko.api.mods.geckolib.renderer.base.GeoRenderState;

public class CompileEntityRenderStateEvent<T extends Entity & GeoAnimatable, R extends EntityRenderState & GeoRenderState> implements GeoRenderEvent<T, Void, R> {
   public static final Event<CompileEntityRenderStateEvent.Listener> EVENT = EventFactory.createArrayBacked(
      CompileEntityRenderStateEvent.Listener.class,
      (CompileEntityRenderStateEvent.Listener)compileEntityRenderStateEvent -> {},
      listenerArray -> compileEntityRenderStateEvent -> {
         for (CompileEntityRenderStateEvent.Listener listener : listenerArray) {
            listener.handle(compileEntityRenderStateEvent);
         }
      }
   );
   private GeoEntityRenderer<T, R> renderer;
   private R renderState;
   private T animatable;

   public CompileEntityRenderStateEvent(GeoEntityRenderer<T, R> geoEntityRenderer, R r, T t) {
      this.renderer = geoEntityRenderer;
      this.renderState = r;
      this.animatable = t;
   }

   public R getRenderState() {
      return this.renderState;
   }

   public GeoEntityRenderer<T, R> getRenderer() {
      return this.renderer;
   }

   public T getAnimatable() {
      return this.animatable;
   }

   public interface Listener {
      void handle(CompileEntityRenderStateEvent<?, ?> var1);
   }
}

