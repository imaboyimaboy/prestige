package rtx.kimiko.api.mods.geckolib.event;

import java.util.Objects;
import rtx.kimiko.api.mods.geckolib.animatable.GeoAnimatable;
import rtx.kimiko.api.mods.geckolib.constant.DataTickets;
import rtx.kimiko.api.mods.geckolib.constant.dataticket.DataTicket;
import rtx.kimiko.api.mods.geckolib.renderer.base.GeoRenderState;
import rtx.kimiko.api.mods.geckolib.renderer.base.GeoRenderer;

public interface GeoRenderEvent<T extends GeoAnimatable, O, R extends GeoRenderState> {
   default R getRenderState() {
      return null;
   }

   default <D> D getRenderData(DataTicket<D> dataTicket) {
      R r = this.getRenderState();
      return r.getGeckolibData(dataTicket);
   }

   default boolean hasData(DataTicket<?> dataTicket) {
      return this.getRenderState().hasGeckolibData(dataTicket);
   }

   default int packedLight() {
      return this.getRenderState().getPackedLight();
   }

   default float getPartialTick() {
      return this.getRenderState().getPartialTick();
   }

   GeoRenderer<T, O, R> getRenderer();

   default Class<? extends GeoAnimatable> getAnimatableClass() {
      return Objects.requireNonNull(this.getRenderData(DataTickets.ANIMATABLE_CLASS));
   }
}

