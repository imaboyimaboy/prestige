package com.water.utils.combat;

import java.util.ArrayDeque;
import java.util.Queue;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Item;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public final class VanillaInteract {
   private static final MinecraftClient mc = MinecraftClient.getInstance();
   private static final Queue<VanillaInteract.Action> actionQueue = new ArrayDeque<>();
   private static BlockHitResult savedHit = null;
   private static BlockPos lastPlacedPos = null;
   private static boolean frozen = false;
   private static int freezeTicks = 0;

   public static void queue(VanillaInteract.Action action) {
      actionQueue.add(action);
   }

   public static void clear() {
      actionQueue.clear();
      savedHit = null;
      lastPlacedPos = null;
      frozen = false;
      freezeTicks = 0;
   }

   public static boolean isBusy() {
      return !actionQueue.isEmpty();
   }

   public static boolean isFrozen() {
      return frozen;
   }

   public static void tick() {
      if (mc.player == null) {
         clear();
      } else {
         if (frozen) {
            mc.options.forwardKey.setPressed(false);
            mc.options.backKey.setPressed(false);
            mc.options.leftKey.setPressed(false);
            mc.options.rightKey.setPressed(false);
            mc.options.sprintKey.setPressed(false);
            mc.player.setSprinting(false);
            mc.player.setVelocity(0.0, mc.player.getVelocity().y, 0.0);
            if (--freezeTicks <= 0) {
               frozen = false;
            }
         }

         if (actionQueue.isEmpty()) {
            savedHit = null;
         } else {
            VanillaInteract.Action action = actionQueue.peek();
            if (action.execute()) {
               actionQueue.poll();
            }
         }
      }
   }

   private static int findHotbar(Item item) {
      if (mc.player == null) {
         return -1;
      } else {
         for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).isOf(item)) {
               return i;
            }
         }

         return -1;
      }
   }

   public static boolean hasItem(Item item) {
      return findHotbar(item) != -1;
   }

   public static BlockHitResult getSavedHit() {
      return savedHit;
   }

   public interface Action {
      boolean execute();
   }

   public class FreezeAction implements VanillaInteract.Action {
      private int duration;

      public FreezeAction(int duration) {
         this.duration = duration;
      }

      @Override
      public boolean execute() {
         VanillaInteract.frozen = true;
         VanillaInteract.freezeTicks = this.duration;
         return true;
      }
   }

   public class InteractPlacedAction implements VanillaInteract.Action {
      @Override
      public boolean execute() {
         if (VanillaInteract.mc.player != null
            && VanillaInteract.mc.interactionManager != null
            && VanillaInteract.mc.world != null
            && VanillaInteract.lastPlacedPos != null) {
            if (!VanillaInteract.mc.world.getBlockState(VanillaInteract.lastPlacedPos).isOf(Blocks.RESPAWN_ANCHOR)) {
               return false;
            } else if (VanillaInteract.mc.crosshairTarget instanceof BlockHitResult bhr
               && bhr.getType() == Type.BLOCK
               && bhr.getBlockPos().equals(VanillaInteract.lastPlacedPos)) {
               VanillaInteract.mc.interactionManager.interactBlock(VanillaInteract.mc.player, Hand.MAIN_HAND, bhr);
               VanillaInteract.mc.player.swingHand(Hand.MAIN_HAND);
               return true;
            } else {
               Vec3d eyes = VanillaInteract.mc.player.getEyePos();
               Vec3d center = Vec3d.ofCenter(VanillaInteract.lastPlacedPos);
               Direction dir = Direction.getFacing((float)(eyes.x - center.x), 0.0F, (float)(eyes.z - center.z));
               Vec3d hitPos = center.add(Vec3d.of(dir.getVector()).multiply(0.4));
               BlockHitResult hit = new BlockHitResult(hitPos, dir, VanillaInteract.lastPlacedPos, false);
               VanillaInteract.mc.interactionManager.interactBlock(VanillaInteract.mc.player, Hand.MAIN_HAND, hit);
               VanillaInteract.mc.player.swingHand(Hand.MAIN_HAND);
               return true;
            }
         } else {
            return false;
         }
      }
   }

   public class PlaceAction implements VanillaInteract.Action {
      @Override
      public boolean execute() {
         if (VanillaInteract.mc.player != null && VanillaInteract.mc.interactionManager != null) {
            BlockHitResult hit = VanillaInteract.savedHit;
            if (hit == null && VanillaInteract.mc.crosshairTarget instanceof BlockHitResult bhr && bhr.getType() == Type.BLOCK) {
               hit = bhr;
            }

            if (hit == null) {
               return false;
            } else {
               VanillaInteract.lastPlacedPos = hit.getBlockPos().offset(hit.getSide());
               VanillaInteract.mc.interactionManager.interactBlock(VanillaInteract.mc.player, Hand.MAIN_HAND, hit);
               VanillaInteract.mc.player.swingHand(Hand.MAIN_HAND);
               return true;
            }
         } else {
            return false;
         }
      }
   }

   public class RunAction implements VanillaInteract.Action {
      private Runnable runnable;

      public RunAction(Runnable r) {
         this.runnable = r;
      }

      @Override
      public boolean execute() {
         this.runnable.run();
         return true;
      }
   }

   public class SaveHitAction implements VanillaInteract.Action {
      @Override
      public boolean execute() {
         if (VanillaInteract.mc.crosshairTarget instanceof BlockHitResult bhr && bhr.getType() == Type.BLOCK) {
            VanillaInteract.savedHit = bhr;
            return true;
         } else {
            return false;
         }
      }
   }

   public class SlotAction implements VanillaInteract.Action {
      private int slot;

      public SlotAction(int slot) {
         this.slot = slot;
      }

      @Override
      public boolean execute() {
         if (VanillaInteract.mc.player != null && this.slot >= 0 && this.slot <= 8) {
            VanillaInteract.mc.player.getInventory().setSelectedSlot(this.slot);
            return true;
         } else {
            return false;
         }
      }
   }

   public class SwapAction implements VanillaInteract.Action {
      private Item item;

      public SwapAction(Item item) {
         this.item = item;
      }

      @Override
      public boolean execute() {
         if (VanillaInteract.mc.player == null) {
            return false;
         } else {
            int slot = VanillaInteract.findHotbar(this.item);
            if (slot == -1) {
               return false;
            } else {
               VanillaInteract.mc.player.getInventory().setSelectedSlot(slot);
               return true;
            }
         }
      }
   }

   public class WaitAction implements VanillaInteract.Action {
      private int ticks;

      public WaitAction(int ticks) {
         this.ticks = ticks;
      }

      @Override
      public boolean execute() {
         return --this.ticks <= 0;
      }
   }
}

