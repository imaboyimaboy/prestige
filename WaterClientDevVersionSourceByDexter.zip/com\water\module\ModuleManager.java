package com.water.module;

import com.water.module.modules.StubModule;
import com.water.module.modules.client.ConfigShare;
import com.water.module.modules.client.Discordrpc;
import com.water.module.modules.client.Friends;
import com.water.module.modules.client.Hud;
import com.water.module.modules.client.SpotifyHud;
import com.water.module.modules.client.SpotifyLyric;
import com.water.module.modules.client.WaterPlus;
import com.water.module.modules.combat.AnchorMacro;
import com.water.module.modules.combat.AutoCrystalAC;
import com.water.module.modules.combat.AutoDoubleHand;
import com.water.module.modules.combat.AutoInvTotem;
import com.water.module.modules.combat.AutoTotem;
import com.water.module.modules.combat.DoubleAnchor;
import com.water.module.modules.combat.Hitbox;
import com.water.module.modules.combat.HoverTotem;
import com.water.module.modules.combat.ShieldBreaker;
import com.water.module.modules.combat.SingleAnchor;
import com.water.module.modules.combat.SpearSwap;
import com.water.module.modules.combat.Triggerbot;
import com.water.module.modules.donut.ActivityDebug;
import com.water.module.modules.donut.AntiTrap;
import com.water.module.modules.donut.AutoSell;
import com.water.module.modules.donut.BoneDropperBot;
import com.water.module.modules.donut.CollosionSensor;
import com.water.module.modules.donut.FakeRoles;
import com.water.module.modules.donut.FakeStats;
import com.water.module.modules.donut.FakeTierBridge;
import com.water.module.modules.donut.NeonChunkFinder;
import com.water.module.modules.donut.OGChunkFinder;
import com.water.module.modules.donut.OldDonutScoreboard;
import com.water.module.modules.donut.RtpHomeReset;
import com.water.module.modules.donut.SpawnerProtect;
import com.water.module.modules.donut.StaffDetector;
import com.water.module.modules.misc.AutoLog;
import com.water.module.modules.misc.AutoMine;
import com.water.module.modules.misc.AutoTPA;
import com.water.module.modules.misc.AutoTool;
import com.water.module.modules.misc.ChatMacro;
import com.water.module.modules.misc.ChunkToggle;
import com.water.module.modules.misc.CoordSnapper;
import com.water.module.modules.misc.FastPlace;
import com.water.module.modules.misc.Freelook;
import com.water.module.modules.misc.GambleRig;
import com.water.module.modules.misc.HomeSetter;
import com.water.module.modules.misc.NameProtect;
import com.water.module.modules.misc.NameTags;
import com.water.module.modules.misc.PearlESP;
import com.water.module.modules.misc.SchematicBuilder;
import com.water.module.modules.misc.SkinChanger;
import com.water.module.modules.misc.Sprint;
import com.water.module.modules.misc.SwingSpeed;
import com.water.module.modules.misc.TabDetector;
import com.water.module.modules.misc.TunnelBaseFinder;
import com.water.module.modules.misc.WeatherNotifier;
import com.water.module.modules.render.BlockESP;
import com.water.module.modules.render.BreakAnimations;
import com.water.module.modules.render.ChinaHat;
import com.water.module.modules.render.DevSpawnerVisuals;
import com.water.module.modules.render.ExtraESP;
import com.water.module.modules.render.Freecam;
import com.water.module.modules.render.FullBright;
import com.water.module.modules.render.FutureDebug;
import com.water.module.modules.render.HitAnimation;
import com.water.module.modules.render.HoleESP;
import com.water.module.modules.render.JumpCircles;
import com.water.module.modules.render.LightDebug;
import com.water.module.modules.render.NoRender;
import com.water.module.modules.render.PlayerESP;
import com.water.module.modules.render.RegionMap;
import com.water.module.modules.render.ScanOverlay;
import com.water.module.modules.render.SkyShaders;
import com.water.module.modules.render.SpawnerNotifier;
import com.water.module.modules.render.StorageESP;
import com.water.module.modules.render.TotemGlow;
import com.water.setting.BlocksSetting;
import com.water.setting.MobsSetting;
import com.water.setting.OptionMultiSelectSetting;
import com.water.setting.Setting;
import com.water.setting.ThresholdSetting;
import com.water.utils.RenderUtils;
import java.awt.Color;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EntityType;
import net.minecraft.network.packet.Packet;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import ru.waterclient.module.api.Manager;

public class ModuleManager {
   private static final String CONFIG_HEADER = "WATER_CONFIG_V2";
   private static final String MODULE_PREFIX = "MODULE";
   private static final String SETTING_PREFIX = "SETTING";
   private static final String HUDPOS_PREFIX = "HUDPOS";
   private static final String BLOCKCOLOR_PREFIX = "BLOCKCOLOR";
   private static final String STORAGECOLOR_PREFIX = "STORAGECOLOR";
   private static final String EXTRACOLOR_PREFIX = "EXTRACOLOR";
   private String activeConfigName = "default";
   public static final ModuleManager INSTANCE = new ModuleManager();
   private final List<Module> modules = new ArrayList<>();
   private boolean initialized = false;
   private boolean loadingConfig = false;
   private int settingChangeBatchDepth = 0;
   private boolean pendingSettingSave = false;

   public void init() {
      if (!this.initialized) {
         this.modules.add(new WaterPlus());
         this.modules.add(new Hud());
         this.modules.add(new SpotifyHud());
         this.modules.add(new SpotifyLyric());
         this.modules.add(new Friends());
         this.modules.add(new ConfigShare());
         this.modules.add(new StubModule("Elytra Swap", Category.COMBAT));
         this.modules.add(new AutoTotem());
         this.modules.add(new ShieldBreaker());
         this.modules.add(new AnchorMacro());
         this.modules.add(new StubModule("Mace Swap", Category.COMBAT));
         this.modules.add(new Triggerbot());
         this.modules.add(new HoverTotem());
         this.modules.add(new DoubleAnchor());
         this.modules.add(new SingleAnchor());
         this.modules.add(new AutoDoubleHand());
         this.modules.add(new AutoInvTotem());
         this.modules.add(new AutoCrystalAC());
         this.modules.add(new Hitbox());
         this.modules.add(new SpearSwap());
         this.modules.add(new Discordrpc());
         this.modules.add(new StorageESP());
         this.modules.add(new ExtraESP());
         this.modules.add(new DevSpawnerVisuals());
         this.modules.add(new Freecam());
         this.modules.add(new FullBright());
         this.modules.add(new PlayerESP());
         this.modules.add(new HoleESP());
         this.modules.add(new NoRender());
         this.modules.add(new JumpCircles());
         this.modules.add(new ChinaHat());
         this.modules.add(new HitAnimation());
         this.modules.add(new BreakAnimations());
         this.modules.add(new TotemGlow());
         this.modules.add(new LightDebug());
         this.modules.add(new SkyShaders());
         this.modules.add(new ChunkToggle());
         this.modules.add(new SpawnerNotifier());
         this.modules.add(new FutureDebug());
         this.modules.add(new CollosionSensor());
         this.modules.add(new AutoMine());
         this.modules.add(new PearlESP());
         this.modules.add(new OGChunkFinder());
         this.modules.add(new ScanOverlay());
         this.modules.add(new SwingSpeed());
         this.modules.add(new NameTags());
         this.modules.add(new RegionMap());
         this.modules.add(new AutoTool());
         this.modules.add(new SchematicBuilder());
         this.modules.add(new Sprint());
         this.modules.add(new NameProtect());
         this.modules.add(new Freelook());
         this.modules.add(new SkinChanger());
         this.modules.add(new HomeSetter());
         this.modules.add(new WeatherNotifier());
         this.modules.add(new CoordSnapper());
         this.modules.add(new FastPlace());
         this.modules.add(new TabDetector());
         this.modules.add(new AutoLog());
         this.modules.add(new AutoTPA());
         this.modules.add(new TunnelBaseFinder());
         this.modules.add(new ChatMacro());
         this.modules.add(new RtpHomeReset());
         this.modules.add(new StaffDetector());
         this.modules.add(new OldDonutScoreboard());
         this.modules.add(new GambleRig());
         this.modules.add(new NeonChunkFinder());
         this.modules.add(new FakeTierBridge());
         this.modules.add(new FakeRoles());
         this.modules.add(new AntiTrap());
         this.modules.add(new ActivityDebug());
         this.modules.add(new SpawnerProtect());
         this.modules.add(new FakeStats());
         this.modules.add(new BoneDropperBot());
         this.modules.add(new AutoSell());
         Manager.registerSupplementalImportedModules();

         try {
            Path active = MinecraftClient.getInstance().runDirectory.toPath().resolve("water_active_config.txt");
            if (Files.exists(active)) {
               this.activeConfigName = Files.readString(active, StandardCharsets.UTF_8).trim();
            }
         } catch (Exception var2) {
            System.err.println("[WaterConfig] active profile: " + var2.getMessage());
         }

         this.initialized = true;
         this.loadConfig();
         this.activateLoadedModules();
      }
   }

   public void onSettingChanged() {
      if (this.initialized && !this.loadingConfig) {
         if (this.settingChangeBatchDepth > 0) {
            this.pendingSettingSave = true;
         } else {
            this.saveConfig();
         }
      }
   }

   public void beginSettingChangeBatch() {
      this.settingChangeBatchDepth++;
   }

   public void endSettingChangeBatch() {
      if (this.settingChangeBatchDepth > 0) {
         this.settingChangeBatchDepth--;
      }

      if (this.settingChangeBatchDepth == 0 && this.pendingSettingSave) {
         this.pendingSettingSave = false;
         this.saveConfig();
      }
   }

   public synchronized void saveConfig() {
      if (this.initialized && !this.loadingConfig) {
         Path configFile = this.getConfigPath();
         Path tmpFile = configFile.resolveSibling(configFile.getFileName().toString() + ".tmp");

         try {
            Files.createDirectories(configFile.getParent());

            try (BufferedWriter writer = Files.newBufferedWriter(tmpFile, StandardCharsets.UTF_8)) {
               writer.write("WATER_CONFIG_V2");
               writer.newLine();

               for (Module module : this.modules) {
                  writer.write("MODULE");
                  writer.write(9);
                  writer.write(this.encode(module.getName()));
                  writer.write(9);
                  writer.write(Integer.toString(module.getBind()));
                  writer.write(9);
                  int activationKey = module instanceof ActivatableModule am ? am.getActivationKey() : 0;
                  writer.write(Integer.toString(activationKey));
                  writer.write(9);
                  writer.write(Boolean.toString(module.isEnabled()));
                  writer.newLine();

                  for (Setting<?> setting : module.getSettings()) {
                     String serialized = this.serializeSettingValue(setting);
                     if (serialized != null) {
                        writer.write("SETTING");
                        writer.write(9);
                        writer.write(this.encode(module.getName()));
                        writer.write(9);
                        writer.write(this.encode(setting.getName()));
                        writer.write(9);
                        writer.write(this.encode(serialized));
                        writer.newLine();
                     }
                  }
               }

               for (Hud.HudElement el : Hud.HudElement.values()) {
                  int[] pos = Hud.getElementPos(el);
                  writer.write("HUDPOS");
                  writer.write(9);
                  writer.write(el.name());
                  writer.write(9);
                  writer.write(Integer.toString(pos[0]));
                  writer.write(9);
                  writer.write(Integer.toString(pos[1]));
                  writer.newLine();
               }

               for (Module module : this.modules) {
                  if (module instanceof BlockESP esp) {
                     Map<Block, Color> bcolors = esp.getBlockColors();

                     for (Entry<Block, Color> entry : bcolors.entrySet()) {
                        Identifier id = Registries.BLOCK.getId(entry.getKey());
                        if (id != null) {
                           Color c = entry.getValue();
                           writer.write("BLOCKCOLOR");
                           writer.write(9);
                           writer.write(this.encode(id.toString()));
                           writer.write(9);
                           writer.write(c.getRed() + "," + c.getGreen() + "," + c.getBlue() + "," + c.getAlpha());
                           writer.newLine();
                        }
                     }
                  }
               }

               for (Module modulex : this.modules) {
                  if (modulex instanceof StorageESP esp) {
                     Map<Block, Color> scolors = esp.getCustomBlockColors();

                     for (Entry<Block, Color> entryx : scolors.entrySet()) {
                        Identifier id = Registries.BLOCK.getId(entryx.getKey());
                        if (id != null) {
                           Color c = entryx.getValue();
                           writer.write("STORAGECOLOR");
                           writer.write(9);
                           writer.write(this.encode(id.toString()));
                           writer.write(9);
                           writer.write(c.getRed() + "," + c.getGreen() + "," + c.getBlue() + "," + c.getAlpha());
                           writer.newLine();
                        }
                     }
                  }
               }

               for (Module modulexx : this.modules) {
                  if (modulexx instanceof ExtraESP esp) {
                     Map<Block, Color> ecolors = esp.getBlockColors();

                     for (Entry<Block, Color> entryxx : ecolors.entrySet()) {
                        Identifier id = Registries.BLOCK.getId(entryxx.getKey());
                        if (id != null) {
                           Color c = entryxx.getValue();
                           writer.write("EXTRACOLOR");
                           writer.write(9);
                           writer.write(this.encode(id.toString()));
                           writer.write(9);
                           writer.write(c.getRed() + "," + c.getGreen() + "," + c.getBlue() + "," + c.getAlpha());
                           writer.newLine();
                        }
                     }
                  }
               }
            }

            try {
               Files.move(tmpFile, configFile, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException var14) {
               Files.move(tmpFile, configFile, StandardCopyOption.REPLACE_EXISTING);
            }
         } catch (Throwable var16) {
            System.err.println("[WaterConfig] save failed: " + var16.getMessage());

            try {
               Files.deleteIfExists(tmpFile);
            } catch (IOException var12) {
            }
         }
      }
   }

   public void loadConfig() {
      Path configFile = this.getConfigPath();
      if (Files.exists(configFile)) {
         this.loadingConfig = true;

         try {
            for (String line : Files.readAllLines(configFile, StandardCharsets.UTF_8)) {
               if (line != null && !line.isBlank() && !"WATER_CONFIG_V2".equals(line)) {
                  if (line.startsWith("MODULE\t")) {
                     this.loadModuleLine(line);
                  } else if (line.startsWith("SETTING\t")) {
                     this.loadSettingLine(line);
                  } else if (line.startsWith("HUDPOS\t")) {
                     this.loadHudPosLine(line);
                  } else if (line.startsWith("BLOCKCOLOR\t")) {
                     this.loadBlockColorLine(line);
                  } else if (line.startsWith("STORAGECOLOR\t")) {
                     this.loadStorageColorLine(line);
                  } else if (line.startsWith("EXTRACOLOR\t")) {
                     this.loadExtraColorLine(line);
                  } else {
                     this.loadLegacyModuleLine(line);
                  }
               }
            }
         } catch (Throwable var8) {
            System.err.println("[WaterConfig] load failed: " + var8.getMessage());
         } finally {
            this.loadingConfig = false;
         }
      }
   }

   private void activateLoadedModules() {
      for (Module module : this.modules) {
         if (module != null && module.isEnabled()) {
            try {
               module.onEnable();
            } catch (Throwable var4) {
               this.disableCrashedModule(module);
            }
         }
      }
   }

   private void loadHudPosLine(String line) {
      try {
         String[] parts = line.split("\t");
         if (parts.length < 4) {
            return;
         }

         Hud.HudElement el = Hud.HudElement.valueOf(parts[1]);
         int x = Integer.parseInt(parts[2]);
         int y = Integer.parseInt(parts[3]);
         Hud.setElementPos(el, x, y);
      } catch (Exception var6) {
      }
   }

   private void loadBlockColorLine(String line) {
      try {
         String[] parts = line.split("\t");
         if (parts.length < 3) {
            return;
         }

         String blockId = this.decode(parts[1]);
         String[] rgba = parts[2].split(",");
         if (rgba.length < 4) {
            return;
         }

         int r = Integer.parseInt(rgba[0].trim());
         int g = Integer.parseInt(rgba[1].trim());
         int b = Integer.parseInt(rgba[2].trim());
         int a = Integer.parseInt(rgba[3].trim());
         Identifier identifier = Identifier.tryParse(blockId);
         if (identifier == null) {
            return;
         }

         Block block = (Block)Registries.BLOCK.get(identifier);
         if (block == null || block == Blocks.AIR) {
            return;
         }

         for (Module m : this.modules) {
            if (m instanceof BlockESP esp) {
               Map<Block, Color> map = esp.getBlockColors();
               map.put(block, new Color(r, g, b, a));
               esp.setBlockColors(map);
            }
         }
      } catch (Exception var15) {
      }
   }

   private void loadStorageColorLine(String line) {
      try {
         String[] parts = line.split("\t");
         if (parts.length < 3) {
            return;
         }

         String blockId = this.decode(parts[1]);
         String[] rgba = parts[2].split(",");
         if (rgba.length < 4) {
            return;
         }

         int r = Integer.parseInt(rgba[0].trim());
         int g = Integer.parseInt(rgba[1].trim());
         int b = Integer.parseInt(rgba[2].trim());
         int a = Integer.parseInt(rgba[3].trim());
         Identifier identifier = Identifier.tryParse(blockId);
         if (identifier == null) {
            return;
         }

         Block block = (Block)Registries.BLOCK.get(identifier);
         if (block == null || block == Blocks.AIR) {
            return;
         }

         for (Module m : this.modules) {
            if (m instanceof StorageESP esp) {
               esp.setBuiltinBlockColor(block, new Color(r, g, b, a));
            }
         }
      } catch (Exception var14) {
      }
   }

   private void loadExtraColorLine(String line) {
      try {
         String[] parts = line.split("\t");
         if (parts.length < 3) {
            return;
         }

         String blockId = this.decode(parts[1]);
         String[] rgba = parts[2].split(",");
         if (rgba.length < 4) {
            return;
         }

         int r = Integer.parseInt(rgba[0].trim());
         int g = Integer.parseInt(rgba[1].trim());
         int b = Integer.parseInt(rgba[2].trim());
         int a = Integer.parseInt(rgba[3].trim());
         Identifier identifier = Identifier.tryParse(blockId);
         if (identifier == null) {
            return;
         }

         Block block = (Block)Registries.BLOCK.get(identifier);
         if (block == null || block == Blocks.AIR) {
            return;
         }

         for (Module m : this.modules) {
            if (m instanceof ExtraESP esp) {
               Map<Block, Color> map = esp.getBlockColors();
               map.put(block, new Color(r, g, b, a));
               esp.setBlockColors(map);
            }
         }
      } catch (Exception var15) {
      }
   }

   public String getActiveConfigName() {
      return this.activeConfigName;
   }

   public void setActiveConfigName(String name) {
      this.activeConfigName = name != null && !name.isBlank() ? name.trim() : "default";

      try {
         Files.writeString(
            MinecraftClient.getInstance().runDirectory.toPath().resolve("water_active_config.txt"), this.activeConfigName, StandardCharsets.UTF_8
         );
      } catch (Exception var3) {
         System.err.println("[WaterConfig] active profile save: " + var3.getMessage());
      }
   }

   public boolean isLoadingConfig() {
      return this.loadingConfig;
   }

   public List<Module> getModules() {
      return this.modules;
   }

   public List<Module> getModulesInCategory(Category category) {
      List<Module> out = new ArrayList<>();

      for (Module m : this.modules) {
         try {
            if (m != null && m.getCategory() == category) {
               out.add(m);
            }
         } catch (Throwable var6) {
         }
      }

      return out;
   }

   public Module getModuleByName(String name) {
      if (name != null && !name.isBlank()) {
         if (name.equalsIgnoreCase("Smooth Builder")) {
            name = "Schematic Builder";
         }

         if (name.equalsIgnoreCase("Tuff Chunk Finder")) {
            name = "Tuff Chunk V2";
         }

         for (Module m : this.modules) {
            try {
               if (m != null) {
                  String moduleName = m.getName();
                  if (moduleName != null && moduleName.equalsIgnoreCase(name)) {
                     return m;
                  }
               }
            } catch (Throwable var5) {
            }
         }

         return null;
      } else {
         return null;
      }
   }

   public Path getCurrentConfigPath() {
      return this.getConfigPath();
   }

   public boolean applyConfigFromPath(Path source) {
      if (source != null && Files.isRegularFile(source)) {
         Path target = this.getConfigPath();

         try {
            Files.createDirectories(target.getParent());
            Files.copy(source, target, StandardCopyOption.REPLACE_EXISTING);
            this.loadConfig();
            return true;
         } catch (Throwable var4) {
            System.err.println("[WaterConfig] apply failed: " + var4.getMessage());
            return false;
         }
      } else {
         return false;
      }
   }

   public void onTick() {
      for (Module m : this.modules) {
         if (m.isEnabled()) {
            try {
               m.onTick();
            } catch (Throwable var4) {
               this.disableCrashedModule(m);
            }
         }
      }
   }

   public void onRender(MatrixStack matrices, float tickDelta) {
      for (Module m : this.modules) {
         if (m.isEnabled() && !(m instanceof ExtraESP) && !(m instanceof StorageESP)) {
            try {
               m.onRender(matrices, tickDelta);
            } catch (Throwable var9) {
               this.disableCrashedModule(m);
            } finally {
               RenderUtils.restoreWorldDepthState();
            }
         }
      }

      this.renderModuleByType(ExtraESP.class, matrices, tickDelta);
      this.renderModuleByType(StorageESP.class, matrices, tickDelta);
      RenderUtils.restoreWorldDepthState();
   }

   private void renderModuleByType(Class<? extends Module> type, MatrixStack matrices, float tickDelta) {
      for (Module m : this.modules) {
         if (m.isEnabled() && type.isInstance(m)) {
            try {
               m.onRender(matrices, tickDelta);
            } catch (Throwable var10) {
               this.disableCrashedModule(m);
            } finally {
               RenderUtils.restoreWorldDepthState();
            }
         }
      }
   }

   private void disableCrashedModule(Module module) {
      try {
         module.applyEnabled(false);
         module.onDisable();
         this.saveConfig();
      } catch (Throwable var3) {
      }
   }

   public void onPacketReceive(Packet<?> packet) {
      for (Module m : this.modules) {
         if (m.isEnabled()) {
            m.onPacketReceive(packet);
         }
      }
   }

   public boolean onPacketSend(Packet<?> packet) {
      boolean cancel = false;

      for (Module m : this.modules) {
         if (m.isEnabled()) {
            try {
               cancel |= m.onPacketSend(packet);
            } catch (Exception var6) {
            }
         }
      }

      return cancel;
   }

   private Path getConfigPath() {
      String name = this.activeConfigName != null && !this.activeConfigName.isBlank() ? this.activeConfigName : "default";
      String fileName = name.equals("default") ? "water_config.txt" : "water_config_null.txt";
      return MinecraftClient.getInstance().runDirectory.toPath().resolve(fileName);
   }

   private void loadModuleLine(String line) {
      String[] parts = line.split("\t", 5);
      if (parts.length >= 5) {
         Module module = this.getModuleByName(this.decode(parts[1]));
         if (module != null) {
            try {
               module.applyBind(Integer.parseInt(parts[2]));
               if (module instanceof ActivatableModule am) {
                  am.applyActivationKey(Integer.parseInt(parts[3]));
               }

               module.applyEnabled(Boolean.parseBoolean(parts[4]));
            } catch (Exception var5) {
            }
         }
      }
   }

   private void loadSettingLine(String line) {
      String[] parts = line.split("\t", 4);
      if (parts.length >= 4) {
         Module module = this.getModuleByName(this.decode(parts[1]));
         if (module != null) {
            Setting<?> setting = this.getSettingByName(module, this.decode(parts[2]));
            if (setting != null) {
               this.applySettingValue(setting, this.decode(parts[3]));
            }
         }
      }
   }

   private void loadLegacyModuleLine(String line) {
      String[] parts = line.split(":", 4);
      if (parts.length >= 2) {
         Module module = this.getModuleByName(parts[0]);
         if (module != null) {
            try {
               if (parts.length >= 2) {
                  module.applyBind(Integer.parseInt(parts[1]));
               }

               if (parts.length >= 3 && module instanceof ActivatableModule am) {
                  am.applyActivationKey(Integer.parseInt(parts[2]));
               }

               if (parts.length >= 4) {
                  module.applyEnabled(Boolean.parseBoolean(parts[3]));
               }
            } catch (Exception var5) {
            }
         }
      }
   }

   private Setting<?> getSettingByName(Module module, String settingName) {
      for (Setting<?> s : module.getSettings()) {
         if (s.matchesName(settingName)) {
            return s;
         }
      }

      return null;
   }

   private String serializeSettingValue(Setting<?> setting) {
      Object value = setting.getValue();
      if (setting instanceof BlocksSetting bs) {
         return this.serializeBlocks(bs);
      } else if (setting instanceof MobsSetting ms) {
         return this.serializeMobs(ms);
      } else if (setting instanceof OptionMultiSelectSetting oms) {
         return this.serializeStringSet(oms.getValue());
      } else if (setting instanceof ThresholdSetting ts) {
         return ts.serialize();
      } else if (value instanceof Boolean v) {
         return Boolean.toString(v);
      } else if (value instanceof Float v) {
         return Float.toString(v);
      } else if (value instanceof Integer v) {
         return Integer.toString(v);
      } else if (value instanceof Double v) {
         return Double.toString(v);
      } else if (value instanceof String v) {
         return v;
      } else {
         return value instanceof Color v ? v.getRed() + "," + v.getGreen() + "," + v.getBlue() + "," + v.getAlpha() : null;
      }
   }

   private void applySettingValue(Setting<?> setting, String serialized) {
      Object value = setting.getValue();

      try {
         if (setting instanceof BlocksSetting bs) {
            bs.setValue(this.deserializeBlocks(serialized));
            return;
         }

         if (setting instanceof MobsSetting ms) {
            ms.setValue(this.deserializeMobs(serialized));
            return;
         }

         if (setting instanceof OptionMultiSelectSetting oms) {
            oms.setValue(this.deserializeStringSet(serialized));
            return;
         }

         if (setting instanceof ThresholdSetting ts) {
            ts.deserialize(serialized);
            return;
         }

         if (value instanceof Boolean) {
            ((Setting<Boolean>)setting).setValue(Boolean.parseBoolean(serialized));
            return;
         }

         if (value instanceof Float) {
            ((Setting<Float>)setting).setValue(Float.parseFloat(serialized));
            return;
         }

         if (value instanceof Integer) {
            ((Setting<Integer>)setting).setValue(Math.round(Float.parseFloat(serialized)));
            return;
         }

         if (value instanceof Double) {
            ((Setting<Double>)setting).setValue(Double.parseDouble(serialized));
            return;
         }

         if (value instanceof String) {
            ((Setting<String>)setting).setValue(serialized);
            return;
         }

         if (value instanceof Color) {
            Color parsed = this.parseColorValue(serialized, (Color)value);
            if (parsed != null) {
               ((Setting<Color>)setting).setValue(parsed);
            }
         }
      } catch (Exception var5) {
      }
   }

   private Color parseColorValue(String serialized, Color fallback) {
      if (serialized == null) {
         return fallback;
      } else {
         String raw = serialized.trim();
         if (raw.isEmpty()) {
            return fallback;
         } else {
            try {
               if (raw.startsWith("#")) {
                  String hex = raw.substring(1).trim();
                  long value = Long.parseLong(hex, 16);
                  if (hex.length() == 6) {
                     return new Color((int)(value >> 16 & 255L), (int)(value >> 8 & 255L), (int)(value & 255L), fallback == null ? 255 : fallback.getAlpha());
                  }

                  if (hex.length() == 8) {
                     return new Color((int)(value >> 16 & 255L), (int)(value >> 8 & 255L), (int)(value & 255L), (int)(value >> 24 & 255L));
                  }
               }

               if (raw.startsWith("java.awt.Color")) {
                  raw = raw.replace("java.awt.Color", "")
                     .replace("[", "")
                     .replace("]", "")
                     .replace("r=", "")
                     .replace("g=", "")
                     .replace("b=", "")
                     .replace("a=", "");
               }

               String[] p = raw.split(",");
               if (p.length >= 3) {
                  int r = this.clampColorComponent(Integer.parseInt(p[0].trim()));
                  int g = this.clampColorComponent(Integer.parseInt(p[1].trim()));
                  int b = this.clampColorComponent(Integer.parseInt(p[2].trim()));
                  int a = p.length >= 4 ? this.clampColorComponent(Integer.parseInt(p[3].trim())) : (fallback == null ? 255 : fallback.getAlpha());
                  return new Color(r, g, b, a);
               }
            } catch (Exception var9) {
            }

            return fallback;
         }
      }
   }

   private int clampColorComponent(int value) {
      return Math.max(0, Math.min(255, value));
   }

   private String serializeBlocks(BlocksSetting setting) {
      StringBuilder sb = new StringBuilder();

      for (Block b : setting.getSelectedBlocks()) {
         Identifier id = Registries.BLOCK.getId(b);
         if (id != null) {
            if (!sb.isEmpty()) {
               sb.append(',');
            }

            sb.append(id);
         }
      }

      return sb.toString();
   }

   private Set<Block> deserializeBlocks(String serialized) {
      LinkedHashSet<Block> blocks = new LinkedHashSet<>();
      if (serialized != null && !serialized.isBlank()) {
         for (String rawId : serialized.split(",")) {
            String blockId = rawId.trim();
            if (!blockId.isEmpty()) {
               Identifier identifier = Identifier.tryParse(blockId);
               if (identifier != null) {
                  Block block = (Block)Registries.BLOCK.get(identifier);
                  if (block != null) {
                     blocks.add(block);
                  }
               }
            }
         }

         return blocks;
      } else {
         return blocks;
      }
   }

   private String serializeMobs(MobsSetting setting) {
      StringBuilder sb = new StringBuilder();

      for (EntityType<?> t : setting.getSelectedMobs()) {
         Identifier id = Registries.ENTITY_TYPE.getId(t);
         if (id != null) {
            if (!sb.isEmpty()) {
               sb.append(',');
            }

            sb.append(id);
         }
      }

      return sb.toString();
   }

   private Set<EntityType<?>> deserializeMobs(String serialized) {
      LinkedHashSet<EntityType<?>> mobs = new LinkedHashSet<>();
      if (serialized != null && !serialized.isBlank()) {
         for (String rawId : serialized.split(",")) {
            String idStr = rawId.trim();
            if (!idStr.isEmpty()) {
               Identifier identifier = Identifier.tryParse(idStr);
               if (identifier != null && Registries.ENTITY_TYPE.containsId(identifier)) {
                  mobs.add((EntityType<?>)Registries.ENTITY_TYPE.get(identifier));
               }
            }
         }

         return mobs;
      } else {
         return mobs;
      }
   }

   private String serializeStringSet(Set<String> values) {
      StringBuilder sb = new StringBuilder();

      for (String v : values) {
         if (v != null && !v.isEmpty()) {
            if (!sb.isEmpty()) {
               sb.append(',');
            }

            sb.append(v);
         }
      }

      return sb.toString();
   }

   private Set<String> deserializeStringSet(String serialized) {
      LinkedHashSet<String> values = new LinkedHashSet<>();
      if (serialized != null && !serialized.isBlank()) {
         for (String v : serialized.split(",")) {
            String t = v.trim();
            if (!t.isEmpty()) {
               values.add(t);
            }
         }

         return values;
      } else {
         return values;
      }
   }

   private String encode(String value) {
      return Base64.getEncoder().encodeToString(value.getBytes(StandardCharsets.UTF_8));
   }

   private String decode(String value) {
      if (value != null && !value.isEmpty()) {
         try {
            return new String(Base64.getDecoder().decode(value), StandardCharsets.UTF_8);
         } catch (IllegalArgumentException var3) {
            return value;
         }
      } else {
         return "";
      }
   }

   static String _ce5a3af53db() {
      return "L";
   }
}

