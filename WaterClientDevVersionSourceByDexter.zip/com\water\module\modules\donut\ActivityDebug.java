package com.water.module.modules.donut;

import com.water.gui.notification.NotificationManager;
import com.water.module.Category;
import com.water.module.Module;
import com.water.setting.Setting;
import com.water.utils.RenderUtils;
import java.awt.Color;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ChunkDeltaUpdateS2CPacket;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;

public final class ActivityDebug extends Module {
   private static final long NOTIFY_COOLDOWN_MS = 1250L;
   private static final double MARKER_SURFACE_Y = 57.0;
   private static final double MARKER_SURFACE_THICKNESS = 0.05;
   private final Setting<Float> yLevel = new Setting<>("y-level", 16.0F, -64.0F, 320.0F);
   private final Setting<Boolean> notification = new Setting<>("Notification", false);
   private final Set<ChunkPos> susChunks = Collections.newSetFromMap(new ConcurrentHashMap<>());
   private final Map<Long, Long> lastNotifiedAt = new ConcurrentHashMap<>();
   private static final Color YELLOW = new Color(255, 220, 0, 180);
   private static final Color YELLOW_OUTLINE = new Color(255, 220, 0, 255);
   private final Map<Class<?>, List<Field>> doubleFields = new ConcurrentHashMap<>();
   private final Map<Class<?>, List<Field>> nestedFields = new ConcurrentHashMap<>();
   private final Map<Class<?>, List<Field>> blockPosFields = new ConcurrentHashMap<>();
   private final Map<Class<?>, List<Field>> vec3Fields = new ConcurrentHashMap<>();
   private final ThreadLocal<Set<Integer>> exploredObjects = ThreadLocal.withInitial(() -> Collections.newSetFromMap(new ConcurrentHashMap<>()));

   public ActivityDebug() {
      super("ActivityDebug", Category.DONUT);
      this.addSetting(this.yLevel);
      this.addSetting(this.notification);
   }

   @Override
   public void onDisable() {
      this.susChunks.clear();
      this.lastNotifiedAt.clear();
      this.doubleFields.clear();
      this.nestedFields.clear();
      this.blockPosFields.clear();
      this.vec3Fields.clear();
   }

   @Override
   public void onPacketReceive(Packet<?> packet) {
      if (packet instanceof ChunkDeltaUpdateS2CPacket sectionUpdate) {
         sectionUpdate.visitUpdates((posx, state) -> this.checkAndAdd(posx.getX(), posx.getY(), posx.getZ()));
      } else if (packet instanceof BlockUpdateS2CPacket blockUpdate) {
         BlockPos pos = blockUpdate.getPos();
         this.checkAndAdd(pos.getX(), pos.getY(), pos.getZ());
      } else {
         this.exploredObjects.get().clear();
         this.analyzeObject(packet, 0);
      }
   }

   private void analyzeObject(Object obj, int depth) {
      if (obj != null && depth <= 3) {
         int hash = System.identityHashCode(obj);
         if (this.exploredObjects.get().add(hash)) {
            Class<?> clazz = obj.getClass();
            this.blockPosFields.computeIfAbsent(clazz, c -> this.getFieldsOfType((Class<?>)c, BlockPos.class));
            this.vec3Fields.computeIfAbsent(clazz, c -> this.getFieldsOfType((Class<?>)c, Vec3d.class));
            this.doubleFields.computeIfAbsent(clazz, c -> this.getFieldsOfType((Class<?>)c, double.class));
            this.nestedFields
               .computeIfAbsent(
                  clazz,
                  c -> {
                     List<Field> list = new ArrayList<>();

                     while (c != null && c != Object.class) {
                        for (Field fx : c.getDeclaredFields()) {
                           if (!Modifier.isStatic(fx.getModifiers())
                              && !fx.getType().isPrimitive()
                              && !fx.getType().getName().startsWith("java.")
                              && !fx.getType().isEnum()) {
                              fx.setAccessible(true);
                              list.add(fx);
                           }
                        }

                        c = c.getSuperclass();
                     }

                     return list;
                  }
               );

            for (Field f : this.blockPosFields.get(clazz)) {
               try {
                  BlockPos bp = (BlockPos)f.get(obj);
                  if (bp != null) {
                     this.checkAndAdd(bp.getX(), bp.getY(), bp.getZ());
                  }
               } catch (Exception var15) {
               }
            }

            for (Field f : this.vec3Fields.get(clazz)) {
               try {
                  Vec3d v = (Vec3d)f.get(obj);
                  if (v != null) {
                     this.checkAndAdd(v.x, v.y, v.z);
                  }
               } catch (Exception var14) {
               }
            }

            List<Field> dFields = this.doubleFields.get(clazz);
            if (dFields.size() >= 3) {
               try {
                  double x = dFields.get(0).getDouble(obj);
                  double y = dFields.get(1).getDouble(obj);
                  double z = dFields.get(2).getDouble(obj);
                  if (Math.abs(x) < 3.E7 && Math.abs(z) < 3.E7 && y > -2048.0 && y < 2048.0) {
                     this.checkAndAdd(x, y, z);
                  }
               } catch (Exception var13) {
               }
            }

            for (Field f : this.nestedFields.get(clazz)) {
               try {
                  Object nestedObj = f.get(obj);
                  if (nestedObj != null) {
                     this.analyzeObject(nestedObj, depth + 1);
                  }
               } catch (Exception var12) {
               }
            }
         }
      }
   }

   private List<Field> getFieldsOfType(Class<?> clazz, Class<?> type) {
      List<Field> list = new ArrayList<>();

      while (clazz != null && clazz != Object.class) {
         for (Field f : clazz.getDeclaredFields()) {
            if (!Modifier.isStatic(f.getModifiers()) && f.getType() == type) {
               f.setAccessible(true);
               list.add(f);
            }
         }

         clazz = clazz.getSuperclass();
      }

      return list;
   }

   private void checkAndAdd(double x, double y, double z) {
      if (mc.player == null || !(mc.player.getY() < 0.0)) {
         if (y <= this.yLevel.getValue().floatValue()) {
            ChunkPos chunkPos = new ChunkPos((int)Math.floor(x) >> 4, (int)Math.floor(z) >> 4);
            if (this.susChunks.add(chunkPos)) {
               this.maybeNotify(chunkPos, y);
            }
         }
      }
   }

   private void maybeNotify(ChunkPos chunkPos, double y) {
      if (this.notification.getValue() && mc.player != null && mc.world != null) {
         long chunkKey = chunkPos.toLong();
         long now = System.currentTimeMillis();
         long last = this.lastNotifiedAt.getOrDefault(chunkKey, 0L);
         if (now - last >= 1250L) {
            this.lastNotifiedAt.put(chunkKey, now);
            NotificationManager.INSTANCE
               .push(
                  "Activity detected",
                  "Chunk " + chunkPos.x + ", " + chunkPos.z + "  Y " + (int)Math.floor(y),
                  new ItemStack(Items.COMPASS),
                  YELLOW_OUTLINE.getRGB()
               );
            mc.world
               .playSound(
                  mc.player, mc.player.getX(), mc.player.getY(), mc.player.getZ(), SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.MASTER, 0.6F, 1.05F
               );
         }
      }
   }

   @Override
   public void onRender(MatrixStack matrices, float tickDelta) {
      if (mc.world != null) {
         Camera camera = RenderUtils.getCamera();
         if (camera != null) {
            Vec3d camPos = RenderUtils.getCameraPos(camera);
            double markerBaseY = Math.max((double)mc.world.getBottomY(), Math.min(57.0, (double)mc.world.getTopYInclusive()));
            RenderUtils.WorldBatch batch = RenderUtils.beginWorldBatch(matrices);

            for (ChunkPos cp : this.susChunks) {
               if (RenderUtils.isWorldBoxVisible(cp.getStartX(), 57.0, cp.getStartZ(), cp.getEndX(), 57.05, cp.getEndZ())) {
                  double x1 = cp.getStartX() - camPos.x;
                  double z1 = cp.getStartZ() - camPos.z;
                  double y1 = markerBaseY - camPos.y;
                  double x2 = x1 + 16.0;
                  double y2 = y1 + 0.05;
                  double z2 = z1 + 16.0;
                  batch.renderFilledBox(x1, y1, z1, x2, y2, z2, YELLOW);
               }
            }

            batch.flush();
         }
      }
   }
}

