package rtx.kimiko.api.mods.geckolib.renderer;

import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import rtx.kimiko.api.mods.geckolib.animatable.GeoItem;
import rtx.kimiko.api.mods.geckolib.model.GeoModel;
import rtx.kimiko.api.mods.geckolib.renderer.base.GeoRenderState;
import rtx.kimiko.api.mods.geckolib.renderer.base.GeoRenderer;
import rtx.kimiko.api.mods.geckolib.renderer.base.RenderPassInfo;

public class GeoItemRenderer<T extends Item & GeoItem> implements GeoRenderer<T, GeoItemRenderer.RenderData, GeoRenderState> {
   protected GeoModel<T> model;

   public GeoItemRenderer(GeoModel<T> model) {
      this.model = model;
   }

   @Override
   public GeoModel<T> getGeoModel() {
      return this.model;
   }

   public GeoRenderState createRenderState(T animatable, GeoItemRenderer.RenderData data) {
      return new GeoRenderState.Impl();
   }

   @Override
   public void fireCompileRenderLayersEvent() {
   }

   public void fireCompileRenderStateEvent(T animatable, GeoItemRenderer.RenderData data, GeoRenderState renderState, float partialTick) {
   }

   @Override
   public boolean firePreRenderEvent(RenderPassInfo<GeoRenderState> renderPassInfo, OrderedRenderCommandQueue commandQueue) {
      return true;
   }

   public final static class RenderData {
      private ItemStack itemStack;

      public RenderData(ItemStack itemStack) {
         this.itemStack = itemStack;
      }

      public ItemStack itemStack() {
         return this.itemStack;
      }
   }

   public final static class StackForRender {
      private ItemStack stack;

      public StackForRender(ItemStack stack) {
         this.stack = stack;
      }

      public ItemStack stack() {
         return this.stack;
      }
   }
}

