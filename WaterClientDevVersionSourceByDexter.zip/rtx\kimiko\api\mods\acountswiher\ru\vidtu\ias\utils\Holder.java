package rtx.kimiko.api.mods.acountswiher.ru.vidtu.ias.utils;

import java.util.Objects;

public final class Holder<T> {
   private T value;

   public Holder() {
      this.value = null;
   }

   public Holder(T t) {
      this.value = t;
   }

   @Override
   public boolean equals(Object object) {
      if (this == object) {
         return true;
      } else {
         return !(object instanceof Holder holder) ? false : Objects.equals(this.value, holder.value);
      }
   }

   @Override
   public String toString() {
      return "Holder{value=" + this.value + "}";
   }

   @Override
   public int hashCode() {
      return Objects.hashCode(this.value);
   }

   public T get() {
      return this.value;
   }

   public void set(T t) {
      this.value = t;
   }
}

