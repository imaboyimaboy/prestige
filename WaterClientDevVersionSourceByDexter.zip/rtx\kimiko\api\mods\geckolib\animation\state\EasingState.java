package rtx.kimiko.api.mods.geckolib.animation.state;

import rtx.kimiko.api.mods.geckolib.animation.object.EasingType;
import rtx.kimiko.api.mods.geckolib.loading.math.MathValue;

public final class EasingState {
   private EasingType easingType;
   private MathValue[] easingArgs;
   private double delta;
   private double fromValue;
   private double toValue;

   public EasingState(EasingType easingType, MathValue[] easingArgs, double delta, double fromValue, double toValue) {
      this.easingType = easingType;
      this.easingArgs = easingArgs;
      this.delta = delta;
      this.fromValue = fromValue;
      this.toValue = toValue;
   }

   public EasingType easingType() {
      return this.easingType;
   }

   public MathValue[] easingArgs() {
      return this.easingArgs;
   }

   public double delta() {
      return this.delta;
   }

   public double fromValue() {
      return this.fromValue;
   }

   public double toValue() {
      return this.toValue;
   }
}

