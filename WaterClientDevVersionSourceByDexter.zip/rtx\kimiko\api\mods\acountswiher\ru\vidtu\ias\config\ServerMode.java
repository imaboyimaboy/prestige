package rtx.kimiko.api.mods.acountswiher.ru.vidtu.ias.config;

public enum ServerMode {
   ALWAYS("ias.config.server.always"),
   AVAILABLE("ias.config.server.available"),
   NEVER("ias.config.server.never");

   private String key;

   private ServerMode(String key) {
      this.key = key;
   }

   @Override
   public String toString() {
      return this.key;
   }

   private static ServerMode[] $values() {
      return new ServerMode[]{ALWAYS, AVAILABLE, NEVER};
   }
}

