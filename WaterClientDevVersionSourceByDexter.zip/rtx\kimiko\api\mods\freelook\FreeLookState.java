package rtx.kimiko.api.mods.freelook;

public final class FreeLookState {
   public static volatile boolean active = false;
   public static volatile float maxHeadYaw = 360.0F;

   private FreeLookState() {
   }
}

