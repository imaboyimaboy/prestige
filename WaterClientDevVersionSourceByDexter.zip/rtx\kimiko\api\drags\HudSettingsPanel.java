package rtx.kimiko.api.drags;

import java.util.List;
import rtx.kimiko.api.ui.settings.Setting;

public final class HudSettingsPanel {
   public static float height(int count) {
      return 24.0F + count * 18.0F;
   }

   public static boolean click(float mouseX, float mouseY, float x, float y, float width, List<Setting> settings) {
      return false;
   }
}

