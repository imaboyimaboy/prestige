package rtx.kimiko.api.drags.components;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gui.DrawContext;
import rtx.kimiko.api.drags.DragSystem;
import rtx.kimiko.api.drags.Draggable;
import rtx.kimiko.api.modules.ModuleManager;
import rtx.kimiko.api.modules.impl.Interface.HPFocus;
import rtx.kimiko.utils.animations.Easings;
import rtx.kimiko.utils.animations.SmoothAnimation;
import rtx.kimiko.utils.color.ColorUtil;
import rtx.kimiko.utils.network.Network;
import rtx.kimiko.utils.render.others.RectUtil;
import rtx.kimiko.utils.render.post.hpfocus.HPFocusRenderer;
import rtx.kimiko.utils.render.render2d.Render2D;
import rtx.kimiko.utils.render.render2d.Render2DCoordinateSpace;

public final class HPFocusComp extends Draggable {
   private static final float BASE_HEIGHT = 46.0F;
   private static final float RADIUS = 5.0F;
   private static final float BORDER = 2.0F;
   private static final float DEFAULT_ASPECT = 3.8461537F;
   private final SmoothAnimation visibility = new SmoothAnimation();

   public HPFocusComp() {
      super("hpfocus", 342.0F, 40.0F);
      this.visibility.set(0.0);
   }

   private static HPFocus module() {
      return ModuleManager.get().get(HPFocus.class);
   }

   @Override
   public float width() {
      return sizeFor(module())[0];
   }

   @Override
   public float height() {
      return sizeFor(module())[1];
   }

   private static float clamp01(float f) {
      return Math.max(0.0F, Math.min(1.0F, f));
   }

   @Override
   public boolean isInteractive() {
      HPFocus hPFocus = module();
      return hPFocus != null && hPFocus.isEnabled();
   }

   @Override
   protected void render(DrawContext drawContext) {
      HPFocus hPFocus = module();
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      boolean bl2 = hPFocus != null && hPFocus.isEnabled();
      boolean bl3 = DragSystem.get().isDragModeActive();
      boolean bl = minecraftClient.options != null && minecraftClient.options.hudHidden;
      boolean bl5 = !bl2 || bl || minecraftClient.player == null
         ? false
         : (bl3 ? true : Network.getResolvedHealth(minecraftClient.player, true) <= hPFocus.hpThresholdHp());
      this.visibility.run(bl5 ? 1.0 : 0.0, bl5 ? 0.18 : 0.14, Easings.CUBIC_OUT, true);
      this.visibility.update();
      float f = this.visibility.get();
      if (!(f <= 0.01F)) {
         HPFocusRenderer.requestCapture();
         float[] fArray = sizeFor(hPFocus);
         float f2 = fArray[0];
         float f3 = fArray[1];
         float f4 = this.getX();
         float f5 = this.getY();
         Render2D.beginFrame(drawContext);
         RectUtil.drawClientRect(f4, f5, f2, f3, 5.0F, f);
         float f6 = f2 - 4.0F;
         float f7 = f3 - 4.0F;
         Framebuffer framebuffer;
         if (f6 > 1.0F
            && f7 > 1.0F
            && HPFocusRenderer.hasCapture()
            && (framebuffer = minecraftClient.getFramebuffer()) != null
            && framebuffer.textureWidth > 0
            && framebuffer.textureHeight > 0) {
            float f8 = framebuffer.textureWidth;
            float f9 = framebuffer.textureHeight;
            float f10 = Render2DCoordinateSpace.guiScale();
            float f11 = hPFocus.captureWidthGui() * f10 * 0.5F;
            float f12 = clamp01((f8 * 0.5F - f11) / f8);
            float f13 = clamp01((f8 * 0.5F + f11) / f8);
            float f14 = clamp01(hPFocus.captureHeightGui() * f10 / f9);
            Render2D.imageUv("kimiko:hpfocus_scene", f4 + 2.0F, f5 + 2.0F, f6, f7, Math.max(0.0F, 3.0F), 1.0F, f12, f14, f13, 0.0F, ColorUtil.multAlpha(-1, f));
         }

         Render2D.flush();
      }
   }

   private static float[] sizeFor(HPFocus hPFocus) {
      float f = hPFocus != null ? hPFocus.scale() : 1.3F;
      float f2 = hPFocus != null ? hPFocus.captureWidthGui() : 200.0F;
      float f3 = hPFocus != null ? hPFocus.captureHeightGui() : 52.0F;
      float f4 = f3 > 0.5F ? f2 / f3 : 3.8461537F;
      float f5 = 46.0F * f;
      return new float[]{f5 * f4, f5};
   }
}

