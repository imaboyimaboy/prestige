package com.water.module.modules.donut;

import com.water.module.Category;
import com.water.module.Module;
import com.water.setting.Setting;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.text.Text;

public final class RtpHomeReset extends Module {
   private final Setting<Float> homeSlot = new Setting<>("Home Slot", 1.0F, 1.0F, 5.0F);
   private final Setting<Boolean> chatFeedback = new Setting<>("Chat Feedback", true);
   private final Setting<Integer> rtpWait = new Setting<>("Cooldown", 3500, 500, 10000);
   private boolean triggered = false;
   private long cooldownUntil = 0L;

   public RtpHomeReset() {
      super("Home Method", Category.DONUT);
      this.addSetting(this.homeSlot);
      this.addSetting(this.chatFeedback);
      this.addSetting(this.rtpWait);
   }

   @Override
   public void onDisable() {
      this.triggered = false;
      this.cooldownUntil = 0L;
   }

   @Override
   public void onTick() {
      if (mc.world != null && mc.player != null) {
         if (!this.triggered) {
            if (System.currentTimeMillis() >= this.cooldownUntil) {
               double y = mc.player.getY();
               if (!(y >= -3.0)) {
                  this.triggered = true;
                  int slot = Math.round(this.homeSlot.getValue());
                  if (this.chatFeedback.getValue() && mc.inGameHud != null) {
                     mc.inGameHud.getChatHud().addMessage(Text.literal(""));
                  }

                  new Thread(() -> {
                     try {
                        mc.execute(() -> this.sendCommand("/delhome " + slot));
                        Thread.sleep(800L);
                        mc.execute(() -> {
                           this.sendCommand("/sethome " + slot);
                           if (this.chatFeedback.getValue() && mc.inGameHud != null) {
                              mc.inGameHud.getChatHud().addMessage(Text.literal(""));
                           }
                        });
                        Thread.sleep(300L);
                        mc.execute(() -> {
                           this.sendCommand("/home 3");
                           if (this.chatFeedback.getValue() && mc.inGameHud != null) {
                              mc.inGameHud.getChatHud().addMessage(Text.literal(""));
                           }
                        });
                        Thread.sleep(this.rtpWait.getValue().intValue());
                        mc.execute(() -> {
                           this.sendCommand("/home " + slot);
                           if (this.chatFeedback.getValue() && mc.inGameHud != null) {
                              mc.inGameHud.getChatHud().addMessage(Text.literal(""));
                           }

                           this.cooldownUntil = System.currentTimeMillis() + 15000L;
                           this.triggered = false;
                        });
                     } catch (InterruptedException var3x) {
                        this.triggered = false;
                     }
                  }, "RtpReset-Thread").start();
               }
            }
         }
      }
   }

   private void sendCommand(String command) {
      if (mc != null && mc.player != null) {
         ClientPlayNetworkHandler nh = null;

         try {
            nh = mc.player.networkHandler;
         } catch (Throwable var8) {
         }

         if (nh == null) {
            try {
               nh = mc.getNetworkHandler();
            } catch (Throwable var7) {
            }
         }

         if (nh != null) {
            String cmdNoSlash = command.startsWith("/") ? command.substring(1) : command;

            try {
               nh.sendChatCommand(cmdNoSlash);
            } catch (Throwable var6) {
               try {
                  nh.sendChatMessage(command);
               } catch (Throwable var5) {
               }
            }
         }
      }
   }
}

