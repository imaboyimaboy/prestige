package rtx.kimiko.api.mods.geckolib.animation;

import io.netty.buffer.ByteBuf;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import rtx.kimiko.api.mods.geckolib.animation.object.LoopType;

public final class RawAnimation {
   public static final PacketCodec<ByteBuf, RawAnimation> STREAM_CODEC = PacketCodec.tuple(
      RawAnimation.Stage.STREAM_CODEC.collect(PacketCodecs.toList()), rawAnimation -> rawAnimation.animationList, RawAnimation::new
   );
   private List<RawAnimation.Stage> animationList;

   private RawAnimation() {
      this(new ObjectArrayList());
   }

   private RawAnimation(List<RawAnimation.Stage> list) {
      this.animationList = list;
   }

   @Override
   public boolean equals(Object object) {
      if (this == object) {
         return true;
      } else if (!(object instanceof RawAnimation rawAnimation)) {
         return false;
      } else {
         return this.animationList.size() != rawAnimation.animationList.size() ? false : this.hashCode() == object.hashCode();
      }
   }

   @Override
   public String toString() {
      return "RawAnimation{" + this.animationList.stream().map(RawAnimation.Stage::toString).collect(Collectors.joining(" -> ")) + "}";
   }

   @Override
   public int hashCode() {
      return Objects.hash(this.animationList);
   }

   public static RawAnimation copyOf(RawAnimation rawAnimation) {
      RawAnimation rawAnimation2 = begin();
      rawAnimation2.animationList.addAll(rawAnimation.animationList);
      return rawAnimation2;
   }

   public static RawAnimation begin() {
      return new RawAnimation();
   }

   public RawAnimation thenWait(int n) {
      this.animationList.add(new Stage("internal.wait", LoopType.PLAY_ONCE, n));
      return this;
   }

   public RawAnimation thenLoop(String string) {
      return this.then(string, LoopType.LOOP);
   }

   public RawAnimation thenPlay(String string) {
      return this.then(string, LoopType.DEFAULT);
   }

   public RawAnimation thenPlayAndHold(String string) {
      return this.then(string, LoopType.HOLD_ON_LAST_FRAME);
   }

   public RawAnimation rawAnimationOf(String string, int n) {
      for (int i = 0; i < n; i++) {
         this.then(string, i == n - 1 ? LoopType.DEFAULT : LoopType.PLAY_ONCE);
      }

      return this;
   }

   public List<RawAnimation.Stage> getAnimationStages() {
      return this.animationList;
   }

   public int getStageCount() {
      return this.animationList.size();
   }

   public RawAnimation then(String string, LoopType loopType) {
      this.animationList.add(new Stage(string, loopType));
      return this;
   }

   public final static class Stage {
      private String animationName;
      private LoopType loopType;
      private int waitTicks;
      public static final PacketCodec<ByteBuf, RawAnimation.Stage> STREAM_CODEC = PacketCodec.tuple(
         PacketCodecs.STRING,
         RawAnimation.Stage::animationName,
         PacketCodecs.STRING.xmap(LoopType::fromString, LoopType::getId),
         RawAnimation.Stage::loopType,
         PacketCodecs.VAR_INT,
         RawAnimation.Stage::waitTicks,
         RawAnimation.Stage::new
      );
      public static final String WAIT = "internal.wait";

      public Stage(String string, LoopType loopType) {
         this(string, loopType, 0);
      }

      public Stage(String animationName, LoopType loopType, int waitTicks) {
         this.animationName = animationName;
         this.loopType = loopType;
         this.waitTicks = waitTicks;
      }

      @Override
      public boolean equals(Object object) {
         if (this == object) {
            return true;
         } else {
            return object != null && this.getClass() == object.getClass() ? this.hashCode() == object.hashCode() : false;
         }
      }

      @Override
      public String toString() {
         return this.animationName;
      }

      @Override
      public int hashCode() {
         return Objects.hash(this.animationName, this.loopType);
      }

      public String animationName() {
         return this.animationName;
      }

      public LoopType loopType() {
         return this.loopType;
      }

      public int waitTicks() {
         return this.waitTicks;
      }
   }
}

