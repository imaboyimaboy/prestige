package com.water.mixin;

import com.water.module.modules.render.DevSpawnerVisuals;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({ItemEntity.class})
public class ItemEntityMixin {
   @Inject(
      method = {"getStack"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void water$devSpawnerDroppedStack(CallbackInfoReturnable<ItemStack> cir) {
      ItemStack original = (ItemStack)cir.getReturnValue();
      ItemStack spoofed = DevSpawnerVisuals.spoofedStack(original);
      if (spoofed != original) {
         cir.setReturnValue(spoofed);
      }
   }
}

