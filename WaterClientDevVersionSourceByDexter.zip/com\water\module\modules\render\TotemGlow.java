package com.water.module.modules.render;

import com.water.mixin.ItemRenderStateAccessor;
import com.water.mixin.LayerRenderStateAccessor;
import com.water.module.Category;
import com.water.module.Module;
import com.water.setting.Setting;
import java.awt.Color;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.render.item.ItemRenderState.LayerRenderState;
import net.minecraft.client.render.model.BakedQuad;
import net.minecraft.client.render.model.json.Transformation;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.joml.Vector3fc;
import ru.waterclient.util.render.world.WorldRenderLayers;

public final class TotemGlow extends Module {
   public static TotemGlow INSTANCE;
   private final Setting<Color> color = new Setting<>("Color", new Color(255, 70, 255, 255));
   private final Setting<Integer> alpha = new Setting<>("Alpha", 230, 0, 255);
   private final Setting<Float> size = new Setting<>("Size", 1.07F, 1.01F, 1.18F);
   private final Setting<Boolean> pulse = new Setting<>("Pulse", true);

   public TotemGlow() {
      super("Totem Glow", Category.RENDER);
      this.addSetting(this.color);
      this.addSetting(this.alpha);
      this.addSetting(this.size);
      this.addSetting(this.pulse);
      INSTANCE = this;
   }

   public static void render(
      LivingEntity entity, ItemStack stack, ItemDisplayContext renderMode, MatrixStack matrices, OrderedRenderCommandQueue queue, int light
   ) {
      TotemGlow self = INSTANCE;
      MinecraftClient mc = MinecraftClient.getInstance();
      if (self != null
         && self.isEnabled()
         && entity != null
         && stack != null
         && stack.isOf(Items.TOTEM_OF_UNDYING)
         && renderMode != null
         && renderMode.isFirstPerson()
         && matrices != null
         && queue != null
         && mc != null) {
         Color c = self.color.getValue();
         int baseAlpha = self.alpha.getValue();
         float pulseMul = 1.0F;
         if (self.pulse.getValue()) {
            pulseMul = 0.82F + 0.18F * (float)Math.sin(System.currentTimeMillis() / 170.0);
         }

         int r = c.getRed();
         int g = c.getGreen();
         int b = c.getBlue();
         int a = Math.max(0, Math.min(255, Math.round(baseAlpha * pulseMul)));
         float base = self.size.getValue();
         ItemRenderState state = new ItemRenderState();
         mc.getItemModelManager().updateForLivingEntity(state, stack, renderMode, entity);
         renderModelGlowPass(state, renderMode, matrices, queue, base + 0.075F, r, g, b, Math.round(a * 0.22F));
         renderModelGlowPass(state, renderMode, matrices, queue, base + 0.04F, r, g, b, Math.round(a * 0.42F));
         renderModelGlowPass(state, renderMode, matrices, queue, base, r, g, b, Math.round(a * 0.88F));
      }
   }

   private static void renderModelGlowPass(
      ItemRenderState state, ItemDisplayContext renderMode, MatrixStack matrices, OrderedRenderCommandQueue queue, float scale, int r, int g, int b, int a
   ) {
      if (a > 0) {
         ItemRenderStateAccessor stateAccess = (ItemRenderStateAccessor)state;
         LayerRenderState[] layers = stateAccess.water$getLayers();
         int layerCount = stateAccess.water$getLayerCount();

         for (int i = 0; i < layerCount && i < layers.length; i++) {
            LayerRenderState layer = layers[i];
            LayerRenderStateAccessor layerAccess = (LayerRenderStateAccessor)layer;
            List<BakedQuad> quads = layer.getQuads();
            if (quads != null && !quads.isEmpty()) {
               matrices.push();
               Transformation transform = layerAccess.water$getTransform();
               transform.apply(renderMode.isLeftHand(), matrices.peek());
               matrices.translate(0.5F, 0.5F, 0.5F);
               matrices.scale(scale, scale, scale);
               matrices.translate(-0.5F, -0.5F, -0.5F);
               matrices.translate(0.0F, 0.0F, -0.004F);
               queue.submitCustom(
                  matrices, WorldRenderLayers.POSITION_COLOR_QUADS_NO_DEPTH_BLEND(), (entry, buffer) -> drawGlowQuads(entry, buffer, quads, r, g, b, a)
               );
               matrices.pop();
            }
         }
      }
   }

   private static void drawGlowQuads(Entry entry, VertexConsumer buffer, List<BakedQuad> quads, int r, int g, int b, int a) {
      for (BakedQuad quad : quads) {
         vertex(buffer, entry, quad.getPosition(0), r, g, b, a);
         vertex(buffer, entry, quad.getPosition(1), r, g, b, a);
         vertex(buffer, entry, quad.getPosition(2), r, g, b, a);
         vertex(buffer, entry, quad.getPosition(3), r, g, b, a);
      }
   }

   private static void vertex(VertexConsumer buffer, Entry entry, Vector3fc pos, int r, int g, int b, int a) {
      buffer.vertex(entry.getPositionMatrix(), pos.x(), pos.y(), pos.z()).color(r, g, b, a);
   }
}

