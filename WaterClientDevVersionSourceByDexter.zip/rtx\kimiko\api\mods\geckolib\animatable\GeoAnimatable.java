package rtx.kimiko.api.mods.geckolib.animatable;

import rtx.kimiko.api.mods.geckolib.animatable.instance.AnimatableInstanceCache;
import rtx.kimiko.api.mods.geckolib.animatable.manager.AnimatableManager;

public interface GeoAnimatable {
   AnimatableInstanceCache getAnimatableInstanceCache();

   default AnimatableInstanceCache animatableCacheOverride() {
      return null;
   }

   void registerControllers(AnimatableManager.ControllerRegistrar var1);
}

