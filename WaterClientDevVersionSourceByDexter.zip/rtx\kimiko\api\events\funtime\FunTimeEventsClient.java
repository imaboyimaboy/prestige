package rtx.kimiko.api.events.funtime;

import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

public final class FunTimeEventsClient {
   public static final FunTimeEventsClient INSTANCE = new FunTimeEventsClient();
   private static final int POLL_SECONDS = 12;
   private final AtomicReference<FunTimeEventsSnapshot> events = new AtomicReference<>(FunTimeEventsSnapshot.offline("Нет связи с API HolyWorld"));
   private final AtomicReference<FunTimeMinesSnapshot> mines = new AtomicReference<>(FunTimeMinesSnapshot.offline("Нет связи с API HolyWorld"));
   private ScheduledExecutorService executor;

   private FunTimeEventsClient() {
   }

   public synchronized void shutdown() {
      if (this.executor != null) {
         this.executor.shutdownNow();
         this.executor = null;
      }
   }

   public synchronized void start() {
      if (this.executor == null) {
         this.executor = Executors.newSingleThreadScheduledExecutor(runnable -> {
            Thread thread = new Thread(runnable, "kimiko-holyworld-events");
            thread.setDaemon(true);
            return thread;
         });
         this.executor.scheduleWithFixedDelay(this::refresh, 0L, 12L, TimeUnit.SECONDS);
      }
   }

   public FunTimeEventsSnapshot snapshot() {
      return this.events.get();
   }

   private void refresh() {
      try {
         long l = System.currentTimeMillis();
         List<FunTimeEvent> list = FunTimeApi.INSTANCE.events();
         list.sort(Comparator.<FunTimeEvent>comparingInt(funTimeEvent -> -rarityWeight(funTimeEvent.rarity())).thenComparingInt(FunTimeEvent::anarchy));
         this.events.set(new FunTimeEventsSnapshot(List.copyOf(list), List.of(), l, true, ""));
         List<FunTimeMine> list2 = FunTimeApi.INSTANCE.mines().stream().filter(funTimeMine -> isNotableRarity(funTimeMine.rarity())).toList();
         this.mines.set(new FunTimeMinesSnapshot(list2, l, true, ""));
      } catch (FunTimeApiException var5) {
         this.setOffline(var5.getMessage());
      } catch (Exception var6) {
         this.setOffline(var6.getClass().getSimpleName());
      }
   }

   public FunTimeMinesSnapshot minesSnapshot() {
      return this.mines.get();
   }

   private static boolean isNotableRarity(String string) {
      if (string == null) {
         return false;
      } else {
         String string2 = string.toLowerCase(Locale.ROOT);
         return string2.contains("легендарн") || string2.contains("мифическ") || string2.contains("эпическ") || string2.contains("редк");
      }
   }

   public long remainingSeconds(FunTimeMine funTimeMine) {
      return funTimeMine.refillAtMs() <= 0L ? 0L : Math.max(0L, (funTimeMine.refillAtMs() - System.currentTimeMillis()) / 1000L);
   }

   public int remainingSeconds(FunTimeEvent funTimeEvent) {
      return 0;
   }

   private static int rarityWeight(String string) {
      if (string == null) {
         return 0;
      } else {
         String var1 = string.toUpperCase(Locale.ROOT);
         switch (var1.hashCode()) {
            case -1986416409:
               if (var1.equals("NORMAL")) {
                  return 1;
               }
               break;
            case 2134789:
               if (var1.equals("EPIC")) {
                  return 3;
               }
               break;
            case 2507938:
               if (var1.equals("RARE")) {
                  return 2;
               }
               break;
            case 705031963:
               if (var1.equals("LEGENDARY")) {
                  return 4;
               }
               break;
            case 909442021:
               if (var1.equals("MYTHICAL")) {
                  return 5;
               }
         }

         return 0;
      }
   }

   private void setOffline(String string) {
      FunTimeEventsSnapshot funTimeEventsSnapshot = this.events.get();
      this.events
         .set(new FunTimeEventsSnapshot(funTimeEventsSnapshot.current(), funTimeEventsSnapshot.nearest(), funTimeEventsSnapshot.generatedAt(), false, string));
      FunTimeMinesSnapshot funTimeMinesSnapshot = this.mines.get();
      this.mines.set(new FunTimeMinesSnapshot(funTimeMinesSnapshot.mines(), funTimeMinesSnapshot.generatedAt(), false, string));
   }
}

