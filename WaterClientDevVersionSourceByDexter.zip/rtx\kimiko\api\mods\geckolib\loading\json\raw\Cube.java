package rtx.kimiko.api.mods.geckolib.loading.json.raw;

import com.google.gson.JsonDeserializer;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.mojang.datafixers.util.Either;
import net.minecraft.util.JsonHelper;
import rtx.kimiko.api.mods.geckolib.util.JsonUtil;

public final class Cube {
   private Double inflate;
   private Boolean mirror;
   private double[] origin;
   private double[] pivot;
   private double[] rotation;
   private double[] size;
   private UVUnion uVUnion;

   public Cube(Double inflate, Boolean mirror, double[] origin, double[] pivot, double[] rotation, double[] size, UVUnion uv) {
      this.inflate = inflate;
      this.mirror = mirror;
      this.origin = origin;
      this.pivot = pivot;
      this.rotation = rotation;
      this.size = size;
      this.uVUnion = uv;
   }

   public static JsonDeserializer<Cube> deserializer() throws JsonParseException {
      return (jsonElement, type, jsonDeserializationContext) -> {
         JsonObject jsonObject = jsonElement.getAsJsonObject();
         Double d = JsonUtil.getOptionalDouble(jsonObject, "inflate");
         Boolean bl = JsonUtil.getOptionalBoolean(jsonObject, "mirror");
         double[] dArray = JsonUtil.jsonArrayToDoubleArray(JsonHelper.getArray(jsonObject, "origin", null));
         double[] dArray2 = JsonUtil.jsonArrayToDoubleArray(JsonHelper.getArray(jsonObject, "pivot", null));
         double[] dArray3 = JsonUtil.jsonArrayToDoubleArray(JsonHelper.getArray(jsonObject, "rotation", null));
         double[] dArray4 = JsonUtil.jsonArrayToDoubleArray(JsonHelper.getArray(jsonObject, "size", null));
         UVUnion uVUnion = (UVUnion)JsonHelper.deserialize(
            jsonObject, "uv", new UVUnion(Either.left(new double[]{0.0, 0.0})), jsonDeserializationContext, UVUnion.class
         );
         return new Cube(d, bl, dArray, dArray2, dArray3, dArray4, uVUnion);
      };
   }

   public Double inflate() {
      return this.inflate;
   }

   public Boolean mirror() {
      return this.mirror;
   }

   public double[] origin() {
      return this.origin;
   }

   public double[] pivot() {
      return this.pivot;
   }

   public double[] rotation() {
      return this.rotation;
   }

   public double[] size() {
      return this.size;
   }

   public UVUnion getUVUnion() {
      return this.uVUnion;
   }
}

