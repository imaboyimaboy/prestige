package com.water.module.modules.misc;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.water.module.Category;
import com.water.module.Module;
import com.water.setting.Setting;
import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpClient.Redirect;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.time.Duration;
import java.util.Base64;
import java.util.Locale;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.client.texture.PlayerSkinTextureDownloader;
import net.minecraft.entity.player.PlayerSkinType;
import net.minecraft.entity.player.SkinTextures;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.AssetInfo.TextureAsset;

public final class SkinChanger extends Module {
   private static final Duration HTTP_TIMEOUT = Duration.ofSeconds(10L);
   private static final long INPUT_DEBOUNCE_MS = 600L;
   private static final String PRIMARY_LOOKUP_URL = "https://api.mojang.com/users/profiles/minecraft/";
   private static final String FALLBACK_LOOKUP_URL = "https://api.minecraftservices.com/minecraft/profile/lookup/name/";
   private static final String PROFILE_LOOKUP_URL = "https://sessionserver.mojang.com/session/minecraft/profile/";
   private static final HttpClient HTTP_CLIENT = HttpClient.newBuilder().connectTimeout(HTTP_TIMEOUT).followRedirects(Redirect.NORMAL).build();
   private static volatile SkinTextures overrideSkin;
   private static volatile TextureAsset overrideTextureAsset;
   private final Setting<String> playerName = new Setting<>("Player Name", "");
   private final AtomicInteger requestGeneration = new AtomicInteger();
   private PlayerSkinTextureDownloader skinDownloader;
   private String lastObservedName = "";
   private String lastRequestedName = "";
   private long lastNameEditAt;

   public SkinChanger() {
      super("SkinChanger", Category.MISC);
      this.addSetting(this.playerName);
   }

   @Override
   public void onEnable() {
      super.onEnable();
      this.lastObservedName = normalizeName(this.playerName.getValue());
      this.lastRequestedName = "";
      this.lastNameEditAt = System.currentTimeMillis();
      if (this.lastObservedName.isEmpty()) {
         clearOverride();
      } else {
         this.requestSkin(this.lastObservedName);
      }
   }

   @Override
   public void onDisable() {
      super.onDisable();
      this.requestGeneration.incrementAndGet();
      this.lastRequestedName = "";
      clearOverride();
   }

   @Override
   public void onTick() {
      String currentName = normalizeName(this.playerName.getValue());
      if (!Objects.equals(currentName, this.lastObservedName)) {
         this.lastObservedName = currentName;
         this.lastNameEditAt = System.currentTimeMillis();
      } else if (!currentName.isEmpty()) {
         if (!Objects.equals(currentName, this.lastRequestedName) && System.currentTimeMillis() - this.lastNameEditAt >= 600L) {
            this.requestSkin(currentName);
         }
      } else {
         if (overrideSkin != null || overrideTextureAsset != null) {
            this.lastRequestedName = "";
            clearOverride();
         }
      }
   }

   public static SkinTextures getOverrideSkin(UUID playerUuid) {
      if (overrideSkin != null && playerUuid != null) {
         UUID localUuid = getLocalPlayerUuid();
         return localUuid != null && localUuid.equals(playerUuid) ? overrideSkin : null;
      } else {
         return null;
      }
   }

   private void requestSkin(String name) {
      this.lastRequestedName = name;
      int generation = this.requestGeneration.incrementAndGet();
      CompletableFuture.<SkinChanger.SkinLookup>supplyAsync(() -> this.lookupSkin(name), Util.getIoWorkerExecutor().named("skinchanger-lookup"))
         .thenCompose(
            result -> this.getSkinDownloader()
               .downloadAndRegisterTexture(this.createTextureId(result), this.getCacheFile(result.uuid()), result.textureUrl(), true)
               .thenApply(textureAsset -> new ResolvedSkin(result, textureAsset))
         )
         .whenComplete((resolvedSkin, throwable) -> mc.execute(() -> {
            if (generation == this.requestGeneration.get() && this.isEnabled()) {
               if (throwable != null) {
                  this.sendFeedback("Failed to apply skin for " + name + ": " + getRootMessage(throwable));
               } else {
                  applyOverride(resolvedSkin.textureAsset(), resolvedSkin.lookup().skinType());
                  this.sendFeedback("Applied skin from " + resolvedSkin.lookup().playerName() + ".");
               }
            } else {
               if (resolvedSkin != null) {
                  destroyTexture(resolvedSkin.textureAsset());
               }
            }
         }));
   }

   private PlayerSkinTextureDownloader getSkinDownloader() {
      if (this.skinDownloader == null) {
         this.skinDownloader = new PlayerSkinTextureDownloader(mc.getNetworkProxy(), mc.getTextureManager(), mc::execute);
      }

      return this.skinDownloader;
   }

   private SkinChanger.SkinLookup lookupSkin(String playerName) {
      try {
         UUID uuid = this.lookupUuid(playerName);
         SkinChanger.TexturePayload payload = this.lookupTexturePayload(uuid);
         return new SkinLookup(playerName, uuid, payload.textureUrl(), payload.skinType());
      } catch (InterruptedException var4) {
         Thread.currentThread().interrupt();
         throw new IllegalStateException("Request interrupted", var4);
      } catch (IOException var5) {
         throw new IllegalStateException(var5.getMessage(), var5);
      }
   }

   private UUID lookupUuid(String playerName) throws IOException, InterruptedException {
      JsonObject lookup = this.requestJson("https://api.mojang.com/users/profiles/minecraft/" + this.encodeName(playerName));
      if (lookup == null) {
         lookup = this.requestJson("https://api.minecraftservices.com/minecraft/profile/lookup/name/" + this.encodeName(playerName));
      }

      if (lookup != null && lookup.has("id")) {
         return parseUuid(lookup.get("id").getAsString());
      } else {
         throw new IOException("Player not found");
      }
   }

   private SkinChanger.TexturePayload lookupTexturePayload(UUID uuid) throws IOException, InterruptedException {
      JsonObject profile = this.requestJson("https://sessionserver.mojang.com/session/minecraft/profile/" + uuid.toString().replace("-", ""));
      if (profile != null && profile.has("properties")) {
         for (JsonElement element : profile.getAsJsonArray("properties")) {
            if (element.isJsonObject()) {
               JsonObject property = element.getAsJsonObject();
               if ("textures".equalsIgnoreCase(getString(property, "name")) && property.has("value")) {
                  String decoded = new String(Base64.getDecoder().decode(property.get("value").getAsString()), StandardCharsets.UTF_8);
                  JsonObject textureRoot = JsonParser.parseString(decoded).getAsJsonObject();
                  JsonObject textures = textureRoot.getAsJsonObject("textures");
                  JsonObject skin = textures != null ? textures.getAsJsonObject("SKIN") : null;
                  if (skin != null && skin.has("url")) {
                     String modelName = null;
                     JsonObject metadata = skin.getAsJsonObject("metadata");
                     if (metadata != null && metadata.has("model")) {
                        modelName = metadata.get("model").getAsString();
                     }

                     PlayerSkinType skinType = "slim".equalsIgnoreCase(modelName) ? PlayerSkinType.SLIM : PlayerSkinType.WIDE;
                     new TexturePayload(skin.get("url").getAsString(), skinType);
                  }
                  break;
               }
            }
         }

         throw new IOException("No usable skin texture found");
      } else {
         throw new IOException("Skin profile not found");
      }
   }

   private JsonObject requestJson(String url) throws IOException, InterruptedException {
      HttpRequest request = HttpRequest.newBuilder(URI.create(url))
         .timeout(HTTP_TIMEOUT)
         .header("Accept", "application/json")
         .header("User-Agent", "Water-SkinChanger")
         .GET()
         .build();
      HttpResponse<String> response = HTTP_CLIENT.send(request, BodyHandlers.ofString());
      int status = response.statusCode();
      if (status == 404 || status == 204) {
         return null;
      } else if (status >= 200 && status < 300) {
         String body = response.body();
         return body != null && !body.isBlank() ? JsonParser.parseString(body).getAsJsonObject() : null;
      } else {
         throw new IOException("HTTP " + status);
      }
   }

   private static synchronized void applyOverride(TextureAsset textureAsset, PlayerSkinType skinType) {
      destroyTexture(overrideTextureAsset);
      overrideTextureAsset = textureAsset;
      overrideSkin = SkinTextures.create(textureAsset, null, null, skinType);
   }

   private static synchronized void clearOverride() {
      destroyTexture(overrideTextureAsset);
      overrideTextureAsset = null;
      overrideSkin = null;
   }

   private static void destroyTexture(TextureAsset textureAsset) {
      if (textureAsset != null && mc != null) {
         try {
            mc.getTextureManager().destroyTexture(textureAsset.texturePath());
         } catch (Throwable var3) {
         }

         try {
            if (!textureAsset.id().equals(textureAsset.texturePath())) {
               mc.getTextureManager().destroyTexture(textureAsset.id());
            }
         } catch (Throwable var2) {
         }
      }
   }

   private void sendFeedback(String message) {
      if (mc != null && mc.inGameHud != null) {
         try {
            mc.inGameHud.getChatHud().addMessage(Text.literal("[SkinChanger] null"));
         } catch (Throwable var3) {
         }
      }
   }

   private Identifier createTextureId(SkinChanger.SkinLookup lookup) {
      String safeName = lookup.playerName().toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_]", "");
      if (safeName.isEmpty()) {
         safeName = "player";
      }

      return Identifier.of("water", "skins/" + safeName + "_" + lookup.uuid().toString().replace("-", ""));
   }

   private Path getCacheFile(UUID uuid) {
      return mc.runDirectory.toPath().resolve("water-cache").resolve("skins").resolve(uuid.toString().replace("-", "") + ".png");
   }

   private String encodeName(String playerName) {
      return URLEncoder.encode(playerName, StandardCharsets.UTF_8);
   }

   private static UUID parseUuid(String rawUuid) {
      String normalized = rawUuid.replace("-", "");
      return UUID.fromString(normalized.replaceFirst("(\\p{XDigit}{8})(\\p{XDigit}{4})(\\p{XDigit}{4})(\\p{XDigit}{4})(\\p{XDigit}+)", "$1-$2-$3-$4-$5"));
   }

   private static String normalizeName(String value) {
      return value == null ? "" : value.trim();
   }

   private static String getString(JsonObject object, String key) {
      return object.has(key) ? object.get(key).getAsString() : "";
   }

   private static String getRootMessage(Throwable throwable) {
      Throwable current = throwable;

      while (current.getCause() != null) {
         current = current.getCause();
      }

      String message = current.getMessage();
      return message != null && !message.isBlank() ? message : current.getClass().getSimpleName();
   }

   private static UUID getLocalPlayerUuid() {
      if (mc == null) {
         return null;
      } else if (mc.player != null) {
         return mc.player.getUuid();
      } else {
         return mc.getSession() != null ? mc.getSession().getUuidOrNull() : null;
      }
   }

   final class ResolvedSkin {
      private SkinChanger.SkinLookup lookup;
      private TextureAsset textureAsset;

      private ResolvedSkin(SkinChanger.SkinLookup lookup, TextureAsset textureAsset) {
         this.lookup = lookup;
         this.textureAsset = textureAsset;
      }

      public SkinChanger.SkinLookup lookup() {
         return this.lookup;
      }

      public TextureAsset textureAsset() {
         return this.textureAsset;
      }
   }

   final class SkinLookup {
      private String playerName;
      private UUID uuid;
      private String textureUrl;
      private PlayerSkinType skinType;

      private SkinLookup(String playerName, UUID uuid, String textureUrl, PlayerSkinType skinType) {
         this.playerName = playerName;
         this.uuid = uuid;
         this.textureUrl = textureUrl;
         this.skinType = skinType;
      }

      public String playerName() {
         return this.playerName;
      }

      public UUID uuid() {
         return this.uuid;
      }

      public String textureUrl() {
         return this.textureUrl;
      }

      public PlayerSkinType skinType() {
         return this.skinType;
      }
   }

   final class TexturePayload {
      private String textureUrl;
      private PlayerSkinType skinType;

      private TexturePayload(String textureUrl, PlayerSkinType skinType) {
         this.textureUrl = textureUrl;
         this.skinType = skinType;
      }

      public String textureUrl() {
         return this.textureUrl;
      }

      public PlayerSkinType skinType() {
         return this.skinType;
      }
   }
}

