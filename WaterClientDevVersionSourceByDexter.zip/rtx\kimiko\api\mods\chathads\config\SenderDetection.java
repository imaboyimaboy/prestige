package rtx.kimiko.api.mods.chathads.config;

public enum SenderDetection {
   UUID_ONLY,
   UUID_AND_HEURISTIC,
   HEURISTIC_ONLY;

   private static SenderDetection[] $values() {
      return new SenderDetection[]{UUID_ONLY, UUID_AND_HEURISTIC, HEURISTIC_ONLY};
   }
}

