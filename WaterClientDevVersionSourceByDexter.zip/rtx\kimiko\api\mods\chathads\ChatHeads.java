package rtx.kimiko.api.mods.chathads;

import com.mojang.datafixers.util.Pair;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.Map.Entry;
import java.util.function.BiConsumer;
import java.util.regex.Pattern;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.ChatHudLine;
import net.minecraft.client.gui.hud.ChatHud.Backend;
import net.minecraft.client.gui.hud.ChatHudLine.Visible;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.message.SignedMessage;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.text.TextContent;
import net.minecraft.text.TranslatableTextContent;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.ColorHelper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.joml.Matrix3x2fStack;
import rtx.kimiko.api.mods.chathads.config.ChatHeadsConfig;
import rtx.kimiko.api.mods.chathads.config.ChatHeadsConfigDefaults;
import rtx.kimiko.api.mods.chathads.config.RenderPosition;
import rtx.kimiko.api.mods.chathads.config.SenderDetection;
import rtx.kimiko.api.mods.chathads.mixininterface.HeadRenderable;
import rtx.kimiko.api.mods.chathads.mixininterface.Ownable;

public class ChatHeads {
   public static final String MOD_ID = "chat_heads";
   public static final Pattern FORMAT_REGEX = Pattern.compile("§.");
   public static final Logger LOGGER = LogManager.getLogger("chat_heads");
   public static final Identifier DISABLE_RESOURCE = Identifier.of("chat_heads", "disable");
   public static ChatHeadsConfig CONFIG = new ChatHeadsConfigDefaults();
   public static HeadData lastSenderData = HeadData.EMPTY;
   public static boolean refreshing;
   public static HeadData lineData = HeadData.EMPTY;
   public static HeadData refreshingLineData = HeadData.EMPTY;
   public static volatile boolean serverSentUuid = false;
   public static volatile boolean serverDisabledChatHeads = false;
   public static final Set<Identifier> blendedHeadTextures = new HashSet<>();
   public static DrawContext guiGraphics = null;
   public static Backend chatGraphicsAccess = null;
   public static boolean customHeadRendering;

   public static void init() {
   }

   public static PlayerListEntry getOwner(SignedMessage signedMessage) {
      return ((Ownable)(Object)signedMessage).chatheads_getOwner();
   }

   public static void setOwner(SignedMessage signedMessage, PlayerListEntry playerListEntry) {
      ((Ownable)(Object)signedMessage).chatheads_setOwner(playerListEntry);
   }

   public static boolean offsetChat(HeadData headData) {
      return CONFIG.renderPosition() != RenderPosition.BEFORE_LINE
         ? false
         : headData != HeadData.EMPTY || CONFIG.offsetNonPlayerText() && !serverDisabledChatHeads;
   }

   public static int headWidth() {
      return headWidth(CONFIG.drawShadow());
   }

   public static int headWidth(boolean bl) {
      return 10 + (bl ? 1 : 0);
   }

   public static HeadData getHeadData(ChatHudLine chatHudLine) {
      return ((HeadRenderable)(Object)chatHudLine).chatheads_getHeadData();
   }

   public static HeadData getHeadData(Visible visible) {
      return ((HeadRenderable)(Object)visible).chatheads_getHeadData();
   }

   public static void setHeadData(ChatHudLine chatHudLine, HeadData headData) {
      ((HeadRenderable)(Object)chatHudLine).chatheads_setHeadData(headData);
   }

   public static int getChatOffset(HeadData headData) {
      return offsetChat(headData) ? headWidth() : 0;
   }

   public static int getTextWidthDifference(HeadData headData) {
      if (CONFIG.renderPosition() != RenderPosition.BEFORE_LINE) {
         return 0;
      } else {
         return headData == HeadData.EMPTY && !offsetChat(headData) ? 0 : headWidth();
      }
   }

   public static int getTextWidthDifference(Visible visible) {
      return getTextWidthDifference(getHeadData(visible));
   }

   public static HeadData scanForPlayerName(String string, ChatHeads.PlayerInfoCache playerInfoCache) {
      Map<Integer, List<String>> map = playerInfoCache.createNamesByFirstCharacterMap();
      boolean bl = false;
      int[] nArray = string.codePoints().toArray();

      for (int i = 0; i < nArray.length; i++) {
         int n = nArray[i];
         if (!bl || !isWordCharacter(n)) {
            for (String string2 : map.getOrDefault(n, List.of())) {
               int[] nArray2 = string2.codePoints().toArray();
               if (i + nArray2.length - 1 < nArray.length) {
                  boolean bl3 = isWordCharacter(nArray2[nArray2.length - 1]);
                  boolean bl2 = i + nArray2.length < nArray.length && isWordCharacter(nArray[i + nArray2.length]);
                  if ((!bl3 || !bl2) && containsSubsequenceAt(nArray, i, nArray2)) {
                     return new HeadData(playerInfoCache.get(string2), i);
                  }
               }
            }

            bl = isWordCharacter(n);
         }
      }

      return HeadData.EMPTY;
   }

   private static boolean isWordCharacter(int n) {
      return Character.isLetterOrDigit(n) || n == 95 || Character.getNumericValue(n) != -1;
   }

   public static void autoDetectAlias(Text text) {
      String string = text.getString();
      int n = string.indexOf(" ");
      if (n != -1) {
         String string2 = string.substring(0, n);
         if (string.substring(n).startsWith(" is ")) {
            String string3 = string.substring(n + 4);
            if (!string3.contains(" ")) {
               CONFIG.addNameAlias(string2, string3);
            }
         }
      }
   }

   public static void setLineData(HeadData headData) {
      if (refreshing) {
         refreshingLineData = headData;
      } else {
         lineData = headData;
      }
   }

   public static Text handleAddedMessage(Text text, PlayerListEntry playerListEntry) {
      if (CONFIG.detectNameAliases()) {
         autoDetectAlias(text);
      }

      lastSenderData = HeadData.EMPTY;
      if (serverDisabledChatHeads) {
         return text;
      } else {
         boolean bl = isShowcaseItemMessage(text);
         if (CONFIG.senderDetection() == SenderDetection.HEURISTIC_ONLY || bl) {
            playerListEntry = null;
         } else if (playerListEntry != null) {
            serverSentUuid = true;
         } else if (CONFIG.senderDetection() == SenderDetection.UUID_ONLY || serverSentUuid && CONFIG.smartHeuristics()) {
            return text;
         }

         Pair<Text, HeadData> pair = detectPlayerAndAddChatHead(text, playerListEntry);
         if (pair == null) {
            return text;
         } else {
            Text text2 = (Text)pair.getFirst();
            lastSenderData = (HeadData)pair.getSecond();
            return CONFIG.renderPosition() == RenderPosition.BEFORE_LINE ? text : text2;
         }
      }
   }

   private static boolean isShowcaseItemMessage(Text text) {
      TextContent textContent = text.getContent();
      TranslatableTextContent translatableTextContent;
      return textContent instanceof TranslatableTextContent
         && Objects.equals((translatableTextContent = (TranslatableTextContent)textContent).getKey(), "showcaseitem.misc.shared_item");
   }

   public static Pair<Text, HeadData> detectPlayerAndAddChatHead(Text text, PlayerListEntry playerListEntry) {
      ClientPlayNetworkHandler clientPlayNetworkHandler = MinecraftClient.getInstance().getNetworkHandler();
      if (clientPlayNetworkHandler == null) {
         return null;
      } else {
         ChatHeads.PlayerInfoCache playerInfoCache = new PlayerInfoCache(clientPlayNetworkHandler);
         if (playerListEntry != null) {
            playerInfoCache.addProfileName(playerListEntry);
         } else {
            playerInfoCache.collectProfileNames();
         }

         ArrayList<Text> arrayList = ComponentProcessor.split(text);
         if (ComponentProcessor.containsPlayerSprite(arrayList)) {
            return null;
         } else {
            PlayerListEntry playerListEntry2 = ComponentProcessor.addChatHeadForClickTellCommand(arrayList, playerInfoCache);
            if (playerListEntry2 != null) {
               return new Pair(ComponentProcessor.join(arrayList), HeadData.headDataOf(playerListEntry2));
            } else {
               if (playerListEntry != null) {
                  playerInfoCache.add(playerListEntry);
               } else {
                  playerInfoCache.collectAllNames();
               }

               playerListEntry2 = ComponentProcessor.addChatHeadForPlayerName(arrayList, playerInfoCache);
               if (playerListEntry2 != null) {
                  return new Pair(ComponentProcessor.join(arrayList), HeadData.headDataOf(playerListEntry2));
               } else if (playerListEntry != null) {
                  MutableText mutableText = ComponentProcessor.createChatHeadComponent(playerListEntry, text);
                  MutableText mutableText2 = Text.empty().append(mutableText).append(text);
                  return new Pair(mutableText2, HeadData.headDataOf(playerListEntry));
               } else {
                  return null;
               }
            }
         }
      }
   }

   public static HeadData getLineData() {
      return refreshing ? refreshingLineData : lineData;
   }

   public static Identifier getBlendedHeadLocation(Identifier identifier) {
      return Identifier.of("chat_heads", identifier.getPath());
   }

   public static NativeImage extractBlendedHead(NativeImage nativeImage) {
      boolean bl = nativeImage.getWidth() / 2 == nativeImage.getHeight();
      int n = nativeImage.getWidth() / 64;
      int n2 = nativeImage.getHeight() / (bl ? 32 : 64);
      NativeImage nativeImage2 = new NativeImage(8 * n, 8 * n2, false);

      for (int i = 0; i < nativeImage2.getHeight(); i++) {
         for (int j = 0; j < nativeImage2.getWidth(); j++) {
            int n3 = nativeImage.getColorArgb(8 * n + j, 8 * n2 + i);
            int n4 = nativeImage.getColorArgb(40 * n + j, 8 * n2 + i);
            nativeImage2.setColorArgb(j, i, blendColors(n3, n4));
         }
      }

      return nativeImage2;
   }

   private static boolean containsSubsequenceAt(int[] nArray, int n, int[] nArray2) {
      for (int i = 0; i < nArray2.length; i++) {
         if (nArray[n + i] != nArray2[i]) {
            return false;
         }
      }

      return true;
   }

   public static int blendColors(int n, int n2) {
      float f = ColorHelper.getAlpha(n) / 255.0F;
      float f2 = ColorHelper.getRed(n) / 255.0F;
      float f3 = ColorHelper.getGreen(n) / 255.0F;
      float f4 = ColorHelper.getBlue(n) / 255.0F;
      float f5 = ColorHelper.getAlpha(n2) / 255.0F;
      float f6 = ColorHelper.getRed(n2) / 255.0F;
      float f7 = ColorHelper.getGreen(n2) / 255.0F;
      float f8 = ColorHelper.getBlue(n2) / 255.0F;
      float f9 = f5 * f5 + (1.0F - f5) * f;
      float f10 = f5 * f6 + (1.0F - f5) * f2;
      float f11 = f5 * f7 + (1.0F - f5) * f3;
      float f12 = f5 * f8 + (1.0F - f5) * f4;
      return ColorHelper.getArgb(
         (int)Math.clamp(f9 * 255.0F, 0.0F, 255.0F),
         (int)Math.clamp(f10 * 255.0F, 0.0F, 255.0F),
         (int)Math.clamp(f11 * 255.0F, 0.0F, 255.0F),
         (int)Math.clamp(f12 * 255.0F, 0.0F, 255.0F)
      );
   }

   public static void renderChatHead(DrawContext drawContext, int n, int n2, PlayerListEntry playerListEntry, float f) {
      renderChatHead(drawContext, n, n2, playerListEntry, f, CONFIG.drawShadow());
   }

   public static void renderChatHead(DrawContext drawContext, int n3, int n4, PlayerListEntry playerListEntry, float f, boolean bl) {
      Identifier identifier = playerListEntry.getSkinTextures().body().texturePath();
      int n5 = ColorHelper.getWhite(f);
      int n6 = ColorHelper.scaleRgb(n5, 0.25F);
      int n7 = bl ? -1 : 0;
      ClientWorld clientWorld = MinecraftClient.getInstance().world;
      PlayerEntity playerEntity = clientWorld != null ? clientWorld.getPlayerByUuid(playerListEntry.getProfile().id()) : null;
      boolean bl3 = playerEntity != null && PlayerEntityRenderer.shouldFlipUpsideDown(playerEntity);
      boolean bl4 = playerListEntry.shouldShowHat();
      int n8 = bl3 ? 8 : 0;
      int n9 = bl3 ? -1 : 1;
      boolean bl2 = CONFIG.threeDeeNess() != 0.0F;
      if (bl4 && !bl2 && blendedHeadTextures.contains(identifier)) {
         if (bl) {
            drawContext.drawTexture(RenderPipelines.GUI_TEXTURED, getBlendedHeadLocation(identifier), n3 + 1, n4, 0.0F, n8, 8, 8, 8, n9 * 8, 8, 8, n6);
         }

         drawContext.drawTexture(RenderPipelines.GUI_TEXTURED, getBlendedHeadLocation(identifier), n3, n4 + n7, 0.0F, n8, 8, 8, 8, n9 * 8, 8, 8, n5);
      } else {
         Matrix3x2fStack matrix3x2fStack = drawContext.getMatrices();
         BiConsumer<Integer, Integer> biConsumer = (n, n2) -> matrix3x2fStack.pushMatrix()
            .scaleAround(1.0F + CONFIG.threeDeeNess() * 0.25F, n.intValue() + 4.0F, n2.intValue() + 4.0F);
         if (bl) {
            drawContext.drawTexture(RenderPipelines.GUI_TEXTURED, identifier, n3 + 1, n4, 8.0F, 8 + n8, 8, 8, 8, n9 * 8, 64, 64, n6);
            if (bl4) {
               if (bl2) {
                  biConsumer.accept(n3 + 1, n4);
               }

               drawContext.drawTexture(RenderPipelines.GUI_TEXTURED, identifier, n3 + 1, n4, 40.0F, 8 + n8, 8, 8, 8, n9 * 8, 64, 64, n6);
               if (bl2) {
                  matrix3x2fStack.popMatrix();
               }
            }
         }

         drawContext.drawTexture(RenderPipelines.GUI_TEXTURED, identifier, n3, n4 + n7, 8.0F, 8 + n8, 8, 8, 8, n9 * 8, 64, 64, n5);
         if (bl4) {
            if (bl2) {
               biConsumer.accept(n3, n4 + n7);
            }

            drawContext.drawTexture(RenderPipelines.GUI_TEXTURED, identifier, n3, n4 + n7, 40.0F, 8 + n8, 8, 8, 8, n9 * 8, 64, 64, n5);
            if (bl2) {
               matrix3x2fStack.popMatrix();
            }
         }
      }
   }

   public static class PlayerInfoCache {
      private ClientPlayNetworkHandler connection;
      private final Map<String, PlayerListEntry> playerInfos = new HashMap<>();
      private boolean collectedProfileNames = false;
      private boolean collectedEverything = false;

      public PlayerInfoCache(ClientPlayNetworkHandler clientPlayNetworkHandler) {
         this.connection = clientPlayNetworkHandler;
      }

      public void add(PlayerListEntry playerListEntry) {
         this.addProfileName(playerListEntry);
         this.addDisplayName(playerListEntry);
         this.addNameAliases();
      }

      public PlayerListEntry get(String string) {
         return this.playerInfos.get(string);
      }

      public Set<String> getNames() {
         return this.playerInfos.keySet();
      }

      public Map<Integer, List<String>> createNamesByFirstCharacterMap() {
         HashMap<Integer, List<String>> hashMap = new HashMap<>();

         for (String string : this.playerInfos.keySet()) {
            hashMap.compute(string.codePointAt(0), (n, arrayList) -> {
               if (arrayList == null) {
                  arrayList = new ArrayList<>();
               }

               arrayList.add(string);
               return arrayList;
            });
         }

         return hashMap;
      }

      public void collectProfileNames() {
         if (!this.collectedProfileNames) {
            this.collectedProfileNames = true;

            for (PlayerListEntry playerListEntry : this.connection.getPlayerList()) {
               this.addProfileName(playerListEntry);
            }
         }
      }

      private void addProfileName(PlayerListEntry playerListEntry) {
         String string = ChatHeads.FORMAT_REGEX.matcher(playerListEntry.getProfile().name()).replaceAll("");
         if (!string.isEmpty()) {
            this.playerInfos.put(string, playerListEntry);
         }
      }

      public void collectAllNames() {
         if (!this.collectedEverything) {
            this.collectedEverything = true;
            this.collectProfileNames();

            for (PlayerListEntry playerListEntry : this.connection.getPlayerList()) {
               this.addDisplayName(playerListEntry);
            }

            this.addNameAliases();
         }
      }

      private void addNameAliases() {
         for (Entry<String, String> entry : ChatHeads.CONFIG.getNameAliases().entrySet()) {
            PlayerListEntry playerListEntry = this.playerInfos.get(entry.getValue());
            if (playerListEntry != null) {
               this.playerInfos.putIfAbsent(entry.getKey(), playerListEntry);
            }
         }
      }

      private void addDisplayName(PlayerListEntry playerListEntry) {
         if (playerListEntry.getDisplayName() != null) {
            String string = ChatHeads.FORMAT_REGEX.matcher(playerListEntry.getDisplayName().getString()).replaceAll("");
            if (string.isEmpty()) {
               return;
            }

            this.playerInfos.putIfAbsent(string, playerListEntry);
         }
      }
   }
}

