package com.water.module.modules.misc;

import com.water.module.Category;
import com.water.module.Module;
import com.water.module.ModuleManager;
import com.water.setting.Setting;
import com.water.utils.RenderUtils;
import java.awt.Color;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeMap;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.block.AbstractSkullBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FallingBlock;
import net.minecraft.block.StairsBlock;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.type.TooltipDisplayComponent;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.VerticallyAttachableBlockItem;
import net.minecraft.item.Item.TooltipContext;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ChunkDeltaUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerActionResponseS2CPacket;
import net.minecraft.registry.Registries;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.state.property.Properties;
import net.minecraft.state.property.Property;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;
import ru.waterclient.mixin.BlockItemPlacementAccessor;

public final class SchematicBuilder extends Module {
   private final Setting<Float> range = new Setting<>("Range", 4.5F, 2.0F, 6.0F);
   private final Setting<Float> delay = new Setting<>("Delay", 1.0F, 1.0F, 20.0F);
   private final Setting<Boolean> useInventory = new Setting<>("Use Inventory", true);
   private final Setting<Boolean> autoWalk = new Setting<>("Auto Walk", true);
   private final Setting<Float> walkRange = new Setting<>("Walk Scan Range", 32.0F, 8.0F, 96.0F);
   private final Setting<Boolean> supports = new Setting<>("Helper Blocks", true);
   private final Setting<Boolean> tower = new Setting<>("Build Under Player", true);
   private final Setting<Boolean> repair = new Setting<>("Replace Wrong Blocks", true);
   private final Setting<Boolean> helperEsp = new Setting<>("Helper ESP", true);
   private final Setting<Boolean> autoAh = new Setting<>("Auto AH", false);
   private final Setting<Float> maxAhPrice = new Setting<>("Max AH Price", 50000.0F, 1000.0F, 1.E7F);
   private final Setting<Boolean> closeAhWhenStocked = new Setting<>("Close AH When Stocked", true);
   private final Setting<Float> ahBuyTarget = new Setting<>("AH Buy Target", 64.0F, 1.0F, 256.0F);
   private final Setting<Boolean> onlyFullStacks = new Setting<>("Only Full Stacks", true);
   private final Setting<Boolean> debug = new Setting<>("Debug", true);
   private int cooldown;
   private int clock;
   private int scanRegion;
   private int scanX;
   private int scanY;
   private int scanZ;
   private int waitTicks;
   private int aimTicks;
   private int pillarTicks;
   private int completeTicks;
   private Method schWorldGetter;
   private Method schBlockMethod;
   private boolean schResolved;
   private boolean cached;
   private boolean waiting;
   private boolean waitingHelper;
   private Object buildWorld;
   private BlockPos target;
   private BlockPos pending;
   private BlockPos pillar;
   private BlockPos bridgeWaypoint;
   private BlockPos motionWaypoint;
   private BlockState pendingState;
   private final TreeMap<Integer, List<BlockPos>> layerCache = new TreeMap<>();
   private final Map<BlockPos, BlockState> blueprint = new HashMap<>();
   private final Map<BlockPos, BlockState> helpers = new LinkedHashMap<>();
   private final Map<BlockPos, Integer> retryAt = new HashMap<>();
   private final List<SchematicBuilder.Region> regions = new ArrayList<>();
   private final SchematicBuilderRotation rotation = new SchematicBuilderRotation();
   private final ConcurrentLinkedQueue<SchematicBuilder.Update> updates = new ConcurrentLinkedQueue<>();
   private BlockPos supportGoal;
   private BlockPos attachmentHelper;
   private BlockPos ascentSite;
   private BlockPos ascentGoal;
   private BlockPos ascentLanding;
   private BlockPos transferLanding;
   private BlockPos recoverHelper;
   private BlockPos ascentWaypoint;
   private int transferStarted;
   private int recoverStarted;
   private int ascentProgressAt;
   private double ascentDistance = Double.POSITIVE_INFINITY;
   private int nextAccessAttempt;
   private boolean transferJumped;
   private int ascentTopY;
   private final ArrayDeque<BlockPos> ascentPath = new ArrayDeque<>();
   private final ArrayDeque<BlockPos> walkPath = new ArrayDeque<>();
   private BlockPos walkGoal;
   private BlockPos edgeGoal;
   private boolean walkPlacing;
   private int edgeStarted;
   private boolean cleaning;
   private final Set<BlockPos> removalPending = new HashSet<>();
   private RenderUtils.PersistentBatch helperBatch;
   private int savedSlot;
   private volatile int sentSequence = -1;
   private volatile int ackSequence = -1;
   private int ackWait;
   private int ahCooldown;
   private int ahScanCd;
   private int ahClickCd;
   private int ahBought;
   private int ahAttempts;
   private int ahCloseWait;
   private Block ahBlock;
   private String ahQuery;
   private boolean ahConfirm;
   private static final Pattern PRICE_PAT = Pattern.compile("\\$\\s*([0-9]+(?:[.,][0-9]+)?)\\s*([kKmMbB]?)");
   private BlockPos aimTarget;
   private int aimStarted;

   public SchematicBuilder() {
      super("Schematic Builder", Category.MISC);

      for (Setting<?> s : List.of(
         this.range,
         this.delay,
         this.useInventory,
         this.autoWalk,
         this.walkRange,
         this.supports,
         this.tower,
         this.helperEsp,
         this.repair,
         this.autoAh,
         this.maxAhPrice,
         this.closeAhWhenStocked,
         this.ahBuyTarget,
         this.onlyFullStacks,
         this.debug
      )) {
         this.addSetting(s);
      }
   }

   @Override
   public void onEnable() {
      this.ascentGoal = null;
      this.ascentLanding = null;
      this.transferLanding = null;
      this.recoverHelper = null;
      this.ascentWaypoint = null;
      this.nextAccessAttempt = 0;
      this.transferJumped = false;
      this.walkPath.clear();
      this.walkGoal = null;
      this.edgeGoal = null;
      this.stop();
      this.rotation.reset();
      this.cleaning = false;
      this.removalPending.clear();
      this.ascentSite = null;
      this.ascentPath.clear();
      this.supportGoal = null;
      this.attachmentHelper = null;
      this.clock = 0;
      this.cooldown = 0;
      this.cached = false;
      this.waiting = false;
      this.target = null;
      this.pending = null;
      this.pillar = null;
      this.bridgeWaypoint = null;
      this.motionWaypoint = null;
      this.pillarTicks = 0;
      this.aimTicks = 0;
      this.completeTicks = 0;
      this.updates.clear();
      this.retryAt.clear();
      this.blueprint.clear();
      this.layerCache.clear();
      if (this.buildWorld != mc.world) {
         this.helpers.clear();
      }

      this.buildWorld = mc.world;
      Module miner = ModuleManager.INSTANCE.getModuleByName("Auto Mine");
      if (miner != null && miner.isEnabled()) {
         miner.setEnabled(false);
      }

      if (mc.player != null) {
         this.savedSlot = mc.player.getInventory().getSelectedSlot();
      }

      this.readRegions();
   }

   @Override
   public void onDisable() {
      this.stop();
      this.ascentSite = null;
      this.ascentPath.clear();
      this.supportGoal = null;
      this.attachmentHelper = null;
      this.waiting = false;
      this.pending = null;
      this.target = null;
      this.pillar = null;
      this.bridgeWaypoint = null;
      this.motionWaypoint = null;
      this.ahBlock = null;
      this.rotation.reset();
      if (mc.player != null) {
         this.select(this.savedSlot);
      }
   }

   @Override
   public boolean onPacketSend(Packet<?> packet) {
      if (this.waiting && packet instanceof PlayerInteractBlockC2SPacket interaction) {
         this.sentSequence = interaction.getSequence();
      }

      return false;
   }

   @Override
   public void onPacketReceive(Packet<?> packet) {
      if (packet instanceof PlayerActionResponseS2CPacket ack) {
         this.ackSequence = ack.sequence();
      }

      if (packet instanceof BlockUpdateS2CPacket p) {
         this.updates.add(new Update(p.getPos().toImmutable(), p.getState()));
      } else if (packet instanceof ChunkDeltaUpdateS2CPacket p) {
         p.visitUpdates((pos, state) -> this.updates.add(new Update(pos.toImmutable(), state)));
      }
   }

   private void msg(String s) {
      if (mc.player != null) {
         mc.player.sendMessage(Text.literal("§b[SB]§f null"), false);
      }
   }

   private void dbg(String s) {
      if (this.debug.getValue() && mc.player != null) {
         mc.player.sendMessage(Text.literal("§7[SB] null"), true);
      }
   }

   private void stop() {
      if (mc.options != null) {
         mc.options.forwardKey.setPressed(false);
         mc.options.backKey.setPressed(false);
         mc.options.leftKey.setPressed(false);
         mc.options.rightKey.setPressed(false);
         mc.options.sprintKey.setPressed(false);
         mc.options.jumpKey.setPressed(false);
         mc.options.sneakKey.setPressed(false);
         mc.options.useKey.setPressed(false);
         mc.options.attackKey.setPressed(false);
      }
   }

   @Override
   public void onTick() {
      try {
         this.tickBuilder();
      } catch (RuntimeException var2) {
         this.stop();
         System.err.println("[Schematic Builder] Tick failed at target " + this.target);
         var2.printStackTrace();
         this.msg("Build error: " + var2.getClass().getSimpleName() + "; see latest.log");
         this.setEnabled(false);
      }
   }

   private void tickBuilder() {
      if (mc.player == null || mc.world == null || mc.interactionManager == null) {
         this.stop();
      } else if (this.buildWorld != mc.world) {
         this.stop();
         this.dbg("World changed: re-enable to scan the placement");
      } else {
         this.clock++;
         this.stop();
         if (mc.currentScreen != null) {
            if (mc.currentScreen instanceof HandledScreen && this.ahBlock != null) {
               this.tickAh();
            }
         } else if (this.ahCloseWait > 0) {
            this.ahCloseWait--;
         } else {
            if (this.ahCooldown > 0) {
               this.ahCooldown--;
            }

            SchematicBuilder.Update u;
            while ((u = this.updates.poll()) != null) {
               if (this.waiting && u.pos.equals(this.pending)) {
                  if (this.matches(u.state, this.pendingState)) {
                     if (this.waitingHelper) {
                        this.helpers.put(this.pending, this.pendingState);
                     }

                     this.cooldown = Math.round(this.delay.getValue());
                     this.retryAt.clear();
                  } else {
                     this.retryAt.put(this.pending, this.clock + 60);
                     this.dbg("Placement rejected or changed by server at " + this.pending.toShortString());
                  }

                  this.waiting = false;
                  this.pending = null;
                  this.target = null;
                  this.pillar = null;
                  this.pillarTicks = 0;
               }

               if (this.helpers.containsKey(u.pos) && !this.matches(u.state, this.helpers.get(u.pos))) {
                  this.helpers.remove(u.pos);
                  this.removalPending.remove(u.pos);
               }
            }

            if (this.bridgeWaypoint != null && !this.standable(this.bridgeWaypoint) && this.atOpenEdge()) {
               mc.options.sneakKey.setPressed(true);
            }

            if (this.waiting) {
               if (this.sentSequence >= 0 && this.ackSequence >= this.sentSequence && ++this.ackWait >= 2) {
                  if (this.matches(mc.world.getBlockState(this.pending), this.pendingState)) {
                     if (this.waitingHelper) {
                        this.helpers.put(this.pending, this.pendingState);
                     }

                     this.retryAt.clear();
                     this.cooldown = Math.round(this.delay.getValue());
                  } else {
                     this.retryAt.put(this.pending, this.clock + 20);
                  }

                  this.waiting = false;
                  this.pending = null;
                  this.target = null;
                  this.pillar = null;
                  this.pillarTicks = 0;
               } else if (++this.waitTicks > 80) {
                  if (!this.matches(mc.world.getBlockState(this.pending), this.pendingState)) {
                     this.retryAt.put(this.pending, this.clock + 20);
                     this.waiting = false;
                     this.pending = null;
                     this.target = null;
                     this.pillar = null;
                     this.dbg("Placement not applied; choosing a new placement");
                  } else {
                     this.dbg("Waiting for server acknowledgement at " + this.pending.toShortString());
                  }
               }
            } else if (this.cooldown > 0) {
               this.cooldown--;
            } else {
               Object schematic = this.getSchematicWorld();
               if (schematic == null) {
                  this.dbg("No schematic world");
               } else if (!this.cached) {
                  this.scan(schematic);
               } else if (this.pillar != null) {
                  this.tickPillar();
               } else if (this.transferLanding == null || !this.transferToLayer()) {
                  if (this.recoverHelper == null || !this.recoverAscentHelper()) {
                     if (this.ascentSite == null || !this.followAscent()) {
                        if (this.bridgeWaypoint != null) {
                           BlockPos step = this.bridgeWaypoint;
                           if (step.equals(this.edgeGoal) && this.clock - this.edgeStarted > 100 && !this.standable(step)) {
                              this.retryAt.put(step.down(), this.clock + 200);
                              this.bridgeWaypoint = null;
                              this.motionWaypoint = null;
                              this.walkPath.clear();
                              this.walkGoal = null;
                              this.edgeGoal = null;
                              this.dbg("Walkway blocked; selecting another construction position");
                           } else {
                              if (!this.standable(step) || !(mc.player.squaredDistanceTo(new Vec3d(step.getX() + 0.5, step.getY(), step.getZ() + 0.5)) < 0.09)) {
                                 this.walk(step);
                                 return;
                              }

                              this.bridgeWaypoint = null;
                           }
                        }

                        int y = this.lowestIncomplete();
                        if (y == Integer.MAX_VALUE) {
                           this.cleaning = true;
                           if (!this.helpers.isEmpty()) {
                              this.completeTicks = 0;
                              this.cleanHelpers();
                           } else if (this.blueprint.isEmpty()) {
                              this.dbg("Selected schematic contains no build blocks");
                           } else {
                              if (++this.completeTicks >= 40) {
                                 this.msg("Schem full builded");
                                 this.setEnabled(false);
                                 if (mc.getNetworkHandler() != null) {
                                    mc.getNetworkHandler().getConnection().disconnect(Text.literal("Schem full builded"));
                                 }
                              }
                           }
                        } else {
                           this.completeTicks = 0;
                           this.cleaning = false;
                           List<BlockPos> layer = this.layerCache.get(y);
                           if (this.target == null
                              || this.matches(mc.world.getBlockState(this.target), this.blueprint.get(this.target))
                              || this.target.getY() != y) {
                              this.target = layer.stream()
                                 .filter(p -> !this.matches(mc.world.getBlockState(p), this.blueprint.get(p)))
                                 .filter(p -> this.retryAt.getOrDefault(p, 0) <= this.clock)
                                 .min(
                                    Comparator.<BlockPos>comparingInt(
                                          p -> this.findSlot(this.blueprint.get(p).getBlock(), this.useInventory.getValue()) >= 0 ? 0 : 1
                                       )
                                       .thenComparingInt(
                                          p -> this.canReplace(mc.world.getBlockState(p))
                                                && !this.occupied(p)
                                                && this.placement(p, this.blueprint.get(p), mc.player.getEyePos(), true) != null
                                             ? 0
                                             : 1
                                       )
                                       .thenComparingDouble(p -> mc.player.squaredDistanceTo(Vec3d.ofCenter(p)))
                                 )
                                 .orElse(null);
                           }

                           if (this.target == null) {
                              if (this.tower.getValue() && this.autoWalk.getValue() && mc.player.isOnGround() && this.clock >= this.nextAccessAttempt) {
                                 this.nextAccessAttempt = this.clock + 40;

                                 for (BlockPos goal : layer.stream()
                                    .filter(p -> mc.world.isChunkLoaded(p) && this.canReplace(mc.world.getBlockState(p)))
                                    .filter(p -> !this.matches(mc.world.getBlockState(p), this.blueprint.get(p)))
                                    .filter(p -> this.findSlot(this.blueprint.get(p).getBlock(), this.useInventory.getValue()) >= 0)
                                    .sorted(Comparator.comparingDouble(p -> mc.player.squaredDistanceTo(Vec3d.ofCenter(p))))
                                    .limit(4L)
                                    .toList()) {
                                    this.target = goal;
                                    if (this.planAscent(goal)) {
                                       return;
                                    }
                                 }

                                 this.target = null;
                              }

                              this.dbg("Layer " + y + ": checking access to blocked placements");
                           } else if (!mc.world.isChunkLoaded(this.target)) {
                              this.dbg("Waiting for chunk at " + this.target.toShortString());
                           } else {
                              BlockState wanted = this.blueprint.get(this.target);
                              BlockState current = mc.world.getBlockState(this.target);
                              if (!this.canReplace(current)) {
                                 if (this.helpers.containsKey(this.target)) {
                                    this.defer("Preserving ascent blocks until cleanup");
                                 } else if (this.repair.getValue()
                                    && (!current.hasBlockEntity() || current.getBlock() instanceof AbstractSkullBlock)
                                    && current.getHardness(mc.world, this.target) >= 0.0F) {
                                    this.removeBlock(this.target);
                                 } else {
                                    this.defer("Wrong block/state at " + this.target.toShortString());
                                 }
                              } else if (this.findSlot(wanted.getBlock(), this.useInventory.getValue()) < 0) {
                                 if (this.autoAh.getValue() && this.ahCooldown <= 0) {
                                    this.openAh(wanted.getBlock());
                                 }

                                 this.defer("Missing " + this.bname(wanted.getBlock()) + " on layer " + y);
                              } else if (!this.target.equals(mc.player.getBlockPos())
                                 || !this.tower.getValue()
                                 || !mc.player.isOnGround()
                                 || !this.startPillar(this.target)) {
                                 if (!this.place(this.target, wanted, false)) {
                                    if (this.autoWalk.getValue()) {
                                       BlockPos step = this.walkStep(this.target, true, false);
                                       if (step != null) {
                                          this.walk(step);
                                          return;
                                       }

                                       if (this.trySupport(this.target)) {
                                          return;
                                       }

                                       BlockPos feet = mc.player.getBlockPos();
                                       if (this.tower.getValue() && this.planAscent(this.target)) {
                                          return;
                                       }
                                    }

                                    if (!this.trySupport(this.target)) {
                                       this.defer("Layer " + y + ": no placement yet; need access, support or matching orientation");
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private void defer(String reason) {
      this.dbg(reason);
      this.retryAt.put(this.target, this.clock + 60);
      this.target = null;
      this.aimTicks = 0;
   }

   private int lowestIncomplete() {
      for (Entry<Integer, List<BlockPos>> layer : this.layerCache.entrySet()) {
         for (BlockPos p : layer.getValue()) {
            if (!mc.world.isChunkLoaded(p) || !this.matches(mc.world.getBlockState(p), this.blueprint.get(p))) {
               return layer.getKey();
            }
         }
      }

      return Integer.MAX_VALUE;
   }

   private boolean matches(BlockState actual, BlockState wanted) {
      if (actual != null && wanted != null && actual.getBlock() == wanted.getBlock()) {
         for (Property<?> property : wanted.getProperties()) {
            String n = property.getName();
            if (!Set.of("powered", "lit", "occupied", "triggered", "age", "distance", "persistent", "moisture", "stage", "snowy").contains(n)
               && !Set.of("north", "south", "east", "west").contains(n)
               && (!n.equals("shape") || !(wanted.getBlock() instanceof StairsBlock))
               && !Objects.equals(actual.get(property), wanted.get(property))) {
               return false;
            }
         }

         return true;
      } else {
         return false;
      }
   }

   private boolean canReplace(BlockState state) {
      return state.isAir() || state.isReplaceable();
   }

   private boolean isPlaceable(BlockState state) {
      return state != null && !state.isAir();
   }

   private boolean occupied(BlockPos pos) {
      return !mc.world.getOtherEntities(null, new Box(pos), e -> e instanceof LivingEntity).isEmpty();
   }

   private SchematicBuilder.Placement placement(BlockPos pos, BlockState wanted, Vec3d eye, boolean predict) {
      ItemStack stack = new ItemStack(wanted.getBlock().asItem());
      int materialSlot = this.findSlot(wanted.getBlock(), this.useInventory.getValue());
      if (materialSlot >= 0) {
         stack = mc.player.getInventory().getStack(materialSlot).copy();
      }

      if (stack.isEmpty()) {
         return null;
      } else {
         double reach = Math.min((double)this.range.getValue().floatValue(), mc.player.getBlockInteractionRange());

         for (Direction face : Direction.values()) {
            BlockPos neighbor = pos.offset(face.getOpposite());
            if (!this.canReplace(mc.world.getBlockState(neighbor))) {
               VoxelShape shape = mc.world.getBlockState(neighbor).getOutlineShape(mc.world, neighbor);
               if (!shape.isEmpty()) {
                  Box bounds = shape.getBoundingBox();

                  for (double height : new double[]{0.5, 0.25, 0.75}) {
                     Vec3d local = bounds.getCenter();
                     Vec3d aim = new Vec3d(
                        neighbor.getX() + (face == Direction.EAST ? bounds.maxX : (face == Direction.WEST ? bounds.minX : local.x)),
                        neighbor.getY()
                           + (face == Direction.UP ? bounds.maxY : (face == Direction.DOWN ? bounds.minY : bounds.minY + (bounds.maxY - bounds.minY) * height)),
                        neighbor.getZ() + (face == Direction.SOUTH ? bounds.maxZ : (face == Direction.NORTH ? bounds.minZ : local.z))
                     );
                     if (wanted.contains(Properties.ROTATION) && face == Direction.UP) {
                        double angle = Math.toRadians(((Integer)wanted.get(Properties.ROTATION)).intValue() * 22.5 - 180.0);
                        double vx = -Math.sin(angle);
                        double vz = Math.cos(angle);
                        double along = (aim.x - eye.x) * vx + (aim.z - eye.z) * vz;
                        if (along <= 0.01) {
                           continue;
                        }

                        double x = eye.x + vx * along;
                        double z = eye.z + vz * along;
                        if (x < neighbor.getX() + bounds.minX + 0.02
                           || x > neighbor.getX() + bounds.maxX - 0.02
                           || z < neighbor.getZ() + bounds.minZ + 0.02
                           || z > neighbor.getZ() + bounds.maxZ - 0.02) {
                           continue;
                        }

                        aim = new Vec3d(x, aim.y, z);
                     }

                     if (!(eye.squaredDistanceTo(aim) > reach * reach)) {
                        BlockHitResult ray = mc.world
                           .raycast(
                              new RaycastContext(
                                 eye, aim.subtract(Vec3d.of(face.getVector()).multiply(0.001)), ShapeType.OUTLINE, FluidHandling.NONE, mc.player
                              )
                           );
                        if (ray.getType() == Type.BLOCK && ray.getBlockPos().equals(neighbor) && ray.getSide() == face) {
                           Vec3d delta = aim.subtract(eye);
                           float yaw = (float)Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0F;
                           float pitch = (float)(-Math.toDegrees(Math.atan2(delta.y, Math.hypot(delta.x, delta.z))));
                           BlockHitResult hit = new BlockHitResult(aim, face, neighbor, false);
                           if (!predict) {
                              return new Placement(hit, yaw, pitch);
                           }

                           float oldYaw = mc.player.getYaw();
                           float oldPitch = mc.player.getPitch();

                           try {
                              mc.player.setYaw(yaw);
                              mc.player.setPitch(pitch);
                              ItemPlacementContext context = new ItemPlacementContext(mc.player, Hand.MAIN_HAND, stack, hit);
                              if (context.getBlockPos().equals(pos)) {
                                 BlockState result = stack.getItem() instanceof VerticallyAttachableBlockItem
                                    ? this.predictItemPlacement(stack, context)
                                    : wanted.getBlock().getPlacementState(context);
                                 if (this.matches(result, wanted)) {
                                    return new Placement(hit, yaw, pitch);
                                 }
                              }
                           } finally {
                              mc.player.setYaw(oldYaw);
                              mc.player.setPitch(oldPitch);
                           }
                        }
                     }
                  }
               }
            }
         }

         return null;
      }
   }

   private BlockState predictItemPlacement(ItemStack stack, ItemPlacementContext context) {
      return stack.getItem() instanceof BlockItem item ? ((BlockItemPlacementAccessor)item).water$getPlacementState(context) : null;
   }

   private boolean place(BlockPos pos, BlockState state, boolean helper) {
      if (this.retryAt.getOrDefault(pos, 0) <= this.clock && !this.occupied(pos) && this.canReplace(mc.world.getBlockState(pos))) {
         SchematicBuilder.Placement plan = this.placement(pos, state, mc.player.getEyePos(), true);
         if (plan == null) {
            return false;
         } else if (!this.prepareSlot(state.getBlock())) {
            return false;
         } else {
            if (!pos.equals(this.aimTarget)) {
               this.aimTarget = pos;
               this.aimTicks = 0;
               this.aimStarted = this.clock;
            }

            if (this.clock - this.aimStarted > 100) {
               this.retryAt.put(pos, this.clock + 40);
               this.aimTarget = null;
               this.motionWaypoint = null;
               this.dbg("Replanning blocked aiming position");
               return false;
            } else {
               this.motionWaypoint = null;
               mc.options.sneakKey.setPressed(this.needsSneak(plan.hit.getBlockPos()) || this.atOpenEdge());
               float[] next = this.rotation.step(mc.player.getYaw(), mc.player.getPitch(), plan.yaw, plan.pitch);
               mc.player.setYaw(next[0]);
               mc.player.setPitch(next[1]);
               if (Math.abs(MathHelper.wrapDegrees(plan.yaw - next[0])) > 0.5 || Math.abs(plan.pitch - next[1]) > 0.5) {
                  this.aimTicks = 0;
                  return true;
               } else if (++this.aimTicks < 1) {
                  return true;
               } else {
                  HitResult ray = mc.player.raycast(Math.min((double)this.range.getValue().floatValue(), mc.player.getBlockInteractionRange()), 1.0F, false);
                  if (ray instanceof BlockHitResult hit
                     && ray.getType() == Type.BLOCK
                     && hit.getBlockPos().equals(plan.hit.getBlockPos())
                     && hit.getSide() == plan.hit.getSide()) {
                     ItemStack held = mc.player.getMainHandStack();
                     if (held.getItem() instanceof BlockItem && this.matchBlock(held, state.getBlock())) {
                        ItemPlacementContext context = new ItemPlacementContext(mc.player, Hand.MAIN_HAND, held, hit);
                        if (context.getBlockPos().equals(pos) && this.matches(this.predictItemPlacement(held, context), state)) {
                           this.pending = pos;
                           this.pendingState = state;
                           this.waitingHelper = helper;
                           this.waitTicks = 0;
                           this.waiting = true;
                           this.sentSequence = -1;
                           this.ackSequence = -1;
                           this.ackWait = 0;
                           ActionResult result = mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
                           this.aimTicks = 0;
                           if (result.isAccepted()) {
                              mc.player.swingHand(Hand.MAIN_HAND);
                           } else {
                              this.waiting = false;
                              this.pending = null;
                              this.retryAt.put(pos, this.clock + 10);
                              this.target = null;
                              this.dbg("Placement not accepted; repositioning");
                           }

                           return true;
                        } else {
                           this.aimTarget = null;
                           this.aimTicks = 0;
                           this.retryAt.put(pos, this.clock + 10);
                           this.dbg("Exact click does not match schematic position/state; repositioning");
                           return false;
                        }
                     } else {
                        return false;
                     }
                  } else {
                     return true;
                  }
               }
            }
         }
      } else {
         return false;
      }
   }

   private BlockState helperState(BlockPos pos) {
      BlockState planned = this.blueprint.get(pos);
      if (planned != null) {
         return planned;
      } else {
         for (Block block : new Block[]{Blocks.DIRT, Blocks.COBBLESTONE, Blocks.COBBLED_DEEPSLATE, Blocks.NETHERRACK}) {
            if (this.findSlot(block, this.useInventory.getValue()) >= 0) {
               return block.getDefaultState();
            }
         }

         for (int slot = 0; slot < (this.useInventory.getValue() ? 36 : 9); slot++) {
            ItemStack stack = mc.player.getInventory().getStack(slot);
            if (stack.getItem() instanceof BlockItem item) {
               BlockState state = item.getBlock().getDefaultState();
               if (state.isFullCube(mc.world, pos)
                  && !state.hasBlockEntity()
                  && !(item.getBlock() instanceof FallingBlock)
                  && item.getBlock() != Blocks.TNT
                  && item.getBlock() != Blocks.MAGMA_BLOCK
                  && item.getBlock() != Blocks.OBSIDIAN
                  && item.getBlock() != Blocks.BEDROCK) {
                  return state;
               }
            }
         }

         return null;
      }
   }

   private boolean helperAllowed(BlockPos pos) {
      return this.supports.getValue()
         && !this.blueprint.containsKey(pos)
         && this.canReplace(mc.world.getBlockState(pos))
         && mc.world.isChunkLoaded(pos)
         && !this.occupied(pos);
   }

   private boolean trySupport(BlockPos goal) {
      if (!this.supports.getValue()) {
         return false;
      } else if (this.placement(goal, this.blueprint.get(goal), mc.player.getEyePos(), true) != null) {
         return false;
      } else {
         for (Direction direction : Direction.values()) {
            BlockPos neighbor = goal.offset(direction);
            BlockState planned = this.blueprint.get(neighbor);
            if (planned != null
               && neighbor.getY() <= goal.getY()
               && this.canReplace(mc.world.getBlockState(neighbor))
               && this.retryAt.getOrDefault(neighbor, 0) <= this.clock
               && this.findSlot(planned.getBlock(), this.useInventory.getValue()) >= 0
               && this.placement(neighbor, planned, mc.player.getEyePos(), true) != null) {
               this.target = neighbor;
               return this.place(neighbor, planned, false);
            }
         }

         if (this.attachmentHelper != null) {
            if (this.canReplace(mc.world.getBlockState(this.attachmentHelper))) {
               this.attachmentHelper = null;
               this.supportGoal = null;
            } else {
               if (goal.equals(this.supportGoal) && !this.matches(mc.world.getBlockState(goal), this.blueprint.get(goal))) {
                  return false;
               }

               this.attachmentHelper = null;
               this.supportGoal = null;
            }
         }

         BlockPos helper = this.helperStep(goal);
         if (helper == null) {
            return false;
         } else {
            BlockState state = this.helperState(helper);
            if (state != null && this.place(helper, state, true)) {
               if (this.waiting && helper.equals(this.pending)) {
                  this.attachmentHelper = helper;
                  this.supportGoal = goal;
               }

               return true;
            } else {
               return false;
            }
         }
      }
   }

   private BlockPos helperStep(BlockPos goal) {
      for (Direction d : Direction.values()) {
         if (!this.canReplace(mc.world.getBlockState(goal.offset(d)))) {
            return null;
         }
      }

      Vec3d eye = mc.player.getEyePos();

      for (Direction dx : Direction.values()) {
         BlockPos helper = goal.offset(dx);
         if (this.helperAllowed(helper)) {
            Direction face = dx.getOpposite();
            Vec3d click = Vec3d.ofCenter(helper).add(Vec3d.of(face.getVector()).multiply(0.5));
            if (!(eye.subtract(click).dotProduct(Vec3d.of(face.getVector())) <= 0.05)
               && !(eye.squaredDistanceTo(click) > Math.pow(Math.min((double)this.range.getValue().floatValue(), mc.player.getBlockInteractionRange()), 2.0))) {
               BlockState material = this.helperState(helper);
               if (material != null && this.placement(helper, material, eye, true) != null) {
                  return helper;
               }
            }
         }
      }

      return null;
   }

   private boolean planAscent(BlockPos goal) {
      if (this.supports.getValue() && mc.player.isOnGround()) {
         BlockPos start = mc.player.getBlockPos();
         ArrayDeque<BlockPos> queue = new ArrayDeque<>();
         Map<BlockPos, BlockPos> previous = new HashMap<>();
         BlockPos bestSite = null;
         BlockPos bestLanding = null;
         int bestRise = 0;
         double bestScore = Double.POSITIVE_INFINITY;
         queue.add(start);
         previous.put(start, start);

         while (!queue.isEmpty() && previous.size() < 8192) {
            BlockPos feet = queue.removeFirst();
            BlockPos landing = this.findLayerLanding(feet, goal);
            int rise = Math.max(1, (landing == null ? goal.getY() : landing.getY() + 1) - feet.getY());
            Box body = mc.player
               .getBoundingBox()
               .offset(feet.getX() + 0.5 - mc.player.getX(), feet.getY() - mc.player.getY(), feet.getZ() + 0.5 - mc.player.getZ());
            boolean clear = (landing != null ? feet.getY() < landing.getY() + 1 : feet.getY() < goal.getY())
               && this.retryAt.getOrDefault(feet, 0) <= this.clock
               && this.ascentColumnAvailable(feet, feet.getY() + rise)
               && this.helperState(feet) != null
               && this.canReplace(mc.world.getBlockState(feet));

            for (int level = 1; clear && level <= rise; level++) {
               clear = mc.world.isSpaceEmpty(mc.player, body.offset(0.0, level + 0.25, 0.0));
            }

            if (clear) {
               Vec3d topEye = new Vec3d(feet.getX() + 0.5, feet.getY() + rise + mc.player.getStandingEyeHeight(), feet.getZ() + 0.5);
               BlockState wanted = this.blueprint.get(goal);
               boolean canBuild = wanted != null && this.placement(goal, wanted, topEye, true) != null;
               double score = (landing != null ? 0 : 10000) + feet.up(rise).getSquaredDistance(goal) + 0.05 * feet.getSquaredDistance(start);
               if ((landing != null || canBuild) && score < bestScore) {
                  bestScore = score;
                  bestSite = feet;
                  bestRise = rise;
                  bestLanding = landing;
               }
            }

            for (Direction d : net.minecraft.util.math.Direction.Type.HORIZONTAL) {
               for (int dy : new int[]{0, 1, -1}) {
                  BlockPos next = feet.offset(d).up(dy);
                  if (!previous.containsKey(next)
                     && next.getManhattanDistance(start) <= Math.round(this.walkRange.getValue())
                     && mc.world.isChunkLoaded(next)
                     && this.standable(next)
                     && (dy <= 0 || mc.world.isSpaceEmpty(mc.player, body.offset(0.0, 1.0, 0.0)))) {
                     previous.put(next, feet);
                     queue.addLast(next);
                     break;
                  }
               }
            }
         }

         if (bestSite == null) {
            return false;
         } else {
            this.ascentGoal = goal;
            this.ascentSite = bestSite;
            this.ascentTopY = bestSite.getY() + bestRise;
            this.ascentPath.clear();
            this.ascentLanding = bestLanding;
            this.ascentWaypoint = null;
            this.walkPath.clear();
            this.walkGoal = null;
            this.motionWaypoint = null;
            this.bridgeWaypoint = null;
            this.edgeGoal = null;

            for (BlockPos cursor = bestSite; !cursor.equals(start); cursor = previous.get(cursor)) {
               this.ascentPath.addFirst(cursor);
            }

            return this.followAscent();
         }
      } else {
         return false;
      }
   }

   private boolean followAscent() {
      if (this.ascentPath.isEmpty() && mc.player.isOnGround() && mc.player.getY() >= this.ascentSite.getY() + 0.9) {
         if (mc.player.getY() >= this.ascentTopY - 0.1) {
            this.target = this.ascentGoal;
            this.ascentGoal = null;
            if (this.target != null) {
               this.retryAt.remove(this.target);
            }

            this.ascentSite = null;
            this.ascentPath.clear();
            this.motionWaypoint = null;
            this.walkPath.clear();
            this.walkGoal = null;
            this.aimTarget = null;
            this.aimTicks = 0;
            if (this.ascentLanding != null) {
               this.transferLanding = this.ascentLanding;
               this.ascentLanding = null;
               this.transferStarted = this.clock;
               this.transferJumped = false;
               return this.transferToLayer();
            }

            this.dbg("Working height reached; continuing schematic layer");
            return false;
         }

         this.ascentSite = mc.player.getBlockPos();
         this.aimTarget = null;
         this.aimTicks = 0;
         this.aimStarted = this.clock;
         this.motionWaypoint = null;
      }

      if (!this.ascentPath.isEmpty()) {
         BlockPos next = this.ascentPath.peekFirst();
         double distance = mc.player.squaredDistanceTo(Vec3d.ofBottomCenter(next));
         if (next.equals(this.ascentWaypoint) && !(distance < this.ascentDistance - 0.02)) {
            if (this.clock - this.ascentProgressAt > 80) {
               this.retryAt.put(this.ascentSite, this.clock + 200);
               this.ascentSite = null;
               this.ascentLanding = null;
               this.ascentPath.clear();
               this.walkPath.clear();
               this.motionWaypoint = null;
               this.dbg("Ascent route blocked; choosing another nearby column");
               return false;
            }
         } else {
            this.ascentWaypoint = next;
            this.ascentDistance = distance;
            this.ascentProgressAt = this.clock;
         }

         if (!this.standable(next)) {
            this.ascentSite = null;
            this.ascentPath.clear();
            this.motionWaypoint = null;
            return false;
         }

         if (!(mc.player.squaredDistanceTo(new Vec3d(next.getX() + 0.5, next.getY(), next.getZ() + 0.5)) < 0.0256)) {
            this.walk(next);
            this.dbg("Moving to clear ascent position");
            return true;
         }

         this.ascentPath.removeFirst();
         this.motionWaypoint = null;
         if (!this.ascentPath.isEmpty()) {
            return true;
         }
      }

      if (!mc.player.isOnGround()) {
         return true;
      } else if (this.startPillar(this.ascentSite)) {
         this.dbg("Building up at clear ascent position");
         return true;
      } else {
         this.ascentSite = null;
         this.ascentPath.clear();
         return false;
      }
   }

   private BlockPos findLayerLanding(BlockPos column, BlockPos goal) {
      int layer = goal.getY();
      BlockState wanted = this.blueprint.get(goal);
      if (wanted == null) {
         return null;
      } else {
         for (int distance = 1; distance <= 2; distance++) {
            for (int y : new int[]{layer, layer + 1}) {
               for (Direction d : net.minecraft.util.math.Direction.Type.HORIZONTAL) {
                  BlockPos feet = new BlockPos(column.getX() + d.getOffsetX() * distance, y, column.getZ() + d.getOffsetZ() * distance);
                  if (!goal.equals(feet) && !goal.equals(feet.up())) {
                     BlockState floor = this.blueprint.get(feet.down());
                     if (floor != null && this.matches(mc.world.getBlockState(feet.down()), floor) && this.standable(feet)) {
                        Vec3d eye = new Vec3d(feet.getX() + 0.5, y + mc.player.getStandingEyeHeight(), feet.getZ() + 0.5);
                        if (this.placement(goal, wanted, eye, true) != null) {
                           Box body = mc.player
                              .getBoundingBox()
                              .offset(column.getX() + 0.5 - mc.player.getX(), y + 1 - mc.player.getY(), column.getZ() + 0.5 - mc.player.getZ());
                           boolean clear = true;

                           for (int i = 0; i <= distance * 4; i++) {
                              double arc = distance > 1 ? 1.25 : 0.0;
                              if (!mc.world.isSpaceEmpty(mc.player, body.offset(d.getOffsetX() * i * 0.25, 0.0, d.getOffsetZ() * i * 0.25))
                                 || !mc.world.isSpaceEmpty(mc.player, body.offset(d.getOffsetX() * i * 0.25, arc, d.getOffsetZ() * i * 0.25))) {
                                 clear = false;
                                 break;
                              }
                           }

                           if (clear) {
                              return feet;
                           }
                        }
                     }
                  }
               }
            }
         }

         return null;
      }
   }

   private boolean transferToLayer() {
      BlockPos landing = this.transferLanding;
      if (this.standable(landing) && this.clock - this.transferStarted <= 100) {
         double dx = landing.getX() + 0.5 - mc.player.getX();
         double dz = landing.getZ() + 0.5 - mc.player.getZ();
         double distance = Math.hypot(dx, dz);
         if (!(distance < 0.16)) {
            float yaw = (float)Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;
            float[] angle = this.rotation.step(mc.player.getYaw(), mc.player.getPitch(), yaw, 20.0F);
            mc.player.setYaw(angle[0]);
            mc.player.setPitch(angle[1]);
            if (Math.abs(MathHelper.wrapDegrees(yaw - angle[0])) < 15.0F) {
               if (distance > 1.4 && !this.transferJumped && mc.player.isOnGround()) {
                  mc.options.jumpKey.setPressed(true);
                  this.transferJumped = true;
               }

               mc.options.forwardKey.setPressed(true);
            }

            this.dbg("Stepping down onto the schematic layer");
            return true;
         } else if (!mc.player.isOnGround()) {
            return true;
         } else {
            this.transferLanding = null;
            this.motionWaypoint = null;
            this.recoverHelper = this.helpers
               .keySet()
               .stream()
               .filter(this::safeRecoveryTarget)
               .min(Comparator.comparingDouble(p -> mc.player.squaredDistanceTo(Vec3d.ofCenter(p))))
               .orElse(null);
            this.recoverStarted = this.clock;
            return false;
         }
      } else {
         this.transferLanding = null;
         this.motionWaypoint = null;
         this.dbg("Landing changed; replanning layer access");
         return false;
      }
   }

   private boolean safeRecoveryTarget(BlockPos p) {
      if (this.helpers.containsKey(p)
         && !this.blueprint.containsKey(p)
         && mc.world.isChunkLoaded(p)
         && p.getY() < mc.player.getBlockPos().getY() - 1
         && !new Box(p).intersects(mc.player.getBoundingBox().offset(0.0, -0.15, 0.0))) {
         BlockState above = mc.world.getBlockState(p.up());
         if (!this.blueprint.containsKey(p.up()) || !(above.getBlock() instanceof FallingBlock) && above.isFullCube(mc.world, p.up())) {
            Vec3d eye = mc.player.getEyePos();
            if (eye.squaredDistanceTo(Vec3d.ofCenter(p))
               > Math.pow(Math.min((double)this.range.getValue().floatValue(), mc.player.getBlockInteractionRange()), 2.0)) {
               return false;
            } else {
               BlockHitResult ray = mc.world.raycast(new RaycastContext(eye, Vec3d.ofCenter(p), ShapeType.OUTLINE, FluidHandling.NONE, mc.player));
               return ray.getType() == Type.BLOCK && ray.getBlockPos().equals(p);
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private boolean recoverAscentHelper() {
      if (this.clock - this.recoverStarted <= 100 && this.safeRecoveryTarget(this.recoverHelper)) {
         int slot = -1;

         for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            String name = stack.getName().getString().toLowerCase(Locale.ROOT);
            if (Registries.ITEM.getId(stack.getItem()).getPath().endsWith("_pickaxe") && !name.contains("drill") && !name.contains("shard")) {
               slot = i;
               break;
            }
         }

         if (slot < 0) {
            this.recoverHelper = null;
            return false;
         } else {
            this.select(slot);
            Vec3d delta = Vec3d.ofCenter(this.recoverHelper).subtract(mc.player.getEyePos());
            float[] angle = this.rotation
               .step(
                  mc.player.getYaw(),
                  mc.player.getPitch(),
                  (float)Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0F,
                  (float)(-Math.toDegrees(Math.atan2(delta.y, Math.hypot(delta.x, delta.z))))
               );
            mc.player.setYaw(angle[0]);
            mc.player.setPitch(angle[1]);
            HitResult ray = mc.player.raycast(Math.min((double)this.range.getValue().floatValue(), mc.player.getBlockInteractionRange()), 1.0F, false);
            if (ray instanceof BlockHitResult hit && ray.getType() == Type.BLOCK && hit.getBlockPos().equals(this.recoverHelper)) {
               this.removalPending.add(this.recoverHelper);
               mc.options.attackKey.setPressed(true);
            }

            return true;
         }
      } else {
         this.recoverHelper = null;
         return false;
      }
   }

   private boolean ascentColumnAvailable(BlockPos pos, int topY) {
      for (int y = pos.getY(); y < topY; y++) {
         if (this.blueprint.containsKey(new BlockPos(pos.getX(), y, pos.getZ()))) {
            return false;
         }
      }

      return true;
   }

   private boolean startPillar(BlockPos pos) {
      boolean schematicFoot = pos.equals(this.target) && this.blueprint.containsKey(pos);
      if (!schematicFoot && !this.ascentColumnAvailable(pos, pos.getY() + 1)) {
         return false;
      } else {
         BlockState material = this.helperState(pos);
         if (material != null && mc.world.isSpaceEmpty(mc.player, mc.player.getBoundingBox().offset(0.0, 1.25, 0.0))) {
            double dx = pos.getX() + 0.5 - mc.player.getX();
            double dz = pos.getZ() + 0.5 - mc.player.getZ();
            if (Math.hypot(dx, dz) > 0.16) {
               this.motionWaypoint = null;
               this.walk(pos);
               return true;
            } else if (this.canReplace(mc.world.getBlockState(pos.down()))) {
               return false;
            } else {
               SchematicBuilder.Placement plan = this.placement(pos, material, mc.player.getEyePos(), true);
               if (plan != null && this.prepareSlot(material.getBlock())) {
                  float[] angles = this.rotation.step(mc.player.getYaw(), mc.player.getPitch(), plan.yaw, plan.pitch);
                  mc.player.setYaw(angles[0]);
                  mc.player.setPitch(angles[1]);
                  if (!(Math.abs(MathHelper.wrapDegrees(plan.yaw - angles[0])) > 0.5) && !(Math.abs(plan.pitch - angles[1]) > 0.5)) {
                     if (this.ascentSite == null && this.target != null && this.target.getY() > pos.getY()) {
                        this.ascentGoal = this.target;
                        this.ascentSite = pos;
                        this.ascentTopY = this.target.getY();
                        this.ascentPath.clear();
                     }

                     this.aimTarget = pos;
                     this.aimStarted = this.clock;
                     this.aimTicks = 0;
                     this.pillar = pos;
                     this.pillarTicks = 0;
                     mc.options.jumpKey.setPressed(true);
                     return true;
                  } else {
                     return true;
                  }
               } else {
                  return false;
               }
            }
         } else {
            return false;
         }
      }
   }

   private void tickPillar() {
      if (++this.pillarTicks > 40) {
         this.pillar = null;
         this.dbg("Could not place under player; retrying from a stable position");
      } else {
         BlockState material = this.helperState(this.pillar);
         if (material == null) {
            this.pillar = null;
         } else {
            if (!this.occupied(this.pillar)) {
               if (!this.pillar.equals(this.aimTarget)) {
                  this.aimTarget = this.pillar;
                  this.aimStarted = this.clock;
               }

               this.aimTicks = 3;
               this.place(this.pillar, material, !this.blueprint.containsKey(this.pillar));
            }
         }
      }
   }

   private boolean standable(BlockPos feet) {
      Box box = mc.player.getBoundingBox().offset(feet.getX() + 0.5 - mc.player.getX(), feet.getY() - mc.player.getY(), feet.getZ() + 0.5 - mc.player.getZ());
      return mc.world.isSpaceEmpty(mc.player, box)
         && !mc.world.isSpaceEmpty(mc.player, box.offset(0.0, -0.1, 0.0))
         && mc.world.getBlockState(feet).getFluidState().isEmpty();
   }

   private BlockPos walkStep(BlockPos goal) {
      return this.walkStep(goal, true);
   }

   private BlockPos walkStep(BlockPos goal, boolean placing) {
      BlockPos existing = this.walkStep(goal, placing, false);
      return existing != null ? existing : this.walkStep(goal, placing, true);
   }

   private BlockPos walkStep(BlockPos goal, boolean placing, boolean allowBuilding) {
      if (goal.equals(this.walkGoal) && placing == this.walkPlacing && !this.walkPath.isEmpty()) {
         while (!this.walkPath.isEmpty() && mc.player.squaredDistanceTo(Vec3d.ofBottomCenter((Vec3i)this.walkPath.peekFirst())) < 0.0256) {
            this.walkPath.removeFirst();
         }

         if (!this.walkPath.isEmpty()) {
            BlockPos next = this.walkPath.peekFirst();
            if (this.standable(next)) {
               return next;
            }

            if (allowBuilding && this.helperAllowed(next.down()) && this.retryAt.getOrDefault(next.down(), 0) <= this.clock) {
               return next;
            }

            if (!allowBuilding && this.helperAllowed(next.down())) {
               return null;
            }
         }
      }

      this.walkPath.clear();
      this.walkGoal = null;
      BlockPos start = mc.player.getBlockPos();
      BlockPos best = null;
      ArrayDeque<BlockPos> q = new ArrayDeque<>();
      Map<BlockPos, BlockPos> prev = new HashMap<>();
      q.add(start);
      prev.put(start, start);
      double bestDistance = start.getSquaredDistance(goal);
      int limit = Math.round(this.walkRange.getValue());

      while (!q.isEmpty() && prev.size() < 4096) {
         BlockPos p = q.removeFirst();
         double distance = p.getSquaredDistance(goal);
         Vec3d eye = new Vec3d(p.getX() + 0.5, p.getY() + mc.player.getStandingEyeHeight(), p.getZ() + 0.5);
         if (!p.equals(start)) {
            boolean accessible;
            if (placing) {
               accessible = this.placement(goal, this.blueprint.get(goal), eye, true) != null;
            } else {
               BlockHitResult hit = mc.world.raycast(new RaycastContext(eye, Vec3d.ofCenter(goal), ShapeType.OUTLINE, FluidHandling.NONE, mc.player));
               accessible = eye.squaredDistanceTo(Vec3d.ofCenter(goal)) < Math.pow(this.range.getValue().floatValue(), 2.0)
                  && hit.getType() == Type.BLOCK
                  && hit.getBlockPos().equals(goal);
            }

            if (accessible) {
               best = p;
               break;
            }
         }

         for (Direction d : net.minecraft.util.math.Direction.Type.HORIZONTAL) {
            for (int rise : new int[]{0, 1, -1}) {
               BlockPos n = p.offset(d).up(rise);
               if ((!placing || n.getY() >= Math.min(start.getY(), goal.getY()))
                  && !prev.containsKey(n)
                  && n.getManhattanDistance(start) <= limit
                  && mc.world.isChunkLoaded(n)) {
                  boolean solid = this.standable(n);
                  Box box = mc.player
                     .getBoundingBox()
                     .offset(n.getX() + 0.5 - mc.player.getX(), n.getY() - mc.player.getY(), n.getZ() + 0.5 - mc.player.getZ());
                  if ((
                        solid
                           || allowBuilding
                              && rise == 0
                              && mc.world.isSpaceEmpty(mc.player, box)
                              && this.helperAllowed(n.down())
                              && this.helperState(n.down()) != null
                              && this.retryAt.getOrDefault(n.down(), 0) <= this.clock
                     )
                     && (
                        rise <= 0
                           || mc.world
                              .isSpaceEmpty(
                                 mc.player,
                                 mc.player
                                    .getBoundingBox()
                                    .offset(p.getX() + 0.5 - mc.player.getX(), p.getY() + 1 - mc.player.getY(), p.getZ() + 0.5 - mc.player.getZ())
                              )
                     )) {
                     prev.put(n, p);
                     q.addLast(n);
                     break;
                  }
               }
            }
         }
      }

      if (best == null) {
         return null;
      } else {
         this.walkGoal = goal;
         this.walkPlacing = placing;

         for (this.motionWaypoint = null; !best.equals(start); best = prev.get(best)) {
            this.walkPath.addFirst(best);
         }

         return this.walkPath.peekFirst();
      }
   }

   private boolean atOpenEdge() {
      if (!mc.player.isOnGround()) {
         return false;
      } else {
         double x = mc.player.getX();
         double y = mc.player.getY();
         double z = mc.player.getZ();
         return mc.world.isSpaceEmpty(mc.player, new Box(x - 0.04, y - 0.15, z - 0.04, x + 0.04, y + 0.01, z + 0.04));
      }
   }

   private boolean needsSneak(BlockPos neighbor) {
      BlockState state = mc.world.getBlockState(neighbor);
      if (!state.hasBlockEntity() && state.createScreenHandlerFactory(mc.world, neighbor) == null) {
         String id = Registries.BLOCK.getId(state.getBlock()).getPath();
         return id.endsWith("_door")
            || id.endsWith("_trapdoor")
            || id.endsWith("_fence_gate")
            || id.endsWith("_button")
            || id.endsWith("_bed")
            || id.equals("lever")
            || id.equals("note_block")
            || id.equals("composter")
            || id.equals("respawn_anchor");
      } else {
         return true;
      }
   }

   private void walk(BlockPos next) {
      if (!this.standable(next)) {
         if (!next.equals(this.edgeGoal)) {
            this.edgeGoal = next;
            this.edgeStarted = this.clock;
         }

         BlockPos floor = next.down();
         BlockState material = this.helperState(floor);
         if (material == null || !this.canReplace(mc.world.getBlockState(floor)) || !this.place(floor, material, !this.blueprint.containsKey(floor))) {
            this.bridgeWaypoint = next;
            this.approachBridgeEdge(next);
         }
      } else {
         double dx = next.getX() + 0.5 - mc.player.getX();
         double dz = next.getZ() + 0.5 - mc.player.getZ();
         double distance = Math.hypot(dx, dz);
         if (distance < 0.16) {
            this.motionWaypoint = null;
         } else {
            this.motionWaypoint = next;
            float yaw = (float)Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;
            float[] angles = this.rotation.step(mc.player.getYaw(), mc.player.getPitch(), yaw, 15.0F);
            mc.player.setYaw(angles[0]);
            mc.player.setPitch(angles[1]);
            if (!(Math.abs(MathHelper.wrapDegrees(yaw - angles[0])) > 25.0F)) {
               Box box = mc.player.getBoundingBox().offset(dx / distance * 0.2, 0.0, dz / distance * 0.2);
               if (next.getY() > mc.player.getY() + 0.4 && mc.player.isOnGround()) {
                  mc.options.jumpKey.setPressed(true);
               } else if (!mc.world.isSpaceEmpty(mc.player, box)) {
                  this.motionWaypoint = null;
                  this.bridgeWaypoint = null;
                  this.walkPath.clear();
                  this.walkGoal = null;
                  return;
               }

               mc.options.forwardKey.setPressed(true);
               mc.options.sneakKey.setPressed(this.atOpenEdge());
            }
         }
      }
   }

   private void approachBridgeEdge(BlockPos next) {
      if (mc.player.isOnGround()) {
         double dx = next.getX() + 0.5 - mc.player.getX();
         double dz = next.getZ() + 0.5 - mc.player.getZ();
         double distance = Math.hypot(dx, dz);
         if (!(distance < 0.12)) {
            Box probe = mc.player.getBoundingBox().offset(dx / distance * 0.08, 0.0, dz / distance * 0.08);
            mc.options.sneakKey.setPressed(true);
            if (mc.world.isSpaceEmpty(mc.player, probe) && !mc.world.isSpaceEmpty(mc.player, probe.offset(0.0, -0.15, 0.0))) {
               Vec3d delta = Vec3d.ofCenter(next.down()).subtract(mc.player.getEyePos());
               float[] angles = this.rotation
                  .step(
                     mc.player.getYaw(),
                     mc.player.getPitch(),
                     (float)Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0F,
                     (float)(-Math.toDegrees(Math.atan2(delta.y, Math.hypot(delta.x, delta.z))))
                  );
               mc.player.setYaw(angles[0]);
               mc.player.setPitch(angles[1]);
               double yaw = Math.toRadians(angles[0]);
               double forward = (-Math.sin(yaw) * dx + Math.cos(yaw) * dz) / distance;
               double left = (Math.cos(yaw) * dx + Math.sin(yaw) * dz) / distance;
               mc.options.forwardKey.setPressed(forward > 0.35);
               mc.options.backKey.setPressed(forward < -0.35);
               mc.options.leftKey.setPressed(left > 0.35);
               mc.options.rightKey.setPressed(left < -0.35);
               this.dbg("Approaching edge to extend the walkway");
            }
         }
      }
   }

   @Override
   public void onRender(MatrixStack matrices, float tickDelta) {
      if (this.helperEsp.getValue() && mc.world != null && this.buildWorld == mc.world && !this.helpers.isEmpty()) {
         Camera camera = RenderUtils.getCamera();
         if (camera != null) {
            Vec3d eye = RenderUtils.getCameraPos(camera);
            if (this.helperBatch == null) {
               this.helperBatch = RenderUtils.createStorageBoxBatch();
            }

            this.helperBatch.begin(matrices);

            for (BlockPos pos : this.helpers.keySet()) {
               if (mc.world.isChunkLoaded(pos) && !mc.world.getBlockState(pos).isAir()) {
                  double x = pos.getX() - eye.x;
                  double y = pos.getY() - eye.y;
                  double z = pos.getZ() - eye.z;
                  this.helperBatch.addFilledBox(x, y, z, x + 1.0, y + 1.0, z + 1.0, new Color(40, 210, 255, 40));
                  this.helperBatch.addOutlineBox(x, y, z, x + 1.0, y + 1.0, z + 1.0, new Color(40, 210, 255, 230));
               }
            }

            this.helperBatch.flush();
         }
      }
   }

   private void cleanHelpers() {
      BlockPos p = this.helpers
         .keySet()
         .stream()
         .filter(mc.world::isChunkLoaded)
         .min(Comparator.comparingInt(Vec3i::getY).reversed().thenComparingDouble(pos -> mc.player.squaredDistanceTo(Vec3d.ofCenter(pos))))
         .orElse(null);
      if (p == null) {
         this.dbg("Waiting for helper chunks");
      } else {
         this.removeHelper(p);
      }
   }

   private void removeHelper(BlockPos pos) {
      if (this.cleaning) {
         if (this.removalPending.contains(pos) && mc.world.getBlockState(pos).isAir()) {
            this.dbg("Waiting for server to confirm helper removal");
         } else if (!this.matches(mc.world.getBlockState(pos), this.helpers.get(pos))) {
            this.helpers.remove(pos);
         } else {
            BlockState above = mc.world.getBlockState(pos.up());
            if (!this.blueprint.containsKey(pos.up()) || !(above.getBlock() instanceof FallingBlock) && above.isFullCube(mc.world, pos.up())) {
               this.removeBlock(pos);
            } else {
               this.dbg("Retaining helper that supports a schematic block at " + pos.up().toShortString());
            }
         }
      }
   }

   private void removeBlock(BlockPos pos) {
      boolean ownDescent = this.helpers.containsKey(pos)
         && mc.player.isOnGround()
         && mc.world.getBlockState(pos.down()).isFullCube(mc.world, pos.down())
         && mc.world.getBlockState(pos.down()).getFluidState().isEmpty();
      if (!ownDescent && new Box(pos).intersects(mc.player.getBoundingBox().offset(0.0, -0.1, 0.0))) {
         for (Direction d : net.minecraft.util.math.Direction.Type.HORIZONTAL) {
            BlockPos step = mc.player.getBlockPos().offset(d);
            if (this.standable(step) && !this.helpers.containsKey(step.down())) {
               this.walk(step);
               return;
            }
         }

         this.dbg("Helper still needed as standing platform");
      } else {
         Vec3d aim = Vec3d.ofCenter(pos);
         Vec3d delta = aim.subtract(mc.player.getEyePos());
         BlockHitResult sight = mc.world.raycast(new RaycastContext(mc.player.getEyePos(), aim, ShapeType.OUTLINE, FluidHandling.NONE, mc.player));
         if (!(delta.length() > Math.min((double)this.range.getValue().floatValue(), mc.player.getBlockInteractionRange()))
            && sight.getType() == Type.BLOCK
            && sight.getBlockPos().equals(pos)) {
            int empty = -1;

            for (int i = 0; i < (this.useInventory.getValue() ? 36 : 9); i++) {
               ItemStack stack = mc.player.getInventory().getStack(i);
               String name = stack.getName().getString().toLowerCase(Locale.ROOT);
               if (Registries.ITEM.getId(stack.getItem()).getPath().endsWith("_pickaxe") && !name.contains("drill") && !name.contains("shard")) {
                  if (i < 9) {
                     empty = i;
                  } else {
                     empty = mc.player.getInventory().getSelectedSlot();
                     mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, i, empty, SlotActionType.SWAP, mc.player);
                  }
                  break;
               }
            }

            if (empty < 0) {
               for (int ix = 0; ix < 9; ix++) {
                  if (mc.player.getInventory().getStack(ix).isEmpty()) {
                     empty = ix;
                     break;
                  }
               }
            }

            if (empty < 0) {
               for (int ixx = 0; ixx < 9; ixx++) {
                  if (mc.player.getInventory().getStack(ixx).getItem() instanceof BlockItem) {
                     empty = ixx;
                     break;
                  }
               }
            }

            if (empty < 0 && this.useInventory.getValue()) {
               for (int ixxx = 9; ixxx < 36; ixxx++) {
                  if (mc.player.getInventory().getStack(ixxx).getItem() instanceof BlockItem item && this.prepareSlot(item.getBlock())) {
                     empty = mc.player.getInventory().getSelectedSlot();
                     break;
                  }
               }
            }

            if (empty < 0) {
               this.dbg("Need an empty slot or building block for removal without an area drill");
            } else {
               this.select(empty);
               float[] angles = this.rotation
                  .step(
                     mc.player.getYaw(),
                     mc.player.getPitch(),
                     (float)Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0F,
                     (float)(-Math.toDegrees(Math.atan2(delta.y, Math.hypot(delta.x, delta.z))))
                  );
               mc.player.setYaw(angles[0]);
               mc.player.setPitch(angles[1]);
               HitResult ray = mc.player.raycast(this.range.getValue().floatValue(), 1.0F, false);
               if (ray instanceof BlockHitResult hit && ray.getType() == Type.BLOCK && hit.getBlockPos().equals(pos)) {
                  if (this.helpers.containsKey(pos)) {
                     this.removalPending.add(pos);
                  }

                  mc.options.attackKey.setPressed(true);
               }
            }
         } else {
            BlockPos step = this.autoWalk.getValue() ? this.walkStep(pos, false) : null;
            if (step != null) {
               this.walk(step);
            } else {
               if (this.cleaning && this.tower.getValue() && pos.getY() > mc.player.getBlockPos().getY() && this.planAscent(pos)) {
                  return;
               }

               this.dbg("Helper remains out of reach at " + pos.toShortString());
            }
         }
      }
   }

   private void readRegions() {
      this.regions.clear();

      try {
         Class<?> data = Class.forName("fi.dy.masa.litematica.data.DataManager");
         Object manager = data.getMethod("getSchematicPlacementManager").invoke(null);
         Object placement = manager.getClass().getMethod("getSelectedSchematicPlacement").invoke(manager);
         if (placement == null) {
            List<Object> enabled = new ArrayList<>();

            for (Object p : (List)manager.getClass().getMethod("getAllSchematicsPlacements").invoke(manager)) {
               if (Boolean.TRUE.equals(p.getClass().getMethod("isEnabled").invoke(p))) {
                  enabled.add(p);
               }
            }

            if (enabled.size() != 1) {
               throw new IllegalStateException("Select one enabled Litematica placement");
            }

            placement = enabled.getFirst();
         }

         if (!Boolean.TRUE.equals(placement.getClass().getMethod("isEnabled").invoke(placement))) {
            throw new IllegalStateException("Selected placement is disabled");
         }

         Class<? extends Enum> required = (Class<? extends Enum>)Class.forName("fi.dy.masa.litematica.schematic.placement.SubRegionPlacement$RequiredEnabled");
         Map<?, ?> boxes = (Map<?, ?>)placement.getClass()
            .getMethod("getSubRegionBoxes", required)
            .invoke(placement, Enum.valueOf(required, "PLACEMENT_ENABLED"));

         for (Object box : boxes.values()) {
            BlockPos a = (BlockPos)box.getClass().getMethod("getPos1").invoke(box);
            BlockPos b = (BlockPos)box.getClass().getMethod("getPos2").invoke(box);
            this.regions
               .add(
                  new Region(
                     new BlockPos(Math.min(a.getX(), b.getX()), Math.min(a.getY(), b.getY()), Math.min(a.getZ(), b.getZ())),
                     new BlockPos(Math.max(a.getX(), b.getX()), Math.max(a.getY(), b.getY()), Math.max(a.getZ(), b.getZ()))
                  )
               );
         }

         if (this.regions.isEmpty()) {
            throw new IllegalStateException("No enabled subregions");
         }

         this.scanRegion = 0;
         this.resetCursor();
         this.msg("Scanning selected schematic");
      } catch (Exception var10) {
         this.msg("Cannot read placement: " + var10.getMessage());
         this.setEnabled(false);
      }
   }

   private void resetCursor() {
      BlockPos min = this.regions.get(this.scanRegion).min;
      this.scanX = min.getX();
      this.scanY = min.getY();
      this.scanZ = min.getZ();
   }

   private void scan(Object world) {
      for (int budget = 0; budget < 3000 && this.scanRegion < this.regions.size(); budget++) {
         SchematicBuilder.Region r = this.regions.get(this.scanRegion);
         BlockPos p = new BlockPos(this.scanX, this.scanY, this.scanZ);
         BlockState state = this.getSchematicBlock(world, p);
         if (state == null) {
            this.dbg("Waiting for readable schematic data");
            return;
         }

         if (this.isPlaceable(state) && this.blueprint.putIfAbsent(p, state) == null) {
            this.layerCache.computeIfAbsent(this.scanY, k -> new ArrayList<>()).add(p);
         }

         if (++this.scanX > r.max.getX()) {
            this.scanX = r.min.getX();
            if (++this.scanZ > r.max.getZ()) {
               this.scanZ = r.min.getZ();
               if (++this.scanY > r.max.getY()) {
                  this.scanRegion++;
                  if (this.scanRegion < this.regions.size()) {
                     this.resetCursor();
                  }
               }
            }
         }
      }

      if (this.scanRegion >= this.regions.size()) {
         this.cached = true;
         this.msg("Loaded " + this.blueprint.size() + " blocks in " + this.layerCache.size() + " layers");
      } else {
         this.dbg("Scanning schematic region " + (this.scanRegion + 1) + "/" + this.regions.size());
      }
   }

   private Object getSchematicWorld() {
      try {
         if (this.schWorldGetter == null) {
            Class<?> h = Class.forName("fi.dy.masa.litematica.world.SchematicWorldHandler");
            this.schWorldGetter = h.getMethod("getSchematicWorld");
         }

         return this.schWorldGetter.invoke(null);
      } catch (Throwable var2) {
         return null;
      }
   }

   private BlockState getSchematicBlock(Object w, BlockPos pos) {
      if (w == null) {
         return null;
      } else {
         try {
            this.resolveSch(w);
            if (this.schBlockMethod != null && this.schBlockMethod.invoke(w, pos) instanceof BlockState bs) {
               return bs;
            }
         } catch (Throwable var5) {
         }

         return null;
      }
   }

   private void resolveSch(Object w) {
      if (!this.schResolved) {
         this.schResolved = true;

         for (Class<?> cls = w.getClass(); cls != null && cls != Object.class; cls = cls.getSuperclass()) {
            for (Method m : cls.getDeclaredMethods()) {
               if (!Modifier.isStatic(m.getModifiers())) {
                  Class<?>[] p = m.getParameterTypes();
                  if (p.length == 1 && p[0].isAssignableFrom(BlockPos.class) && BlockState.class.isAssignableFrom(m.getReturnType())) {
                     m.setAccessible(true);
                     this.schBlockMethod = m;
                     return;
                  }
               }
            }
         }
      }
   }

   private boolean prepareSlot(Block block) {
      int hb = this.findHotbar(block);
      if (hb != -1) {
         this.select(hb);
         return true;
      } else if (!this.useInventory.getValue()) {
         return false;
      } else {
         int inv = this.findMain(block);
         int tgt = this.freeHotbar();
         if (inv != -1 && tgt != -1) {
            mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, toHandler(inv), tgt, SlotActionType.SWAP, mc.player);
            this.select(tgt);
            return true;
         } else {
            return false;
         }
      }
   }

   private int findSlot(Block b, boolean main) {
      int s = this.findHotbar(b);
      return s == -1 && main ? this.findMain(b) : s;
   }

   private int findHotbar(Block b) {
      PlayerInventory inv = mc.player.getInventory();

      for (int i = 0; i < 9; i++) {
         if (this.matchBlock(inv.getStack(i), b)) {
            return i;
         }
      }

      return -1;
   }

   private int findMain(Block b) {
      PlayerInventory inv = mc.player.getInventory();

      for (int i = 9; i < 36; i++) {
         if (this.matchBlock(inv.getStack(i), b)) {
            return i;
         }
      }

      return -1;
   }

   private boolean matchBlock(ItemStack s, Block b) {
      return !s.isEmpty() && b.asItem() != Items.AIR && s.getItem() == b.asItem();
   }

   private int freeHotbar() {
      PlayerInventory inv = mc.player.getInventory();

      for (int i = 0; i < 9; i++) {
         if (inv.getStack(i).isEmpty()) {
            return i;
         }
      }

      for (int ix = 0; ix < 9; ix++) {
         if (!(inv.getStack(ix).getItem() instanceof BlockItem)) {
            return ix;
         }
      }

      return mc.player.getInventory().getSelectedSlot();
   }

   private void select(int s) {
      if (s >= 0 && s <= 8 && mc.player.getInventory().getSelectedSlot() != s) {
         mc.player.getInventory().setSelectedSlot(s);
      }
   }

   private int countBlock(Block b) {
      if (mc.player == null) {
         return 0;
      } else {
         int c = 0;

         for (int i = 0; i < 36; i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            if (this.matchBlock(s, b)) {
               c += s.getCount();
            }
         }

         return c;
      }
   }

   private void openAh(Block block) {
      if (block != null && block != Blocks.AIR && mc.getNetworkHandler() != null && mc.currentScreen == null) {
         String q = this.bname(block);
         if (!q.isBlank()) {
            this.msg("§eOpening /ah null");
            mc.getNetworkHandler().sendChatCommand("ah null");
            this.ahBlock = block;
            this.ahQuery = q;
            this.ahBought = 0;
            this.ahAttempts = 0;
            this.ahConfirm = false;
            this.ahCooldown = 60;
         }
      }
   }

   private void tickAh() {
      if (this.ahBlock != null && mc.player != null) {
         ScreenHandler handler = mc.player.currentScreenHandler;
         if (handler != null) {
            int stock = this.countBlock(this.ahBlock);
            int target = Math.max(1, Math.round(this.ahBuyTarget.getValue()));
            if (this.closeAhWhenStocked.getValue() && stock >= target) {
               this.closeAh("§aGot " + stock + "x " + this.ahQuery);
            } else if (this.ahAttempts > 12) {
               this.closeAh("§cMax attempts");
            } else if (this.ahClickCd > 0) {
               this.ahClickCd--;
            } else {
               int upper = Math.max(0, handler.slots.size() - 36);
               if (this.ahConfirm) {
                  int slot = this.findConfirm(handler, upper);
                  if (slot != -1) {
                     mc.interactionManager.clickSlot(handler.syncId, slot, 0, SlotActionType.PICKUP, mc.player);
                     this.ahClickCd = 10;
                     this.ahConfirm = false;
                     this.ahBought += 64;
                     this.msg("§aConfirmed (" + (this.ahBought + stock) + "/" + target + ")");
                  } else {
                     this.ahConfirm = false;
                     this.ahClickCd = 8;
                     this.ahAttempts++;
                  }
               } else if (this.ahScanCd > 0) {
                  this.ahScanCd--;
               } else {
                  this.ahScanCd = 8;
                  long maxP = Math.max(1L, (long)Math.round(this.maxAhPrice.getValue()));
                  String wId = Registries.BLOCK.getId(this.ahBlock).getPath();
                  String wName = wId.replace('_', ' ').toLowerCase();
                  int bestSlot = -1;
                  long bestPrice = Long.MAX_VALUE;

                  for (int i = 0; i < upper && i < handler.slots.size(); i++) {
                     Slot slot = (Slot)handler.slots.get(i);
                     if (slot != null && slot.hasStack()) {
                        ItemStack stack = slot.getStack();
                        if (!this.onlyFullStacks.getValue() || stack.getCount() >= 64) {
                           boolean ok = false;
                           if (stack.getItem() instanceof BlockItem bi && bi.getBlock() == this.ahBlock) {
                              ok = true;
                           }

                           if (!ok) {
                              try {
                                 ok = Registries.ITEM.getId(stack.getItem()).getPath().equals(wId);
                              } catch (Throwable var18) {
                              }
                           }

                           if (!ok) {
                              String dn = stack.getName().getString().toLowerCase().trim();
                              if (!dn.isEmpty() && (dn.contains(wName) || wName.contains(dn))) {
                                 ok = true;
                              }
                           }

                           if (ok) {
                              long price = this.extractPrice(stack);
                              if (price <= 0L) {
                                 price = 1L;
                              }

                              if (price <= maxP && price < bestPrice) {
                                 bestPrice = price;
                                 bestSlot = i;
                              }
                           }
                        }
                     }
                  }

                  if (bestSlot == -1) {
                     this.msg("§cNo 64x " + this.ahQuery);
                     this.ahAttempts++;
                     this.ahClickCd = 20;
                  } else {
                     mc.interactionManager.clickSlot(handler.syncId, bestSlot, 0, SlotActionType.PICKUP, mc.player);
                     this.ahConfirm = true;
                     this.ahClickCd = 8;
                     this.ahAttempts++;
                     this.msg("§eBuying " + this.ahQuery + (bestPrice > 1L ? " $" + this.fmtMoney(bestPrice) : ""));
                  }
               }
            }
         }
      }
   }

   private void closeAh(String reason) {
      this.msg("null §7— building.");
      mc.player.closeHandledScreen();
      mc.setScreen(null);
      this.ahBought = 0;
      this.ahConfirm = false;
      this.ahAttempts = 0;
      this.ahCloseWait = 2;
      this.ahCooldown = 40;
      this.ahBlock = null;
      this.ahQuery = null;
      this.target = null;
      this.aimTarget = null;
      this.bridgeWaypoint = null;
      this.motionWaypoint = null;
      this.pillar = null;
      this.retryAt.clear();
      this.aimTicks = 0;
      this.rotation.reset();
   }

   private int findConfirm(ScreenHandler h, int upper) {
      for (int i = 0; i < upper && i < h.slots.size(); i++) {
         Slot s = (Slot)h.slots.get(i);
         if (s != null && s.hasStack()) {
            ItemStack stack = s.getStack();
            String name = stack.getName().getString().toLowerCase();
            if (name.contains("confirm")
               || name.contains("buy")
               || name.contains("purchase")
               || name.contains("accept")
               || name.contains("kaufen")
               || name.contains("bestätigen")
               || name.contains("yes")
               || name.contains("click to buy")) {
               return i;
            }

            String id = Registries.ITEM.getId(stack.getItem()).getPath();
            if ((id.contains("green") || id.contains("lime"))
               && (id.contains("wool") || id.contains("stained_glass_pane") || id.contains("concrete") || id.contains("terracotta") || id.contains("dye"))) {
               return i;
            }
         }
      }

      return -1;
   }

   private long extractPrice(ItemStack stack) {
      long best = this.parsePrice(stack.getName().getString());

      try {
         List<Text> lines = new ArrayList<>();
         stack.appendTooltip(TooltipContext.DEFAULT, TooltipDisplayComponent.DEFAULT, mc.player, TooltipType.BASIC, lines::add);

         for (Text l : lines) {
            long p = this.parsePrice(l.getString());
            if (p > 0L && (best <= 0L || p < best)) {
               best = p;
            }
         }
      } catch (Throwable var9) {
      }

      return best;
   }

   private long parsePrice(String t) {
      if (t != null && !t.isBlank()) {
         Matcher m = PRICE_PAT.matcher(t.replace(",", ""));
         if (!m.find()) {
            return -1L;
         } else {
            double v;
            try {
               v = Double.parseDouble(m.group(1));
            } catch (NumberFormatException var6) {
               return -1L;
            }

            String s = m.group(2);
            if ("k".equalsIgnoreCase(s)) {
               v *= 1000.0;
            } else if ("m".equalsIgnoreCase(s)) {
               v *= 1000000.0;
            } else if ("b".equalsIgnoreCase(s)) {
               v *= 1.E9;
            }

            return Math.max(1L, Math.round(v));
         }
      } else {
         return -1L;
      }
   }

   private String fmtMoney(long v) {
      if (v >= 1000000000L) {
         return this.trimM(v / 1.E9) + "B";
      } else if (v >= 1000000L) {
         return this.trimM(v / 1000000.0) + "M";
      } else {
         return v >= 1000L ? this.trimM(v / 1000.0) + "K" : Long.toString(v);
      }
   }

   private String trimM(double v) {
      String f = String.format(Locale.ROOT, "%.1f", v);
      return f.endsWith(".0") ? f.substring(0, f.length() - 2) : f;
   }

   private String bname(Block b) {
      try {
         return Registries.BLOCK.getId(b).getPath().replace('_', ' ');
      } catch (Throwable var3) {
         return "";
      }
   }

   private static int toHandler(int inv) {
      return inv < 9 ? 36 + inv : inv;
   }

   final class Placement {
      private BlockHitResult hit;
      private float yaw;
      private float pitch;

      private Placement(BlockHitResult hit, float yaw, float pitch) {
         this.hit = hit;
         this.yaw = yaw;
         this.pitch = pitch;
      }

      public BlockHitResult hit() {
         return this.hit;
      }

      public float yaw() {
         return this.yaw;
      }

      public float pitch() {
         return this.pitch;
      }
   }

   final static class Region {
      private BlockPos min;
      private BlockPos max;

      private Region(BlockPos min, BlockPos max) {
         this.min = min;
         this.max = max;
      }

      public BlockPos min() {
         return this.min;
      }

      public BlockPos max() {
         return this.max;
      }
   }

   final class Update {
      private BlockPos pos;
      private BlockState state;

      private Update(BlockPos pos, BlockState state) {
         this.pos = pos;
         this.state = state;
      }

      public BlockPos pos() {
         return this.pos;
      }

      public BlockState state() {
         return this.state;
      }
   }
}

