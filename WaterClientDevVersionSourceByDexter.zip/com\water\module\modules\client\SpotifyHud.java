package com.water.module.modules.client;

import com.water.gui.HudEditor;
import com.water.gui.SpotifyBrowserScreen;
import com.water.gui.hud.SpotifyQueueHud;
import com.water.module.Category;
import com.water.module.Module;
import com.water.setting.Setting;
import com.water.utils.renderer.AwtFontRenderer;
import com.water.utils.renderer.RenderUtil;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import rtx.kimiko.api.ui.UI;

public final class SpotifyHud extends Module {
   private static SpotifyHud INSTANCE;
   private final Setting<Float> scale = new Setting<>("Scale", 1.0F, 0.6F, 2.0F);
   private final Setting<Float> roundness = new Setting<>("Roundness", 8.0F, 0.0F, 20.0F);
   private volatile String title = "";
   private volatile String artist = "";
   private volatile boolean isPlaying = false;
   private volatile boolean isRepeating = false;
   private volatile long anchorPosMs = 0L;
   private volatile long anchorTimeMs = 0L;
   private volatile long durMs = 0L;
   private ScheduledExecutorService scheduler;
   private ExecutorService actionExec;
   private File pollScriptFile;
   private File ctrlScriptFile;
   private File artFile;
   private static final Identifier ART_ID = Identifier.of("water", "spotify_art");
   private static final Identifier SPOTIFY_LOGO_ID = Identifier.of("water", "textures/gui/spotify_logo.png");
   private static final Identifier ICON_PREV_ID = Identifier.of("water", "textures/gui/spotify/prev.png");
   private static final Identifier ICON_PLAY_ID = Identifier.of("water", "textures/gui/spotify/play.png");
   private static final Identifier ICON_PAUSE_ID = Identifier.of("water", "textures/gui/spotify/pause.png");
   private static final Identifier ICON_NEXT_ID = Identifier.of("water", "textures/gui/spotify/next.png");
   private NativeImageBackedTexture artTex = null;
   private volatile long artLastModified = 0L;
   private volatile boolean hasArt = false;
   private float fade = 0.0F;
   private long lastNanos = 0L;
   private static boolean dragging = false;
   private static boolean mouseWasDown = false;
   private static double dragOffsetX;
   private static double dragOffsetY;
   private volatile boolean hasPolledOnce = false;
   private final AtomicBoolean polling = new AtomicBoolean(false);
   private final AtomicInteger fastPollCount = new AtomicInteger(0);
   private static final int BASE_W = 190;
   private static final int BASE_H = 58;
   private static final int BASE_ART = 46;
   private static final int BASE_PAD = 6;
   private static final int PROG_H = 3;
   private static final int WAVE_BARS = 32;
   private static final int WAVE_H = 8;
   private volatile float waveSeed = 0.0F;
   private volatile String waveForTitle = null;
   private static final String POLL_SCRIPT = "[void][System.Reflection.Assembly]::LoadFile('C:\\Windows\\Microsoft.NET\\Framework64\\v4.0.30319\\System.Runtime.WindowsRuntime.dll')\r\n$null = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager,Windows.Media.Control,ContentType=WindowsRuntime]\r\n$g = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -like 'IAsyncOperation*' })[0]\r\nfunction Aw($op,$t){$m=$g.MakeGenericMethod($t);$task=$m.Invoke($null,@($op));$task.GetAwaiter().GetResult()}\r\n$asStreamForRead = [System.IO.WindowsRuntimeStreamExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsStreamForRead' -and $_.GetParameters().Count -eq 1 } | Select-Object -First 1\r\ntry {\r\n  $mgr = Aw([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])\r\n  $s = $mgr.GetCurrentSession()\r\n  if ($s) {\r\n    $p = Aw($s.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties])\r\n    $tl = $s.GetTimelineProperties()\r\n    $pb = $s.GetPlaybackInfo()\r\n    if ($p.Title) {\r\n      if ($p.Thumbnail -and $asStreamForRead) {\r\n        try {\r\n          $stream = Aw($p.Thumbnail.OpenReadAsync()) ([Windows.Storage.Streams.IRandomAccessStreamWithContentType])\r\n          $netStream = $asStreamForRead.Invoke($null, @($stream))\r\n          $outPath = Join-Path $env:TEMP 'water_spotify_art.png'\r\n          $fs = [System.IO.File]::Create($outPath)\r\n          $netStream.CopyTo($fs)\r\n          $fs.Close()\r\n          $netStream.Close()\r\n        } catch {}\r\n      }\r\n      Write-Output ($p.Artist + '|||' + $p.Title + '|||' + [long]$tl.Position.TotalMilliseconds + '|||' + [long]$tl.EndTime.TotalMilliseconds + '|||' + ($pb.PlaybackStatus.ToString() -eq 'Playing'))\r\n    }\r\n  }\r\n} catch {}\r\n";
   private static final String CTRL_SCRIPT = "param([string]$action)\r\n[void][System.Reflection.Assembly]::LoadFile('C:\\Windows\\Microsoft.NET\\Framework64\\v4.0.30319\\System.Runtime.WindowsRuntime.dll')\r\n$null = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager,Windows.Media.Control,ContentType=WindowsRuntime]\r\n$g = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -like 'IAsyncOperation*' })[0]\r\nfunction Aw($op,$t){$m=$g.MakeGenericMethod($t);$task=$m.Invoke($null,@($op));$task.GetAwaiter().GetResult()}\r\ntry {\r\n  $mgr = Aw([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])\r\n  $s = $mgr.GetCurrentSession()\r\n  if ($s) {\r\n    switch ($action) {\r\n      'next'    { Aw($s.TrySkipNextAsync()) ([bool]) | Out-Null }\r\n      'prev'    { Aw($s.TrySkipPreviousAsync()) ([bool]) | Out-Null }\r\n      'toggle'  { Aw($s.TryTogglePlayPauseAsync()) ([bool]) | Out-Null }\r\n      'repeat'  { try { $pb2 = $s.GetPlaybackInfo(); $cur = $pb2.AutoRepeatMode; $next = if($cur -eq [Windows.Media.MediaPlaybackAutoRepeatMode]::None){'Track'} elseif($cur -eq [Windows.Media.MediaPlaybackAutoRepeatMode]::Track){'List'} else{'None'}; Aw($s.TryChangeAutoRepeatModeAsync([Windows.Media.MediaPlaybackAutoRepeatMode]::$next)) ([bool]) | Out-Null } catch {} }\r\n    }\r\n  }\r\n} catch {}\r\n";

   public SpotifyHud() {
      super("Spotify HUD", Category.CLIENT);
      this.addSetting(this.scale);
      this.addSetting(this.roundness);
      INSTANCE = this;
   }

   public static boolean isActive() {
      return INSTANCE != null && INSTANCE.isEnabled();
   }

   public static float getScale() {
      return INSTANCE == null ? 1.0F : INSTANCE.scale.getValue();
   }

   public static void setScale(float v) {
      if (INSTANCE != null) {
         float lo = INSTANCE.scale.getMin() instanceof Float f ? f : 0.6F;
         float hi = INSTANCE.scale.getMax() instanceof Float fx ? fx : 2.0F;
         INSTANCE.scale.setValue(Math.max(lo, Math.min(hi, v)));
         int[] pos = Hud.getElementPos(Hud.HudElement.SPOTIFY_HUD);
         int nx = clampX(pos[0]);
         int ny = clampY(pos[1]);
         if (nx != pos[0] || ny != pos[1]) {
            Hud.setElementPos(Hud.HudElement.SPOTIFY_HUD, nx, ny);
         }
      }
   }

   public static int getCardW() {
      return Math.round(190.0F * getScale());
   }

   public static int getCardH() {
      return Math.round(58.0F * getScale());
   }

   private static int intOf(int base) {
      return Math.round(base * getScale());
   }

   private static float floatOf(float base) {
      return base * getScale();
   }

   private static int clampX(int x) {
      MinecraftClient mc = MinecraftClient.getInstance();
      return mc == null ? x : Math.max(0, Math.min(x, mc.getWindow().getScaledWidth() - getCardW()));
   }

   private static int clampY(int y) {
      MinecraftClient mc = MinecraftClient.getInstance();
      return mc == null ? y : Math.max(0, Math.min(y, mc.getWindow().getScaledHeight() - getCardH()));
   }

   private static int getPosX() {
      return clampX(Hud.getElementPos(Hud.HudElement.SPOTIFY_HUD)[0]);
   }

   private static int getPosY() {
      return clampY(Hud.getElementPos(Hud.HudElement.SPOTIFY_HUD)[1]);
   }

   private static void updateDragging(MinecraftClient mc) {
      if (mc != null && mc.getWindow() != null) {
         long handle = mc.getWindow().getHandle();
         boolean canDrag = mc.currentScreen instanceof ChatScreen;
         boolean mouseDown = canDrag && GLFW.glfwGetMouseButton(handle, 0) == 1;
         double[] rawX = new double[1];
         double[] rawY = new double[1];
         GLFW.glfwGetCursorPos(handle, rawX, rawY);
         double scaleX = (double)mc.getWindow().getScaledWidth() / Math.max(1, mc.getWindow().getWidth());
         double scaleY = (double)mc.getWindow().getScaledHeight() / Math.max(1, mc.getWindow().getHeight());
         double mouseX = rawX[0] * scaleX;
         double mouseY = rawY[0] * scaleY;
         int x = getPosX();
         int y = getPosY();
         if (mouseDown && !mouseWasDown && mouseX >= x && mouseX <= x + getCardW() && mouseY >= y && mouseY <= y + getCardH() && controlAt(mouseX, mouseY) < 0) {
            dragging = true;
            dragOffsetX = mouseX - x;
            dragOffsetY = mouseY - y;
         }

         if (dragging && mouseDown) {
            Hud.setElementPos(Hud.HudElement.SPOTIFY_HUD, clampX((int)Math.round(mouseX - dragOffsetX)), clampY((int)Math.round(mouseY - dragOffsetY)));
         }

         if (!mouseDown) {
            dragging = false;
         }

         mouseWasDown = mouseDown;
      }
   }

   @Override
   public void onEnable() {
      this.startBackground();
   }

   @Override
   public void onTick() {
      if (this.scheduler == null || this.scheduler.isShutdown()) {
         this.startBackground();
      }
   }

   private void startBackground() {
      if (this.scheduler == null || this.scheduler.isShutdown()) {
         this.fade = 0.0F;
         this.lastNanos = 0L;
         this.hasPolledOnce = false;
         this.fastPollCount.set(0);
         this.writeScripts();
         this.artFile = new File(System.getenv("TEMP"), "water_spotify_art.png");
         Thread t0 = new Thread(this::poll, "water-spotify-initial");
         t0.setDaemon(true);
         t0.start();
         this.scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "water-spotify");
            t.setDaemon(true);
            return t;
         });
         this.actionExec = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "water-spotify-ctrl");
            t.setDaemon(true);
            return t;
         });
         this.scheduler.scheduleAtFixedRate(() -> {
            int c = this.fastPollCount.getAndIncrement();
            if (c < 10) {
               this.poll();
               if (!this.title.isEmpty()) {
                  this.fastPollCount.set(Integer.MAX_VALUE);
               }
            }
         }, 1000L, 800L, TimeUnit.MILLISECONDS);
         this.scheduler.scheduleAtFixedRate(this::poll, 2L, 2L, TimeUnit.SECONDS);
      }
   }

   @Override
   public void onDisable() {
      if (!SpotifyLyric.active()) {
         if (this.scheduler != null) {
            this.scheduler.shutdownNow();
         }

         if (this.actionExec != null) {
            this.actionExec.shutdownNow();
         }

         this.title = "";
         this.artist = "";
         this.isPlaying = false;
         this.anchorPosMs = 0L;
         this.anchorTimeMs = 0L;
         this.durMs = 0L;
         this.fade = 0.0F;
         this.hasArt = false;
         this.waveForTitle = null;
         if (this.artTex != null) {
            try {
               MinecraftClient.getInstance().getTextureManager().destroyTexture(ART_ID);
            } catch (Exception var2) {
            }

            this.artTex = null;
         }
      }
   }

   private void writeScripts() {
      try {
         this.pollScriptFile = File.createTempFile("water_smtc_poll_", ".ps1");
         this.pollScriptFile.deleteOnExit();

         try (Writer w = new FileWriter(this.pollScriptFile, StandardCharsets.UTF_8)) {
            w.write(
               "[void][System.Reflection.Assembly]::LoadFile('C:\\Windows\\Microsoft.NET\\Framework64\\v4.0.30319\\System.Runtime.WindowsRuntime.dll')\r\n$null = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager,Windows.Media.Control,ContentType=WindowsRuntime]\r\n$g = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -like 'IAsyncOperation*' })[0]\r\nfunction Aw($op,$t){$m=$g.MakeGenericMethod($t);$task=$m.Invoke($null,@($op));$task.GetAwaiter().GetResult()}\r\n$asStreamForRead = [System.IO.WindowsRuntimeStreamExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsStreamForRead' -and $_.GetParameters().Count -eq 1 } | Select-Object -First 1\r\ntry {\r\n  $mgr = Aw([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])\r\n  $s = $mgr.GetCurrentSession()\r\n  if ($s) {\r\n    $p = Aw($s.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties])\r\n    $tl = $s.GetTimelineProperties()\r\n    $pb = $s.GetPlaybackInfo()\r\n    if ($p.Title) {\r\n      if ($p.Thumbnail -and $asStreamForRead) {\r\n        try {\r\n          $stream = Aw($p.Thumbnail.OpenReadAsync()) ([Windows.Storage.Streams.IRandomAccessStreamWithContentType])\r\n          $netStream = $asStreamForRead.Invoke($null, @($stream))\r\n          $outPath = Join-Path $env:TEMP 'water_spotify_art.png'\r\n          $fs = [System.IO.File]::Create($outPath)\r\n          $netStream.CopyTo($fs)\r\n          $fs.Close()\r\n          $netStream.Close()\r\n        } catch {}\r\n      }\r\n      Write-Output ($p.Artist + '|||' + $p.Title + '|||' + [long]$tl.Position.TotalMilliseconds + '|||' + [long]$tl.EndTime.TotalMilliseconds + '|||' + ($pb.PlaybackStatus.ToString() -eq 'Playing'))\r\n    }\r\n  }\r\n} catch {}\r\n"
            );
         }

         this.ctrlScriptFile = File.createTempFile("water_smtc_ctrl_", ".ps1");
         this.ctrlScriptFile.deleteOnExit();

         try (FileWriter var9 = new FileWriter(this.ctrlScriptFile, StandardCharsets.UTF_8)) {
            var9.write(
               "param([string]$action)\r\n[void][System.Reflection.Assembly]::LoadFile('C:\\Windows\\Microsoft.NET\\Framework64\\v4.0.30319\\System.Runtime.WindowsRuntime.dll')\r\n$null = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager,Windows.Media.Control,ContentType=WindowsRuntime]\r\n$g = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -like 'IAsyncOperation*' })[0]\r\nfunction Aw($op,$t){$m=$g.MakeGenericMethod($t);$task=$m.Invoke($null,@($op));$task.GetAwaiter().GetResult()}\r\ntry {\r\n  $mgr = Aw([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])\r\n  $s = $mgr.GetCurrentSession()\r\n  if ($s) {\r\n    switch ($action) {\r\n      'next'    { Aw($s.TrySkipNextAsync()) ([bool]) | Out-Null }\r\n      'prev'    { Aw($s.TrySkipPreviousAsync()) ([bool]) | Out-Null }\r\n      'toggle'  { Aw($s.TryTogglePlayPauseAsync()) ([bool]) | Out-Null }\r\n      'repeat'  { try { $pb2 = $s.GetPlaybackInfo(); $cur = $pb2.AutoRepeatMode; $next = if($cur -eq [Windows.Media.MediaPlaybackAutoRepeatMode]::None){'Track'} elseif($cur -eq [Windows.Media.MediaPlaybackAutoRepeatMode]::Track){'List'} else{'None'}; Aw($s.TryChangeAutoRepeatModeAsync([Windows.Media.MediaPlaybackAutoRepeatMode]::$next)) ([bool]) | Out-Null } catch {} }\r\n    }\r\n  }\r\n} catch {}\r\n"
            );
         }
      } catch (Exception var8) {
         this.pollScriptFile = null;
         this.ctrlScriptFile = null;
      }
   }

   private void poll() {
      if (this.pollScriptFile == null || !this.pollScriptFile.exists()) {
         this.writeScripts();
      }

      if (this.pollScriptFile == null) {
         this.hasPolledOnce = true;
      } else if (this.polling.compareAndSet(false, true)) {
         try {
            long beforeMs = System.currentTimeMillis();
            Process proc = new ProcessBuilder(
                  "powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", this.pollScriptFile.getAbsolutePath()
               )
               .redirectErrorStream(true)
               .start();
            boolean finished = proc.waitFor(5L, TimeUnit.SECONDS);
            if (!finished) {
               proc.destroyForcibly();
            }

            String line = null;
            BufferedReader br = new BufferedReader(new InputStreamReader(proc.getInputStream(), StandardCharsets.UTF_8));

            String l;
            try {
               while ((l = br.readLine()) != null) {
                  l = l.trim();
                  if (l.contains("|||")) {
                     line = l;
                     break;
                  }
               }
            } catch (Throwable var29) {
               try {
                  br.close();
               } catch (Throwable var28) {
                  var29.addSuppressed(var28);
               }

               throw var29;
            }

            br.close();
            long var32 = System.currentTimeMillis();
            long effMs = (beforeMs + var32) / 2L;
            if (line == null) {
               return;
            }

            String[] p = line.split("\\|\\|\\|", -1);
            if (p.length < 2 || p[1].trim().isEmpty()) {
               return;
            }

            String nt = p[1].trim();
            String na = p[0].trim();
            long np = p.length > 2 ? parseLong(p[2]) : 0L;
            long nd = p.length > 3 ? parseLong(p[3]) : 0L;
            boolean pl = p.length > 4 && p[4].trim().equalsIgnoreCase("True");
            boolean tc = !nt.equals(this.title);
            boolean sc = pl != this.isPlaying;
            long pred = this.isPlaying ? this.anchorPosMs + Math.max(0L, effMs - this.anchorTimeMs) : this.anchorPosMs;
            boolean big = Math.abs(np - pred) > 4000L;
            this.title = nt;
            this.artist = na;
            this.durMs = nd;
            this.isPlaying = pl;
            if (tc || sc || big || this.anchorTimeMs == 0L) {
               this.anchorPosMs = np;
               this.anchorTimeMs = effMs;
            }

            if (tc) {
               SpotifyQueueHud.onSongChanged(na, nt);
            }
         } catch (Exception var30) {
            return;
         } finally {
            this.hasPolledOnce = true;
            this.polling.set(false);
         }
      }
   }

   private static long parseLong(String s) {
      try {
         return Long.parseLong(s.trim());
      } catch (Exception var2) {
         return 0L;
      }
   }

   public static SpotifyHud.LyricPlayback lyricPlayback() {
      if (INSTANCE == null) {
         return new LyricPlayback("", "", false, 0L);
      } else {
         INSTANCE.startIfNeededForLyrics();
         long position = INSTANCE.anchorPosMs + (INSTANCE.isPlaying ? Math.max(0L, System.currentTimeMillis() - INSTANCE.anchorTimeMs) : 0L);
         if (INSTANCE.durMs > 0L) {
            position = Math.min(position, INSTANCE.durMs);
         }

         return new LyricPlayback(INSTANCE.title, INSTANCE.artist, INSTANCE.isPlaying, Math.max(0L, position));
      }
   }

   private void startIfNeededForLyrics() {
      if (this.scheduler == null || this.scheduler.isShutdown()) {
         this.startBackground();
      }
   }

   public static void releaseLyrics() {
      if (INSTANCE != null && !INSTANCE.isEnabled()) {
         INSTANCE.onDisable();
      }
   }

   private static float waveSeedFor(String t) {
      return t == null ? 0.0F : t.hashCode() % 1000 / 1000.0F;
   }

   public static boolean handleClick(double mouseX, double mouseY) {
      return handleClick(mouseX, mouseY, 0);
   }

   public static boolean handleClick(double mouseX, double mouseY, int button) {
      if (INSTANCE != null && INSTANCE.isEnabled()) {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc == null) {
            return false;
         } else if (HudEditor.INSTANCE.isDragging()) {
            return false;
         } else {
            int bx = getPosX();
            int by = getPosY();
            int cW = getCardW();
            int cH = getCardH();
            if (mouseX >= bx && mouseX <= bx + cW && mouseY >= by && mouseY <= by + cH) {
               int control = controlAt(mouseX, mouseY);
               if (button == 0 && control >= 0) {
                  runAction(new String[]{"prev", "toggle", "next"}[control]);
                  return true;
               } else if (button == 1) {
                  mc.setScreen(new SpotifyBrowserScreen(mc.currentScreen));
                  return true;
               } else {
                  return false;
               }
            } else {
               return false;
            }
         }
      } else {
         return false;
      }
   }

   private static boolean inside(double mouseX, double mouseY, int x, int y, int w, int h) {
      return mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h;
   }

   public static void openBrowser() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc != null) {
         mc.setScreen(new SpotifyBrowserScreen(mc.currentScreen));
      }
   }

   public static void runAction(String action) {
      if (INSTANCE != null && INSTANCE.actionExec != null && INSTANCE.ctrlScriptFile != null) {
         long nowMs = System.currentTimeMillis();
         if ("repeat".equals(action)) {
            INSTANCE.isRepeating = !INSTANCE.isRepeating;
         }

         if ("toggle".equals(action)) {
            if (INSTANCE.isPlaying) {
               INSTANCE.anchorPosMs = INSTANCE.anchorPosMs + Math.max(0L, nowMs - INSTANCE.anchorTimeMs);
               INSTANCE.anchorTimeMs = nowMs;
               INSTANCE.isPlaying = false;
            } else {
               INSTANCE.anchorTimeMs = nowMs;
               INSTANCE.isPlaying = true;
            }
         }

         INSTANCE.actionExec
            .submit(
               () -> {
                  try {
                     Process p = new ProcessBuilder(
                           "powershell",
                           "-NoProfile",
                           "-NonInteractive",
                           "-ExecutionPolicy",
                           "Bypass",
                           "-File",
                           INSTANCE.ctrlScriptFile.getAbsolutePath(),
                           action
                        )
                        .redirectErrorStream(true)
                        .start();
                     p.waitFor(5L, TimeUnit.SECONDS);
                     if (INSTANCE.scheduler != null && !INSTANCE.scheduler.isShutdown()) {
                        INSTANCE.scheduler.submit(INSTANCE::poll);
                     }
                  } catch (Exception var2) {
                  }
               }
            );
      }
   }

   private void tryLoadArt() {
      if (this.artFile != null && this.artFile.exists() && this.artFile.length() >= 200L) {
         long mod = this.artFile.lastModified();
         if (mod != this.artLastModified || this.artTex == null) {
            try {
               byte[] bytes = Files.readAllBytes(this.artFile.toPath());

               try (InputStream in = new ByteArrayInputStream(bytes)) {
                  NativeImage img = NativeImage.read(in);
                  if (this.artTex != null) {
                     try {
                        MinecraftClient.getInstance().getTextureManager().destroyTexture(ART_ID);
                     } catch (Exception var8) {
                     }
                  }

                  this.artTex = new NativeImageBackedTexture(() -> "spotify_art", img);
                  MinecraftClient.getInstance().getTextureManager().registerTexture(ART_ID, this.artTex);
                  this.artLastModified = mod;
                  this.hasArt = true;
               }
            } catch (Exception var10) {
            }
         }
      }
   }

   public static void renderHud(DrawContext ctx) {
      if (INSTANCE != null && INSTANCE.isEnabled()) {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc != null && mc.player != null) {
            if (!(mc.currentScreen instanceof UI)) {
               if (!mc.getDebugHud().shouldShowDebugHud()) {
                  updateDragging(mc);
                  long now = System.nanoTime();
                  float dt = INSTANCE.lastNanos == 0L ? 0.016F : Math.min(0.1F, (float)(now - INSTANCE.lastNanos) / 1.E9F);
                  INSTANCE.lastNanos = now;
                  INSTANCE.fade = INSTANCE.fade + (1.0F - INSTANCE.fade) * (1.0F - (float)Math.exp(-12.0F * dt));
                  float a = INSTANCE.fade;
                  if (!(a < 0.01F)) {
                     INSTANCE.tryLoadArt();
                     if (!INSTANCE.hasPolledOnce || !INSTANCE.title.isEmpty() || mc.currentScreen instanceof ChatScreen) {
                        if (!Objects.equals(INSTANCE.waveForTitle, INSTANCE.title)) {
                           INSTANCE.waveSeed = waveSeedFor(INSTANCE.title);
                           INSTANCE.waveForTitle = INSTANCE.title;
                        }

                        int bx = getPosX();
                        int by = getPosY();
                        int width = getCardW();
                        int height = getCardH();
                        float radius = floatOf(INSTANCE.roundness.getValue());
                        RenderUtil.drawRoundedRect(
                           ctx,
                           (float)(bx - intOf(2)),
                           (float)(by + intOf(1)),
                           (float)(width + intOf(4)),
                           (float)(height + intOf(3)),
                           radius + floatOf(2.0F),
                           col(0, (int)(38.0F * a)),
                           false
                        );
                        RenderUtil.drawBlur(ctx, bx, by, width, height, radius, 1.0F, false);
                        RenderUtil.drawRoundedRect(ctx, (float)bx, (float)by, (float)width, (float)height, radius, col(2169900, (int)(120.0F * a)), false);
                        RenderUtil.drawOutline(
                           ctx, (float)bx, (float)by, (float)width, (float)height, radius, floatOf(0.7F), col(16777215, (int)(65.0F * a)), false
                        );
                        RenderUtil.drawRoundedRect(
                           ctx,
                           (float)(bx + intOf(8)),
                           (float)(by + intOf(1)),
                           (float)(width - intOf(16)),
                           floatOf(0.7F),
                           floatOf(0.3F),
                           col(16777215, (int)(48.0F * a)),
                           false
                        );
                        int art = intOf(46);
                        int ax = bx + intOf(6);
                        int ay = by + intOf(6);
                        if (INSTANCE.hasArt) {
                           RenderUtil.drawTexture(ctx, (float)ax, (float)ay, (float)art, ART_ID, col(16777215, (int)(255.0F * a)), floatOf(5.0F), false);
                        } else {
                           RenderUtil.drawRoundedRect(ctx, (float)ax, (float)ay, (float)art, (float)art, floatOf(5.0F), col(5468077, (int)(155.0F * a)), false);
                           drawSpotifyIcon(ctx, ax + intOf(12), ay + intOf(12), intOf(22), a * 0.8F);
                        }

                        RenderUtil.drawOutline(
                           ctx, (float)ax, (float)ay, (float)art, (float)art, floatOf(5.0F), floatOf(0.6F), col(16777215, (int)(45.0F * a)), false
                        );
                        AwtFontRenderer font = AwtFontRenderer.INSTANCE;
                        int textX = bx + intOf(59);
                        String title = INSTANCE.title.isBlank() ? "Spotify" : INSTANCE.title;
                        String artist = INSTANCE.artist.isBlank() ? "Waiting for music" : INSTANCE.artist;
                        drawLabel(ctx, INSTANCE.isPlaying ? "now playing" : "paused", textX, by + intOf(6), 0.75F, col(16777215, (int)(150.0F * a)));
                        drawLabel(ctx, trimToWidth(title, 102, font), textX, by + intOf(17), 1.0F, col(16777215, (int)(245.0F * a)));
                        drawLabel(ctx, trimToWidth(artist, 113, font), textX, by + intOf(29), 0.9F, col(14736106, (int)(160.0F * a)));
                        long elapsed = INSTANCE.isPlaying && INSTANCE.anchorTimeMs > 0L ? Math.max(0L, System.currentTimeMillis() - INSTANCE.anchorTimeMs) : 0L;
                        long pos = Math.max(0L, INSTANCE.anchorPosMs + elapsed);
                        float progress = INSTANCE.durMs > 0L ? Math.clamp((float)pos / (float)INSTANCE.durMs, 0.0F, 1.0F) : 0.0F;
                        RenderUtil.drawRoundedRect(
                           ctx, (float)textX, (float)(by + intOf(46)), (float)intOf(101), floatOf(2.0F), floatOf(1.0F), col(16777215, (int)(35.0F * a)), false
                        );
                        if (progress > 0.0F) {
                           RenderUtil.drawRoundedRect(
                              ctx,
                              (float)textX,
                              (float)(by + intOf(46)),
                              floatOf(101.0F) * progress,
                              floatOf(2.0F),
                              floatOf(1.0F),
                              col(11640043, (int)(220.0F * a)),
                              false
                           );
                        }

                        for (int i = 0; i < 3; i++) {
                           int cx = bx + intOf(168);
                           int cy = by + intOf(5 + i * 16);
                           RenderUtil.drawRoundedRect(
                              ctx, (float)cx, (float)cy, (float)intOf(17), (float)intOf(15), floatOf(5.0F), col(16777215, (int)(18.0F * a)), false
                           );
                           Identifier icon = i == 0 ? ICON_PREV_ID : (i == 2 ? ICON_NEXT_ID : (INSTANCE.isPlaying ? ICON_PAUSE_ID : ICON_PLAY_ID));
                           drawPngIcon(ctx, icon, cx + intOf(3), cy + intOf(2), intOf(11), 16777215, a);
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private static int controlAt(double mouseX, double mouseY) {
      for (int i = 0; i < 3; i++) {
         if (inside(mouseX, mouseY, getPosX() + intOf(168), getPosY() + intOf(5 + i * 16), intOf(17), intOf(15))) {
            return i;
         }
      }

      return -1;
   }

   private static void drawLabel(DrawContext ctx, String label, int x, int y, float size, int color) {
      float factor = getScale() * size;
      ctx.getMatrices().pushMatrix();
      ctx.getMatrices().scale(factor, factor);
      AwtFontRenderer.INSTANCE.drawString(ctx, label, x / factor, y / factor, color);
      ctx.getMatrices().popMatrix();
   }

   private static void drawPngIcon(DrawContext ctx, Identifier icon, int x, int y, int size, int color, float alpha) {
      int tint = col(color, (int)(235.0F * alpha));
      RenderUtil.drawTexture(ctx, (float)x, (float)y, (float)size, icon, tint, 0.0F, false);
   }

   private static void drawSpotifyIcon(DrawContext ctx, int x, int y, int size, float alpha) {
      if (size >= 0) {
         int tint = Math.max(0, Math.min(255, (int)(alpha * 255.0F))) << 24 | 16777215;
         RenderUtil.drawTexture(ctx, (float)x, (float)y, (float)size, SPOTIFY_LOGO_ID, tint, 0.0F, false);
      } else {
         int a = (int)(alpha * 255.0F);
         RenderUtil.drawRoundedRect(ctx, (float)x, (float)y, (float)size, (float)size, size / 2.0F, col(1947988, a), false);
         RenderUtil.drawOutline(ctx, (float)x, (float)y, (float)size, (float)size, size / 2.0F, 0.8F, col(16777215, (int)(50.0F * alpha)), false);
         float pad = size * 0.18F;
         float waveH = size * 0.09F;
         float gap = size * 0.115F;
         float rr = waveH / 2.0F;
         int wc = col(16777215, a);
         float w1x = x + pad * 0.7F;
         float w1y = y + size * 0.3F;
         float w1w = size - pad * 1.4F;
         float w2x = x + pad * 1.1F;
         float w2y = w1y + waveH + gap;
         float w2w = size - pad * 2.2F;
         float w3x = x + pad * 1.55F;
         float w3y = w2y + waveH + gap;
         float w3w = size - pad * 3.1F;
         RenderUtil.drawRoundedRect(ctx, (float)((int)w1x), (float)((int)w1y), (float)((int)w1w), (float)((int)waveH), rr, wc, false);
         RenderUtil.drawRoundedRect(ctx, (float)((int)w2x), (float)((int)w2y), (float)((int)w2w), (float)((int)waveH), rr, wc, false);
         RenderUtil.drawRoundedRect(ctx, (float)((int)w3x), (float)((int)w3y), (float)((int)w3w), (float)((int)waveH), rr, wc, false);
      }
   }

   private static String trimToWidth(String text, int maxWidth, AwtFontRenderer font) {
      if (text != null && !text.isEmpty()) {
         if (font.getWidth(text) <= maxWidth) {
            return text;
         } else {
            int ellipsisW = font.getWidth("...");
            if (ellipsisW >= maxWidth) {
               return "...";
            } else {
               StringBuilder sb = new StringBuilder();
               int[] codepoints = text.codePoints().toArray();

               for (int cp : codepoints) {
                  String candidate = sb.toString() + new String(Character.toChars(cp));
                  if (font.getWidth("null...") > maxWidth) {
                     break;
                  }

                  sb.appendCodePoint(cp);
               }

               return sb.toString() + "...";
            }
         }
      } else {
         return "";
      }
   }

   private static String formatMs(long ms) {
      long s = ms / 1000L;
      return s / 60L + ":" + String.format("%02d", s % 60L);
   }

   private static int col(int rgb, int alpha) {
      return Math.max(0, Math.min(255, alpha)) << 24 | rgb & 16777215;
   }

   private static int multiplyAlpha(int color, float alphaMul) {
      int a = color >>> 24 & 0xFF;
      int nextAlpha = Math.max(0, Math.min(255, Math.round(a * alphaMul)));
      return color & 16777215 | nextAlpha << 24;
   }

   static String _cab8b213245() {
      return "T";
   }

   public final static class LyricPlayback {
      private String title;
      private String artist;
      private boolean playing;
      private long position;

      public LyricPlayback(String title, String artist, boolean playing, long position) {
         this.title = title;
         this.artist = artist;
         this.playing = playing;
         this.position = position;
      }

      public String title() {
         return this.title;
      }

      public String artist() {
         return this.artist;
      }

      public boolean playing() {
         return this.playing;
      }

      public long position() {
         return this.position;
      }
   }
}

