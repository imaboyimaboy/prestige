package com.water.mixin;

import com.water.module.modules.misc.GambleRig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({HandledScreen.class})
public abstract class GambleRigMixin {
   @Shadow
   protected Slot focusedSlot;

   @Inject(
      method = {"drawSlot"},
      at = {@At("HEAD")}
   )
   private void gambleRig$slotHead(DrawContext ctx, Slot slot, int x, int y, CallbackInfo ci) {
      GambleRig.setCurrentDrawSlotId(slot.id);
      GambleRig.tryScanIfNeeded();
   }

   @Inject(
      method = {"drawSlot"},
      at = {@At("TAIL")}
   )
   private void gambleRig$slotTail(DrawContext ctx, Slot slot, int x, int y, CallbackInfo ci) {
      GambleRig.setCurrentDrawSlotId(-1);
   }

   @Redirect(
      method = {"drawSlot"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/screen/slot/Slot;getStack()Lnet/minecraft/item/ItemStack;",
         ordinal = 0
      )
   )
   private ItemStack gambleRig$swapSlotStack(Slot slot) {
      ItemStack real = slot.getStack();
      if (!GambleRig.isFakeActive()) {
         return real;
      } else {
         if (slot.id >= 0 && slot.id <= 8) {
            if (GambleRig.isItemPlacedBack()) {
               if (real.isEmpty()) {
                  ItemStack f = GambleRig.getFillerItem();
                  if (f != null) {
                     return f.copy();
                  }
               }

               return real;
            }

            if (slot.id == GambleRig.getFakeEmptySlot()) {
               return ItemStack.EMPTY;
            }

            if (real.isEmpty()) {
               ItemStack f = GambleRig.getFillerItem();
               if (f != null) {
                  return f.copy();
               }
            }
         }

         return real;
      }
   }

   @Inject(
      method = {"onMouseClick(Lnet/minecraft/screen/slot/Slot;IILnet/minecraft/screen/slot/SlotActionType;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void gambleRig$redirectClick(Slot slot, int slotId, int button, SlotActionType action, CallbackInfo ci) {
      if (GambleRig.shouldAutoSwap() && slot != null) {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc.player != null && mc.interactionManager != null) {
            int syncId = mc.player.currentScreenHandler.syncId;
            if (slot.id == GambleRig.getFakeEmptySlot() && action == SlotActionType.PICKUP) {
               int r = GambleRig.findRealEmptySlot(mc.player.currentScreenHandler);
               if (r >= 0) {
                  ci.cancel();
                  mc.interactionManager.clickSlot(syncId, r, button, action, mc.player);
               }
            } else {
               if (slot.id >= 9 && action == SlotActionType.QUICK_MOVE && slot.hasStack()) {
                  Item dt = GambleRig.getCurrentDropperItemType();
                  if (dt != null && slot.getStack().getItem() == dt) {
                     GambleRig.setItemPlacedBack(true);
                  }
               }
            }
         }
      }
   }

   @Inject(
      method = {"drawMouseoverTooltip"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void gambleRig$tooltip(DrawContext ctx, int mx, int my, CallbackInfo ci) {
      if (GambleRig.isFakeActive() && this.focusedSlot != null) {
         if (this.focusedSlot.id >= 0 && this.focusedSlot.id <= 8) {
            if (this.focusedSlot.id == GambleRig.getFakeEmptySlot() && !GambleRig.isItemPlacedBack()) {
               ci.cancel();
               return;
            }

            if (!this.focusedSlot.hasStack() || this.focusedSlot.getStack().isEmpty()) {
               ItemStack f = GambleRig.getFillerItem();
               if (f != null) {
                  ci.cancel();
                  ctx.drawItemTooltip(MinecraftClient.getInstance().textRenderer, f, mx, my);
               }
            }
         }
      }
   }
}

