package com.water.module.modules.misc;

final class AutoMineRoute {
   private int minX;
   private int minY;
   private int minZ;
   private int maxX;
   private int maxY;
   private int maxZ;
   private int size;
   private boolean xAxis;
   private boolean forward;
   private boolean reverseCross;
   private boolean topDown;

   AutoMineRoute(int minX, int minY, int minZ, int maxX, int maxY, int maxZ, boolean xAxis, boolean forward, boolean reverseCross, boolean topDown, int size) {
      this.minX = minX;
      this.minY = minY;
      this.minZ = minZ;
      this.maxX = maxX;
      this.maxY = maxY;
      this.maxZ = maxZ;
      this.xAxis = xAxis;
      this.forward = forward;
      this.reverseCross = reverseCross;
      this.topDown = topDown;
      this.size = size;
   }

   static int remainingCentreY(int layerY) {
      return layerY + 1;
   }

   static boolean remainingStep(int fromY, int toY, int centreY) {
      int feetY = centreY - 1;
      return toY == feetY || fromY > feetY && toY < fromY && toY > feetY;
   }

   int entryX() {
      int edge = (this.xAxis ? !this.forward : this.reverseCross) ? this.maxX : this.minX;
      return Math.max(
         this.minX,
         Math.min(this.maxX, edge == this.minX ? this.minX + Math.min(1, (this.maxX - this.minX) / 2) : this.maxX - Math.min(1, (this.maxX - this.minX) / 2))
      );
   }

   int entryZ() {
      int edge = (this.xAxis ? this.reverseCross : !this.forward) ? this.maxZ : this.minZ;
      return Math.max(
         this.minZ,
         Math.min(this.maxZ, edge == this.minZ ? this.minZ + Math.min(1, (this.maxZ - this.minZ) / 2) : this.maxZ - Math.min(1, (this.maxZ - this.minZ) / 2))
      );
   }

   boolean xAxis() {
      return this.xAxis;
   }

   int band(int y) {
      return (this.topDown ? this.maxY - y : y - this.minY) / this.size;
   }

   int lane(int x, int z) {
      int cross = this.xAxis ? z : x;
      return (this.reverseCross ? (this.xAxis ? this.maxZ : this.maxX) - cross : cross - (this.xAxis ? this.minZ : this.minX)) / this.size;
   }

   int step(int x, int z) {
      boolean positive = this.forward ^ (this.lane(x, z) & 1) != 0;
      int along = this.xAxis ? x : z;
      return positive ? along - (this.xAxis ? this.minX : this.minZ) : (this.xAxis ? this.maxX : this.maxZ) - along;
   }

   private int crossCentre(int x, int z) {
      int low = this.xAxis ? this.minZ : this.minX;
      int high = this.xAxis ? this.maxZ : this.maxX;
      int start = this.reverseCross ? high - this.lane(x, z) * this.size : low + this.lane(x, z) * this.size;
      int end = this.reverseCross ? Math.max(low, start - this.size + 1) : Math.min(high, start + this.size - 1);
      return Math.floorDiv(start + end, 2);
   }

   int bandBottom(int y) {
      return this.topDown ? Math.max(this.minY, this.maxY - this.band(y) * this.size - this.size + 1) : this.minY + this.band(y) * this.size;
   }

   int centreY(int y) {
      int start = this.topDown ? this.maxY - this.band(y) * this.size : this.minY + this.band(y) * this.size;
      int end = this.topDown ? Math.max(this.minY, start - this.size + 1) : Math.min(this.maxY, start + this.size - 1);
      return Math.floorDiv(start + end, 2);
   }

   int centrePriority(int x, int y, int z) {
      int start = this.topDown ? this.maxY - this.band(y) * this.size : this.minY + this.band(y) * this.size;
      int end = this.topDown ? Math.max(this.minY, start - this.size + 1) : Math.min(this.maxY, start + this.size - 1);
      return Math.abs(y - Math.floorDiv(start + end, 2)) + Math.abs((this.xAxis ? z : x) - this.crossCentre(x, z));
   }

   boolean sameSlice(int x, int y, int z, int otherX, int otherY, int otherZ) {
      return this.band(y) == this.band(otherY) && this.lane(x, z) == this.lane(otherX, otherZ) && this.step(x, z) == this.step(otherX, otherZ);
   }

   boolean drillCentre(int x, int y, int z) {
      if (this.size == 3 && this.centrePriority(x, y, z) == 0) {
         for (int cross = -1; cross <= 1; cross++) {
            for (int vertical = -1; vertical <= 1; vertical++) {
               int px = x + (this.xAxis ? 0 : cross);
               int py = y + vertical;
               int pz = z + (this.xAxis ? cross : 0);
               if (px < this.minX
                  || px > this.maxX
                  || py < this.minY
                  || py > this.maxY
                  || pz < this.minZ
                  || pz > this.maxZ
                  || !this.sameSlice(x, y, z, px, py, pz)) {
                  return false;
               }
            }
         }

         return true;
      } else {
         return false;
      }
   }

   int turnOrder(int x, int z) {
      return (this.reverseCross ? -1 : 1) * (this.xAxis ? z : x);
   }

   private int turnAlong(int x, int z) {
      boolean positive = this.forward ^ (this.lane(x, z) & 1) != 0;
      return positive ? (this.xAxis ? this.minX : this.minZ) + 1 : (this.xAxis ? this.maxX : this.maxZ) - 1;
   }

   int turnX(int x, int z) {
      return this.xAxis ? this.turnAlong(x, z) : x;
   }

   int turnZ(int x, int z) {
      return this.xAxis ? z : this.turnAlong(x, z);
   }

   boolean turnCentre(int x, int y, int z) {
      if (this.size == 3 && this.lane(x, z) != 0 && y == this.centreY(y) && (this.xAxis ? x : z) == this.turnAlong(x, z)) {
         for (int along = -1; along <= 1; along++) {
            for (int v = -1; v <= 1; v++) {
               int px = x + (this.xAxis ? along : 0);
               int py = y + v;
               int pz = z + (this.xAxis ? 0 : along);
               if (px < this.minX
                  || px > this.maxX
                  || py < this.minY
                  || py > this.maxY
                  || pz < this.minZ
                  || pz > this.maxZ
                  || this.band(py) != this.band(y)
                  || this.lane(px, pz) != this.lane(x, z)
                  || this.step(px, pz) >= 3) {
                  return false;
               }
            }
         }

         return true;
      } else {
         return false;
      }
   }

   int turnApproachX(int x, int z) {
      return this.xAxis ? x : x + (this.reverseCross ? 2 : -2);
   }

   int turnApproachZ(int x, int z) {
      return this.xAxis ? z + (this.reverseCross ? 2 : -2) : z;
   }

   private int approachOffset(int x, int z) {
      return this.forward ^ (this.lane(x, z) & 1) != 0 ? -2 : 2;
   }

   int approachX(int x, int z) {
      return this.xAxis ? x + this.approachOffset(x, z) : this.crossCentre(x, z);
   }

   int approachZ(int x, int z) {
      return this.xAxis ? this.crossCentre(x, z) : z + this.approachOffset(x, z);
   }

   int walkX(int x, int z) {
      return this.xAxis ? x : this.crossCentre(x, z);
   }

   int walkZ(int x, int z) {
      return this.xAxis ? this.crossCentre(x, z) : z;
   }
}

