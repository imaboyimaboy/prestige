package com.water.utils;

import org.lwjgl.glfw.GLFW;

public final class KeyNameUtil {
   private KeyNameUtil() {
   }

   public static String displayName(int keyCode) {
      if (keyCode != 0 && keyCode != -1) {
         String glfwName = GLFW.glfwGetKeyName(keyCode, 0);
         if (glfwName != null && !glfwName.isBlank()) {
            return normalize(glfwName);
         } else {
            return switch (keyCode) {
               case 32 -> "Space";
               case 256 -> "Esc";
               case 257 -> "Enter";
               case 258 -> "Tab";
               case 259 -> "Backspace";
               case 260 -> "Insert";
               case 261 -> "Delete";
               case 262 -> "Right";
               case 263 -> "Left";
               case 264 -> "Down";
               case 265 -> "Up";
               case 266 -> "Page Up";
               case 267 -> "Page Down";
               case 268 -> "Home";
               case 269 -> "End";
               case 280 -> "Caps";
               case 340 -> "LShift";
               case 341 -> "LCtrl";
               case 342 -> "LAlt";
               case 344 -> "RShift";
               case 345 -> "RCtrl";
               case 346 -> "RAlt";
               default -> "Key " + keyCode;
            };
         }
      } else {
         return "None";
      }
   }

   private static String normalize(String value) {
      String trimmed = value.trim();
      String var2 = trimmed.toLowerCase();
      switch (var2.hashCode()) {
         case -1871889026:
            if (var2.equals("right shift")) {
               return "RShift";
            }
            break;
         case -1649025270:
            if (var2.equals("caps lock")) {
               return "Caps";
            }
            break;
         case -1570678363:
            if (var2.equals("right alt")) {
               return "RAlt";
            }
            break;
         case -1446321681:
            if (var2.equals("right ctrl")) {
               return "RCtrl";
            }
            break;
         case -1294172031:
            if (var2.equals("escape")) {
               return "Esc";
            }
            break;
         case -1236358588:
            if (var2.equals("left control")) {
               return "LCtrl";
            }
            break;
         case -803609140:
            if (var2.equals("page up")) {
               return "Page Up";
            }
            break;
         case -403773607:
            if (var2.equals("right control")) {
               return "RCtrl";
            }
            break;
         case 656850729:
            if (var2.equals("left shift")) {
               return "LShift";
            }
            break;
         case 825226131:
            if (var2.equals("page down")) {
               return "Page Down";
            }
            break;
         case 1683291876:
            if (var2.equals("left ctrl")) {
               return "LCtrl";
            }
            break;
         case 1716865552:
            if (var2.equals("left alt")) {
               return "LAlt";
            }
      }

      return trimmed.length() == 1 ? trimmed.toUpperCase() : trimmed;
   }
}

