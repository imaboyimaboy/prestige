package rtx.kimiko.api.mods.acountswiher.ru.vidtu.ias.config;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.function.Predicate;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.InflaterInputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rtx.kimiko.api.mods.acountswiher.ru.vidtu.ias.account.Account;

public final class IASStorage {
   private static final String DISCLAIMER = "> ENGLISH\nNotification about security of accounts stored in the \"In-Game Account Switcher\" mod:\nUNDER NO CIRCUMSTANCES SHOULD YOU SEND THIS FOLDER TO *ANYONE* (INCLUDING DEVELOPERS OF THIS MOD),\nEVEN IF IT APPEARS THAT THIS FOLDER IS FULLY EMPTY.\nIF YOU ACCIDENTALLY SENT THIS FOLDER TO ANYONE, PLEASE, VISIT THE FOLLOWING WEBSITE:\nhttps://account.microsoft.com/security\nAND CHANGE YOUR PASSWORD, THEN VISIT THE FOLLOWING WEBSITE:\nhttps://account.live.com/consent/manage\nAND REVOKE THE PERMISSIONS (ACCESS) TO THE \"In-Game Account Switcher\" APPLICATION,\nAND/OR ANY OTHER THAT YOU DO CAN'T RECOGNIZE OR YOU SUSPECT IT COULD ACCESS YOUR GAME ACCOUNT.\nAFTER REVOKING ACCESS YOU SHOULD *NOT* USE THIS MODIFICATION FOR 31 DAYS.\n(If you suspect someone has got access to your game account, revoke ALL permissions\nfor ALL applications and do *NOT* launch the game for 31 days at all)\n\n> РУССКИЙ (RUSSIAN)\nУведомление о безопасности аккаунтов из мода \"In-Game Account Switcher\":\nНИ ПРИ КАКИХ ОБСТОЯТЕЛЬСТВАХ НЕ ОТПРАВЛЯЙТЕ ЭТУ ПАПКУ *КОМУ-ЛИБО* (В ТОМ ЧИСЛЕ И РАЗРАБОТЧИКАМ ЭТОГО МОДА),\nДАЖЕ ЕСЛИ ВАМ КАЖЕТСЯ, ЧТО ЭТА ПАПКА ПОЛНОСТЬЮ ПУСТАЯ.\nЕСЛИ ВЫ СЛУЧАЙНО ОТПРАВИЛИ ЭТУ ПАПКУ КОМУ-ЛИБО, ПОЖАЛУЙСТА, ЗАЙДИТЕ НА СЛЕДУЮЩИЙ ВЕБСАЙТ:\nhttps://account.microsoft.com/security\nИ СМЕНИТЕ СВОЙ ПАРОЛЬ, ПОТОМ ЗАЙДИТЕ НА СЛЕДУЮЩИЙ ВЕБСАЙТ:\nhttps://account.live.com/consent/manage\nИ ОТЗОВИТЕ РАЗРЕШЕНИЯ (ДОСТУП) К ПРИЛОЖЕНИЮ \"In-Game Account Switcher\"\nИ/ИЛИ ЛЮБОМУ ДРУГОМУ, КОТОРОЕ ВЫ НЕ МОЖЕТЕ ОПОЗНАТЬ ИЛИ ПОДОЗРЕВАЕТЕ, ЧТО ОНО МОЖЕТ\nПОЛУЧИТЬ ДОСТУП К ВАШЕМУ ИГРОВОМУ АККАУНТУ.\nПОСЛЕ ОТЗЫВА ДОСТУПА ВЫ *НЕ* ДОЛЖНЫ ИСПОЛЬЗОВАТЬ ЭТУ МОДИФИКАЦИЮ КАК МИНИМУМ 31 ДЕНЬ.\n(Если вы подозреваете, что кто-то получил доступ к вашему игровому аккаунту, отзовите ВСЕ разрешения\nдля ВСЕХ приложений и *НЕ* запускайте игру вообще как минимум 31 день)\n";
   private static final List<String> DISCLAIMER_FILE_NAMES = List.of("READ_ME_IMPORTANT.txt", "ПРОЧТИ_МЕНЯ_ВАЖНО.txt");
   public static final Logger LOGGER = LoggerFactory.getLogger("IAS/IASStorage");
   public static final List<Account> ACCOUNTS = new ArrayList<>(0);
   public static boolean gameDisclaimerShown = false;

   private IASStorage() {
      throw new AssertionError("No instances.");
   }

   public static void load(Path path) {
      try {
         LOGGER.debug("IAS: Loading storage for {}...", path);
         Path path2 = path.resolve("_IAS_ACCOUNTS_DO_NOT_SEND_TO_ANYONE/.hidden");
         Path path3 = path2.resolve("accounts_v1.do_not_send_to_anyone");
         gameDisclaimerShown = Files.isRegularFile(path2.resolve("game_disclaimer_shown"), LinkOption.NOFOLLOW_LINKS);
         if (!Files.isRegularFile(path3, LinkOption.NOFOLLOW_LINKS)) {
            LOGGER.debug("IAS: Storage not found. Saving...");
            save(path);
         } else {
            path3 = path3.toRealPath(LinkOption.NOFOLLOW_LINKS);
            byte[] byArray = Files.readAllBytes(path3);

            try (DataInputStream dataInputStream = new DataInputStream(new InflaterInputStream(new ByteArrayInputStream(byArray)))) {
               int n = dataInputStream.readUnsignedShort();
               ArrayList<Account> arrayList = new ArrayList<>(n);

               for (int i = 0; i < n; i++) {
                  arrayList.add(Account.readTyped(dataInputStream));
               }

               ACCOUNTS.addAll(arrayList);
               HashSet hashSet = new HashSet(ACCOUNTS.size());
               ACCOUNTS.removeIf(Predicate.not(hashSet::add));
               LOGGER.debug("IAS: Loaded {} (currently: {}) accounts from {}.", new Object[]{arrayList.size(), ACCOUNTS.size(), path3});
            }
         }
      } catch (Throwable var10) {
         throw new RuntimeException("Unable to load IAS storage.", var10);
      }
   }

   public static void save(Path path) {
      try {
         LOGGER.debug("IAS: Saving storage into {}...", path);
         Path path2 = path.resolve("_IAS_ACCOUNTS_DO_NOT_SEND_TO_ANYONE/.hidden/accounts_v1.do_not_send_to_anyone");

         byte[] byArray;
         Account[] accountArray;
         try (
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            DeflaterOutputStream deflaterOutputStream = new DeflaterOutputStream(byteArrayOutputStream);
            DataOutputStream dataOutputStream = new DataOutputStream(deflaterOutputStream);
         ) {
            accountArray = ACCOUNTS.toArray(Account[]::new);
            dataOutputStream.writeShort(accountArray.length);

            for (Account account : accountArray) {
               Account.writeTyped(dataOutputStream, account);
            }

            deflaterOutputStream.finish();
            byArray = byteArrayOutputStream.toByteArray();
         }

         Files.createDirectories(path2.getParent());

         try {
            Files.setAttribute(path2.getParent(), "dos:hidden", true, LinkOption.NOFOLLOW_LINKS);
         } catch (Throwable var15) {
         }

         try {
            Files.setAttribute(path2.getParent(), "dos:system", true, LinkOption.NOFOLLOW_LINKS);
         } catch (Throwable var14) {
         }

         Files.write(
            path2,
            byArray,
            StandardOpenOption.CREATE,
            StandardOpenOption.TRUNCATE_EXISTING,
            StandardOpenOption.WRITE,
            StandardOpenOption.SYNC,
            StandardOpenOption.DSYNC,
            LinkOption.NOFOLLOW_LINKS
         );
         LOGGER.debug("IAS: Saved {} accounts to {}.", accountArray.length, path2);
      } catch (Throwable var19) {
         throw new RuntimeException("Unable to save IAS storage.", var19);
      }
   }

   public static void gameDisclaimerShown(Path path) {
      try {
         LOGGER.debug("IAS: Marking in-game disclaimers as shown into {}...", path);
         gameDisclaimerShown = true;
         Path path2 = path.resolve("_IAS_ACCOUNTS_DO_NOT_SEND_TO_ANYONE/.hidden/game_disclaimer_shown");
         Files.createDirectories(path2.getParent());
         Files.createFile(path2);
         LOGGER.debug("IAS: Marked in-game disclaimers as shown to {}.", path2);
      } catch (Throwable var2) {
         throw new RuntimeException("Unable to mark game disclaimer as shown.", var2);
      }
   }

   public static void disclaimers(Path path) {
      try {
         LOGGER.debug("IAS: Writing disclaimers into {}...", path);
         path = path.resolve("_IAS_ACCOUNTS_DO_NOT_SEND_TO_ANYONE");
         Files.createDirectories(path);
         byte[] byArray = "> ENGLISH\nNotification about security of accounts stored in the \"In-Game Account Switcher\" mod:\nUNDER NO CIRCUMSTANCES SHOULD YOU SEND THIS FOLDER TO *ANYONE* (INCLUDING DEVELOPERS OF THIS MOD),\nEVEN IF IT APPEARS THAT THIS FOLDER IS FULLY EMPTY.\nIF YOU ACCIDENTALLY SENT THIS FOLDER TO ANYONE, PLEASE, VISIT THE FOLLOWING WEBSITE:\nhttps://account.microsoft.com/security\nAND CHANGE YOUR PASSWORD, THEN VISIT THE FOLLOWING WEBSITE:\nhttps://account.live.com/consent/manage\nAND REVOKE THE PERMISSIONS (ACCESS) TO THE \"In-Game Account Switcher\" APPLICATION,\nAND/OR ANY OTHER THAT YOU DO CAN'T RECOGNIZE OR YOU SUSPECT IT COULD ACCESS YOUR GAME ACCOUNT.\nAFTER REVOKING ACCESS YOU SHOULD *NOT* USE THIS MODIFICATION FOR 31 DAYS.\n(If you suspect someone has got access to your game account, revoke ALL permissions\nfor ALL applications and do *NOT* launch the game for 31 days at all)\n\n> РУССКИЙ (RUSSIAN)\nУведомление о безопасности аккаунтов из мода \"In-Game Account Switcher\":\nНИ ПРИ КАКИХ ОБСТОЯТЕЛЬСТВАХ НЕ ОТПРАВЛЯЙТЕ ЭТУ ПАПКУ *КОМУ-ЛИБО* (В ТОМ ЧИСЛЕ И РАЗРАБОТЧИКАМ ЭТОГО МОДА),\nДАЖЕ ЕСЛИ ВАМ КАЖЕТСЯ, ЧТО ЭТА ПАПКА ПОЛНОСТЬЮ ПУСТАЯ.\nЕСЛИ ВЫ СЛУЧАЙНО ОТПРАВИЛИ ЭТУ ПАПКУ КОМУ-ЛИБО, ПОЖАЛУЙСТА, ЗАЙДИТЕ НА СЛЕДУЮЩИЙ ВЕБСАЙТ:\nhttps://account.microsoft.com/security\nИ СМЕНИТЕ СВОЙ ПАРОЛЬ, ПОТОМ ЗАЙДИТЕ НА СЛЕДУЮЩИЙ ВЕБСАЙТ:\nhttps://account.live.com/consent/manage\nИ ОТЗОВИТЕ РАЗРЕШЕНИЯ (ДОСТУП) К ПРИЛОЖЕНИЮ \"In-Game Account Switcher\"\nИ/ИЛИ ЛЮБОМУ ДРУГОМУ, КОТОРОЕ ВЫ НЕ МОЖЕТЕ ОПОЗНАТЬ ИЛИ ПОДОЗРЕВАЕТЕ, ЧТО ОНО МОЖЕТ\nПОЛУЧИТЬ ДОСТУП К ВАШЕМУ ИГРОВОМУ АККАУНТУ.\nПОСЛЕ ОТЗЫВА ДОСТУПА ВЫ *НЕ* ДОЛЖНЫ ИСПОЛЬЗОВАТЬ ЭТУ МОДИФИКАЦИЮ КАК МИНИМУМ 31 ДЕНЬ.\n(Если вы подозреваете, что кто-то получил доступ к вашему игровому аккаунту, отзовите ВСЕ разрешения\nдля ВСЕХ приложений и *НЕ* запускайте игру вообще как минимум 31 день)\n"
            .getBytes(StandardCharsets.UTF_8);

         for (String string : DISCLAIMER_FILE_NAMES) {
            try {
               Path path2 = path.resolve(string);
               if (!Files.isRegularFile(path2, LinkOption.NOFOLLOW_LINKS) || Files.size(path2) != byArray.length) {
                  Files.write(
                     path2, byArray, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE, LinkOption.NOFOLLOW_LINKS
                  );
               }
            } catch (Throwable var5) {
               if (string.equals("READ_ME_IMPORTANT.txt")) {
                  throw var5;
               }
            }
         }

         LOGGER.debug("IAS: Disclaimers ({}) written to {}.", DISCLAIMER_FILE_NAMES, path);
      } catch (Throwable var6) {
         LOGGER.error("Unable to write IAS disclaimers.", var6);
      }
   }
}

