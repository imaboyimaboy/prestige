package com.water.mixin;

import com.water.module.modules.render.DevSpawnerVisuals;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.WorldChunk;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin({WorldChunk.class})
public class WorldChunkMixin {
   @ModifyVariable(
      method = {"setBlockState"},
      at = @At("HEAD"),
      argsOnly = true,
      ordinal = 0
   )
   private BlockState water$devSpawnerChunkState(BlockState state, BlockPos pos) {
      return DevSpawnerVisuals.visualStateForPlacement(pos, state);
   }
}

