package rtx.kimiko.api.events.impl.input;

import rtx.kimiko.api.events.CancellableEvent;

public final class KeyPressEvent extends CancellableEvent {
   public int keyCode;
   public int scanCode;
   public int modifiers;
   public KeyPressEvent.Action action;

   public KeyPressEvent(int n, int n2, int n3, KeyPressEvent.Action action) {
      this.keyCode = n;
      this.scanCode = n2;
      this.modifiers = n3;
      this.action = action;
   }

   public enum Action {
      PRESS,
      RELEASE,
      REPEAT;

      public static KeyPressEvent.Action keyPressEventActionOf(int n) {
         return switch (n) {
            case 0 -> RELEASE;
            case 1 -> PRESS;
            default -> REPEAT;
         };
      }

      private static KeyPressEvent.Action[] $values() {
         return new KeyPressEvent.Action[]{PRESS, RELEASE, REPEAT};
      }
   }
}

