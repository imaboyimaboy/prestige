package com.water.module.modules.donut;

import com.water.module.Category;
import com.water.module.Module;
import com.water.setting.Setting;
import com.water.utils.RenderUtils;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import org.lwjgl.opengl.GL11;

public final class FutureDebug extends Module {
   private static final int BASE_CHEST_THRESHOLD = 10;
   private static final double CHUNK_THICKNESS = 0.1;
   private static final double RENDER_Y = 63.0;
   private static final long CELL_ANIMATION_MS = 1000L;
   private static final long CELL_STAGGER_MS = 220L;
   private static final int MARKER_SPACING_CHUNKS = 7;
   private final Setting<Integer> scanRadius = new Setting<>("Scan Radius", 1, 1, 5);
   private final Setting<Boolean> smartCheck = new Setting<>("Smart Check", true);
   private final Setting<Integer> sensitivity = new Setting<>("Sensitivity", 5, 1, 10);
   private final Setting<Color> fillColor = new Setting<>("Fill Color", new Color(180, 60, 60, 40));
   private final Setting<Integer> fillAlpha = new Setting<>("Fill Alpha", 40, 0, 255);
   private static final int[][] SHAPES = new int[][]{
      {5, 9}, {6, 3}, {6, 3}, {7, 6}, {7, 7}, {5, 5}, {6, 2}, {1, 9}, {8, 5}, {8, 8}, {10, 6}, {13, 6}, {5, 6}, {12, 9}, {7, 9}
   };
   private final Map<Long, Long> confirmedChunks = new ConcurrentHashMap<>();
   private final Set<ChunkPos> baseHits = ConcurrentHashMap.newKeySet();
   private ExecutorService scanExec;
   private final AtomicBoolean scanning = new AtomicBoolean(false);
   private int tickCount = 0;

   public FutureDebug() {
      super("FutureDebug", Category.DONUT);
      this.addSetting(this.scanRadius);
      this.addSetting(this.smartCheck);
      this.addSetting(this.sensitivity);
      this.addSetting(this.fillColor);
      this.addSetting(this.fillAlpha);
   }

   @Override
   public void onEnable() {
      this.confirmedChunks.clear();
      this.baseHits.clear();
      this.tickCount = 0;
      this.scanning.set(false);
   }

   @Override
   public void onDisable() {
      this.confirmedChunks.clear();
      this.baseHits.clear();
      if (this.scanExec != null) {
         this.scanExec.shutdownNow();
      }
   }

   private int getMinAmethyst() {
      return (int)(40.0 - (this.sensitivity.getValue() - 1) * 3.5555555555555554);
   }

   private float getMinDensity() {
      return 0.01F - (this.sensitivity.getValue() - 1) * 8.8888896E-4F;
   }

   private int getMinCalciteBasalt() {
      return (int)(15.0 - (this.sensitivity.getValue() - 1) * 1.3333333333333333);
   }

   private float getMaxAirRatio() {
      return 0.35F + (this.sensitivity.getValue() - 1) * 0.05F;
   }

   private float getMaxAvgDist() {
      return 7.0F + (this.sensitivity.getValue() - 1) * 0.5555556F;
   }

   private boolean isUnknownGeode(WorldChunk chunk) {
      ChunkSection[] sections = chunk.getSectionArray();
      int minY = chunk.getBottomY();
      int amethyst = 0;
      int calcite = 0;
      int basalt = 0;
      int airNext = 0;
      int solidNext = 0;
      int sumX = 0;
      int sumY = 0;
      int sumZ = 0;
      List<int[]> pos = new ArrayList<>();
      byte[][][] map = new byte[16][384][16];

      for (int si = 0; si < sections.length; si++) {
         int baseY = minY + si * 16;
         if (baseY <= 64 && baseY + 16 >= -64) {
            ChunkSection sec = sections[si];
            if (sec != null && !sec.isEmpty()) {
               for (int lx = 0; lx < 16; lx++) {
                  for (int ly = 0; ly < 16; ly++) {
                     int wy = baseY + ly;
                     if (wy >= -64 && wy <= 64) {
                        int my = wy + 64;
                        if (my >= 0 && my < 384) {
                           for (int lz = 0; lz < 16; lz++) {
                              BlockState bs = sec.getBlockState(lx, ly, lz);
                              if (bs.isOf(Blocks.BUDDING_AMETHYST)) {
                                 return false;
                              }

                              if (this.isCountableAmethyst(bs)) {
                                 map[lx][my][lz] = 1;
                                 amethyst++;
                                 sumX += lx;
                                 sumY += wy;
                                 sumZ += lz;
                                 pos.add(new int[]{lx, wy, lz});
                              } else if (bs.isOf(Blocks.CALCITE)) {
                                 map[lx][my][lz] = 2;
                                 calcite++;
                              } else if (bs.isOf(Blocks.SMOOTH_BASALT)) {
                                 map[lx][my][lz] = 3;
                                 basalt++;
                              } else if (!bs.isAir() && !bs.isOf(Blocks.CAVE_AIR) && !bs.isOf(Blocks.VOID_AIR)) {
                                 map[lx][my][lz] = 5;
                              } else {
                                 map[lx][my][lz] = 4;
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      if (amethyst == 0) {
         return false;
      } else if (!this.smartCheck.getValue()) {
         return amethyst >= this.getMinAmethyst();
      } else {
         int yMin = Integer.MAX_VALUE;
         int yMax = Integer.MIN_VALUE;

         for (int[] p : pos) {
            if (p[1] < yMin) {
               yMin = p[1];
            }

            if (p[1] > yMax) {
               yMax = p[1];
            }
         }

         float density = amethyst / (256.0F * Math.max(1, yMax - yMin + 1));
         float cx = (float)sumX / amethyst;
         float cy = (float)sumY / amethyst;
         float cz = (float)sumZ / amethyst;
         float avgDist = 0.0F;

         for (int[] p : pos) {
            float dx = p[0] - cx;
            float dy = p[1] - cy;
            float dz = p[2] - cz;
            avgDist += (float)Math.sqrt(dx * dx + dy * dy + dz * dz);
         }

         avgDist /= amethyst;
         int[] ndx = new int[]{1, -1, 0, 0, 0, 0};
         int[] ndy = new int[]{0, 0, 1, -1, 0, 0};
         int[] ndz = new int[]{0, 0, 0, 0, 1, -1};

         for (int[] p : pos) {
            int ax = p[0];
            int ay = p[1] + 64;
            int az = p[2];

            for (int n = 0; n < 6; n++) {
               int nx = ax + ndx[n];
               int ny = ay + ndy[n];
               int nz = az + ndz[n];
               if (nx >= 0 && nx <= 15 && ny >= 0 && ny < 384 && nz >= 0 && nz <= 15) {
                  byte nb = map[nx][ny][nz];
                  if (nb == 4) {
                     airNext++;
                  } else if (nb >= 2) {
                     solidNext++;
                  }
               }
            }
         }

         int totalN = airNext + solidNext;
         float airRatio = totalN > 0 ? (float)airNext / totalN : 0.0F;
         return amethyst >= this.getMinAmethyst()
            && density >= this.getMinDensity()
            && calcite + basalt >= this.getMinCalciteBasalt()
            && avgDist <= this.getMaxAvgDist()
            && airRatio <= this.getMaxAirRatio();
      }
   }

   private boolean isCountableAmethyst(BlockState bs) {
      return bs.isOf(Blocks.AMETHYST_CLUSTER)
         || bs.isOf(Blocks.LARGE_AMETHYST_BUD)
         || bs.isOf(Blocks.MEDIUM_AMETHYST_BUD)
         || bs.isOf(Blocks.SMALL_AMETHYST_BUD)
         || bs.isOf(Blocks.AMETHYST_BLOCK);
   }

   private boolean hasChestsBelowZero(WorldChunk chunk) {
      int count = 0;
      ChunkSection[] secs = chunk.getSectionArray();
      int minY = chunk.getBottomY();

      for (int si = 0; si < secs.length; si++) {
         int baseY = minY + si * 16;
         if (baseY >= 0) {
            break;
         }

         ChunkSection sec = secs[si];
         if (sec != null && !sec.isEmpty() && sec.hasAny(bsx -> bsx.isOf(Blocks.CHEST) || bsx.isOf(Blocks.TRAPPED_CHEST))) {
            int lyMax = Math.min(15, -baseY - 1);

            for (int lx = 0; lx < 16; lx++) {
               for (int lz = 0; lz < 16; lz++) {
                  for (int ly = 0; ly <= lyMax; ly++) {
                     BlockState bs = sec.getBlockState(lx, ly, lz);
                     if (bs.isOf(Blocks.CHEST) || bs.isOf(Blocks.TRAPPED_CHEST)) {
                        if (++count >= 10) {
                           return true;
                        }
                     }
                  }
               }
            }
         }
      }

      return false;
   }

   @Override
   public void onTick() {
      if (mc.world != null && mc.player != null) {
         ChunkPos playerChunk = mc.player.getChunkPos();
         int r = this.scanRadius.getValue() * 5;
         this.baseHits.removeIf(cpx -> Math.abs(cpx.x - playerChunk.x) <= 1 && Math.abs(cpx.z - playerChunk.z) <= 1);
         if (++this.tickCount % 5 == 0) {
            if (this.scanning.compareAndSet(false, true)) {
               if (this.scanExec == null || this.scanExec.isShutdown()) {
                  this.scanExec = Executors.newSingleThreadExecutor(t -> {
                     Thread th = new Thread(t, "futuredebug-scan");
                     th.setDaemon(true);
                     return th;
                  });
               }

               List<ChunkPos> toScan = new ArrayList<>();
               List<WorldChunk> wchunks = new ArrayList<>();

               for (int dx = -r; dx <= r; dx++) {
                  for (int dz = -r; dz <= r; dz++) {
                     ChunkPos cp = new ChunkPos(playerChunk.x + dx, playerChunk.z + dz);
                     WorldChunk wc = mc.world.getChunkManager().getWorldChunk(cp.x, cp.z, false);
                     if (wc != null && !wc.isEmpty()) {
                        toScan.add(cp);
                        wchunks.add(wc);
                     }
                  }
               }

               long now = System.currentTimeMillis();
               this.scanExec.submit(() -> {
                  try {
                     for (int i = 0; i < toScan.size(); i++) {
                        ChunkPos cpx = toScan.get(i);
                        WorldChunk wcx = wchunks.get(i);
                        long key = cpx.toLong();
                        if (!this.confirmedChunks.containsKey(key) && this.canAddMarker(cpx) && this.isUnknownGeode(wcx)) {
                           this.confirmedChunks.put(key, now);
                        }

                        if (this.hasChestsBelowZero(wcx)) {
                           this.baseHits.add(cpx);
                        }
                     }
                  } catch (Exception var13) {
                  } finally {
                     this.scanning.set(false);
                  }
               });
            }
         }
      }
   }

   @Override
   public void onRender(MatrixStack matrices, float tickDelta) {
      if (mc.world != null && mc.player != null) {
         if (!this.confirmedChunks.isEmpty() || !this.baseHits.isEmpty()) {
            Camera cam = RenderUtils.getCamera();
            if (cam != null) {
               Vec3d camPos = cam.getCameraPos();
               Color base = this.fillColor.getValue();
               long renderNow = System.currentTimeMillis();
               double y1 = 63.0 - camPos.y;
               double y2 = 63.1 - camPos.y;
               matrices.push();
               GL11.glDisable(2929);
               RenderUtils.WorldBatch batch = RenderUtils.beginWorldBatch(matrices);

               for (long key : this.confirmedChunks.keySet()) {
                  int gx = ChunkPos.getPackedX(key);
                  int gz = ChunkPos.getPackedZ(key);
                  long h = key * -7046029254386353131L;
                  h ^= h >>> 32;
                  int[] shape = SHAPES[Math.floorMod(h, SHAPES.length)];
                  int w = shape[0];
                  int l = shape[1];
                  int offX = -((w - 1) / 2);
                  int offZ = -((l - 1) / 2);

                  for (int dx = 0; dx < w; dx++) {
                     for (int dz = 0; dz < l; dz++) {
                        int cx2 = gx + offX + dx;
                        int cz2 = gz + offZ + dz;
                        int cellIndex = dx + dz * w;
                        float progress = Math.min(1.0F, Math.max(0.0F, (float)(renderNow - this.confirmedChunks.get(key) - cellIndex * 220L) / 1000.0F));
                        if (!(progress <= 0.0F)) {
                           float eased = 1.0F - (float)Math.pow(1.0F - progress, 3.0);
                           double size = 16.0 * (0.04 + 0.96 * eased);
                           double centerX = (cx2 << 4) + 8.0 - camPos.x;
                           double centerZ = (cz2 << 4) + 8.0 - camPos.z;
                           double half = size * 0.5;
                           Color animatedFill = new Color(
                              base.getRed(),
                              base.getGreen(),
                              base.getBlue(),
                              Math.max(0, Math.min(255, Math.round(this.fillAlpha.getValue().intValue() * eased)))
                           );
                           batch.renderFilledBox(centerX - half, y1, centerZ - half, centerX + half, y2, centerZ + half, animatedFill);
                        }
                     }
                  }
               }

               batch.flush();
               GL11.glEnable(2929);
               matrices.pop();
            }
         }
      }
   }

   private boolean canAddMarker(ChunkPos candidate) {
      for (long existing : this.confirmedChunks.keySet()) {
         int existingX = ChunkPos.getPackedX(existing);
         int existingZ = ChunkPos.getPackedZ(existing);
         if (Math.abs(existingX - candidate.x) <= 7 && Math.abs(existingZ - candidate.z) <= 7) {
            return false;
         }
      }

      return true;
   }
}

