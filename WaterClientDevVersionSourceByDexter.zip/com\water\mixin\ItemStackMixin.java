package com.water.mixin;

import com.water.module.modules.misc.GambleRig;
import com.water.module.modules.render.DevSpawnerVisuals;
import java.util.function.Consumer;
import net.minecraft.component.type.TooltipDisplayComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item.TooltipContext;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({ItemStack.class})
public class ItemStackMixin {
   @Inject(
      method = {"getName"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void water$selectedBlockNameAsSpawner(CallbackInfoReturnable<Text> cir) {
      if (DevSpawnerVisuals.shouldSpoofInventory((ItemStack)(Object)this)) {
         cir.setReturnValue(Text.literal("Spawner").formatted(Formatting.LIGHT_PURPLE));
      } else {
         ItemStack self = (ItemStack)(Object)this;
         if (GambleRig.shouldRenameItem(self)) {
            cir.setReturnValue(GambleRig.getRenamedText(self));
         }
      }
   }

   @Inject(
      method = {"appendTooltip"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void water$selectedBlockSpawnerTooltip(
      TooltipContext context, TooltipDisplayComponent displayComponent, PlayerEntity player, TooltipType type, Consumer<Text> textConsumer, CallbackInfo ci
   ) {
      if (DevSpawnerVisuals.shouldSpoofInventory((ItemStack)(Object)this)) {
         textConsumer.accept(Text.literal("Skeleton").formatted(Formatting.YELLOW));
         textConsumer.accept(Text.empty());
         textConsumer.accept(Text.literal("Interact with Spawn Egg:").formatted(Formatting.GRAY));
         textConsumer.accept(Text.literal("Sets Mob Type").formatted(Formatting.BLUE));
         ci.cancel();
      }
   }
}

