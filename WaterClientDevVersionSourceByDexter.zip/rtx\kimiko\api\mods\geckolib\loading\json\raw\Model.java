package rtx.kimiko.api.mods.geckolib.loading.json.raw;

import com.google.gson.JsonDeserializer;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import net.minecraft.util.JsonHelper;
import rtx.kimiko.api.mods.geckolib.util.JsonUtil;

public final class Model {
   private String formatVersion;
   private MinecraftGeometry[] minecraftGeometry;

   public Model(String formatVersion, MinecraftGeometry[] minecraftGeometry) {
      this.formatVersion = formatVersion;
      this.minecraftGeometry = minecraftGeometry;
   }

   public static JsonDeserializer<Model> deserializer() throws JsonParseException {
      return (jsonElement, type, jsonDeserializationContext) -> {
         JsonObject jsonObject = jsonElement.getAsJsonObject();
         String string = jsonObject.get("format_version").getAsString();
         MinecraftGeometry[] minecraftGeometryArray = JsonUtil.jsonArrayToObjectArray(
            JsonHelper.getArray(jsonObject, "minecraft:geometry", null), jsonDeserializationContext, MinecraftGeometry.class
         );
         if (minecraftGeometryArray == null) {
            minecraftGeometryArray = new MinecraftGeometry[0];
         }

         return new Model(string, minecraftGeometryArray);
      };
   }

   public String formatVersion() {
      return this.formatVersion;
   }

   public MinecraftGeometry[] minecraftGeometry() {
      return this.minecraftGeometry;
   }
}

